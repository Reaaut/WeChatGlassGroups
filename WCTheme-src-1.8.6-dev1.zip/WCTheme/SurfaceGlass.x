#import <UIKit/UIKit.h>

#import "WCSurfaceGlass.h"
#import "WCLayout.h"

// 表面级 hook 只挂 UIKit 通用类，不猜微信私有类名：
// - UITableViewCell.layoutSubviews：布局微调 + 液态卡片（只对已标记列表生效）
// - UINavigationBar / UITabBar.layoutSubviews：插模糊 + 高光描边
// - UIViewController.preferredStatusBarStyle：布局模块的状态栏样式
// 微信宿主类（首页 / 聊天页 / 搜索栏）的锚点 hook 在 src/WCAnchors.mm 里做运行时校验后安装。

%hook UITableViewCell

- (void)layoutSubviews {
    %orig;

    @try {
        WCLayoutApplyToCell(self);
    } @catch (NSException *exception) {
    }

    @try {
        WCSurfaceCardApplyToCell(self);
    } @catch (NSException *exception) {
    }
}

%end

%hook UINavigationBar

- (void)layoutSubviews {
    %orig;

    @try {
        WCLayoutApplyToNavBar(self);
    } @catch (NSException *exception) {
    }

    @try {
        WCSurfaceGlassApplyToNavBar(self);
    } @catch (NSException *exception) {
    }
}

%end

%hook UITabBar

- (void)layoutSubviews {
    %orig;

    @try {
        WCLayoutApplyToTabBar(self);
    } @catch (NSException *exception) {
    }

    @try {
        WCSurfaceGlassApplyToTabBar(self);
    } @catch (NSException *exception) {
    }
}

%end

%hook UIViewController

- (UIStatusBarStyle)preferredStatusBarStyle {
    UIStatusBarStyle original = %orig;
    @try {
        return WCLayoutPreferredStatusBarStyle(original);
    } @catch (NSException *exception) {
        return original;
    }
}

%end
