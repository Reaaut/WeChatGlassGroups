#import <UIKit/UIKit.h>

#import "WCSettingsEntry.h"

// 微信内设置入口：
// - viewDidAppear: 每次页面出现时记录类名（诊断用，每个类只记一次），
//   并在候选「我」页控制器上插入一行入口；
// - 悬浮齿轮入口由 WCSettingsEntryStart 通过窗口通知挂载，不依赖任何微信私有类。
// 类名不命中时全部静默，不影响微信本身。

%hook UIViewController

- (void)viewDidAppear:(BOOL)animated {
    %orig;

    @try {
        WCSettingsEntryHandleViewControllerAppear(self);
    } @catch (NSException *exception) {
    }
}

%end
