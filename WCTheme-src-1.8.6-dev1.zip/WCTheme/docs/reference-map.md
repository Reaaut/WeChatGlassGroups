# WCGlass 4.1.6 行为地图（只取公开字符串，不复制代码）

来源：`WCGlass_4.1.6-2_banfix.deb` 里的 `WCGlass.dylib`（strip 过、类名随机化、含 `WLGSEAL2` 段）。
方法：扫描 `__cstring` / `__objc_methname` / `__objc_classname` 的可打印字符串，按前缀归类。
**限制**：数值型默认值存在代码常量里，字符串里看不到；下表的数值是"键名语义推断"，不是抄来的值。
本文件仅作开发参考，不含任何反编译代码。

## 1. 模块划分（按键名前缀）

| 前缀 | 覆盖范围 | 典型键 |
| --- | --- | --- |
| `wclg_simulated_glass_*` | iOS 16 上的"模拟玻璃"层 | `material`, `material_light`, `material_dark`, `material_blur` |
| `wclg_liquid_display_style` / `wclg_force_liquid_glass_disabled` | 液态玻璃总风格开关 | `liquid_display_style` |
| `wclg_contacts_liquid_*` | 通讯录/列表液态卡片 | `liquid_color`, `liquid_corner`, `liquid_gap`, `independent_liquid` |
| `wclg_me_liquid_card` / `wclg_me_profile_card_*` | 「我」页卡片 | `corner_radius`, `inset`, `height`, `offset_x`, `offset_y` |
| `wclg_home_func_card_*` | 首页功能卡片 | `corner_radius`, `border_width`, `inset`, `top_gap`, `bottom_gap` |
| `wclg_free_tabbar_*` / `wclg_morphing_tabbar_*` / `wclg_segmented_capsule_tabbar_*` | 底栏玻璃/胶囊/悬浮 | `frosted_border_width`, `horizontal_inset`, `height`, `capsule_spacing` |
| `wclg_chat_*_frosted_*` / `wclg_chat_free_input_*` | 输入栏磨砂 | `frosted_material_mode`, `frosted_border_width`, `radius` |
| `wclg_bubble_*` / `wclg_chat_bubble_*` | 气泡 | `corner_radius`, `line_width`, `separator_width` |
| `wclg_chat_fade_*` / `wclg_home_fade_*` | 边缘渐隐+模糊 | `fade_blur_radius`, `fade_inset`, `fade_min_height` |
| `wclg_ins_*` / `wclg_me_profile_*` | 首页/我页排版 | `native_layout_style`, `card_*` |

## 2. 视觉参数（可直接落地的）

| 参数 | 参考键名 | 采用值 | 依据 |
| --- | --- | --- | --- |
| 卡片圆角 | `wclg_contacts_liquid_corner` / `wclg_home_func_card_corner_radius` / `wclg_me_profile_card_corner_radius` | 14 pt | 键名语义 + iOS 16 视觉经验，落在 12–16 区间 |
| 卡片水平内缩 | `wclg_me_profile_card_inset` / `wclg_home_func_card_inset` / `wclg_free_list_bg_left_inset` | 12 pt | 同上 |
| 卡片上下间距 | `wclg_contacts_liquid_gap` / `wclg_home_func_card_bottom_gap` | 6 pt | 同上 |
| 描边宽度 | `wclg_simulated_chat_capsule_border_width` / `wclg_free_tabbar_frosted_border_width` | 1 px（`1/scale`） | 键名语义 |
| 玻璃白色 tint | `wclg_simulated_glass_material_light` | 0.06–0.12 | 命名"light material"，配合 `material_blur` 的白化层 |
| 模糊强度 | `wclg_simulated_glass_material_blur` | SystemMaterial / Thin / UltraThin 三档 | iOS 16 无自定义半径，用系统材质枚举等价映射 |
| 阴影 | `wclgSuppressSimulatedShadow` / `wclgManagedCornerRadius` | opacity 0.08、radius 8、offset (0,3) | 键名说明它们自己也在"托管/抑制阴影"，说明重绘是真实成本，必须给开关 |

## 3. 宿主类映射（全部来自 `__objc_classname`，运行时必须 `objc_getClass` 校验）

| 宿主类 | 用途 | 我们用在哪 |
| --- | --- | --- |
| `NewMainFrameViewController` | 微信首页 | 页面背景模糊 + 标记首页列表 |
| `MainFrameTableView` | 首页会话列表 | 透明化 + 背后插模糊层 |
| `NewMainFrameCell` / `MainFrameItemView` / `MainFrameCellData` | 首页 cell 与内容 | 卡片化命中判断（cell 父级为已标记 table） |
| `BaseMsgContentViewController` | 聊天页 | 页面背景模糊 + 聊天列表标记 |
| `WCSearchViewController` | 搜索页 | 页面背景处理 |
| `WCSearchBar` | 搜索栏 | 圆角 + 模糊 + 描边 |
| `FTSHomeViewController` / `FTSBaseViewController` | 搜索首页 | 预留锚点（1.2.0 只做存在性校验） |
| `MMTListAdapter` / `MMServiceCenter` / `MMNewSessionMgr` | 列表适配 / 服务 / 会话 | 预留锚点（不 hook 数据层） |

补充：我们 1.1.2 的运行时日志里额外出现 `MMUIHookView`（搜索胶囊容器），参考包里没有该字符串，属于微信宿主类，一并作为锚点。

## 4. 结构上的启发（不是代码）

- 它们把玻璃拆成"surface"对象（`WCLGFreeBlurSurface`、`WCLGFreeFrostedBackground`、`WCLGFreeTabBarFrostedLens`、`WCLGExpandingGlassEffect`），按表面挂载，而不是全局刷底色 —— 与 1.2.0 的按表面处理方向一致。
- `wclgSuppressSimulatedShadow` + `wclgManagedCornerRadius` 说明它们缓存并托管圆角/阴影参数（对应我们的"性能优先"开关）。
- `wclg_*_light` / `_dark` 成对出现，说明 tint 与描边在深/浅色模式下是两套值；1.2.0 先只做浅色，深色留作后续。
