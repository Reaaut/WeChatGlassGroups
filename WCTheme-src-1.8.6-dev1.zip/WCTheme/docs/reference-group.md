# WCGlass 4.1.6 分组实现拆解（只取证据）

分析样本：`WCGlass_4.1.6-2_banfix.deb`
dylib：`/var/jb/Library/MobileSubstrate/DynamicLibraries/WCGlass.dylib`（约 61 MB，fat 双切片 arm64/arm64e）
手段：`strings` 式提取 `__objc_methname` / `__objc_classname` / `__ustring`，按关键词聚类。
限制：类名随机化前缀（大量 `_TtC7WCGlass…` Swift mangled name）、`WLGSEAL2` 加密段、符号已 strip —— **没有源码可抄**，以下严格区分「证据」与「推断」。

---

## 1. 结论先写

WCGlass 的分组是 **「改原生会话数据源 + 复用原生 cell」**，不是纯叠加层。三条硬证据：

1. 直接调用微信会话管理器方法：
   - `hideSessionOfUsernames:`
   - `DeleteSessionOfUsernames:`
   - `ChangeSessionUnReadCount:to:`
   - `getSessionCount` / `getSessionCountForSection:`
2. 直接操作原生顺序数组与「折叠占位会话」：
   - `m_frontSessionArray`
   - `@placeholder_foldgroup`（伪会话名，插入原生列表当作折叠组行）
3. 直接对原生表做增量更新：
   - `insertRowsAtIndexPaths:withRowAnimation:`
   - `deleteRowsAtIndexPaths:withRowAnimation:`
   - `beginUpdates` / `endUpdates`
   - `reloadSections:withRowAnimation:`

同时它 **复用原生 cell**，而不是自绘：
- `MainFrameCellData` / `NewMainFrameCell`
- `updateWithCellData:`
- `m_itemView` / `m_frameHeadView` / `m_nameLabel` / `m_unreadCountView`
- `WCLGListCollectNativeRow`（把原生 cell 的视图拿来当自定义行）

即：**数据源层负责“哪些会话出现在列表、以什么顺序/分组出现”，渲染层复用原生 cell。**“收纳/侧栏”等模式再额外套一层自绘卡片。

置信度：
- 「调用了 hideSession / placeholder / insert-deleteRows」= 高（符号成组出现，且是分组折叠必需的语义）。
- 「hook 了 `numberOfSectionsInTableView:` / `cellForRowAtIndexPath:`」= 中。这些 selector 在字符串里存在，但二进制里所有用到 UITableView 的类都会带，无法仅凭 strings 确认是 hook 还是自用（它的设置页/收纳列表也是 UITableView）。因此不把它当作“已证实的 hook 点”。

---

## 2. 分组配置键（可复用的命名体系）

### 2.1 总开关与模式
| 键 | 语义（推断） |
| --- | --- |
| `WCLGHomeGroupsEnabled` | 首页分组总开关 |
| `WCLGHomeGroupsQQMode` | QQ 式折叠（原生列表内折叠组） |
| `WCLGHomeGroupsSideMode` | 横排侧栏模式 |
| `WCLGHomeGroupsTGMode` | TG 式（分组会话页） |
| `WCLGHomeGroupsChatMode` | 会话内分组 |
| `WCLGHomeGroupsListCollectMode` | 收纳卡片模式（自绘列表） |
| `WCLGHomeGroupsDidChangeNotification` | 分组变化通知 |
| `WCLGHomeGroupsChatSelectionDidChangeNotification` | 当前选中分组变化 |
| `WCLGHomeGroupsVisualStyleDidChangeNotification` | 外观参数变化 |

### 2.2 数据模型
| 键 | 语义（推断） |
| --- | --- |
| `WCLGHomeGroupsList` | 分组数组，元素是字典 |
| `groupID` | 分组唯一 id |
| `displayIndex` | 组内显示顺序 |
| `members` | 组成员（userName 数组） |
| `rule` | 匹配规则（自定义组） |
| `suffix` | 分组行标题后缀（配合 `setGroupOverride:groupID:suffix:`） |
| `WCLGHomeGroupsUngroupedMembers` | 未分组会话 |
| `WCLGHomeGroupsUngroupedGap` | 未分组与分组之间的间距 |
| `WCLGHomeGroupsCurrentID` | 当前展开/选中的组 |
| `WCLGHomeGroupsAllTitle` / `AllIndex` / `HideAll` | “全部”组的标题/索引/隐藏 |
| `WCLGHomeGroupsSeededDefaults` | 是否已写入默认分组 |

### 2.3 内置过滤（对应“置顶/好友/群聊”自动分类）
| 键 | 语义（推断） |
| --- | --- |
| `WCLGHomeGroupsFilterPinned` | 置顶会话是否从分组里排除 |
| `WCLGHomeGroupsFilterPinnedFromDefaultGroups` | 置顶是否从默认组排除 |
| `WCLGHomeGroupsFilterContacts` | 过滤单聊 |
| `WCLGHomeGroupsFilterChatrooms` | 过滤群聊 |
| `WCLGHomeGroupsHideAll` | 隐藏“全部”组 |
| `WCLGListCollectHideUnreadGroup` / `HideEmptyGroups` | 收纳模式隐藏未读组/空组 |

### 2.4 渲染参数（只列与结构相关的）
`WCLGHomeGroupsQQGap`、`QQVerticalOffset`、`QQWidth`、`QQBadgePosition`、`QQMemberCountPosition`、`QQTitleCentered`、`QQHideArrow`、`QQMultiExpand`、`QQDefaultExpand`、`QQDefaultExpandedIDs`、`AccordionCornerRadius`、`PillGap`、`PillHorizontalInset`、`PillGlassStyle`、`PillGlassStrength`、`BarVerticalOffset`、`ShowBadge`、`FilterPinned` …
（颜色类键都成对出现 `*ColorMode` / `*ColorDarkMode`，说明它区分浅色/深色两套。）

---

## 3. 宿主选择器 / 字段清单（可直接复用）

### 3.1 会话数据（对 `MainFrameCellData` / `m_sessionInfo` 取值）
```
m_nsUsrName        m_nsUserName      m_nsUsername     m_nsRealUsrName
usrName            username          userName         m_nsFromUsr
m_nsToUsr          m_nsRealChatUsr
```
置顶 / sticky（布尔）：
```
m_bTop  m_bIsTop  m_bIsStickyOnTop  m_bStickyOnTop  m_bIsSticky
m_bIsOnTop  m_bOnTop  isTop  isStickyTop  isStickyOnTop  stickyOnTop  isSticky
```
> 另有 `m_bMakeTopCell`：证据显示它出现在 cell 数据附近，但语义更像“cell 处于置顶区域”的布局标记。**本轮不使用**，否则首屏 cell 会被整体判成置顶（就是 1.7.0 只剩「置顶 10」的根因之一）。

### 3.2 会话管理器方法
```
getSessionCount
getSessionCountForSection:
hideSessionOfUsernames:
DeleteSessionOfUsernames:
ChangeSessionUnReadCount:to:
m_frontSessionArray
```

### 3.3 原生 cell 复用
```
MainFrameCellData / NewMainFrameCell
updateWithCellData:
m_itemView  m_frameHeadView  m_nameLabel  m_unreadCountView
```
头像相关：`avatarForEntry:side:`、`placeAvatarForRow:frame:border:`（证据说明它自己摆头像视图，而不是仅依赖 cell 布局）。

### 3.4 伪会话
```
@placeholder_foldgroup
```
用途推断：把一个伪 userName 插进 `m_frontSessionArray`，原生列表就会多出一行“折叠组”；组内真实会话通过 `hideSessionOfUsernames:` 从原生列表隐藏，展开时再放回。

---

## 4. 中文 UI 串（证明它的分组是“手动分组”，不是自动分类）

从 `__ustring` 提取到的相关文案：
```
新建分组 / 删除分组 / 重命名分组 / 分组名称 / 给分组起个名字
加入分组 / 移出分组 / 添加到大分组 / 添加到小分组 / 移出此分组
不进入分组 / 分组上显示 / 显示所有分组 / 隐藏没有会话的分组
大分组 / 小分组 / 常规分组 / 横排分组 / 收纳分组 / 列表收纳分组
叠放分组卡片 / 收起分组 / 展开分组 / 收起全部分组
分组人数文字 / 分组未读角标 / 未读列表与分组间距
```
只有 `好友 / 群聊`、`未命名群聊`、`服务号`、`授权联系公众号` 这几条是系统会话类型相关；**没有**「置顶 / 好友 / 群聊 / 服务号 / 公众号 / 其他」这种固定六组。

结论：WCGlass 的分组主体是 **用户手工维护的 members 列表**（大组/小组/规则），系统分类只作为过滤条件（`FilterPinned` / `FilterContacts` / `FilterChatrooms`）。

---

## 5. 与我们当前方案的对比

| 维度 | 数据源方案（WCGlass） | 叠加层方案（WCTheme 1.6.4/1.7.0） |
| --- | --- | --- |
| 侵入性 | 高：改会话数组、隐藏会话、插伪会话、增量改表 | 低：只隐藏原生表 + 同区域盖一层自绘面板 |
| 稳定性 | 依赖 `hideSessionOfUsernames:` / `m_frontSessionArray` 等私有实现，微信升级即碎 | 只依赖 UITableView + UILabel 文本，升级风险低 |
| 点击进聊天 | 原生行天然可点 | 需要拿真实 indexPath 调原生 delegate（1.7.0 已实现） |
| 头像 | 原生 cell 自带 | 从原生 cell 的 HeadImageView 截图（1.7.0 已实现） |
| 滚动/动画 | 原生 | 自绘，跟随性一般 |
| 实现成本 | 高（要处理 insert/delete、未读、@、置顶、搜索联动） | 低（已在 1.7.0 中完成） |

### 本轮取舍
1. **保留叠加层**：1.7.0 已把“采集不全 / 分组不准 / 点击不进聊天 / 头像占位”四个核心问题在叠加层内解决，不再引入数据源改造的回归风险。
2. **借用它的数据字典**：`userName` 候选字段、sticky 字段、系统号名单（见 §3.1）已经落到 `WCGroup.mm`，这是本轮分组准确率的关键。
3. **记录后续可做的数据源增强**（若将来要“真·折叠”）：
   - 用 `hideSessionOfUsernames:` + `@placeholder_foldgroup` 把组行塞进原生列表；
   - 用 `insertRowsAtIndexPaths:` / `deleteRowsAtIndexPaths:` 做展开收起动画；
   - 只 hook `MMNewSessionMgr` 的数据出口，不 hook 表视图；
   - 必须先做“hide 名单恢复”兜底，否则微信升级后会出现会话消失。

---

## 6. 无法确证的点

1. 是否真的 hook 了 `numberOfSectionsInTableView:` / `tableView:numberOfRowsInSection:` / `tableView:cellForRowAtIndexPath:` —— strings 只能证明这些 selector 在二进制里，无法证明挂在 `MainFrameTableView` 上。
2. `@placeholder_foldgroup` 具体插在 `m_frontSessionArray` 的哪个位置、如何与置顶行排序，未知。
3. `rule` 的匹配语法（正则 / 子串 / 通配）未知，只能确认存在这个键。
4. 479 个随机化前缀与 `WLGSEAL2` 段内的逻辑无法还原。
