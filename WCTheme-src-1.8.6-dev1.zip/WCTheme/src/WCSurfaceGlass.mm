#import "WCSurfaceGlass.h"
#import "WCPrefs.h"
#import "WCLog.h"
#import "WCDock.h"
#import "WCBadge.h"
#import "WCWallpaper.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

// 由本模块挂载的所有模糊视图共用一个 tag，便于幂等复用与整体移除。
static const NSInteger WCSurfaceBlurTag = 0x57435331; // 'WCS1'
static const void *WCTableMarkKey = &WCTableMarkKey;

static BOOL gActive = NO;      // 总开关 + 毛玻璃开关
static BOOL gCards = NO;       // 液态卡片
static BOOL gDockWanted = NO;  // 底栏浮岛是否启用（启用时不要还原原生底栏）
static BOOL gPerfFirst = NO;   // 性能优先（关闭阴影）
static BOOL gLite = NO;        // 轻量版（关闭阴影 / 多层描边）
static double gIntensity = 0.35;
static NSInteger gStyle = 0;
static double gCardCorner = 14.0;
static double gCardInset = 12.0;

static NSMutableSet<NSString *> *gLoggedNames = nil;

static void WCSurfaceLogOnce(NSString *kind, NSString *name) {
    if (name.length == 0) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gLoggedNames = [NSMutableSet set];
    });
    if (gLoggedNames.count >= 60) return;
    if ([gLoggedNames containsObject:name]) return;
    [gLoggedNames addObject:name];
    WCLogLine(@"info", @"surface", @"%@ %@", kind, name);
}

static UIBlurEffectStyle WCSurfaceEffectStyle(void) {
    switch (gStyle) {
        case 1:
            return UIBlurEffectStyleSystemThinMaterial;
        case 2:
            return UIBlurEffectStyleSystemUltraThinMaterial;
        default:
            return UIBlurEffectStyleSystemMaterial;
    }
}

/// 白色 tint：滑块值就是 alpha 本身，限制在 0.04 ~ 0.16。
static CGFloat WCSurfaceTintAlpha(void) {
    double value = gIntensity;
    if (value < 0.04) value = 0.04;
    if (value > 0.16) value = 0.16;
    return (CGFloat)value;
}

static CGFloat WCSurfaceHairline(void) {
    CGFloat scale = [UIScreen mainScreen].scale;
    if (scale <= 0) scale = 2.0;
    return 1.0 / scale;
}

#pragma mark - 模糊视图

@interface WCSurfaceBlurView : UIVisualEffectView
@property (nonatomic, strong) UIView *tintView;
@property (nonatomic, strong) UIView *topLine;
@property (nonatomic, strong) UIView *bottomLine;
@end

@implementation WCSurfaceBlurView

- (instancetype)initWithBlurStyle:(UIBlurEffectStyle)style
                             tint:(CGFloat)tint
                          topLine:(BOOL)topLine
                       bottomLine:(BOOL)bottomLine {
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:style];
    self = [super initWithEffect:effect];
    if (!self) return nil;

    self.userInteractionEnabled = NO;
    self.clipsToBounds = YES;

    _tintView = [[UIView alloc] initWithFrame:self.bounds];
    _tintView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:tint];
    _tintView.userInteractionEnabled = NO;
    _tintView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.contentView addSubview:_tintView];

    CGFloat hair = WCSurfaceHairline();
    if (topLine) {
        _topLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, hair)];
        _topLine.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.34];
        _topLine.userInteractionEnabled = NO;
        _topLine.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [self.contentView addSubview:_topLine];
    }
    if (bottomLine) {
        _bottomLine = [[UIView alloc] initWithFrame:
                       CGRectMake(0, MAX(0, self.bounds.size.height - hair),
                                  self.bounds.size.width, hair)];
        _bottomLine.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.22];
        _bottomLine.userInteractionEnabled = NO;
        _bottomLine.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
        [self.contentView addSubview:_bottomLine];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat hair = WCSurfaceHairline();
    self.tintView.frame = self.bounds;
    self.topLine.frame = CGRectMake(0, 0, self.bounds.size.width, hair);
    self.bottomLine.frame = CGRectMake(0, MAX(0, self.bounds.size.height - hair),
                                       self.bounds.size.width, hair);
}

@end

#pragma mark - 挂载 / 移除

/// 在 host 的第 0 层挂一个模糊视图；已存在则只更新 frame。
static UIView *WCSurfaceAttachBlur(UIView *host, BOOL topLine, BOOL bottomLine, NSString *kind) {
    if (!host) return nil;

    UIView *existing = [host viewWithTag:WCSurfaceBlurTag];
    if (existing) {
        if (!CGRectEqualToRect(existing.frame, host.bounds)) {
            existing.frame = host.bounds;
        }
        return existing;
    }

    @try {
        WCSurfaceBlurView *blur = [[WCSurfaceBlurView alloc] initWithBlurStyle:WCSurfaceEffectStyle()
                                                                        tint:WCSurfaceTintAlpha()
                                                                     topLine:(topLine && !gLite)
                                                                  bottomLine:(bottomLine && !gLite)];
        if (!blur) return nil;
        blur.tag = WCSurfaceBlurTag;
        blur.frame = host.bounds;
        blur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [host insertSubview:blur atIndex:0];
        WCLogLine(@"info", @"surface", @"attach %@（%@）alpha=%.2f style=%ld",
                  NSStringFromClass([host class]), kind, WCSurfaceTintAlpha(), (long)gStyle);
        return blur;
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"surface", @"attach 失败 %@：%@",
                  NSStringFromClass([host class]), exception.reason);
        return nil;
    }
}

static void WCSurfaceRemoveTagged(UIView *view) {
    if (!view) return;
    NSArray<UIView *> *children = [view.subviews copy];
    for (UIView *child in children) {
        if (child.tag == WCSurfaceBlurTag) {
            [child removeFromSuperview];
        } else {
            WCSurfaceRemoveTagged(child);
        }
    }
}

#pragma mark - 标记列表

/// 向上最多 6 层找到被标记的列表；标记值是"标记原因"（通常是控制器类名）。
static UITableView *WCMarkedTableForView(UIView *view) {
    UIView *current = view;
    for (NSUInteger depth = 0; depth < 6 && current; depth++) {
        if (objc_getAssociatedObject(current, WCTableMarkKey)) {
            return [current isKindOfClass:[UITableView class]] ? (UITableView *)current : nil;
        }
        current = current.superview;
    }
    return nil;
}

static BOOL WCViewIsMarkedTable(UIView *view) {
    return WCMarkedTableForView(view) != nil;
}

static NSString *WCTableMarkReason(UIView *view) {
    id value = objc_getAssociatedObject(view, WCTableMarkKey);
    return [value isKindOfClass:[NSString class]] ? (NSString *)value : nil;
}

/// 聊天页列表：不做卡片化。微信原生气泡本身就成型，套卡片只会变成灰方块。
static BOOL WCTableIsChatList(NSString *reason) {
    if (reason.length == 0) return NO;
    return ([reason rangeOfString:@"MsgContent"].location != NSNotFound ||
            [reason rangeOfString:@"Chat"].location != NSNotFound);
}

static UIColor *WCSurfacePaperColor(UIView *view) {
    UITraitCollection *trait = view.traitCollection ?: UITraitCollection.currentTraitCollection;
    return trait.userInterfaceStyle == UIUserInterfaceStyleDark ? [UIColor blackColor]
                                                                : [UIColor whiteColor];
}

static void WCMarkTable(UITableView *table, NSString *reason) {
    if (!table) return;
    objc_setAssociatedObject(table, WCTableMarkKey, reason ?: @"",
                             OBJC_ASSOCIATION_COPY_NONATOMIC);
    // 1.7.3：聊天页保持透明（气泡自带底色）；其余列表统一纯白/纯黑，
    // 否则首页会露出原生浅灰底，形成「页面灰 + 行白卡」的拼贴感。
    // 1.8.0：有壁纸时一律 clear，绝不允许这里把壁纸盖成白底。
    table.backgroundColor = (WCWallpaperActive() || WCTableIsChatList(reason))
        ? [UIColor clearColor] : WCSurfacePaperColor(table);
    WCSurfaceLogOnce(@"标记列表", [NSString stringWithFormat:@"%@（%@）",
                                   NSStringFromClass([table class]), reason ?: @"-"]);
}

static UITableView *WCFirstTableViewInView(UIView *root) {
    if (!root) return nil;

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 300;
    while (queue.count && budget > 0) {
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        budget -= 1;

        if ([view isKindOfClass:[UITableView class]]) {
            return (UITableView *)view;
        }
        for (UIView *sub in view.subviews) {
            [queue addObject:sub];
        }
    }
    return nil;
}

#pragma mark - 表面

static BOOL gSurfaceNavApplying = NO;
static BOOL gSurfaceSearchApplying = NO;
static BOOL gSurfaceNavPending = NO;
static BOOL gSurfaceSearchPending = NO;

static void WCSurfaceGlassApplyToNavBarNow(UINavigationBar *bar);
static void WCSurfaceGlassApplyToSearchHostNow(UIView *host);

/// 1.5.1：绝不在 layoutSubviews 调用栈里改视图树。
/// 布局回调只负责排队，真正插入/改属性在下一个 runloop turn 执行。
void WCSurfaceGlassApplyToNavBar(UINavigationBar *bar) {
    if (!bar || !gActive) return;
    if (gSurfaceNavPending) return;
    gSurfaceNavPending = YES;
    __weak UINavigationBar *weakBar = bar;
    dispatch_async(dispatch_get_main_queue(), ^{
        gSurfaceNavPending = NO;
        WCSurfaceGlassApplyToNavBarNow(weakBar);
    });
}

static void WCSurfaceGlassApplyToNavBarNow(UINavigationBar *bar) {
    if (!bar || !gActive || gSurfaceNavApplying) return;
    // 1.8.2：壁纸模式下顶栏必须真透明。这里挂的白色 tint（alpha≈0.13）
    // 就是真机上顶栏发灰的来源，壁纸模式直接跳过并清掉旧玻璃。
    if (WCWallpaperActive()) {
        WCSurfaceRemoveTagged(bar);
        for (UIView *sub in bar.subviews) {
            if ([NSStringFromClass([sub class]).lowercaseString
                 rangeOfString:@"background"].location != NSNotFound) {
                WCSurfaceRemoveTagged(sub);
            }
        }
        WCSurfaceLogOnce(@"导航栏跳过", @"wallpaper");
        return;
    }
    gSurfaceNavApplying = YES;
    @try {

    // UIKit 导航栏的实际背景在 _UIBarBackground 这类子视图里；
    // 找不到就用 bar 本身（模糊仍然可见，只是会被内容覆盖一点点）。
    UIView *host = bar;
    for (UIView *sub in bar.subviews) {
        NSString *name = NSStringFromClass([sub class]).lowercaseString;
        if ([name rangeOfString:@"background"].location != NSNotFound) {
            host = sub;
            break;
        }
    }

    if (host != bar) {
        host.backgroundColor = [UIColor clearColor];
    }
    WCSurfaceAttachBlur(host, YES, YES, @"导航栏");
    } @finally {
        gSurfaceNavApplying = NO;
    }
}

void WCSurfaceGlassApplyToTabBar(UITabBar *bar) {
    if (!bar) return;
    // 底栏有自己的开关，不依赖毛玻璃总开关。
    WCDockApplyToTabBar(bar);
}

/// 同上：搜索栏 / 容器也改为下一个 runloop turn 再处理。
void WCSurfaceGlassApplyToSearchHost(UIView *host) {
    if (!host || !gActive) return;
    if (gSurfaceSearchPending) return;
    gSurfaceSearchPending = YES;
    __weak UIView *weakHost = host;
    dispatch_async(dispatch_get_main_queue(), ^{
        gSurfaceSearchPending = NO;
        WCSurfaceGlassApplyToSearchHostNow(weakHost);
    });
}

static void WCSurfaceGlassApplyToSearchHostNow(UIView *host);
static UIView *WCFirstSearchHostInView(UIView *root);

static UITextField *WCSurfaceSearchField(UISearchBar *bar) {
    if (![bar isKindOfClass:[UISearchBar class]]) return nil;
    @try {
        UITextField *field = bar.searchTextField;
        if ([field isKindOfClass:[UITextField class]]) return field;
    } @catch (NSException *exception) {
    }
    @try {
        id value = [bar valueForKey:@"_searchField"];
        if ([value isKindOfClass:[UITextField class]]) return (UITextField *)value;
    } @catch (NSException *exception) {
    }
    return nil;
}

static void WCSurfaceGlassApplyToSearchHostNow(UIView *host) {
    if (!host || !gActive || gSurfaceSearchApplying) return;
    gSurfaceSearchApplying = YES;
    @try {
        UISearchBar *bar = nil;
        if ([host isKindOfClass:[UISearchBar class]]) {
            bar = (UISearchBar *)host;
        } else {
            UIView *found = WCFirstSearchHostInView(host);
            if ([found isKindOfClass:[UISearchBar class]]) bar = (UISearchBar *)found;
        }

        if (!bar) {
            host.backgroundColor = [UIColor clearColor];
            WCSurfaceLogOnce(@"搜索栏", [NSString stringWithFormat:@"%@ 非 UISearchBar（仅清底色）",
                                        NSStringFromClass([host class])]);
            return;
        }

        // 1.6.1：整条 bar 的白底来自 _UISearchBarBackground / barTintColor，
        // 只改外层 cornerRadius 会得到"整条白色大胶囊"（1.6.0 的 h=52 radius=26 就是这么来的）。
        // 这里把 bar 自己的圆角撤掉，几何一律不动，只把背景变通透、输入框变半透明白。
        bar.layer.cornerRadius = 0.0;
        bar.layer.masksToBounds = NO;
        bar.clipsToBounds = NO;

        bar.barTintColor = [UIColor clearColor];
        bar.backgroundColor = [UIColor clearColor];
        bar.backgroundImage = [[UIImage alloc] init];

        for (UIView *sub in bar.subviews) {
            NSString *name = NSStringFromClass([sub class]).lowercaseString;
            if ([name containsString:@"searchbarbackground"]) {
                sub.hidden = YES;
                sub.backgroundColor = [UIColor clearColor];
            }
        }

        UITextField *field = WCSurfaceSearchField(bar);
        CGFloat fieldHeight = field.bounds.size.height;
        if (fieldHeight > 8.0) {
            field.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.55];
            field.layer.cornerRadius = fieldHeight / 2.0;
            field.layer.cornerCurve = kCACornerCurveContinuous;
            field.layer.masksToBounds = YES;
        }

        WCSurfaceLogOnce(@"搜索栏", [NSString stringWithFormat:@"%@ 通透 h=%.1f fieldH=%.1f",
                                     NSStringFromClass([bar class]),
                                     bar.bounds.size.height, fieldHeight]);
    } @finally {
        gSurfaceSearchApplying = NO;
    }
}

// 1.6.0：不再自建标题。微信首页本来就有一个原生大标题，再叠一个 26pt label
// 会出现两个「微信」。导航栏只做背景透明 + 模糊，标题完全交给微信原生渲染。

/// 在页面里找一次搜索栏（微信的 WCSearchBar 或系统 UISearchBar）。
static UIView *WCFirstSearchHostInView(UIView *root) {
    if (!root) return nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 300;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UISearchBar class]]) return view;
        if ([NSStringFromClass([view class]) isEqualToString:@"WCSearchBar"]) return view;
        [queue addObjectsFromArray:view.subviews];
    }
    return nil;
}

void WCSurfaceGlassHandleController(UIViewController *controller) {
    if (!controller) return;
    // 1.6.0：只要「表面模糊」或「卡片」任一模块开启才处理。
    if (!gActive && !gCards) return;

    UIView *view = controller.view;
    if (!view) return;

    NSString *name = NSStringFromClass([controller class]);
    WCSurfaceLogOnce(@"页面", name);

    // 1.6.3：聊天页只做最小处理（导航栏透明 + 输入栏玻璃）。
    // 不铺整页背景模糊、不做卡片、不遍历视图树 —— 这是聊天页黑屏/卡顿的根因路径。
    if ([name containsString:@"BaseMsgContent"]) {
        CFAbsoluteTime started = CFAbsoluteTimeGetCurrent();
        if (gActive) {
            UINavigationBar *navBar = controller.navigationController.navigationBar;
            if (navBar) WCSurfaceGlassApplyToNavBar(navBar);
        }
        double ms = (CFAbsoluteTimeGetCurrent() - started) * 1000.0;
        if (ms > 100.0) {
            WCLogLine(@"warn", @"perf", @"enter chat ms=%.1f（超 100ms）", ms);
        } else {
            WCLogLine(@"info", @"perf", @"enter chat ms=%.1f（最小处理）", ms);
        }
        return;
    }

    UITableView *table = WCFirstTableViewInView(view);
    if (table) {
        WCMarkTable(table, name);
    }

    // 只有首页在列表背后挂一层模糊。聊天页 / 搜索页保持微信原生底色，
    // 不再给整页铺模糊——那正是上一版聊天页"灰底"的来源。
    if ([name rangeOfString:@"MainFrame"].location != NSNotFound) {
        if (gActive) {
            // 1.7.3：首页改为不透明纯白/纯黑，不再挂背景模糊（那是灰底的来源之一）。
            // 1.8.0：有壁纸时根视图转 clear，壁纸图（insertSubview:atIndex:0）才能透出来。
            view.backgroundColor = WCWallpaperActive() ? [UIColor clearColor]
                                                       : WCSurfacePaperColor(view);
            UINavigationBar *bar = controller.navigationController.navigationBar;
            if (bar) WCSurfaceGlassApplyToNavBar(bar);
            UIView *search = WCFirstSearchHostInView(view);
            if (search) WCSurfaceGlassApplyToSearchHost(search);
        }
    }
}

void WCSurfaceGlassHandleMainTable(UIView *table) {
    if (!table || !gActive) return;

    WCMarkTable((UITableView *)table, @"MainFrameTableView");
    // 背景模糊挂在首页根视图上（见 WCSurfaceGlassHandleController），
    // 这里不再按列表父视图重复挂，避免同一页面出现多层模糊。
}

#pragma mark - 聊天页：只做轻微修饰，保留原生结构

static const void *WCMessagePolishedKey = &WCMessagePolishedKey;

/// 消息 cell 只统一图片圆角（6pt），不加描边/阴影，不改气泡形状与间距。
/// 每个 cell 只处理一次，避免滚动时反复遍历子视图。
static void WCSurfacePolishMessageCell(UITableViewCell *cell) {
    if (!cell || !gCards) return;
    if (objc_getAssociatedObject(cell, WCMessagePolishedKey)) return;
    objc_setAssociatedObject(cell, WCMessagePolishedKey, @YES,
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:cell.contentView];
    NSUInteger budget = 48;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        for (UIView *sub in view.subviews) {
            [queue addObject:sub];
        }
        if (![view isKindOfClass:[UIImageView class]]) continue;

        CGSize size = view.bounds.size;
        // 只处理缩略图/大图；头像本来就小，不碰。
        if (size.width < 36.0 || size.height < 36.0) continue;
        view.layer.cornerRadius = 6.0;
        view.layer.cornerCurve = kCACornerCurveContinuous;
        view.layer.masksToBounds = YES;
    }
    WCSurfaceLogOnce(@"聊天", NSStringFromClass([cell class]));
}

#pragma mark - 卡片

void WCSurfaceCardApplyToCell(UITableViewCell *cell) {
    if (!cell) return;

    // 角标改色独立于卡片：只要 cell 布局就把红点刷成当前颜色。
    WCBadgeApplyToView(cell.contentView);

    if (!gCards) return;

    UITableView *table = WCMarkedTableForView(cell.superview ?: cell);
    if (!table) return;

    if (WCTableIsChatList(WCTableMarkReason(table))) {
        WCSurfacePolishMessageCell(cell);
        return;
    }

    UIView *content = cell.contentView;
    if (!content) return;

    @try {
        CGFloat radius = (CGFloat)gCardCorner;
        if (radius < 8.0) radius = 8.0;
        if (radius > 20.0) radius = 20.0;

        content.layer.cornerRadius = radius;
        content.layer.cornerCurve = kCACornerCurveContinuous;
        content.layer.masksToBounds = YES;
        content.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.72];
        cell.backgroundColor = [UIColor clearColor];

        CGFloat inset = (CGFloat)gCardInset;
        if (inset < 0) inset = 0;
        if (inset > 24) inset = 24;

        CGRect bounds = cell.bounds;
        CGRect frame = content.frame;
        frame.origin.x = inset;
        frame.origin.y = 3.0;
        frame.size.width = MAX(0.0, bounds.size.width - inset * 2.0);
        frame.size.height = MAX(0.0, bounds.size.height - 6.0);
        content.frame = frame;

        if (gPerfFirst || gLite) {
            // 性能优先：不画阴影，只保留圆角与半透明卡片。
            cell.layer.shadowOpacity = 0.0;
            cell.layer.shadowPath = NULL;
            cell.layer.shadowRadius = 0.0;
        } else {
            cell.layer.shadowColor = [UIColor blackColor].CGColor;
            cell.layer.shadowOpacity = 0.08;
            cell.layer.shadowRadius = 8.0;
            cell.layer.shadowOffset = CGSizeMake(0, 3);
            cell.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:content.frame
                                                               cornerRadius:radius].CGPath;
        }

        WCSurfaceLogOnce(@"卡片", NSStringFromClass([cell class]));
        WCBadgeApplyToView(cell.contentView);
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"surface", @"卡片失败 %@：%@",
                  NSStringFromClass([cell class]), exception.reason);
    }
}

#pragma mark - 刷新 / 生命周期

static void WCSurfaceRefreshTree(UIView *view, NSUInteger *budget) {
    if (!view || *budget == 0) return;
    *budget -= 1;

    if ([view isKindOfClass:[UINavigationBar class]]) {
        WCSurfaceGlassApplyToNavBar((UINavigationBar *)view);
    } else if ([view isKindOfClass:[UITabBar class]]) {
        WCSurfaceGlassApplyToTabBar((UITabBar *)view);
    } else if ([view isKindOfClass:[UITableView class]] && WCViewIsMarkedTable(view)) {
        NSString *reason = WCTableMarkReason(view) ?: @"refresh";
        // 1.6.3：聊天列表在刷新时整段跳过，避免滚动/刷新时反复遍历大量气泡 cell。
        if ([reason containsString:@"Chat"]) return;
        WCMarkTable((UITableView *)view, reason);
    } else {
        NSString *name = NSStringFromClass([view class]);
        if ([name isEqualToString:@"WCSearchBar"] || [name isEqualToString:@"MMUIHookView"]) {
            WCSurfaceGlassApplyToSearchHost(view);
        }
    }

    for (UIView *sub in view.subviews) {
        WCSurfaceRefreshTree(sub, budget);
    }
}

static void WCSurfaceRestoreChrome(UIView *view, NSUInteger *budget) {
    if (!view || *budget == 0) return;
    *budget -= 1;

    // 底栏有自己的开关：浮岛启用时这里不能把原生底栏还原，否则会来回打架。
    if ([view isKindOfClass:[UITabBar class]] && !gDockWanted) {
        WCDockRestore((UITabBar *)view);
    }

    for (UIView *sub in view.subviews) {
        WCSurfaceRestoreChrome(sub, budget);
    }
}

// 1.6.3：偏好变更通知往往连发多条，合并成一次全窗口刷新（0.35s 去抖），
// 避免进聊天页时 RemoveTagged + 2000 节点遍历连续跑十几遍造成卡顿。
static BOOL gSurfaceRefreshPending = NO;

void WCSurfaceGlassRefresh(void) {
    WCPrefs *prefs = [WCPrefs shared];
    // 1.5.1：模块总闸 + 子开关双保险。默认全关，只留 core。
    gActive = prefs.enabled && prefs.moduleGlass && prefs.glassEnabled;
    gCards = prefs.enabled && prefs.moduleLayout && prefs.cardEnabled;
    gDockWanted = prefs.enabled && prefs.moduleDock && prefs.dockEnabled;
    gPerfFirst = prefs.performanceFirst;
    gLite = prefs.liteMode;
    gIntensity = prefs.glassIntensity;
    gStyle = prefs.glassStyle;
    gCardCorner = prefs.cardCornerRadius;
    gCardInset = prefs.cardInset;

    if (gSurfaceRefreshPending) return;
    gSurfaceRefreshPending = YES;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        gSurfaceRefreshPending = NO;
        WCLogLine(@"info", @"surface", @"refresh active=%d card=%d perf=%d intensity=%.2f style=%ld",
                  gActive, gCards, gPerfFirst, gIntensity, (long)gStyle);

        if (!gActive) {
            NSArray<UIWindow *> *windows = [[UIApplication sharedApplication].windows copy];
            for (UIWindow *window in windows) {
                WCSurfaceRemoveTagged(window);
                NSUInteger budget = 2000;
                WCSurfaceRestoreChrome(window, &budget);
            }
            return;
        }

        NSUInteger budget = 2000;
        NSArray<UIWindow *> *windows = [[UIApplication sharedApplication].windows copy];
        for (UIWindow *window in windows) {
            // 材质 / 强度变化后重建模糊层，避免沿用旧的 tint 与描边。
            WCSurfaceRemoveTagged(window);
            WCSurfaceRefreshTree(window, &budget);
        }
    });
}

void WCSurfaceGlassRemoveAll(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSArray<UIWindow *> *windows = [[UIApplication sharedApplication].windows copy];
        for (UIWindow *window in windows) {
            WCSurfaceRemoveTagged(window);
        }
    });
}

#pragma mark - 1.8.4 液态玻璃共用配方

static const NSInteger WCLiquidBackdropTag = 0x574C4701; // 'WLG1'
static const NSInteger WCLiquidTintTag = 0x574C4702;
static const NSInteger WCLiquidSheenTag = 0x574C4703;
static NSString *gLiquidLogSignature = nil;

void WCApplyLiquidGlass(UIView *view, CGFloat corner, WCLiquidGlassStyle style, BOOL topOnly) {
    if (!view) return;

    BOOL panel = (style == WCLiquidGlassStylePanel);
    BOOL nativeBlur = [view isKindOfClass:[UIVisualEffectView class]];
    UIView *target = nativeBlur ? ((UIVisualEffectView *)view).contentView : view;

    // 幂等：先摘掉上一轮加的分层，避免反复调用叠出灰。
    for (NSNumber *tag in @[@(WCLiquidBackdropTag), @(WCLiquidTintTag), @(WCLiquidSheenTag)]) {
        [[target viewWithTag:tag.integerValue] removeFromSuperview];
    }

    BOOL dark = NO;
    if (@available(iOS 13.0, *)) {
        dark = (view.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark);
    }

    // 1) backdrop 模糊：面板 / 组行才加；底栏已有原生模糊底，不叠加第二层。
    NSString *blurName = @"native";
    if (!nativeBlur) {
        UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterial];
        UIVisualEffectView *backdrop = [[UIVisualEffectView alloc] initWithEffect:effect];
        backdrop.tag = WCLiquidBackdropTag;
        backdrop.frame = target.bounds;
        backdrop.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        backdrop.userInteractionEnabled = NO;
        backdrop.alpha = panel ? 0.55 : 0.62;
        backdrop.layer.cornerRadius = corner;
        backdrop.layer.masksToBounds = YES;
        [target insertSubview:backdrop atIndex:0];
        blurName = @"ultraThin";
    }

    // 2) tint：只有面板补 tint（比底栏轻一档，避免整块发灰）。
    //    底栏浮岛 / 头像胶囊自带 contentView tint（updateGlassForRadius），再叠一层会把
    //    1.8.3 已确认的观感打亮成灰，所以 dock 分支不叠 tint / sheen，只做参数归一。
    CGFloat tint = panel ? 0.045 : (dark ? 0.06 : 0.14);
    if (panel) {
        UIView *tintView = [[UIView alloc] initWithFrame:target.bounds];
        tintView.tag = WCLiquidTintTag;
        tintView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        tintView.userInteractionEnabled = NO;
        tintView.backgroundColor = dark ? [UIColor colorWithWhite:0.0 alpha:tint]
                                        : [UIColor colorWithWhite:1.0 alpha:tint];
        [target addSubview:tintView];

        // 3) sheen：顶部高光渐变（只给面板，底栏保留原生观感）。
        UIView *sheen = [[UIView alloc] initWithFrame:target.bounds];
        sheen.tag = WCLiquidSheenTag;
        sheen.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        sheen.userInteractionEnabled = NO;
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.frame = sheen.bounds;
        gradient.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:0.10].CGColor,
                            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor];
        gradient.startPoint = CGPointMake(0.5, 0.0);
        gradient.endPoint = CGPointMake(0.5, 0.55);
        [sheen.layer addSublayer:gradient];
        [target addSubview:sheen];
    }

    // 4) 描边 / 羽化：面板用极细高光边 + 很轻外阴影；底栏保留 1.8.3 的原生 1px 边。
    CGFloat hairline = 1.0 / MAX([UIScreen mainScreen].scale, 1.0);
    if (panel) {
        view.layer.borderWidth = hairline;
        view.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:(dark ? 0.18 : 0.30)].CGColor;
    }
    if (!nativeBlur) {
        view.layer.cornerRadius = corner;
        view.layer.masksToBounds = NO;   // 剪裁交给 backdrop 自己，外层阴影才能透出来
    }
    if (topOnly) {
        if (@available(iOS 11.0, *)) {
            view.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
        }
    }
    if (panel) {
        view.layer.shadowColor = [UIColor blackColor].CGColor;
        view.layer.shadowOpacity = 0.035;
        view.layer.shadowRadius = 6.0;
        view.layer.shadowOffset = CGSizeMake(0.0, 2.0);
        view.layer.shadowPath = nil;   // 交给系统按 bounds 渲染，避免外扩成灰边
    }

    // 5) 只在参数变化时打一条，证明底栏 / 面板走的是同一套配方。
    NSString *signature = [NSString stringWithFormat:@"%d#%.1f#%@#%.2f#%d#%d#%d",
                           (int)style, corner, blurName, tint, panel ? 1 : 0,
                           topOnly ? 1 : 0, dark ? 1 : 0];
    if (![signature isEqualToString:(gLiquidLogSignature ?: @"")]) {
        gLiquidLogSignature = [signature copy];
        WCLogLine(@"info", @"glass", @"配方 使用=%@ corner=%.1f blur=%@ tint=%.2f sheen=%d feather=%d",
                  panel ? @"panel" : @"dock", corner, blurName, tint, panel ? 1 : 0, panel ? 1 : 0);
    }
}

void WCSurfaceGlassStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        NSOperationQueue *mainQueue = [NSOperationQueue mainQueue];

        [center addObserverForName:UIWindowDidBecomeKeyNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            WCSurfaceGlassRefresh();
                        }];

        [center addObserverForName:UIApplicationDidBecomeActiveNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            WCSurfaceGlassRefresh();
                        }];
    });
}
