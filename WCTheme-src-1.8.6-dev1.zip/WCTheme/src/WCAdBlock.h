#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, WCHookReturnKind) {
    WCHookReturnVoid = 0,
    WCHookReturnBool = 1,
};

typedef void (^WCAdBlockHandler)(id target);

/// 一条可插拔 hook：类名、方法名、sel 类型（实例/类方法）、返回值类型、处理 block。
/// 只支持“无参数”方法（除 self/_cmd 外没有别的参数），
/// 这样能安全地用 imp_implementationWithBlock 包一层，不会破坏 ABI。
@interface WCHookEntry : NSObject

@property (nonatomic, copy, readonly) NSString *className;
@property (nonatomic, copy, readonly) NSString *selectorName;
@property (nonatomic, assign, readonly) WCHookReturnKind returnKind;
@property (nonatomic, assign, readonly) BOOL classMethod;
@property (nonatomic, copy, readonly) WCAdBlockHandler handler;

+ (instancetype)entryWithClass:(NSString *)className
                        selector:(NSString *)selectorName
                    returnKind:(WCHookReturnKind)returnKind
                     classMethod:(BOOL)classMethod
                       handler:(WCAdBlockHandler)handler;

@end

// 供 .x（ObjC）与 .mm（ObjC++）共同调用，固定 C linkage。
#ifdef __cplusplus
extern "C" {
#endif

/// 把一条 hook 追加到注册表；进程内重复调用不会重复安装同一个 Method。
void WCAdBlockRegisterHook(WCHookEntry *entry);

/// 安装默认表 + 运行时注册表。启动时调用一次；内部对每个目标做
/// objc_getClass / class_getInstanceMethod / respondsToSelector / 参数个数 /
/// 返回值编码 的校验，任何一项不满足就 NSLog 后跳过。
void WCAdBlockInstallAll(void);

/// 1.0 版本的默认表：故意留空。
/// 微信类名必须通过 WCDiscovery 在真机抓取确认后再加，见 README。
NSArray<WCHookEntry *> *WCAdBlockDefaultHooks(void);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
