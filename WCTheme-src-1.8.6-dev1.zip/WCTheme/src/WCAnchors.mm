#import "WCAnchors.h"
#import "WCLog.h"
#import "WCSurfaceGlass.h"
#import "WCGroup.h"
#import "WCDock.h"
#import "WCWallpaper.h"

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

typedef struct {
    const char *name;
    const char *purpose;
} WCAnchorEntry;

// 名称全部来自参考包的 __objc_classname（微信宿主类），外加运行时日志里确认的 MMUIHookView。
static const WCAnchorEntry kWCAnchors[] = {
    {"NewMainFrameViewController", "微信首页"},
    {"MainFrameTableView", "首页会话列表"},
    {"NewMainFrameCell", "首页会话 cell"},
    {"MainFrameItemView", "首页 cell 内容"},
    {"MainFrameCellData", "首页 cell 数据"},
    {"MainFrameLogicController", "首页逻辑"},
    {"BaseMsgContentViewController", "聊天页"},
    {"WCSearchViewController", "搜索页"},
    {"WCSearchBar", "搜索栏"},
    {"FTSHomeViewController", "搜索首页"},
    {"FTSBaseViewController", "搜索基类"},
    {"MMTListAdapter", "列表适配器"},
    {"MMServiceCenter", "服务容器"},
    {"MMNewSessionMgr", "会话管理"},
    {"MMUIHookView", "搜索胶囊容器"},
};

static NSObject *WCAnchorLock(void) {
    static NSObject *lock;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        lock = [[NSObject alloc] init];
    });
    return lock;
}

static NSMutableDictionary<NSString *, id> *WCAnchorCache(void) {
    static NSMutableDictionary<NSString *, id> *cache;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        cache = [NSMutableDictionary dictionary];
    });
    return cache;
}

Class WCAnchorClass(NSString *name) {
    if (name.length == 0) return Nil;

    @synchronized (WCAnchorLock()) {
        id cached = WCAnchorCache()[name];
        if (cached) {
            if ([cached isKindOfClass:[NSNull class]]) return Nil;
            return (Class)cached;
        }

        Class cls = objc_getClass(name.UTF8String);
        WCAnchorCache()[name] = cls ? (id)cls : (id)[NSNull null];
        WCLogLine(@"anchor", @"anchor", @"%@ %@", cls ? @"OK  " : @"SKIP", name);
        return cls;
    }
}

BOOL WCAnchorExists(NSString *name) {
    return WCAnchorClass(name) != Nil;
}

void WCAnchorLogAll(void) {
    @autoreleasepool {
        NSUInteger total = sizeof(kWCAnchors) / sizeof(kWCAnchors[0]);
        NSUInteger hit = 0;
        NSMutableArray<NSString *> *missing = [NSMutableArray array];

        for (NSUInteger i = 0; i < total; i++) {
            Class cls = WCAnchorClass([NSString stringWithUTF8String:kWCAnchors[i].name]);
            if (cls) {
                hit += 1;
            } else {
                [missing addObject:[NSString stringWithUTF8String:kWCAnchors[i].name]];
            }
        }

        WCLogLine(@"anchor", @"anchor", @"锚点命中 %lu/%lu%@",
                  (unsigned long)hit, (unsigned long)total,
                  missing.count ? [NSString stringWithFormat:@"，缺失：%@",
                                   [missing componentsJoinedByString:@","]] : @"");
    }
}

#pragma mark - hook 安装

static IMP WCHookInstanceMethod(NSString *clsName, NSString *selName, IMP replacement) {
    Class cls = WCAnchorClass(clsName);
    if (!cls) {
        WCLogLine(@"anchor", @"hook", @"SKIP %@.%@（类不存在）", clsName, selName);
        return NULL;
    }

    SEL sel = NSSelectorFromString(selName);
    Method method = (sel != NULL) ? class_getInstanceMethod(cls, sel) : NULL;
    if (!method) {
        WCLogLine(@"anchor", @"hook", @"SKIP %@.%@（方法不存在）", clsName, selName);
        return NULL;
    }

    IMP original = method_getImplementation(method);
    const char *types = method_getTypeEncoding(method);

    // 若方法是从父类继承来的，class_addMethod 只在本类上新增一个实现，
    // 不会把父类（例如 UIViewController）的方法改掉。子类已实现时才原地替换。
    BOOL added = class_addMethod(cls, sel, replacement, types);
    if (!added) {
        method_setImplementation(method, replacement);
    }

    WCLogLine(@"anchor", @"hook", @"OK %@.%@（%@）", clsName, selName,
              added ? @"新增实现" : @"替换实现");
    return original;
}

static void WCApplyPaperBackground(UIViewController *controller, BOOL home);

static IMP gOrigMainFrameWillAppear = NULL;
static IMP gOrigMainFrameDidAppear = NULL;
static IMP gOrigMsgContentWillAppear = NULL;
static IMP gOrigSearchWillAppear = NULL;
static BOOL gHookedMainFrameWillAppear = NO;
static BOOL gHookedMainFrameDidAppear = NO;
static BOOL gHookedMsgContentWillAppear = NO;
static BOOL gHookedSearchWillAppear = NO;

static void WCCallOrigAppear(IMP orig, id target, SEL cmd, BOOL animated) {
    if (!orig) return;
    ((void (*)(id, SEL, BOOL))orig)(target, cmd, animated);
}

static void WCMainFrameWillAppear(id self, SEL _cmd, BOOL animated) {
    WCCallOrigAppear(gOrigMainFrameWillAppear, self, _cmd, animated);
    @try {
        WCSurfaceGlassHandleController((UIViewController *)self);
        // 1.7.3：首页纯白底要在 surface 之后落，覆盖它设的 clearColor。
        WCApplyPaperBackground((UIViewController *)self, YES);
        // 1.7.5：壁纸必须在底色之后落，否则会被纯白 / 纯黑遮住。
        WCWallpaperApplyToController((UIViewController *)self);
        // 1.7.7：分组面板只允许出现在首页。
        WCGroupSetPageVisible(YES, NSStringFromClass([self class]));
        WCGroupHandleController((UIViewController *)self);
        WCDockHandleHome((UIViewController *)self);
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"surface", @"首页 viewWillAppear 异常：%@", exception.reason);
    }
}

static void WCMainFrameDidAppear(id self, SEL _cmd, BOOL animated) {
    WCCallOrigAppear(gOrigMainFrameDidAppear, self, _cmd, animated);
    @try {
        WCSurfaceGlassHandleController((UIViewController *)self);
        WCApplyPaperBackground((UIViewController *)self, YES);
        WCWallpaperApplyToController((UIViewController *)self);
        WCGroupSetPageVisible(YES, NSStringFromClass([self class]));
        // 1.7.4：viewDidAppear 作为独立重建触发点（从聊天返回时也会再跑一次）。
        WCGroupHandleControllerTrigger((UIViewController *)self, @"viewDidAppear");
        WCDockHandleHome((UIViewController *)self);
    } @catch (NSException *exception) {
    }
}

static void WCMsgContentWillAppear(id self, SEL _cmd, BOOL animated) {
    WCCallOrigAppear(gOrigMsgContentWillAppear, self, _cmd, animated);
    @try {
        // 1.7.7：任何 push 页都不允许出现分组面板。
        WCGroupSetPageVisible(NO, NSStringFromClass([self class]));
        // 1.6.4：聊天页隐藏浮岛，并按要求把原生底栏恢复 alpha=1。
        WCDockSetHomeVisible(NO, NSStringFromClass([self class]), YES);
        WCDockScheduleVerdictCheck();
        WCSurfaceGlassHandleController((UIViewController *)self);
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"surface", @"聊天页 viewWillAppear 异常：%@", exception.reason);
    }
}

static void WCSearchWillAppear(id self, SEL _cmd, BOOL animated) {
    WCCallOrigAppear(gOrigSearchWillAppear, self, _cmd, animated);
    @try {
        WCGroupSetPageVisible(NO, NSStringFromClass([self class]));
        WCDockSetHomeVisible(NO, NSStringFromClass([self class]), YES);
        WCDockScheduleVerdictCheck();
        WCSurfaceGlassHandleController((UIViewController *)self);
    } @catch (NSException *exception) {
    }
}

// 1.6.3：通讯录 / 发现 / 我 是主 TabBar 的子控制器，必须一直显示浮岛。
static BOOL WCIsTabChildController(UIViewController *vc) {
    UIViewController *cur = vc.parentViewController;
    while (cur) {
        if ([cur isKindOfClass:[UITabBarController class]]) return YES;
        cur = cur.parentViewController;
    }
    return NO;
}

// 1.6.2：其它 tab / 二级页面出现时隐藏浮岛（只隐藏不移除）。
// 每个类各自的原始 IMP 存在字典里，共用同一个替换实现。
static NSMutableDictionary<NSString *, id> *WCOtherOrigIMPs(void) {
    static NSMutableDictionary<NSString *, id> *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ map = [NSMutableDictionary dictionary]; });
    return map;
}

static void WCOtherPageWillAppear(id self, SEL _cmd, BOOL animated) {
    NSString *key = NSStringFromClass([self class]);
    NSValue *value = WCOtherOrigIMPs()[key];
    IMP orig = value ? (IMP)(void *)[value pointerValue] : NULL;
    WCCallOrigAppear(orig, self, _cmd, animated);
    @try {
        // 1.7.7：通讯录 / 发现 / 我 与任何 push 页都不显示分组面板。
        WCGroupSetPageVisible(NO, key);
        // 1.6.3：这三个是主 TabBar 的子控制器 → 显示浮岛；若是独立 push 页则隐藏。
        BOOL tabChild = WCIsTabChildController((UIViewController *)self);
        WCDockSetHomeVisible(tabChild, key, !tabChild);
        WCDockScheduleVerdictCheck();
        // 1.7.3：通讯录 / 发现 / 我 统一纯白底（深色纯黑）。
        WCApplyPaperBackground((UIViewController *)self, NO);
        WCWallpaperApplyToController((UIViewController *)self);
        // 1.7.0：在「我」页顺手缓存当前账号真实头像给底栏用。
        if ([key containsString:@"More"] || [key containsString:@"Profile"]) {
            WCDockCaptureProfileAvatar((UIViewController *)self);
        }
    } @catch (NSException *exception) {
    }
}

static void WCHookOtherPage(NSString *clsName) {
    Class cls = WCAnchorClass(clsName);
    if (!cls) return;
    SEL sel = @selector(viewWillAppear:);
    Method method = class_getInstanceMethod(cls, sel);
    if (!method) return;

    IMP original = method_getImplementation(method);
    const char *types = method_getTypeEncoding(method);
    BOOL added = class_addMethod(cls, sel, (IMP)WCOtherPageWillAppear, types);
    if (!added) {
        method_setImplementation(method, (IMP)WCOtherPageWillAppear);
    }
    WCOtherOrigIMPs()[clsName] = [NSValue valueWithPointer:(const void *)original];
    WCLogLine(@"anchor", @"hook", @"OK %@.viewWillAppear:（非首页隐藏浮岛）", clsName);
}

/// 1.7.7：朋友圈 + FTS 搜索系列 push 页也要登记「非首页」，禁止分组面板出现。
static void WCHookPushPages(void) {
    static BOOL hooked = NO;
    if (hooked) return;
    hooked = YES;

    WCHookOtherPage(@"TimeLineViewController");

    int total = objc_getClassList(NULL, 0);
    if (total <= 0) return;
    Class *classes = (Class *)malloc(sizeof(Class) * (size_t)total);
    if (!classes) return;
    total = objc_getClassList(classes, total);
    NSUInteger hits = 0;
    for (int i = 0; i < total && hits < 20; i++) {
        NSString *name = NSStringFromClass(classes[i]);
        if (![name hasPrefix:@"WCFTS"]) continue;
        WCHookOtherPage(name);
        hits += 1;
    }
    free(classes);
    WCLogLine(@"anchor", @"hook", @"push 页分组禁用 hook 完成（WCFTS* 命中 %lu）",
              (unsigned long)hits);
}

#pragma mark - 1.7.3 全局纯白 / 纯黑底色

static UIColor *WCPaperColor(UIView *view) {
    UITraitCollection *trait = view.traitCollection ?: UITraitCollection.currentTraitCollection;
    return trait.userInterfaceStyle == UIUserInterfaceStyleDark ? [UIColor blackColor]
                                                                : [UIColor whiteColor];
}

/// 分组面板内部的 table 不参与底色统一（它有自己的纯白/纯黑容器）。
static BOOL WCInGroupPanel(UIView *view) {
    UIView *cur = view;
    while (cur) {
        if (cur.tag == 0x574C4750) return YES;   // 'WCGP' WCGroupPanelTag
        cur = cur.superview;
    }
    return NO;
}

/// 首页 / 通讯录 / 发现 / 我：view 与列表统一纯白 #FFFFFF（深色 #000），
/// 首页列表同时去掉原生分隔线（分组面板自己画 0.5pt 线）。
static void WCApplyPaperBackground(UIViewController *controller, BOOL home) {
    if (!controller) return;
    UIView *root = controller.view;
    if (!root) return;

    UITraitCollection *trait = root.traitCollection ?: UITraitCollection.currentTraitCollection;
    BOOL dark = (trait.userInterfaceStyle == UIUserInterfaceStyleDark);
    UIColor *paper = WCPaperColor(root);
    // 1.7.5：壁纸存在时不铺纯白 / 纯黑，页面与列表都转 clear，露出壁纸。
    if (WCWallpaperActive()) paper = [UIColor clearColor];
    UIColor *line = dark ? [UIColor colorWithWhite:1.0 alpha:0.12]
                         : [UIColor colorWithRed:0.929 green:0.929 blue:0.929 alpha:1.0]; // #EDEDED
    root.backgroundColor = paper;

    NSUInteger tables = 0;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 80;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if (WCInGroupPanel(view)) continue;

        if ([view isKindOfClass:[UIScrollView class]] && view != root) {
            ((UIScrollView *)view).backgroundColor = paper;
            if ([view isKindOfClass:[UITableView class]]) {
                UITableView *table = (UITableView *)view;
                // 「我」页的灰色缝隙来自 backgroundView / 原生背景，必须一起清掉。
                table.backgroundView = nil;
                if (home) table.separatorStyle = UITableViewCellSeparatorStyleNone;
                table.separatorColor = line;
                tables += 1;
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }

    WCLogLine(@"info", @"surface", @"底色 %@ %@ 表=%lu",
              home ? @"首页" : NSStringFromClass([controller class]),
              WCWallpaperActive() ? @"clear" : (dark ? @"#000" : @"#FFF"),
              (unsigned long)tables);
}

static NSMutableDictionary<NSString *, id> *WCTraitOrigIMPs(void) {
    static NSMutableDictionary<NSString *, id> *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ map = [NSMutableDictionary dictionary]; });
    return map;
}

static void WCTraitCollectionChanged(id self, SEL _cmd, UITraitCollection *previous) {
    NSString *key = NSStringFromClass([self class]);
    NSValue *value = WCTraitOrigIMPs()[key];
    IMP orig = value ? (IMP)(void *)[value pointerValue] : NULL;
    if (orig) ((void (*)(id, SEL, id))orig)(self, _cmd, previous);
    @try {
        WCApplyPaperBackground((UIViewController *)self,
                               [key rangeOfString:@"MainFrame"].location != NSNotFound);
        // 1.7.5：深浅切换时换壁纸（浅色 → bg-light，深色 → bg-dark）。
        WCWallpaperApplyToController((UIViewController *)self);
    } @catch (NSException *exception) {
    }
}

/// 深色/浅色切换时同步刷新底色（只对四个主页面装一次）。
static void WCHookTraitRefresh(NSString *clsName) {
    static NSMutableSet<NSString *> *hooked;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ hooked = [NSMutableSet set]; });
    if ([hooked containsObject:clsName]) return;

    Class cls = WCAnchorClass(clsName);
    if (!cls) return;
    SEL sel = @selector(traitCollectionDidChange:);
    Method method = class_getInstanceMethod(cls, sel);
    if (!method) return;

    IMP original = method_getImplementation(method);
    const char *types = method_getTypeEncoding(method);
    BOOL added = class_addMethod(cls, sel, (IMP)WCTraitCollectionChanged, types);
    if (!added) method_setImplementation(method, (IMP)WCTraitCollectionChanged);
    WCTraitOrigIMPs()[clsName] = [NSValue valueWithPointer:(const void *)original];
    [hooked addObject:clsName];
    WCLogLine(@"anchor", @"hook", @"OK %@.traitCollectionDidChange:（底色跟随）", clsName);
}

// 1.5.1：已删除 WCSearchBar / MMUIHookView / MainFrameTableView 的 layoutSubviews hook。
// 启动期卡死证据的最后一行正是搜索栏 attach；布局回调里插模糊视图属于高风险路径。
// 搜索栏样式改由首页 viewWillAppear / viewDidAppear 时一次性（异步）应用。

void WCAnchorInstallAll(void) {
    @autoreleasepool {
        if (!gHookedMainFrameWillAppear) {
            gOrigMainFrameWillAppear = WCHookInstanceMethod(@"NewMainFrameViewController",
                                                            @"viewWillAppear:",
                                                            (IMP)WCMainFrameWillAppear);
            gHookedMainFrameWillAppear = (gOrigMainFrameWillAppear != NULL);
        }
        if (!gHookedMainFrameDidAppear) {
            gOrigMainFrameDidAppear = WCHookInstanceMethod(@"NewMainFrameViewController",
                                                           @"viewDidAppear:",
                                                           (IMP)WCMainFrameDidAppear);
            gHookedMainFrameDidAppear = (gOrigMainFrameDidAppear != NULL);
        }
        if (!gHookedMsgContentWillAppear) {
            gOrigMsgContentWillAppear = WCHookInstanceMethod(@"BaseMsgContentViewController",
                                                             @"viewWillAppear:",
                                                             (IMP)WCMsgContentWillAppear);
            gHookedMsgContentWillAppear = (gOrigMsgContentWillAppear != NULL);
        }
        if (!gHookedSearchWillAppear) {
            gOrigSearchWillAppear = WCHookInstanceMethod(@"WCSearchViewController",
                                                         @"viewWillAppear:",
                                                         (IMP)WCSearchWillAppear);
            gHookedSearchWillAppear = (gOrigSearchWillAppear != NULL);
        }
        // 1.5.1：不再安装任何 layoutSubviews 锚点（见上方注释）。

        // 1.6.2：非首页隐藏浮岛。
        static BOOL hookedOtherPages = NO;
        if (!hookedOtherPages) {
            WCHookOtherPage(@"ContactsViewController");
            WCHookOtherPage(@"FindFriendEntryViewController");
            WCHookOtherPage(@"MoreViewController");
            WCHookPushPages();
            hookedOtherPages = YES;
        }

        // 1.7.3：深色/浅色切换时刷新四个主页面的底色。
        static BOOL hookedTraitPages = NO;
        if (!hookedTraitPages) {
            WCHookTraitRefresh(@"NewMainFrameViewController");
            WCHookTraitRefresh(@"ContactsViewController");
            WCHookTraitRefresh(@"FindFriendEntryViewController");
            WCHookTraitRefresh(@"MoreViewController");
            hookedTraitPages = YES;
        }
    }
}
