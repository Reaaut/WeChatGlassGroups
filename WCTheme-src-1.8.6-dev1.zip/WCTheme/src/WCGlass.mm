#import "WCGlass.h"
#import "WCPrefs.h"
#import "WCLog.h"

static const NSInteger WCGlassBlurTag = 0x57435431; // 'WCT1'

static BOOL gGlassActive = NO;
static double gGlassIntensity = 0.35;
static NSInteger gGlassStyle = 0;

// 采样日志：每个进程最多记 40 条，避免刷爆日志文件。
static void WCGlassSampleLog(NSString *module, NSString *message) {
    static NSUInteger count = 0;
    if (count >= 40) return;
    count += 1;
    WCLogLine(@"info", module, @"%@", message);
}


static BOOL WCGlassWindowShouldBeSkipped(UIWindow *window) {
    if (![window isKindOfClass:[UIWindow class]]) return YES;
    // 只处理普通层级窗口；状态栏 / 弹窗 / 键盘等系统窗口不处理。
    if (window.windowLevel != UIWindowLevelNormal) return YES;
    if (window.bounds.size.width < 100.0 || window.bounds.size.height < 100.0) return YES;

    NSString *className = NSStringFromClass([window class]).lowercaseString;
    NSArray<NSString *> *skip = @[@"keyboard", @"statusbar", @"progress", @"hud", @"texteffect",
                                  @"iconsole", @"console"];
    for (NSString *token in skip) {
        if ([className rangeOfString:token].location != NSNotFound) return YES;
    }
    return NO;
}

static UIBlurEffectStyle WCGlassEffectStyle(void) {
    switch (gGlassStyle) {
        case 1:
            return UIBlurEffectStyleSystemThinMaterial;
        case 2:
            return UIBlurEffectStyleSystemUltraThinMaterial;
        default:
            return UIBlurEffectStyleSystemMaterial;
    }
}

static void WCGlassRemoveFromWindow(UIWindow *window) {
    UIView *existing = [window viewWithTag:WCGlassBlurTag];
    if (existing) {
        [existing removeFromSuperview];
    }
}

void WCGlassRemoveAll(void) {
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        WCGlassRemoveFromWindow(window);
    }
}

void WCGlassAttachToWindow(UIWindow *window) {
    if (!window) return;

    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            WCGlassAttachToWindow(window);
        });
        return;
    }

    if (!gGlassActive || WCGlassWindowShouldBeSkipped(window)) {
        WCGlassRemoveFromWindow(window);
        return;
    }

    UIView *existing = [window viewWithTag:WCGlassBlurTag];
    if (existing) {
        existing.frame = window.bounds;
        return;
    }

    UIView *background = nil;

    @try {
        UIBlurEffect *effect = [UIBlurEffect effectWithStyle:WCGlassEffectStyle()];
        if (effect) {
            UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
            effectView.frame = window.bounds;
            effectView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            effectView.userInteractionEnabled = NO;
            effectView.tag = WCGlassBlurTag;
            background = effectView;
        }
    } @catch (NSException *exception) {
        background = nil;
    }

    // Fallback：UIVisualEffectView 创建失败（极少数越狱环境）时改用半透明底色，
    // 逻辑仍然是“通用层”，不会影响微信启动。
    if (!background) {
        UIView *fallback = [[UIView alloc] initWithFrame:window.bounds];
        fallback.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        fallback.userInteractionEnabled = NO;
        fallback.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.35];
        fallback.tag = WCGlassBlurTag;
        background = fallback;
    }

    @try {
        [window insertSubview:background atIndex:0];
        WCGlassSampleLog(@"glass", [NSString stringWithFormat:@"attach %@ style=%ld",
                                   NSStringFromClass([window class]), (long)WCGlassEffectStyle()]);
    } @catch (NSException *exception) {
        // 插入失败（窗口层级异常）就放弃，不影响微信本身。
        WCGlassSampleLog(@"glass", [NSString stringWithFormat:@"attach 失败 %@: %@",
                                   NSStringFromClass([window class]), exception.reason]);
    }
}

UIColor *WCGlassAdjustedColor(UIView *view, UIColor *color) {
    if (!gGlassActive || !view || !color) return nil;
    if ([view isKindOfClass:[UIWindow class]]) return nil;
    if (view.tag == WCGlassBlurTag) return nil;

    UIColor *resolved = color;
    if (@available(iOS 13.0, *)) {
        if ([color respondsToSelector:@selector(resolvedColorWithTraitCollection:)]) {
            resolved = [color resolvedColorWithTraitCollection:view.traitCollection];
        }
    }

    CGFloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
    BOOL ok = [resolved getRed:&r green:&g blue:&b alpha:&a];
    if (!ok) {
        CGFloat white = 0.0;
        if ([resolved getWhite:&white alpha:&a]) {
            r = g = b = white;
            ok = YES;
        }
    }
    if (!ok) return nil;

    // 判据放宽：微信大量背景是 #EDEDED / #F5F5F5 这类浅灰（0.88~0.94），
    // 原来 0.94 的门槛会把它们全部漏掉，表现就是“装了完全没变化”。
    BOOL nearWhite = (r >= 0.88 && g >= 0.88 && b >= 0.88);
    BOOL nearBlack = (r <= 0.10 && g <= 0.10 && b <= 0.10);
    BOOL grayish = (MAX(r, MAX(g, b)) - MIN(r, MIN(g, b))) <= 0.10;
    BOOL accepted = (a >= 0.90) && (nearWhite || nearBlack) && grayish;

    if (!accepted) {
        WCGlassSampleLog(@"glass", [NSString stringWithFormat:
            @"skip %@ a=%.2f rgb=%.2f/%.2f/%.2f", NSStringFromClass([view class]), a, r, g, b]);
        return nil;
    }

    double alpha = 1.0 - gGlassIntensity;
    if (alpha < 0.45) alpha = 0.45;
    if (alpha > 0.90) alpha = 0.90;

    CGFloat white = nearWhite ? 1.0 : 0.0;

    WCGlassSampleLog(@"glass", [NSString stringWithFormat:
        @"apply %@ rgb=%.2f/%.2f/%.2f -> white=%.0f alpha=%.2f",
        NSStringFromClass([view class]), r, g, b, white, alpha]);
    return [UIColor colorWithWhite:white alpha:(CGFloat)alpha];
}

static void WCGlassUpdateExistingBackgrounds(UIView *view, NSUInteger *budget) {
    if (!view || *budget == 0) return;
    *budget -= 1;

    // 只处理已经建成、但创建时 hook 还没生效的视图（例如刚打开开关）。
    UIColor *adjusted = WCGlassAdjustedColor(view, view.backgroundColor);
    if (adjusted) {
        view.backgroundColor = adjusted;
    }

    for (UIView *subview in view.subviews) {
        WCGlassUpdateExistingBackgrounds(subview, budget);
    }
}

void WCGlassRefresh(void) {
    WCPrefs *prefs = [WCPrefs shared];
    // 1.2.0：全局换色只作为 fallback，并且默认关闭。
    // 真正的毛玻璃改由 WCSurfaceGlass 按表面处理（导航栏 / 底栏 / 搜索栏 / 列表背景）。
    gGlassActive = prefs.enabled && prefs.glassEnabled && prefs.legacyGlassEnabled;
    gGlassIntensity = prefs.glassIntensity;
    gGlassStyle = prefs.glassStyle;

    void (^apply)(void) = ^{
        WCLogLine(@"info", @"glass", @"refresh legacy=%d intensity=%.2f style=%ld",
                  gGlassActive, gGlassIntensity, (long)gGlassStyle);
        if (!gGlassActive) {
            WCGlassRemoveAll();
            return;
        }
        NSArray<UIWindow *> *windows = [[UIApplication sharedApplication].windows copy];
        for (UIWindow *window in windows) {
            WCGlassAttachToWindow(window);
            NSUInteger budget = 3000;
            WCGlassUpdateExistingBackgrounds(window, &budget);
        }
    };

    // 统一异步到主线程：%ctor 可能早于 UIApplicationMain 执行，
    // 这里不能同步访问 UIApplication/windows。
    dispatch_async(dispatch_get_main_queue(), apply);
}

void WCGlassStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        NSOperationQueue *mainQueue = [NSOperationQueue mainQueue];

        [center addObserverForName:UIWindowDidBecomeKeyNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            if ([note.object isKindOfClass:[UIWindow class]]) {
                                WCGlassAttachToWindow((UIWindow *)note.object);
                            }
                        }];

        [center addObserverForName:UIWindowDidBecomeVisibleNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            if ([note.object isKindOfClass:[UIWindow class]]) {
                                WCGlassAttachToWindow((UIWindow *)note.object);
                            }
                        }];

        [center addObserverForName:UIApplicationDidBecomeActiveNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            WCGlassRefresh();
                        }];
    });
}
