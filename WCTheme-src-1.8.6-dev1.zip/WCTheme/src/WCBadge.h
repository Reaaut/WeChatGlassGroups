#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 未读角标改色：只改颜色/描边，位置与尺寸保持原生。
// 通过类名子串（badge / reddot / redpoint / unread）识别，识别不到就什么都不做。

#ifdef __cplusplus
extern "C" {
#endif

/// 按当前偏好把 root 子树里的角标颜色刷一遍（幂等，可反复调用）。
void WCBadgeApplyToView(UIView *root);

/// 偏好变化时刷新所有窗口里的角标。
void WCBadgeRefresh(void);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
