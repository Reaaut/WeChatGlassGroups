#import "WCBadge.h"
#import "WCPrefs.h"
#import "WCLog.h"

#import <UIKit/UIKit.h>

static BOOL gBadgeEnabled = NO;
static UIColor *gBadgeColor = nil;

static UIColor *WCBadgeColorFromHex(NSString *hex) {
    if (hex.length < 6) return nil;

    NSString *clean = [hex stringByReplacingOccurrencesOfString:@"#" withString:@""];
    clean = [clean stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (clean.length < 6) return nil;

    unsigned int value = 0;
    NSScanner *scanner = [NSScanner scannerWithString:clean];
    if (![scanner scanHexInt:&value]) return nil;

    return [UIColor colorWithRed:((value >> 16) & 0xFF) / 255.0
                           green:((value >> 8) & 0xFF) / 255.0
                            blue:(value & 0xFF) / 255.0
                           alpha:1.0];
}

static UIColor *WCBadgeResolvedColor(void) {
    switch ([WCPrefs shared].badgePreset) {
        case 1: return [UIColor colorWithRed:0.10 green:0.54 blue:0.98 alpha:1.0]; // 1989FA
        case 2: return [UIColor colorWithRed:0.48 green:0.38 blue:1.00 alpha:1.0]; // 7B61FF
        case 3: return [UIColor colorWithRed:0.00 green:0.71 blue:0.47 alpha:1.0]; // 00B578
        case 4: return [UIColor colorWithRed:1.00 green:0.56 blue:0.12 alpha:1.0]; // FF8F1F
        case 5: return WCBadgeColorFromHex([WCPrefs shared].badgeHex) ?: nil;
        default: return [UIColor colorWithRed:0.98 green:0.32 blue:0.32 alpha:1.0]; // FA5151
    }
}

static BOOL WCBadgeNameMatches(NSString *className) {
    NSString *name = className.lowercaseString;
    return ([name rangeOfString:@"badge"].location != NSNotFound ||
            [name rangeOfString:@"reddot"].location != NSNotFound ||
            [name rangeOfString:@"redpoint"].location != NSNotFound ||
            [name rangeOfString:@"unread"].location != NSNotFound);
}

void WCBadgeApplyToView(UIView *root) {
    if (!root || !gBadgeEnabled || !gBadgeColor) return;

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 220;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];

        if (WCBadgeNameMatches(NSStringFromClass([view class]))) {
            // 只改底色，不动位置 / 尺寸 / 文字颜色。
            view.backgroundColor = gBadgeColor;
        }
        [queue addObjectsFromArray:view.subviews];
    }
}

void WCBadgeRefresh(void) {
    WCPrefs *prefs = [WCPrefs shared];
    // 1.5.1：角标模块总闸默认关。
    gBadgeEnabled = prefs.enabled && prefs.moduleBadge && prefs.badgeColorEnabled;
    gBadgeColor = WCBadgeResolvedColor();

    dispatch_async(dispatch_get_main_queue(), ^{
        WCLogLine(@"info", @"badge", @"refresh enabled=%d preset=%ld",
                  gBadgeEnabled, (long)prefs.badgePreset);
        if (!gBadgeEnabled) return;

        for (UIWindow *window in [[UIApplication sharedApplication].windows copy]) {
            WCBadgeApplyToView(window);
        }
    });
}
