#import "WCAdBlock.h"
#import "WCPrefs.h"

#import <objc/runtime.h>
#import <objc/message.h>

// 说明：这里刻意没有用 Logos 的 %hook。
// ios-logos-tweak 规范要求能用 %hook 的地方一律用 %hook，例外是"Logos 无法表达的场景"。
// 本模块的钩子目标是运行时才确定的（类名/方法名来自可插拔表，真机抓取后再补），
// 编译期没有确定的类名，%hook 无法表达，所以这里保留 method_setImplementation。
// 静态已知的钩子（毛玻璃、布局）全部在 Glass.x / Layout.x 里用 %hook + %orig 实现。

static NSMutableArray<WCHookEntry *> *gRegisteredHooks = nil;
static NSMutableSet<NSString *> *gInstalledKeys = nil;
static BOOL gInstalled = NO;

static void WCAdBlockEnsureStorage(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gRegisteredHooks = [NSMutableArray array];
        gInstalledKeys = [NSMutableSet set];
    });
}

@interface WCHookEntry ()
@property (nonatomic, copy, readwrite) NSString *className;
@property (nonatomic, copy, readwrite) NSString *selectorName;
@property (nonatomic, assign, readwrite) WCHookReturnKind returnKind;
@property (nonatomic, assign, readwrite) BOOL classMethod;
@property (nonatomic, copy, readwrite) WCAdBlockHandler handler;
@end

@implementation WCHookEntry

+ (instancetype)entryWithClass:(NSString *)className
                        selector:(NSString *)selectorName
                    returnKind:(WCHookReturnKind)returnKind
                     classMethod:(BOOL)classMethod
                       handler:(WCAdBlockHandler)handler {
    WCHookEntry *entry = [[WCHookEntry alloc] init];
    entry.className = className;
    entry.selectorName = selectorName;
    entry.returnKind = returnKind;
    entry.classMethod = classMethod;
    entry.handler = handler;
    return entry;
}

@end

NSArray<WCHookEntry *> *WCAdBlockDefaultHooks(void) {
    // 1.0 默认表为空。
    //
    // 这里刻意不写任何“猜出来的微信私有类名”，避免微信更新后 hook 到不存在的类，
    // 或者 hook 到错误的方法导致崩溃。等真机抓取到类名后，按下面格式补充：
    //
    // return @[
    //     [WCHookEntry entryWithClass:@"<真机确认的类名>"
    //                          selector:@"<无参方法名>"
    //                      returnKind:WCHookReturnVoid
    //                       classMethod:NO
    //                         handler:^(id target) {
    //         // 例如：把广告视图 hidden / 改 frame，或修改某个 BOOL 属性
    //     }],
    // ];
    return @[];
}

static BOOL WCAdBlockActive(void) {
    WCPrefs *prefs = [WCPrefs shared];
    return prefs.enabled && prefs.adBlockEnabled;
}

static NSString *WCHookKey(WCHookEntry *entry) {
    return [NSString stringWithFormat:@"%@|%@|%d",
            entry.className, entry.selectorName, (int)entry.classMethod];
}

static BOOL WCInstallEntry(WCHookEntry *entry) {
    NSString *key = WCHookKey(entry);
    if ([gInstalledKeys containsObject:key]) {
        return YES; // 同一个 Method 只包一次
    }

    Class cls = objc_getClass(entry.className.UTF8String);
    if (!cls) {
        NSLog(@"[WCTheme][AdBlock] 跳过：类不存在 %@", entry.className);
        return NO;
    }

    SEL sel = NSSelectorFromString(entry.selectorName);
    if (!sel) {
        NSLog(@"[WCTheme][AdBlock] 跳过：selector 无效 %@", entry.selectorName);
        return NO;
    }

    // 实例方法额外做 respondsToSelector 校验；类方法用 class_getClassMethod 校验。
    if (!entry.classMethod && !class_respondsToSelector(cls, sel)) {
        NSLog(@"[WCTheme][AdBlock] 跳过：%@ 不响应 %@",
              entry.className, entry.selectorName);
        return NO;
    }

    Method method = entry.classMethod ? class_getClassMethod(cls, sel)
                                      : class_getInstanceMethod(cls, sel);
    if (!method) {
        NSLog(@"[WCTheme][AdBlock] 跳过：找不到 Method %@ %@",
              entry.className, entry.selectorName);
        return NO;
    }

    // 只支持无参方法（self、_cmd 之外没有参数），否则 block 签名会错位。
    unsigned int argCount = method_getNumberOfArguments(method);
    if (argCount != 2) {
        NSLog(@"[WCTheme][AdBlock] 跳过：%@ %@ 参数个数=%u（只支持 0 参数）",
              entry.className, entry.selectorName, argCount);
        return NO;
    }

    const char *returnType = method_copyReturnType(method);
    BOOL returnIsVoid = (returnType && returnType[0] == 'v');
    BOOL returnIsBool = (returnType && (returnType[0] == 'c' || returnType[0] == 'B'));
    free((void *)returnType);

    if (entry.returnKind == WCHookReturnVoid && !returnIsVoid) {
        NSLog(@"[WCTheme][AdBlock] 跳过：%@ %@ 返回值不是 void",
              entry.className, entry.selectorName);
        return NO;
    }
    if (entry.returnKind == WCHookReturnBool && !returnIsBool) {
        NSLog(@"[WCTheme][AdBlock] 跳过：%@ %@ 返回值不是 BOOL",
              entry.className, entry.selectorName);
        return NO;
    }

    IMP originalIMP = method_getImplementation(method);

    if (entry.returnKind == WCHookReturnVoid) {
        void (^replacement)(id, SEL) = ^(id target, SEL cmd) {
            @try {
                if (WCAdBlockActive()) {
                    entry.handler(target);
                }
            } @catch (NSException *exception) {
                NSLog(@"[WCTheme][AdBlock] handler 异常 %@: %@",
                      entry.selectorName, exception.reason);
            }
            @try {
                ((void (*)(id, SEL))originalIMP)(target, cmd);
            } @catch (NSException *exception) {
            }
        };
        method_setImplementation(method, imp_implementationWithBlock(replacement));
    } else {
        BOOL (^replacement)(id, SEL) = ^BOOL(id target, SEL cmd) {
            @try {
                if (WCAdBlockActive()) {
                    entry.handler(target);
                }
            } @catch (NSException *exception) {
                NSLog(@"[WCTheme][AdBlock] handler 异常 %@: %@",
                      entry.selectorName, exception.reason);
            }
            @try {
                return ((BOOL (*)(id, SEL))originalIMP)(target, cmd);
            } @catch (NSException *exception) {
                return NO;
            }
        };
        method_setImplementation(method, imp_implementationWithBlock(replacement));
    }

    [gInstalledKeys addObject:key];
    NSLog(@"[WCTheme][AdBlock] 已安装 %@%@", entry.classMethod ? @"+" : @"-",
          entry.selectorName);
    return YES;
}

void WCAdBlockRegisterHook(WCHookEntry *entry) {
    if (!entry) return;
    WCAdBlockEnsureStorage();
    [gRegisteredHooks addObject:entry];
    if (gInstalled) {
        @try {
            WCInstallEntry(entry);
        } @catch (NSException *exception) {
            NSLog(@"[WCTheme][AdBlock] 安装异常 %@: %@",
                  entry.selectorName, exception.reason);
        }
    }
}

void WCAdBlockInstallAll(void) {
    WCAdBlockEnsureStorage();
    gInstalled = YES;

    for (WCHookEntry *entry in WCAdBlockDefaultHooks()) {
        @try {
            WCInstallEntry(entry);
        } @catch (NSException *exception) {
            NSLog(@"[WCTheme][AdBlock] 安装异常 %@: %@",
                  entry.selectorName, exception.reason);
        }
    }
    for (WCHookEntry *entry in gRegisteredHooks) {
        @try {
            WCInstallEntry(entry);
        } @catch (NSException *exception) {
            NSLog(@"[WCTheme][AdBlock] 安装异常 %@: %@",
                  entry.selectorName, exception.reason);
        }
    }
}
