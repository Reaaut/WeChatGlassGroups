#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#ifdef __cplusplus
extern "C" {
#endif

/// 注册 Darwin 通知（偏好面板的“抓取当前界面类名”按钮）+ 按偏好启停周期扫描。
/// 进程内只需调用一次。
void WCDiscoveryStart(void);

/// 偏好变化后调用：根据 discoveryEnabled 开/关周期扫描。
void WCDiscoveryRefresh(void);

/// 立即抓取当前 key window 的 VC 层级、相关方法、以及（手动触发时）视图树。
/// 输出到 os_log(subsystem=com.wctheme.dev, category=discovery) 和 NSLog。
void WCDiscoveryDumpNow(void);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
