#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

#ifdef __cplusplus
extern "C" {
#endif

/// 注册窗口通知 + 首次挂载微信内入口（悬浮齿轮，以及「我」页候选行）。
void WCSettingsEntryStart(void);

/// 偏好变化后重新挂载 / 移除入口。
void WCSettingsEntryRefresh(void);

/// 每个 UIViewController 的 viewDidAppear: 调用一次：记录类名、尝试「我」页入口。
BOOL WCSettingsEntryHandleViewControllerAppear(UIViewController *controller);

/// 打开设置面板（纯 UIKit，UITableView）。
void WCSettingsEntryPresentPanel(void);

/// 1.8.4：打开微信内设置面板并滚动到标题包含 keyword 的分区（如「壁纸」「首页」）。
void WCSettingsEntryPresentPanelSection(NSString *sectionKeyword);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
