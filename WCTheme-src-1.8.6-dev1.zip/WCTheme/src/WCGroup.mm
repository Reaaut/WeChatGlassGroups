#import "WCGroup.h"
#import "WCPrefs.h"
#import "WCLog.h"
#import "WCDock.h"
#import "WCWallpaper.h"
#import "WCSurfaceGlass.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

// 首页会话分组：纯叠加层，零侵入。
//
// 1.5.0 起不再参与列表布局：
// - 不 hook 列表布局、不改 cell 高度、不参与 contentSize；
// - 只在「首页出现 / 回到前台 / 偏好变化」时构建，且带缓存与签名比对；
// - 分组数据从 table.visibleCells 读取（不调用 cellForRowAtIndexPath，避免布局重入）；
// - 关闭分组或打开安全模式时，overlay / 通知监听 / 缓存全部清理。

static const NSInteger WCGroupPanelTag = 0x574C4750;   // 'WCGP'
static const void *WCGroupIndexPathKey = &WCGroupIndexPathKey;

static __weak UIView *gGroupHost = nil;
static __weak UIViewController *gGroupController = nil;
static __weak UITableView *gGroupTable = nil;

// 1.7.1：液态胶囊分组的尺寸常量（采集阶段也要用到行高，放在文件顶部）。
static NSInteger const WCGroupFoldHeaderHeight = 44;   // 1.7.6：胶囊高 44
static NSInteger const WCGroupFoldRowHeight = 56;      // 1.7.6：组内行高 56
static CGFloat const WCGroupHeaderCorner = 22.0;       // 1.7.6：圆角 22（=高/2）
static CGFloat const WCGroupPanelCorner = 24.0;        // 1.7.6：面板圆角 24
static NSInteger const WCGroupTitleCardTag = 0x574C5454; // 'WCTT' 自定义标题区
// 1.7.3：面板不再贴 table bounds —— 左右固定 12pt 屏幕内缩，胶囊再内缩 12pt，
// 让面板 x=12、胶囊 x=24，和标题左边缘对齐。
static CGFloat const WCGroupPanelInset = 12.0;
static CGFloat const WCGroupChipInset = 12.0;
static CGFloat const WCGroupTitleInset = 24.0;
static CGFloat const WCGroupPanelPaddingV = 8.0;       // 1.7.6：容器内上下各留 8

static NSArray<NSArray<NSDictionary *> *> *gGroupBuckets = nil;
static NSString *gGroupSignature = nil;
static BOOL gGroupCacheValid = NO;
static BOOL gGroupActive = NO;
static BOOL gGroupBuilding = NO;
static NSTimeInterval gGroupLastBuild = 0.0;
static BOOL gGroupRetryPending = NO;
static NSUInteger gGroupRetryCount = 0;
static NSUInteger gGroupCellsSeen = 0;      // 1.6.2：本次采集看到的 cell 数
static NSUInteger gGroupCandidates = 0;     // 1.6.2：成功拿到标题的会话数
static NSUInteger gGroupUntitledLogged = 0; // 1.6.2：无标题 cell 的日志上限
static NSUInteger gGroupNoUserLogged = 0;   // 1.7.1：无 userName 的日志上限
static NSUInteger gGroupAvatarMisses = 0;   // 1.7.1：本次采集头像缺失数
static BOOL gGroupAvatarRetried = NO;       // 1.7.1：头像缺失只补采一次
static NSString *gGroupLoggedSignature = nil;
static id gGroupRotateObserver = nil;
// 1.7.4：本次构建结果 / 失败原因，供「重建」日志一眼看清为什么没出来。
static NSString *gGroupBuildResult = @"-";
static NSString *gGroupBuildReason = @"-";
static NSString *gGroupHeightSignature = nil;   // 1.8.2：行高诊断去重
static NSString *gGroupFrameLogSignature = nil;  // 1.8.3：灰框开关去重
static NSString *gGroupBehindLogSignature = nil; // 1.8.3：背后灰框去重
static NSString *gGroupGeometrySignature = nil;  // 1.8.4：面板几何去重

// 1.7.2：置顶判定证据（三路：布尔字段 / 折叠行数量 / 折叠行之前的位置）。
static NSInteger gGroupPinnedFoldRow = -1;
// 1.7.8：折叠行所在 section —— 只有同一 section 内、折叠行之前的行才算置顶。
static NSInteger gGroupPinnedFoldSection = -1;
static NSUInteger gGroupPinnedFoldCount = 0;
static NSString *gGroupPinnedFoldTitle = nil;
static NSIndexPath *gGroupPinnedFoldIndexPath = nil;
static NSUInteger gGroupPinnedBoolHits = 0;
static NSUInteger gGroupPinnedPosHits = 0;
// 1.7.9：自持置顶覆盖（长按行标记 / 取消），优先级高于折叠边界与字段。
static NSUInteger gGroupPinnedOverrideHits = 0;
static NSString *gGroupPinLoggedSource = nil;

static NSString *gGroupExpanded = nil;
// 1.6.4：YES = 显示原生消息列表；NO = 分组接管列表（默认）。
static BOOL gGroupMessagesMode = NO;
static double gGroupOffset = 0.0;
static double gGroupSpacing = 9.0;
static double gGroupSpacingV = 10.0;   // 1.7.6：组间上下间距 10
static double gGroupCorner = 22.0;
static NSString *gGroupChipHex = @"#1E70E6";
static NSUInteger gGroupGeneration = 0;   // 1.7.2：每次采集自增，用作官方快照缓存 key

// 1.7.7：面板只在首页出现；其它页面一律隐藏并恢复原生列表。
static BOOL gGroupPageVisible = NO;
static NSString *gGroupPageClass = nil;
static NSUInteger gGroupRowLogged = 0;    // 逐行诊断日志上限 20 行
// 1.7.7：累积合并 —— 同一 userName 只入一个桶，重建不清空已有条目。
static NSMutableDictionary<NSString *, NSMutableDictionary *> *gGroupKnownItems = nil;
static NSMutableArray<NSString *> *gGroupKnownOrder = nil;

static id gGroupKeyObserver = nil;
static id gGroupActiveObserver = nil;
static NSTimer *gGroupYieldTimer = nil;   // 1.7.6：弹层让位轮询（0.6s）

static void WCGroupBuildNow(BOOL force);
static void WCGroupOpenIndexPath(NSIndexPath *indexPath);

#pragma mark - 基础

static BOOL WCGroupPrefsEnabled(void) {
    WCPrefs *prefs = [WCPrefs shared];
    // 1.5.1：分组模块总闸默认关；安全模式优先级最高。
    return prefs.enabled && prefs.moduleGroup && prefs.groupEnabled && !prefs.groupSafeMode;
}

/// 1.7.0：固定 6 个内置组 + 3 个自定义组（keyword 为空时该组为空，不显示 section）。
static NSArray<NSString *> *WCGroupIdents(void) {
    static NSArray<NSString *> *idents;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        idents = @[@"pinned", @"friends", @"groups", @"service", @"official", @"other",
                   @"custom1", @"custom2", @"custom3"];
    });
    return idents;
}

// 1.7.3：组顺序 / 单组隐藏。顺序状态放自有 suite（不用参考包的键名）。
static NSUserDefaults *WCGroupDefaults(void) {
    static NSUserDefaults *defaults;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        defaults = [[NSUserDefaults alloc] initWithSuiteName:@"com.wctheme.dev.group"];
    });
    return defaults;
}

static NSString *const WCGroupOrderKey = @"order";

/// 用户保存的顺序 + 新增组自动补到末尾。
static NSArray<NSString *> *WCGroupOrderedIdents(void) {
    NSArray<NSString *> *canonical = WCGroupIdents();
    NSArray<NSString *> *saved = [WCGroupDefaults() arrayForKey:WCGroupOrderKey];
    NSMutableArray<NSString *> *result = [NSMutableArray array];
    for (NSString *ident in saved) {
        if ([canonical containsObject:ident] && ![result containsObject:ident]) {
            [result addObject:ident];
        }
    }
    for (NSString *ident in canonical) {
        if (![result containsObject:ident]) [result addObject:ident];
    }
    return result;
}

static void WCGroupMoveIdent(NSString *ident, NSInteger delta) {
    if (ident.length == 0 || delta == 0) return;
    NSMutableArray<NSString *> *order = [WCGroupOrderedIdents() mutableCopy];
    NSUInteger from = [order indexOfObject:ident];
    if (from == NSNotFound) return;
    NSInteger to = (NSInteger)from + delta;
    if (to < 0 || (NSUInteger)to >= order.count) return;
    [order exchangeObjectAtIndex:from withObjectAtIndex:(NSUInteger)to];
    [WCGroupDefaults() setObject:order forKey:WCGroupOrderKey];
    WCLogLine(@"info", @"group", @"排序 %@ → %ld 顺序=%@", ident, (long)to,
              [order componentsJoinedByString:@","]);
}

#pragma mark - 1.7.9 置顶判定（折叠边界 / 字段 / 自持覆盖）

/// 自持置顶集合放自己的 suite（WCGlass 也是用自己的 pinned members 覆盖宿主状态）。
static NSUserDefaults *WCGroupPinDefaults(void) {
    static NSUserDefaults *defaults;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        defaults = [[NSUserDefaults alloc] initWithSuiteName:@"wxgb.pin"];
    });
    return defaults;
}

static NSString *const WCGroupPinOverrideKey = @"pinOverride";

static BOOL WCGroupPinOverrideValue(NSString *user, BOOL *has) {
    if (has) *has = NO;
    if (user.length == 0) return NO;
    NSDictionary *dict = [WCGroupPinDefaults() dictionaryForKey:WCGroupPinOverrideKey];
    id value = dict[user];
    if (!value) return NO;
    if (has) *has = YES;
    return [value boolValue];
}

/// 字段是否可信：全 true 说明宿主这组字段已经失真，退回边界判定。
static BOOL WCGroupFieldTrusted(void) {
    if (!gGroupKnownItems) return NO;
    NSUInteger total = 0, topTrue = 0;
    for (NSString *key in gGroupKnownOrder) {
        NSDictionary *entry = gGroupKnownItems[key];
        if (!entry) continue;
        total += 1;
        if ([entry[@"topRaw"] boolValue]) topTrue += 1;
    }
    return !(total > 0 && topTrue == total);
}

/// 平铺语义：所有 section 摊平成一条线性序列，折叠行之前的行才算置顶
/// （section 更小的行天然在折叠行之前；同一 section 内按 row 比较）。
static BOOL WCGroupPinnedByHost(NSDictionary *entry) {
    if (!entry) return NO;
    NSInteger row = [entry[@"row"] integerValue];
    NSInteger section = [entry[@"section"] integerValue];
    NSInteger foldRow = gGroupPinnedFoldRow;
    NSInteger foldSection = gGroupPinnedFoldSection;
    if (foldRow > 0 && foldSection >= 0) {
        if (section < foldSection) return YES;
        if (section == foldSection) return (row + 1) < foldRow;
        return NO;
    }
    return WCGroupFieldTrusted() ? [entry[@"topRaw"] boolValue] : NO;
}

/// 最终置顶：自持覆盖 > 折叠边界 > 逐行字段。
static BOOL WCGroupPinnedEffective(NSDictionary *entry, NSString *key, BOOL *hasOverride) {
    BOOL overridden = NO;
    BOOL value = WCGroupPinOverrideValue(key, &overridden);
    if (hasOverride) *hasOverride = overridden;
    if (overridden) return value;
    return WCGroupPinnedByHost(entry);
}

/// 长按组行：在「置顶 / 非置顶」之间翻转，并写入自持集合。
static void WCGroupTogglePinOverride(NSString *user) {
    if (user.length == 0 || [user isEqualToString:@"__fold__"]) return;
    BOOL current = WCGroupPinnedEffective(gGroupKnownItems[user], user, NULL);
    NSMutableDictionary *dict =
        [[WCGroupPinDefaults() dictionaryForKey:WCGroupPinOverrideKey] mutableCopy];
    if (!dict) dict = [NSMutableDictionary dictionary];
    dict[user] = @(!current);
    [WCGroupPinDefaults() setObject:[dict copy] forKey:WCGroupPinOverrideKey];
    WCLogLine(@"info", @"group", @"置顶覆盖 user=%@ 置顶=%d 来源=override 数量=%lu",
              user, current ? 0 : 1, (unsigned long)dict.count);
    dispatch_async(dispatch_get_main_queue(), ^{
        WCGroupBuildNow(YES);
    });
}

static NSString *WCGroupHidePrefKey(NSString *ident) {
    if ([ident isEqualToString:@"pinned"]) return WCKeyGroupHidePinned;
    if ([ident isEqualToString:@"friends"]) return WCKeyGroupHideFriends;
    if ([ident isEqualToString:@"groups"]) return WCKeyGroupHideGroups;
    if ([ident isEqualToString:@"service"]) return WCKeyGroupHideService;
    if ([ident isEqualToString:@"official"]) return WCKeyGroupHideOfficial;
    if ([ident isEqualToString:@"other"]) return WCKeyGroupHideOther;
    return nil;
}

static NSArray<NSString *> *WCGroupDefaultNames(void) {
    static NSArray<NSString *> *names;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        names = @[@"置顶", @"好友", @"群聊", @"服务号", @"公众号", @"其他",
                  @"自定义1", @"自定义2", @"自定义3"];
    });
    return names;
}

/// 内置组名可被 prefs 覆盖；为空则回落默认名。
static NSString *WCGroupIdentName(NSString *ident) {
    if (ident.length == 0) return @"其他";
    WCPrefs *prefs = [WCPrefs shared];
    NSArray<NSString *> *idents = WCGroupIdents();
    NSUInteger index = [idents indexOfObject:ident];
    NSArray<NSString *> *names = WCGroupDefaultNames();

    NSString *custom = nil;
    if ([ident isEqualToString:@"pinned"]) custom = prefs.groupNamePinned;
    else if ([ident isEqualToString:@"friends"]) custom = prefs.groupNameFriends;
    else if ([ident isEqualToString:@"groups"]) custom = prefs.groupNameGroups;
    else if ([ident isEqualToString:@"service"]) custom = prefs.groupNameService;
    else if ([ident isEqualToString:@"official"]) custom = prefs.groupNameOfficial;
    else if ([ident isEqualToString:@"other"]) custom = prefs.groupNameOther;
    else {
        for (NSDictionary *rule in prefs.customGroupRules) {
            if ([rule[@"ident"] isEqualToString:ident]) {
                custom = rule[@"name"];
                break;
            }
        }
    }
    if ([custom isKindOfClass:[NSString class]] && custom.length > 0) return custom;
    if (index != NSNotFound && index < names.count) return names[index];
    return ident;
}

/// 1.7.1：用户是否给该组起了名字（自定义组没名字就整组不显示）。
static BOOL WCGroupIdentHasCustomName(NSString *ident) {
    if (ident.length == 0) return NO;
    if ([ident isEqualToString:@"pinned"]) return [[WCPrefs shared] groupNamePinned].length > 0;
    if ([ident isEqualToString:@"friends"]) return [[WCPrefs shared] groupNameFriends].length > 0;
    if ([ident isEqualToString:@"groups"]) return [[WCPrefs shared] groupNameGroups].length > 0;
    if ([ident isEqualToString:@"service"]) return [[WCPrefs shared] groupNameService].length > 0;
    if ([ident isEqualToString:@"official"]) return [[WCPrefs shared] groupNameOfficial].length > 0;
    if ([ident isEqualToString:@"other"]) return [[WCPrefs shared] groupNameOther].length > 0;
    for (NSDictionary *rule in [WCPrefs shared].customGroupRules) {
        if ([rule[@"ident"] isEqualToString:ident]) {
            id name = rule[@"name"];
            return [name isKindOfClass:[NSString class]] && ((NSString *)name).length > 0;
        }
    }
    return NO;
}

#pragma mark - 自定义组规则

/// { ident, name, keyword }，keyword 为空表示未启用。
static NSArray<NSDictionary *> *WCGroupCustomRules(void) {
    NSMutableArray<NSDictionary *> *rules = [NSMutableArray array];
    WCPrefs *prefs = [WCPrefs shared];
    NSArray<NSDictionary *> *saved = prefs.customGroupRules;
    NSArray<NSArray<NSString *> *> *specs = @[
        @[@"custom1", WCKeyCustomGroup1Name, WCKeyCustomGroup1Keyword],
        @[@"custom2", WCKeyCustomGroup2Name, WCKeyCustomGroup2Keyword],
        @[@"custom3", WCKeyCustomGroup3Name, WCKeyCustomGroup3Keyword],
    ];
    for (NSArray<NSString *> *spec in specs) {
        NSString *ident = spec[0];
        NSString *name = nil;
        NSString *keyword = nil;
        for (NSDictionary *rule in saved) {
            if ([rule[@"ident"] isEqualToString:ident]) {
                if ([rule[@"name"] isKindOfClass:[NSString class]]) name = rule[@"name"];
                if ([rule[@"keyword"] isKindOfClass:[NSString class]]) {
                    keyword = rule[@"keyword"];
                }
                break;
            }
        }
        keyword = [keyword stringByTrimmingCharactersInSet:
                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (keyword.length == 0) continue;
        if (name.length == 0) name = WCGroupIdentName(ident);
        [rules addObject:@{@"ident": ident, @"name": name, @"keyword": keyword}];
    }
    return rules;
}

/// 标题 / 摘要包含关键词即归入对应自定义组（优先于内置分类）。
static NSString *WCGroupCustomMatch(NSString *title, NSString *summary) {
    if (title.length == 0) return nil;
    for (NSDictionary *rule in WCGroupCustomRules()) {
        NSString *keyword = rule[@"keyword"];
        if (keyword.length == 0) continue;
        if ([title rangeOfString:keyword].location != NSNotFound) return rule[@"ident"];
        if (summary.length && [summary rangeOfString:keyword].location != NSNotFound) {
            return rule[@"ident"];
        }
    }
    return nil;
}

static NSString *WCGroupExpandedKey(void) { return @"wcgroup.expanded"; }

static void WCGroupInvalidate(void) {
    gGroupCacheValid = NO;
}

#pragma mark - 从 cell 里取会话信息

static NSString *WCGroupStringValue(id object, NSArray<NSString *> *keys) {
    if (!object) return nil;
    for (NSString *key in keys) {
        @try {
            id value = [object valueForKey:key];
            if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) {
                return (NSString *)value;
            }
        } @catch (NSException *exception) {
        }
    }
    return nil;
}

/// 1.7.7：诊断用 —— 原样打印某个 key 的真实取值（nil / 0 / 1 / 数字）。
static NSString *WCGroupRawValueText(id object, NSString *key) {
    if (!object || key.length == 0) return @"nil";
    @try {
        id value = [object valueForKey:key];
        if (!value || [value isKindOfClass:[NSNull class]]) return @"nil";
        if ([value isKindOfClass:[NSNumber class]]) {
            NSNumber *number = (NSNumber *)value;
            const char *type = number.objCType;
            if (type && (type[0] == 'c' || type[0] == 'B')) {
                return number.boolValue ? @"1" : @"0";
            }
            return number.stringValue;
        }
        return [NSString stringWithFormat:@"%@", value];
    } @catch (NSException *exception) {
        return @"nil";
    }
}

/// 1.7.7：置顶判定只认这四个明确字段，任一为真即置顶；全部 nil 视为非置顶。
static NSArray<NSString *> *WCGroupTopKeys(void) {
    static NSArray<NSString *> *keys;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keys = @[@"m_bIsTop", @"m_bIsStickyOnTop", @"m_isTop", @"m_uiTopFlag"];
    });
    return keys;
}

static BOOL WCGroupTopFromObject(id object, BOOL *found) {
    if (found) *found = NO;
    if (!object) return NO;
    for (NSString *key in WCGroupTopKeys()) {
        @try {
            id value = [object valueForKey:key];
            if (!value || [value isKindOfClass:[NSNull class]]) continue;
            if (found) *found = YES;
            if ([value isKindOfClass:[NSNumber class]]) {
                if ([(NSNumber *)value boolValue]) return YES;
            } else if ([value isKindOfClass:[NSString class]]) {
                NSString *text = [(NSString *)value lowercaseString];
                if ([text isEqualToString:@"1"] || [text isEqualToString:@"yes"] ||
                    [text isEqualToString:@"true"]) {
                    return YES;
                }
            }
        } @catch (NSException *exception) {
        }
    }
    return NO;
}

/// 微信首页 cell 的数据字段名没有公开文档，按常见命名逐个试。
static id WCGroupCellData(UITableViewCell *cell) {
    static NSArray<NSString *> *keys;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keys = @[@"cellData", @"m_cellData", @"data", @"item", @"m_item"];
    });
    for (NSString *key in keys) {
        @try {
            id value = [cell valueForKey:key];
            if (value && ![value isKindOfClass:[NSNull class]] && value != cell) {
                return value;
            }
        } @catch (NSException *exception) {
        }
    }
    return nil;
}

/// 标题兜底：cell 里字号最大的短文本通常是会话名。
/// 1.6.2：去掉「子视图数 <= 8 才入队」的限制 —— 微信 MainFrameCell 的 contentView
/// 子视图远超 8 个，旧逻辑连一层都走不下去，所有 cell 都被跳过，于是日志里连
/// 一条 [group] 都没有。
static NSString *WCGroupTitleFromCell(UITableViewCell *cell) {
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:cell.contentView];
    NSString *best = nil;
    CGFloat bestSize = 0.0;
    NSUInteger budget = 80;

    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];

        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *label = (UILabel *)view;
            NSString *text = [label.text stringByTrimmingCharactersInSet:
                              [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (text.length > 0 && text.length <= 32 &&
                label.font.pointSize >= 11.0 && label.font.pointSize > bestSize) {
                if ([text rangeOfString:@"个置顶聊天"].location == NSNotFound) {
                    bestSize = label.font.pointSize;
                    best = text;
                }
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return best;
}

/// 1.7.2：识别「N个置顶聊天」折叠行（微信把置顶会话折叠成单独一行）。
/// 1.7.9：除「个置顶聊天」外也认「个置顶」。
static NSString *WCGroupFoldTitleFromCell(UITableViewCell *cell) {
    if (!cell) return nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:cell.contentView];
    NSUInteger budget = 80;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UILabel class]]) {
            NSString *text = ((UILabel *)view).text;
            if (text.length > 0 &&
                ([text rangeOfString:@"个置顶聊天"].location != NSNotFound ||
                 [text rangeOfString:@"个置顶"].location != NSNotFound)) {
                return text;
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return nil;
}

/// 1.6.3：摘要行 = 字号比标题小、长度最长的那条 label（微信会话 cell 的第二行）。
static NSString *WCGroupSummaryFromCell(UITableViewCell *cell, NSString *title) {
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:cell.contentView];
    NSString *best = nil;
    NSUInteger budget = 80;

    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];

        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *label = (UILabel *)view;
            NSString *text = [label.text stringByTrimmingCharactersInSet:
                              [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (text.length > 0 && text.length <= 60 && ![text isEqualToString:title] &&
                label.font.pointSize > 9.0 && label.font.pointSize < 15.5) {
                if (best.length < text.length) best = text;
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return best;
}

static BOOL WCGroupIsConversationCell(UITableViewCell *cell) {
    NSString *name = NSStringFromClass([cell class]);
    if ([name rangeOfString:@"FakeMainFrameCell"].location != NSNotFound) return NO;
    return ([name rangeOfString:@"MainFrameCell"].location != NSNotFound ||
            [name rangeOfString:@"SessionCell"].location != NSNotFound);
}

/// 微信内置服务/系统号（来自 WCGlass 的 userName 名单，见 docs/reference-group.md）。
static NSSet<NSString *> *WCGroupServiceUsernames(void) {
    static NSSet<NSString *> *set;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        set = [NSSet setWithArray:@[
            @"weixin", @"weixingongzhong", @"newsapp", @"mphelper", @"notifymessage",
            @"qmessage", @"qqmail", @"tmessage", @"floatbottle", @"medianote", @"fmessage",
            @"brandsessionholder", @"officialaccounts", @"masssendapp",
            @"brandservicesessionholder", @"brandsessionholder_weapp", @"notification_messages",
            @"opencustomerservicemsg", @"wxpay", @"@openim",
        ]];
    });
    return set;
}

/// 会话 userName 的候选字段名（WCGlass 实际遍历过的顺序）。
static NSArray<NSString *> *WCGroupUserNameKeys(void) {
    static NSArray<NSString *> *keys;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keys = @[@"m_nsUsrName", @"m_nsUserName", @"m_nsUsername", @"m_nsRealUsrName",
                 @"usrName", @"username", @"userName", @"getUsrName", @"getUserName",
                 @"m_nsFromUsr", @"m_nsToUsr", @"m_nsRealChatUsr"];
    });
    return keys;
}

static NSString *WCGroupClassify(NSString *userName, NSString *title, BOOL pinned) {
    if (pinned) return @"pinned";
    // 有 userName 时以它为准：@chatroom=群聊，gh_=公众号，服务号/系统号=服务号，其余单聊=好友。
    // 1.7.0：userName 字段名与系统号名单来自 WCGlass 逆向（docs/reference-group.md）。
    if (userName.length > 0) {
        NSString *lower = userName.lowercaseString;
        if ([lower rangeOfString:@"@chatroom"].location != NSNotFound) return @"groups";
        if ([lower hasPrefix:@"gh_"]) return @"official";
        if ([WCGroupServiceUsernames() containsObject:lower]) return @"service";
        if ([lower hasPrefix:@"@biz"] || [lower hasPrefix:@"weixin"] ||
            [lower hasPrefix:@"@openim"]) return @"service";
        return @"friends";
    }
    // userName 取不到时才用标题启发式。
    if (title.length && [title rangeOfString:@"公众号"].location != NSNotFound) return @"official";
    if (title.length && ([title rangeOfString:@"服务号"].location != NSNotFound ||
                         [title rangeOfString:@"助手"].location != NSNotFound ||
                         [title rangeOfString:@"通知"].location != NSNotFound ||
                         [title rangeOfString:@"微信团队"].location != NSNotFound ||
                         [title rangeOfString:@"文件传输"].location != NSNotFound)) {
        return @"service";
    }
    if (title.length && [title rangeOfString:@"群"].location != NSNotFound) return @"groups";
    return @"other";
}

/// 真实会话头像：从原生 cell 里找 HeadImageView / Avatar 视图，截 40×40 并按会话缓存。
static NSCache<NSString *, UIImage *> *WCGroupAvatarCache(void) {
    static NSCache<NSString *, UIImage *> *cache;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        cache = [[NSCache alloc] init];
        cache.countLimit = 200;
    });
    return cache;
}

static UIImage *WCGroupAvatarFromCell(UITableViewCell *cell, NSString *key, BOOL isGroup) {
    if (key.length == 0) return nil;
    UIImage *cached = [WCGroupAvatarCache() objectForKey:key];
    if (cached) return cached;

    // 离屏 cell 可能还没 layout：先强制排一次，否则头像 image 还是空的。
    [cell setNeedsLayout];
    [cell layoutIfNeeded];

    UIImageView *target = nil;
    UIView *composite = nil;   // 群聊九宫格合成头像容器
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:cell.contentView];
    NSUInteger budget = 120;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        NSString *cls = NSStringFromClass([view class]);
        NSString *lower = cls.lowercaseString;
        if (isGroup && !composite && ![view isKindOfClass:[UIImageView class]] &&
            view.bounds.size.width >= 20.0 &&
            ([lower rangeOfString:@"group"].location != NSNotFound ||
             [lower rangeOfString:@"composite"].location != NSNotFound ||
             [lower rangeOfString:@"grid"].location != NSNotFound ||
             [lower rangeOfString:@"multi"].location != NSNotFound)) {
            composite = view;   // 优先整块九宫格，而不是单个成员头像
        }
        if ([view isKindOfClass:[UIImageView class]]) {
            if ([lower rangeOfString:@"headimage"].location != NSNotFound ||
                [lower rangeOfString:@"avatar"].location != NSNotFound) {
                UIImageView *imageView = (UIImageView *)view;
                if (imageView.image && imageView.bounds.size.width >= 20.0) {
                    target = imageView;
                }
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }

    UIImage *snap = nil;
    CGSize snapSize = CGSizeZero;
    if (composite && composite.bounds.size.width >= 20.0) {
        [composite layoutIfNeeded];
        snapSize = composite.bounds.size;
        UIGraphicsImageRenderer *inner =
            [[UIGraphicsImageRenderer alloc] initWithSize:snapSize];
        snap = [inner imageWithActions:^(UIGraphicsImageRendererContext *context) {
            [composite.layer renderInContext:context.CGContext];
        }];
    }
    if (!snap && target) {
        snap = target.image;
        snapSize = target.bounds.size;
    }
    if (!snap || snapSize.width < 8.0) return nil;

    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(40.0, 40.0)];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
        CGContextRef ctx = context.CGContext;
        CGContextAddEllipseInRect(ctx, CGRectMake(0, 0, 40.0, 40.0));
        CGContextClip(ctx);
        CGFloat scale = 40.0 / MAX(snapSize.width, 1.0);
        CGFloat w = snapSize.width * scale;
        CGFloat h = snapSize.height * scale;
        [snap drawInRect:CGRectMake((40.0 - w) / 2.0, (40.0 - h) / 2.0, w, h)];
    }];
    if (image) [WCGroupAvatarCache() setObject:image forKey:key];
    return image;
}

/// 1.7.2：官方会话行快照缓存（key = 采集代次 + indexPath + 行宽）。
static NSCache<NSString *, UIImage *> *WCGroupSnapshotCache(void) {
    static NSCache<NSString *, UIImage *> *cache;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        cache = [[NSCache alloc] init];
        cache.countLimit = 160;
    });
    return cache;
}

/// 1.7.2：把原生 MainFrameCell 的真实内容（头像/标题/摘要/时间/红点）渲染成一张图，
/// 放进分组行里当「官方内容」，我们只负责外面那层液态玻璃壳。
/// 只对可见行调用（cellForRow / willDisplay），避免一次性渲染 400 行。
static UIImage *WCGroupOfficialCellImage(NSIndexPath *indexPath,
                                         CGFloat rowWidth, CGFloat rowHeight) {
    if (!indexPath || !gGroupTable || rowWidth < 40.0 || rowHeight < 20.0) return nil;
    NSString *key = [NSString stringWithFormat:@"%lu-%ld-%ld-%.0f",
                     (unsigned long)gGroupGeneration,
                     (long)indexPath.section, (long)indexPath.row, rowWidth];
    UIImage *cached = [WCGroupSnapshotCache() objectForKey:key];
    if (cached) return cached;

    UITableView *table = gGroupTable;
    id<UITableViewDataSource> dataSource = table.dataSource;
    if (![dataSource respondsToSelector:@selector(tableView:cellForRowAtIndexPath:)]) return nil;

    UITableViewCell *cell = nil;
    @try {
        cell = [dataSource tableView:table cellForRowAtIndexPath:indexPath];
    } @catch (NSException *exception) {
        cell = nil;
    }
    if (!cell) return nil;

    CGRect nativeRect = CGRectZero;
    @try {
        nativeRect = [table rectForRowAtIndexPath:indexPath];
    } @catch (NSException *exception) {
        nativeRect = CGRectZero;
    }
    CGFloat nativeW = table.bounds.size.width;
    if (nativeW < 100.0) nativeW = MAX(rowWidth, 320.0);
    CGFloat nativeH = nativeRect.size.height;
    if (nativeH < 20.0) nativeH = 56.0;

    CGRect savedFrame = cell.frame;
    UIColor *savedBg = cell.backgroundColor;
    UIColor *savedContentBg = cell.contentView.backgroundColor;
    BOOL savedOpaque = cell.isOpaque;

    cell.frame = CGRectMake(0.0, 0.0, nativeW, nativeH);
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.opaque = NO;
    [cell setNeedsLayout];
    [cell layoutIfNeeded];

    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(nativeW, nativeH)];
    UIImage *snap = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
        [cell.contentView.layer renderInContext:context.CGContext];
    }];

    cell.frame = savedFrame;
    cell.backgroundColor = savedBg;
    cell.contentView.backgroundColor = savedContentBg;
    cell.opaque = savedOpaque;

    if (!snap) return nil;
    UIGraphicsImageRenderer *out =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(rowWidth, rowHeight)];
    UIImage *image = [out imageWithActions:^(UIGraphicsImageRendererContext *context) {
        CGFloat scale = MIN(rowWidth / nativeW, rowHeight / nativeH);
        CGFloat w = nativeW * scale;
        CGFloat h = nativeH * scale;
        [snap drawInRect:CGRectMake((rowWidth - w) / 2.0, (rowHeight - h) / 2.0, w, h)];
    }];
    if (image) [WCGroupSnapshotCache() setObject:image forKey:key];
    return image;
}

#pragma mark - 采集（1.7.6：首屏快采 + 每批 30 行增量补齐）

static void WCGroupBuildNow(BOOL force);

/// 行缓存：indexPath → item（同一 row 再次构建直接复用，不重造 cell）。
static NSMutableDictionary<NSIndexPath *, NSDictionary *> *WCGroupIndexCache(void) {
    static NSMutableDictionary<NSIndexPath *, NSDictionary *> *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ map = [NSMutableDictionary dictionary]; });
    return map;
}

/// 内容缓存：userName（或标题）→ 标题 / 摘要 / 时间 / 头像 / 分组。
static NSMutableDictionary<NSString *, NSDictionary *> *WCGroupItemCacheMap(void) {
    static NSMutableDictionary<NSString *, NSDictionary *> *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ map = [NSMutableDictionary dictionary]; });
    return map;
}

static void WCGroupResetCollectStats(void) {
    gGroupCellsSeen = 0;
    gGroupCandidates = 0;
    gGroupUntitledLogged = 0;
    gGroupNoUserLogged = 0;
    gGroupAvatarMisses = 0;
    gGroupRowLogged = 0;
    gGroupPinnedBoolHits = 0;
    gGroupPinnedPosHits = 0;
    gGroupPinnedOverrideHits = 0;
}

static NSMutableArray<NSMutableArray<NSDictionary *> *> *WCGroupNewBuckets(void) {
    NSMutableArray<NSMutableArray<NSDictionary *> *> *buckets = [NSMutableArray array];
    NSArray<NSString *> *idents = WCGroupIdents();
    for (NSUInteger i = 0; i < idents.count; i++) {
        [buckets addObject:[NSMutableArray array]];
    }
    return buckets;
}

static NSString *WCGroupBucketSummary(NSArray<NSArray<NSDictionary *> *> *buckets) {
    NSArray<NSString *> *idents = WCGroupIdents();
    NSMutableArray<NSString *> *counts = [NSMutableArray array];
    for (NSUInteger i = 0; i < idents.count && i < buckets.count; i++) {
        if (buckets[i].count == 0) continue;
        [counts addObject:[NSString stringWithFormat:@"%@=%lu", idents[i],
                           (unsigned long)buckets[i].count]];
    }
    return counts.count ? [counts componentsJoinedByString:@" "] : @"空";
}

static void WCGroupLogBucketCounts(NSString *tag,
                                   NSArray<NSArray<NSDictionary *> *> *buckets,
                                   NSInteger sections, NSUInteger rows,
                                   NSUInteger cells, NSUInteger created) {
    (void)created;
    WCLogLine(@"info", @"group", @"%@ sections=%ld rows=%lu cells=%lu 候选=%lu 桶[%@]",
              tag, (long)sections, (unsigned long)rows, (unsigned long)cells,
              (unsigned long)gGroupCandidates, WCGroupBucketSummary(buckets));
}

static NSUInteger WCGroupBucketIndex(NSArray<NSString *> *idents, NSString *group) {
    NSUInteger index = [idents indexOfObject:group ?: @"other"];
    if (index == NSNotFound) index = idents.count ? idents.count - 1 : 0;
    return index;
}

#pragma mark - 1.7.7 累积合并 / 分类重建

static void WCGroupKnownEnsure(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gGroupKnownItems = [NSMutableDictionary dictionary];
        gGroupKnownOrder = [NSMutableArray array];
    });
}

/// 同一 userName（无 userName 时用标题）只保留一条；重建时不清空已有条目。
static void WCGroupKnownUpsert(NSDictionary *item) {
    if (!item) return;
    NSString *key = item[@"user"];
    if (key.length == 0) key = item[@"title"];
    if (key.length == 0) return;
    WCGroupKnownEnsure();

    NSMutableDictionary *entry = gGroupKnownItems[key];
    if (!entry) {
        entry = [item mutableCopy];
        gGroupKnownItems[key] = entry;
        [gGroupKnownOrder addObject:key];
        return;
    }
    for (NSString *field in @[@"title", @"summary", @"time", @"avatar"]) {
        id value = item[field];
        if (value) entry[field] = value;
    }
    // 1.7.9：同一轮采集内，username 始终映射到第一次采集到的真实 indexPath；
    // 只有新一轮采集（gen 变化）才允许更新，避免滚动增量把点击目标改到失效位置。
    BOOL sameRound = ([entry[@"gen"] integerValue] == (NSInteger)gGroupGeneration) &&
                     entry[@"indexPath"] != nil;
    if (!sameRound) {
        for (NSString *field in @[@"indexPath", @"row", @"section"]) {
            id value = item[field];
            if (value) entry[field] = value;
        }
    }
    entry[@"topRaw"] = item[@"topRaw"] ?: @NO;
    entry[@"gen"] = item[@"gen"] ?: @(gGroupGeneration);
}

/// 只有全量采集完成才允许裁剪（防止「本批只看了 30 行」把其它会话全删掉）。
static void WCGroupKnownPrune(NSUInteger generation) {
    WCGroupKnownEnsure();
    NSUInteger before = gGroupKnownOrder.count;
    NSMutableArray<NSString *> *keep = [NSMutableArray array];
    for (NSString *key in gGroupKnownOrder) {
        NSMutableDictionary *entry = gGroupKnownItems[key];
        if (entry && ([entry[@"gen"] unsignedIntegerValue] == generation)) {
            [keep addObject:key];
        }
    }
    NSUInteger after = keep.count;
    for (NSString *key in gGroupKnownOrder) {
        if (![keep containsObject:key]) [gGroupKnownItems removeObjectForKey:key];
    }
    gGroupKnownOrder = keep;
    if (before != after) {
        WCLogLine(@"info", @"group", @"合并 前=%lu 后=%lu", (unsigned long)before,
                  (unsigned long)after);
    }
}

/// 分类只在这里做一次：折叠行位置优先 → 四个置顶字段任一为真 → 类型 → 自定义关键词覆盖。
static NSArray<NSArray<NSDictionary *> *> *WCGroupPublishBuckets(void) {
    WCGroupKnownEnsure();
    NSMutableArray<NSMutableArray<NSDictionary *> *> *buckets = WCGroupNewBuckets();
    NSArray<NSString *> *idents = WCGroupIdents();
    NSMutableSet<NSString *> *placed = [NSMutableSet set];
    // 1.7.9：这两个计数按「每次发布」统计，日志才能稳定去重。
    gGroupPinnedOverrideHits = 0;
    gGroupPinnedPosHits = 0;
    NSInteger foldRow = gGroupPinnedFoldRow;   // 1-based：折叠行之前才是置顶

    for (NSString *key in gGroupKnownOrder) {
        NSMutableDictionary *entry = gGroupKnownItems[key];
        if (!entry) continue;
        if ([placed containsObject:key]) continue;
        [placed addObject:key];

        NSString *title = [entry[@"title"] isKindOfClass:[NSString class]]
            ? entry[@"title"] : key;
        NSString *summary = [entry[@"summary"] isKindOfClass:[NSString class]]
            ? entry[@"summary"] : nil;

        // 1.7.9：平铺语义 —— 不看 section 编号分类，只用「折叠行之前的线性位置」；
        // 折叠行存在时边界优先，没有折叠行才看逐行字段（全 true 视为字段失真）。
        // 自持覆盖（长按标记）永远最高优先级。
        BOOL pinnedOverride = NO;
        BOOL pinned = WCGroupPinnedEffective(entry, key, &pinnedOverride);
        if (pinnedOverride) {
            gGroupPinnedOverrideHits += 1;
        } else if (foldRow > 0 && pinned) {
            gGroupPinnedPosHits += 1;
        }

        NSString *custom = WCGroupCustomMatch(title, summary);
        NSString *group = custom.length ? custom
                                        : (pinned ? @"pinned"
                                                  : WCGroupClassify(key, title, NO));
        if (group.length == 0) group = @"other";

        NSMutableDictionary *item = [NSMutableDictionary dictionary];
        item[@"title"] = title;
        item[@"user"] = key;
        item[@"group"] = group;
        if (entry[@"indexPath"]) item[@"indexPath"] = entry[@"indexPath"];
        if (summary.length) item[@"summary"] = summary;
        if (entry[@"time"]) item[@"time"] = entry[@"time"];
        if (entry[@"avatar"]) item[@"avatar"] = entry[@"avatar"];
        NSUInteger index = WCGroupBucketIndex(idents, group);
        [buckets[index] addObject:[item copy]];
    }

    NSUInteger pinnedIndex = [idents indexOfObject:@"pinned"];
    // 置顶被微信折叠成一行时，至少把这一行放进置顶组，保证组一定出现。
    if (pinnedIndex != NSNotFound && pinnedIndex < buckets.count &&
        buckets[pinnedIndex].count == 0 &&
        gGroupPinnedFoldIndexPath && gGroupPinnedFoldCount > 0) {
        NSMutableDictionary *item = [NSMutableDictionary dictionary];
        item[@"title"] = gGroupPinnedFoldTitle ?: @"置顶聊天";
        item[@"user"] = @"__fold__";
        item[@"group"] = @"pinned";
        item[@"indexPath"] = gGroupPinnedFoldIndexPath;
        [buckets[pinnedIndex] addObject:[item copy]];
        WCLogLine(@"info", @"group", @"置顶组=1（原生折叠行占位 数量=%lu）",
                  (unsigned long)gGroupPinnedFoldCount);
    }

    // 1.7.9：置顶判定来源一眼可见（状态变化才打，避免增量刷新刷屏）。
    NSString *pinSource = @"none";
    if (gGroupPinnedOverrideHits > 0) pinSource = @"override";
    else if (foldRow > 0) pinSource = @"fold";
    else if (WCGroupFieldTrusted()) pinSource = @"field";
    NSString *pinState = [NSString stringWithFormat:@"%ld|%@|%lu",
                          (long)foldRow, pinSource,
                          (unsigned long)gGroupPinnedOverrideHits];
    if (![pinState isEqualToString:(gGroupPinLoggedSource ?: @"")]) {
        gGroupPinLoggedSource = [pinState copy];
        WCLogLine(@"info", @"group",
                  @"置顶 边界=%ld 来源=%@ 覆盖=%lu 边界section=%ld",
                  (long)foldRow, pinSource,
                  (unsigned long)gGroupPinnedOverrideHits,
                  (long)gGroupPinnedFoldSection);
    }

    NSMutableArray<NSString *> *counts = [NSMutableArray array];
    for (NSUInteger i = 0; i < idents.count && i < buckets.count; i++) {
        if (buckets[i].count == 0) continue;
        [counts addObject:[NSString stringWithFormat:@"%@=%lu", idents[i],
                           (unsigned long)buckets[i].count]];
    }
    WCLogLine(@"info", @"group", @"桶[%@]",
              counts.count ? [counts componentsJoinedByString:@" "] : @"空");

    NSMutableArray<NSArray<NSDictionary *> *> *result = [NSMutableArray array];
    for (NSMutableArray<NSDictionary *> *bucket in buckets) {
        [result addObject:[bucket copy]];
    }
    return result;
}

/// 从一行 cell 读取会话；返回 nil 表示折叠行 / 非会话 cell / 无标题。
/// 1.7.6：结果按 userName 缓存，二次进入不再重算摘要 / 头像。
static NSDictionary *WCGroupItemFromCell(UITableViewCell *cell, NSIndexPath *indexPath,
                                         NSArray<NSString *> *idents, BOOL *foldRow) {
    if (foldRow) *foldRow = NO;
    if (!cell) return nil;
    gGroupCellsSeen += 1;
    if (!WCGroupIsConversationCell(cell)) return nil;

    // 离屏 cell 从 dataSource 新建后 bounds 为 0，label 全空，先给真实尺寸再布局。
    if (!cell.window) {
        if (cell.bounds.size.width < 100.0) {
            cell.frame = CGRectMake(0.0, 0.0, MAX(cell.superview.bounds.size.width, 320.0),
                                    (CGFloat)WCGroupFoldRowHeight);
        }
        [cell setNeedsLayout];
        [cell layoutIfNeeded];
    }

    id data = WCGroupCellData(cell);
    id session = nil;
    @try {
        session = [data valueForKey:@"m_sessionInfo"];
    } @catch (NSException *exception) {
        session = nil;
    }

    NSString *foldTitle = WCGroupFoldTitleFromCell(cell);
    // 1.7.9：合成行（class 含 Fold / placeholder_foldgroup）即使没抓到标题也不能当会话。
    if (foldTitle.length == 0) {
        NSString *cls = NSStringFromClass([cell class]);
        if (cls.length > 0 &&
            ([cls rangeOfString:@"Fold" options:NSCaseInsensitiveSearch].location != NSNotFound ||
             [cls rangeOfString:@"placeholder_foldgroup" options:NSCaseInsensitiveSearch].location != NSNotFound)) {
            return nil;
        }
    }
    if (foldTitle.length > 0) {
        if (foldRow) *foldRow = YES;
        gGroupPinnedFoldRow = indexPath.row + 1;
        gGroupPinnedFoldSection = indexPath.section;
        gGroupPinnedFoldTitle = [foldTitle copy];
        gGroupPinnedFoldIndexPath = indexPath;
        NSInteger digits = 0;
        for (NSInteger i = 0; i < (NSInteger)foldTitle.length; i++) {
            unichar c = [foldTitle characterAtIndex:(NSUInteger)i];
            if (c >= '0' && c <= '9') digits = digits * 10 + (NSInteger)(c - '0');
            else break;
        }
        gGroupPinnedFoldCount = (NSUInteger)MAX(0, digits);
        WCLogLine(@"info", @"group", @"置顶折叠行 row=%ld 标题=%@ 数量=%lu",
                  (long)(indexPath.row + 1), foldTitle, (unsigned long)gGroupPinnedFoldCount);
        return nil;
    }

    NSString *title = WCGroupStringValue(data, @[@"m_nsNickName", @"m_nsRemark", @"nickname",
                                                @"m_nsName", @"name"]);
    if (title.length == 0) {
        title = WCGroupStringValue(session, @[@"m_nsNickName", @"m_nsRemark",
                                              @"m_nsName", @"nickname"]);
    }
    if (title.length == 0) title = WCGroupTitleFromCell(cell);

    NSString *userName = WCGroupStringValue(data, WCGroupUserNameKeys());
    if (userName.length == 0) userName = WCGroupStringValue(session, WCGroupUserNameKeys());
    if (title.length == 0 && userName.length > 0) title = userName;
    if (title.length == 0) {
        if (gGroupUntitledLogged < 3) {
            gGroupUntitledLogged += 1;
            WCLogLine(@"warn", @"group", @"无标题 cell=%@ 子视图=%lu content=%lu",
                      NSStringFromClass([cell class]),
                      (unsigned long)cell.subviews.count,
                      (unsigned long)cell.contentView.subviews.count);
        }
        return nil;
    }
    if (userName.length == 0 && gGroupNoUserLogged < 5) {
        gGroupNoUserLogged += 1;
        WCLogLine(@"warn", @"group", @"无 userName 标题=%@ cell=%@",
                  title, NSStringFromClass([cell class]));
    }
    gGroupCandidates += 1;

    NSString *cacheKey = userName.length ? userName : title;
    NSDictionary *cached = WCGroupItemCacheMap()[cacheKey];

    // 1.7.7：诊断日志 —— 逐行打印 top / sticky / flag 的真实取值（最多 20 行）。
    if (gGroupRowLogged < 20) {
        gGroupRowLogged += 1;
        NSString *topText = WCGroupRawValueText(session, @"m_bIsTop");
        if ([topText isEqualToString:@"nil"]) topText = WCGroupRawValueText(data, @"m_bIsTop");
        NSString *stickyText = WCGroupRawValueText(session, @"m_bIsStickyOnTop");
        if ([stickyText isEqualToString:@"nil"]) {
            stickyText = WCGroupRawValueText(data, @"m_bIsStickyOnTop");
        }
        NSString *flagText = WCGroupRawValueText(session, @"m_uiTopFlag");
        if ([flagText isEqualToString:@"nil"]) flagText = WCGroupRawValueText(data, @"m_uiTopFlag");
        WCLogLine(@"info", @"group", @"row i=%ld user=%@ top=%@ sticky=%@ flag=%@ title=%@",
                  (long)indexPath.row, userName.length ? userName : @"-",
                  topText, stickyText, flagText, title);
    }

    // 1.7.7：置顶字段只认 m_bIsTop / m_bIsStickyOnTop / m_isTop / m_uiTopFlag，
    // 全部为 nil 时一律视为非置顶（不再默认 true）。
    BOOL found = NO;
    BOOL topRaw = WCGroupTopFromObject(session, &found);
    if (!found) topRaw = WCGroupTopFromObject(data, &found);
    if (topRaw) gGroupPinnedBoolHits += 1;

    NSString *summary = cached[@"summary"];
    NSString *time = cached[@"time"];
    UIImage *avatar = cached[@"avatar"];

    if (!cached) {
        summary = WCGroupSummaryFromCell(cell, title);
        time = WCGroupStringValue(data, @[@"m_nsTime", @"m_nsTimeText",
                                          @"m_nsDate", @"timeString"]);
        if (time.length == 0) {
            time = WCGroupStringValue(session, @[@"m_nsTime", @"m_nsTimeText", @"m_nsDate"]);
        }
        NSString *custom = WCGroupCustomMatch(title, summary);
        NSString *autoGroup = custom.length ? custom : WCGroupClassify(userName, title, topRaw);
        avatar = WCGroupAvatarFromCell(cell, cacheKey, [autoGroup isEqualToString:@"groups"]);
        if (!avatar) gGroupAvatarMisses += 1;

        // 只缓存稳定内容；分组 / 置顶每次重建时重算（折叠行、关键词都可能变化）。
        NSMutableDictionary *entry = [NSMutableDictionary dictionary];
        if (summary.length) entry[@"summary"] = summary;
        if (time.length) entry[@"time"] = time;
        if (avatar) entry[@"avatar"] = avatar;
        WCGroupItemCacheMap()[cacheKey] = [entry copy];

        if (gGroupCandidates <= 12) {
            WCLogLine(@"info", @"group", @"头像 row=%ld 命中=%d key=%@",
                      (long)indexPath.row, avatar ? 1 : 0, cacheKey);
        }
    }

    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    item[@"title"] = title;
    item[@"user"] = cacheKey;
    item[@"section"] = @(indexPath.section);
    item[@"row"] = @(indexPath.row);
    item[@"topRaw"] = @(topRaw);
    item[@"gen"] = @(gGroupGeneration);
    item[@"indexPath"] = indexPath;
    if (summary.length) item[@"summary"] = summary;
    if (time.length) item[@"time"] = time;
    if (avatar) item[@"avatar"] = avatar;
    return [item copy];
}

static __weak UITableView *gGroupProgressiveTable = nil;
static NSMutableSet<NSIndexPath *> *gGroupProgressiveDone = nil;
static BOOL gGroupProgressiveCapped = NO;   // 触发行数上限 → 不算全量，禁止裁剪
static NSUInteger gGroupProgressiveSection = 0;
static NSUInteger gGroupProgressiveRow = 0;
static NSUInteger gGroupProgressiveGeneration = 0;
static BOOL gGroupProgressiveRunning = NO;
// 1.7.8：全 section 累计上限 600 行（原来只看 section 0，导致只剩置顶组）。
static const NSUInteger WCGroupMaxCollectRows = 600;
static NSUInteger gGroupProgressiveMaxRows = 600;

static void WCGroupProgressivePublish(void);
static void WCGroupProgressiveStart(UITableView *table, NSUInteger generation);
static BOOL gGroupYielded = NO;
static BOOL gGroupPanelForceHidden = NO;
static void WCGroupInstallMenuYield(void);

/// 首屏快采：只读 visibleCells，绝不申请新 cell（目标 < 30ms）。
static NSArray<NSArray<NSDictionary *> *> *WCGroupCollect(UITableView *table) {
    WCGroupResetCollectStats();
    if (!table.window) return @[];

    gGroupGeneration += 1;
    [WCGroupSnapshotCache() removeAllObjects];
    NSArray<NSString *> *idents = WCGroupIdents();
    NSTimeInterval started = CFAbsoluteTimeGetCurrent();

    NSArray<UITableViewCell *> *visible =
        [table.visibleCells sortedArrayUsingComparator:
         ^NSComparisonResult(UITableViewCell *a, UITableViewCell *b) {
            NSIndexPath *pa = [table indexPathForCell:a];
            NSIndexPath *pb = [table indexPathForCell:b];
            if (!pa) return NSOrderedDescending;
            if (!pb) return NSOrderedAscending;
            if (pa.section != pb.section) return pa.section < pb.section ? NSOrderedAscending
                                                                        : NSOrderedDescending;
            if (pa.row < pb.row) return NSOrderedAscending;
            if (pa.row > pb.row) return NSOrderedDescending;
            return NSOrderedSame;
        }];

    gGroupProgressiveDone = [NSMutableSet set];
    gGroupProgressiveCapped = NO;
    NSUInteger created = 0;

    for (UITableViewCell *cell in visible) {
        NSIndexPath *indexPath = [table indexPathForCell:cell];
        if (!indexPath) continue;
        [gGroupProgressiveDone addObject:indexPath];
        BOOL fold = NO;
        NSDictionary *item = WCGroupItemFromCell(cell, indexPath, idents, &fold);
        if (!item) continue;
        // 1.7.7：累积合并 —— 不再按本次可见结果重建桶。
        WCGroupKnownUpsert(item);
        WCGroupIndexCache()[indexPath] = item;
    }

    // 1.7.8：首页表视图是多 section，必须把所有 section 的行数都算进上限，
    // 否则 visibleCells 一填满就把后面的会话全部裁掉（这就是只剩置顶组的原因）。
    NSInteger sections = MAX(1, [table numberOfSections]);
    NSUInteger totalRows = 0;
    for (NSInteger s = 0; s < sections; s++) {
        totalRows += (NSUInteger)MAX(0, [table numberOfRowsInSection:s]);
    }
    NSUInteger rowsSeen = visible.count;
    WCLogLine(@"info", @"group", @"首屏 sections=%ld rows=%lu cells=%lu 候选=%lu 耗时=%.0fms",
              (long)sections, (unsigned long)totalRows, (unsigned long)visible.count,
              (unsigned long)gGroupCandidates,
              (CFAbsoluteTimeGetCurrent() - started) * 1000.0);

    NSUInteger cap = MIN(WCGroupMaxCollectRows, totalRows);
    gGroupProgressiveMaxRows = MAX(visible.count, MAX(1, cap));
    WCGroupProgressiveStart(table, gGroupGeneration);
    (void)created;

    NSArray<NSArray<NSDictionary *> *> *buckets = WCGroupPublishBuckets();
    NSUInteger pinnedIndex = [idents indexOfObject:@"pinned"];
    NSUInteger pinnedCount = (pinnedIndex != NSNotFound && pinnedIndex < buckets.count)
        ? buckets[pinnedIndex].count : 0;
    WCLogLine(pinnedCount ? @"info" : @"warn", @"group",
              @"置顶桶 pinned=%lu 布尔=%lu 位置=%lu 覆盖=%lu",
              (unsigned long)pinnedCount, (unsigned long)gGroupPinnedBoolHits,
              (unsigned long)gGroupPinnedPosHits, (unsigned long)gGroupPinnedOverrideHits);

    WCGroupLogBucketCounts(@"采集", buckets, sections, totalRows, rowsSeen, created);
    return buckets;
}

#pragma mark - 增量补齐（1.7.6）

static void WCGroupProgressivePublish(void) {
    if (!gGroupKnownItems) return;
    gGroupBuckets = WCGroupPublishBuckets();
    gGroupCacheValid = YES;
    gGroupSignature = nil;
    WCGroupBuildNow(YES);
}

static void WCGroupProgressiveStep(void) {
    if (!gGroupProgressiveRunning) return;
    if (!gGroupActive || !WCGroupPrefsEnabled()) {
        gGroupProgressiveRunning = NO;
        return;
    }
    UITableView *table = gGroupProgressiveTable;
    if (!table || !table.window || gGroupProgressiveGeneration != gGroupGeneration) {
        gGroupProgressiveRunning = NO;
        return;
    }

    NSArray<NSString *> *idents = WCGroupIdents();
    NSInteger sectionCount = MAX(1, [table numberOfSections]);
    NSUInteger budget = 30;
    NSUInteger created = 0;

    while (budget > 0 && gGroupProgressiveSection < (NSUInteger)sectionCount) {
        NSInteger rows = [table numberOfRowsInSection:(NSInteger)gGroupProgressiveSection];
        if (gGroupProgressiveRow >= (NSUInteger)MAX(0, rows)) {
            gGroupProgressiveSection += 1;
            gGroupProgressiveRow = 0;
            sectionCount = MAX(1, [table numberOfSections]);
            continue;
        }
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:(NSInteger)gGroupProgressiveRow
                                                    inSection:(NSInteger)gGroupProgressiveSection];
        gGroupProgressiveRow += 1;
        budget -= 1;

        if ([gGroupProgressiveDone containsObject:indexPath]) continue;
        if (gGroupProgressiveDone.count >= gGroupProgressiveMaxRows) {
            gGroupProgressiveCapped = YES;
            gGroupProgressiveSection = (NSUInteger)sectionCount;
            break;
        }
        [gGroupProgressiveDone addObject:indexPath];

        // 二次进入：该行上次已采集过，直接复用缓存，不再创建 cell。
        NSDictionary *cached = WCGroupIndexCache()[indexPath];
        if (cached) {
            NSMutableDictionary *reuse = [cached mutableCopy];
            reuse[@"gen"] = @(gGroupGeneration);   // 本次仍存在的会话，裁剪时保留
            reuse[@"row"] = @(indexPath.row);
            reuse[@"section"] = @(indexPath.section);   // 1.7.8：多 section 下位置可能变化
            reuse[@"indexPath"] = indexPath;
            WCGroupKnownUpsert([reuse copy]);
            continue;
        }

        UITableViewCell *cell = nil;
        id<UITableViewDataSource> dataSource = table.dataSource;
        if (dataSource &&
            [dataSource respondsToSelector:@selector(tableView:cellForRowAtIndexPath:)]) {
            @try {
                cell = [dataSource tableView:table cellForRowAtIndexPath:indexPath];
                if (cell) created += 1;
            } @catch (NSException *exception) {
                cell = nil;
            }
        }
        if (!cell) continue;
        NSDictionary *item = WCGroupItemFromCell(cell, indexPath, idents, NULL);
        if (!item) continue;
        WCGroupKnownUpsert(item);
        WCGroupIndexCache()[indexPath] = item;
    }

    BOOL capped = gGroupProgressiveCapped;
    BOOL finished = gGroupProgressiveSection >= (NSUInteger)sectionCount;
    if (finished) {
        gGroupProgressiveRunning = NO;
        // 只有全量采集完成（未触发行数上限）才允许移除已删除会话。
        if (!capped) WCGroupKnownPrune(gGroupGeneration);
        NSUInteger totalRows = 0;
        NSInteger totalSections = MAX(1, [table numberOfSections]);
        for (NSInteger s = 0; s < totalSections; s++) {
            totalRows += (NSUInteger)MAX(0, [table numberOfRowsInSection:s]);
        }
        WCGroupLogBucketCounts(@"补齐完成", WCGroupPublishBuckets(),
                               totalSections, totalRows, gGroupProgressiveDone.count, created);
    } else {
        WCLogLine(@"info", @"group", @"增量 cells=%lu 本批创建=%lu 候选=%lu",
                  (unsigned long)gGroupProgressiveDone.count, (unsigned long)created,
                  (unsigned long)gGroupCandidates);
    }
    WCGroupProgressivePublish();
    if (!finished) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.03 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            WCGroupProgressiveStep();
        });
    }
}

static void WCGroupProgressiveStart(UITableView *table, NSUInteger generation) {
    if (!table || !table.window) return;
    gGroupProgressiveTable = table;
    gGroupProgressiveGeneration = generation;
    gGroupProgressiveSection = 0;
    gGroupProgressiveRow = 0;
    gGroupProgressiveRunning = YES;
    // 1.7.9：折叠边界只在全量扫描开始时重置，由首批扫描重新确认；
    // 滚动增量不再清掉边界（否则折叠行不在屏内时会误判置顶）。
    gGroupPinnedFoldRow = -1;
    gGroupPinnedFoldSection = -1;
    gGroupPinnedFoldCount = 0;
    gGroupPinnedFoldTitle = nil;
    gGroupPinnedFoldIndexPath = nil;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.03 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        WCGroupProgressiveStep();
    });
}

#pragma mark - 点击目标

@interface WCGroupTapTarget : NSObject
- (void)wc_toggleGroup:(UIButton *)sender;
- (void)wc_openItem:(UIButton *)sender;
- (void)wc_switchMode:(UIButton *)sender;
@end

@implementation WCGroupTapTarget

- (void)wc_toggleGroup:(UIButton *)sender {
    NSString *group = sender.accessibilityIdentifier;
    if (group.length == 0) return;

    BOOL same = [gGroupExpanded isEqualToString:group];
    gGroupExpanded = same ? nil : [group copy];
    [[NSUserDefaults standardUserDefaults] setObject:(gGroupExpanded ?: @"")
                                              forKey:WCGroupExpandedKey()];

    gGroupSignature = nil;
    WCGroupInvalidate();
    // 异步重建：避免在按钮自己的点击回调里把按钮从父视图移除。
    dispatch_async(dispatch_get_main_queue(), ^{
        WCGroupBuildNow(YES);
    });
}

- (void)wc_openItem:(UIButton *)sender {
    NSIndexPath *indexPath = objc_getAssociatedObject(sender, WCGroupIndexPathKey);
    WCGroupOpenIndexPath(indexPath);
}

- (void)wc_switchMode:(UIButton *)sender {
    // 1.6.4：分段控件 tag 0=分组，1=消息。
    BOOL messages = (sender.tag == 1);
    if (gGroupMessagesMode == messages) return;
    gGroupMessagesMode = messages;
    WCLogLine(@"info", @"group", @"切换模式 %@", messages ? @"消息" : @"分组");
    dispatch_async(dispatch_get_main_queue(), ^{
        WCGroupBuildNow(YES);
    });
}

@end

static WCGroupTapTarget *WCGroupTarget(void) {
    static WCGroupTapTarget *target;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        target = [[WCGroupTapTarget alloc] init];
    });
    return target;
}

static UIColor *WCGroupColorFromHex(NSString *hex, CGFloat alpha) {
    UIColor *fallback = [UIColor colorWithRed:0.12 green:0.44 blue:0.90 alpha:alpha];
    if (![hex isKindOfClass:[NSString class]]) return fallback;
    NSString *s = [hex stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (s.length != 6) return fallback;
    unsigned int value = 0;
    NSScanner *scanner = [NSScanner scannerWithString:s];
    if (![scanner scanHexInt:&value]) return fallback;
    return [UIColor colorWithRed:((value >> 16) & 0xFF) / 255.0
                           green:((value >> 8) & 0xFF) / 255.0
                            blue:(value & 0xFF) / 255.0
                           alpha:alpha];
}

#pragma mark - 面板构建

/// 1.7.1：深浅模式判定 —— 面板底色跟随微信。
static BOOL WCGroupDarkTheme(UIView *view) {
    UITraitCollection *trait = view.traitCollection ?: UITraitCollection.currentTraitCollection;
    return trait.userInterfaceStyle == UIUserInterfaceStyleDark;
}

static UIColor *WCGroupPrimaryText(UIView *view) {
    return WCGroupDarkTheme(view) ? [UIColor whiteColor] : [UIColor labelColor];
}

static UIColor *WCGroupSecondaryText(UIView *view) {
    return WCGroupDarkTheme(view) ? [UIColor colorWithWhite:1.0 alpha:0.55]
                                  : [UIColor colorWithWhite:0.0 alpha:0.52];
}

static UIColor *WCGroupTertiaryText(UIView *view) {
    return WCGroupDarkTheme(view) ? [UIColor colorWithWhite:1.0 alpha:0.40]
                                  : [UIColor colorWithWhite:0.0 alpha:0.36];
}

/// 1.7.4：全局页面底色（首页 view / MainFrameTableView / 面板所在区域）同一常量，
/// 跟随 traitCollection：浅色纯白 #FFFFFF，深色纯黑 #000000。
static UIColor *WCGlobalBackgroundColor(UIView *view) {
    // 1.7.5：壁纸存在时面板直接坐在壁纸上，不再铺纯白 / 纯黑。
    if (WCWallpaperActive()) return [UIColor clearColor];
    return WCGroupDarkTheme(view) ? [UIColor blackColor] : [UIColor whiteColor];
}

/// 1.8.0：面板容器不再铺不透明白卡 —— 统一玻璃（blur + 白/黑 tint 0.12）。
static const NSInteger WCGroupPanelBlurTag = 9919;
static const NSInteger WCGroupPanelTintTag = 9920;

/// 1.7.2：全局面板统一的一套液态玻璃外壳。
/// 1.7.4：胶囊只保留「模糊 + tint + 1pt 外描边 + 顶部高光」；
/// 删掉底部 1px 黑 0.12 暗边（这就是胶囊下方那条灰杠的真实来源），
/// 并且胶囊 masksToBounds=YES，不再在胶囊本体上挂 shadow（避免硬边）。
static void WCGroupApplyGlass(UIView *view, CGFloat corner, BOOL expanded) {
    if (!view) return;
    // 1.8.0：每次重建先清掉上一轮的旧玻璃层（9914-9917），避免叠加成不透明卡片。
    for (NSNumber *tag in @[@(9914), @(9915), @(9916), @(9917)]) {
        [[view viewWithTag:tag.integerValue] removeFromSuperview];
    }

    // 1.8.4：组行直接复用底栏那套液态玻璃配方（backdrop → tint → sheen → 描边 → 羽化），
    // 只是面板 / 组行的 tint 比底栏轻一档（0.045 vs 0.07），不再各写一套参数。
    view.backgroundColor = [UIColor clearColor];
    WCApplyLiquidGlass(view, corner, WCLiquidGlassStylePanel, expanded);
    if (@available(iOS 11.0, *)) {
        view.layer.cornerCurve = kCACornerCurveContinuous;
    }
}

static void __attribute__((unused)) WCGroupApplyGlassLegacyUnused(UIView *view, CGFloat corner, BOOL expanded) {
    BOOL dark = WCGroupDarkTheme(view);

    UIVisualEffectView *blur = [[UIVisualEffectView alloc] initWithEffect:
        [UIBlurEffect effectWithStyle:(dark ? UIBlurEffectStyleSystemUltraThinMaterialDark
                                            : UIBlurEffectStyleSystemUltraThinMaterialLight)]];
    blur.tag = 9914;
    blur.frame = view.bounds;
    blur.alpha = 0.78;   // 1.8.2：超薄材质 + 0.78，壁纸透上来，不再像白卡
    blur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    blur.layer.cornerRadius = corner;
    blur.layer.cornerCurve = kCACornerCurveContinuous;
    blur.layer.maskedCorners = expanded
        ? (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner)
        : (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner |
           kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner);
    blur.layer.masksToBounds = YES;
    blur.userInteractionEnabled = NO;
    [view addSubview:blur];

    UIView *tint = [[UIView alloc] initWithFrame:view.bounds];
    tint.tag = 9915;
    tint.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tint.backgroundColor = dark ? [UIColor colorWithWhite:0.0 alpha:0.12]
                                : [UIColor colorWithWhite:1.0 alpha:0.12];
    tint.layer.cornerRadius = corner;
    tint.layer.cornerCurve = kCACornerCurveContinuous;
    tint.layer.maskedCorners = blur.layer.maskedCorners;
    tint.layer.masksToBounds = YES;
    tint.userInteractionEnabled = NO;
    [view addSubview:tint];

    // 1.8.0：顶部 sheen（CAGradientLayer）—— 只加一层，别用多张高光图叠。
    UIView *sheen = [[UIView alloc] initWithFrame:view.bounds];
    sheen.tag = 9916;
    sheen.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    sheen.userInteractionEnabled = NO;
    sheen.layer.cornerRadius = corner;
    sheen.layer.cornerCurve = kCACornerCurveContinuous;
    sheen.layer.maskedCorners = blur.layer.maskedCorners;
    sheen.layer.masksToBounds = YES;
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = sheen.bounds;
    gradient.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:dark ? 0.10 : 0.22].CGColor,
                        (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor];
    gradient.locations = @[@0.0, @0.48];
    gradient.startPoint = CGPointMake(0.5, 0.0);
    gradient.endPoint = CGPointMake(0.5, 1.0);
    [sheen.layer addSublayer:gradient];
    [view addSubview:sheen];

    // 1.8.0：near/far 双层阴影（far 用独立底层，避免被本体圆角裁掉）。
    UIView *far = [[UIView alloc] initWithFrame:CGRectInset(view.bounds, 1.0, 1.0)];
    far.tag = 9917;
    far.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    far.backgroundColor = [UIColor clearColor];
    far.userInteractionEnabled = NO;
    far.layer.cornerRadius = corner;
    far.layer.cornerCurve = kCACornerCurveContinuous;
    far.layer.maskedCorners = blur.layer.maskedCorners;
    // 1.8.2：原来 0.10 / radius 14 / offset 8 的远阴影就是每组下方那条「灰杠」。
    far.layer.shadowColor = [UIColor blackColor].CGColor;
    far.layer.shadowOpacity = dark ? 0.22 : 0.05;
    far.layer.shadowRadius = 8.0;
    far.layer.shadowOffset = CGSizeMake(0.0, 2.0);
    far.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:far.bounds
                                                     cornerRadius:corner].CGPath;
    [view insertSubview:far atIndex:0];

    view.backgroundColor = [UIColor clearColor];
    view.layer.cornerRadius = corner;
    view.layer.cornerCurve = kCACornerCurveContinuous;
    view.layer.maskedCorners = blur.layer.maskedCorners;
    // 本体不裁剪，near 阴影才能露出来；内容由 blur/tint/sheen 自己裁。
    view.layer.masksToBounds = NO;
    // 1.8.2：去掉 1pt 白色外描边 —— 它压在底边就是那条浅灰横线；高光改由顶部 sheen 承担。
    view.layer.borderWidth = 0.0;
    view.layer.borderColor = [UIColor clearColor].CGColor;
    view.layer.shadowColor = [UIColor blackColor].CGColor;
    view.layer.shadowOpacity = dark ? 0.18 : 0.04;
    view.layer.shadowRadius = 3.0;
    view.layer.shadowOffset = CGSizeMake(0.0, 1.0);
    view.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:view.bounds
                                                      cornerRadius:corner].CGPath;
}

/// 1.8.2：扫描「又细又宽、还带不透明底色」的视图 —— 这就是灰杠的实际来源。
static void WCGroupScanHairlines(UIView *root, NSMutableArray<NSString *> *hits,
                                 NSUInteger *scanned, NSUInteger depth) {
    if (!root || depth > 4) return;
    if (scanned) *scanned += 1;
    for (UIView *sub in root.subviews) {
        if (!sub.hidden && sub.alpha > 0.05) {
            UIColor *color = sub.backgroundColor;
            CGFloat h = sub.bounds.size.height;
            CGFloat w = sub.bounds.size.width;
            if (color && CGColorGetAlpha(color.CGColor) > 0.05 &&
                h > 0.0 && h <= 2.5 && w >= 40.0) {
                [hits addObject:[NSString stringWithFormat:@"%@(%.0fx%.0f)",
                                 NSStringFromClass([sub class]), w, h]];
            }
        }
        WCGroupScanHairlines(sub, hits, scanned, depth + 1);
    }
}

#pragma mark - 1.6.3 QQ 式竖向折叠面板 / 1.6.4 接管列表

static const NSInteger WCGroupSegmentTag = 0x574C4753; // 'WCGS'

/// 当前正在做「液滴入场」的 section（-1 表示无）。
static NSInteger gGroupDropletSection = -1;

/// 1.7.0：点击必须真正进聊天 —— 调原生 table 的 delegate，而不是 scrollToRow。
/// 微信自己的 didSelectRowAtIndexPath: 会 push 会话；只有 delegate 缺失时才回退滚动。
static void WCGroupOpenIndexPath(NSIndexPath *indexPath) {
    UITableView *table = gGroupTable;
    if (!indexPath || !table) return;
    id<UITableViewDelegate> delegate = table.delegate;
    if ([delegate respondsToSelector:@selector(tableView:didSelectRowAtIndexPath:)]) {
        @try {
            [delegate tableView:table didSelectRowAtIndexPath:indexPath];
            WCLogLine(@"info", @"group", @"点击 row=%ld section=%ld -> delegate=%@",
                      (long)indexPath.row, (long)indexPath.section,
                      NSStringFromClass([delegate class]));
            return;
        } @catch (NSException *exception) {
            WCLogLine(@"warn", @"group", @"delegate 点击失败：%@", exception.reason);
        }
    }
    @try {
        [table scrollToRowAtIndexPath:indexPath
                     atScrollPosition:UITableViewScrollPositionMiddle
                             animated:YES];
        WCLogLine(@"info", @"group", @"点击 row=%ld section=%ld -> 回退 scroll（无 delegate）",
                  (long)indexPath.row, (long)indexPath.section);
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"group", @"滚动失败：%@", exception.reason);
    }
}

@interface WCGroupFoldCell : UITableViewCell
@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) UIVisualEffectView *blurView;
@property (nonatomic, strong) UIImageView *snapshotView;
@property (nonatomic, strong) UIView *edgeLeft;
@property (nonatomic, strong) UIView *edgeRight;
@property (nonatomic, strong) UIView *edgeBottom;
@property (nonatomic, strong) UIView *avatarView;
@property (nonatomic, strong) UIImageView *avatarImageView;
@property (nonatomic, strong) UILabel *avatarLabel;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIView *separator;
// 1.7.9：长按该行可切换「置顶 / 取消置顶」（写入 wxgb.pin 的自持集合）。
@property (nonatomic, copy) NSString *pinUser;
- (void)wc_applyTheme:(BOOL)dark lastInSection:(BOOL)last;
@end

@implementation WCGroupFoldCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor clearColor];
    self.contentView.backgroundColor = [UIColor clearColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;

    _bgView = [[UIView alloc] initWithFrame:CGRectZero];
    _bgView.layer.masksToBounds = YES;
    [self.contentView addSubview:_bgView];

    // 1.7.2：整块连续的液态玻璃底（逐行同一材质，行间无缝隙）。
    _blurView = [[UIVisualEffectView alloc] initWithEffect:
                 [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialLight]];
    _blurView.tag = 9914;   // 1.8.4：让「组行玻璃=N/M」统计能数到真实行玻璃
    _blurView.alpha = 0.62; // 1.8.4：和面板同档，不再整行发灰
    _blurView.userInteractionEnabled = NO;
    _blurView.layer.masksToBounds = YES;
    [_bgView addSubview:_blurView];

    // 官方 cell 内容快照（头像/标题/摘要/时间/红点），我们只包外壳。
    _snapshotView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _snapshotView.contentMode = UIViewContentModeScaleAspectFit;
    _snapshotView.clipsToBounds = YES;
    _snapshotView.backgroundColor = [UIColor clearColor];
    _snapshotView.hidden = YES;
    [self.contentView addSubview:_snapshotView];

    // 展开组是一个连续容器：左右描边 + 最后一行的底部描边，形成整块玻璃。
    _edgeLeft = [[UIView alloc] initWithFrame:CGRectZero];
    _edgeLeft.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.26];
    [_bgView addSubview:_edgeLeft];
    _edgeRight = [[UIView alloc] initWithFrame:CGRectZero];
    _edgeRight.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.26];
    [_bgView addSubview:_edgeRight];
    _edgeBottom = [[UIView alloc] initWithFrame:CGRectZero];
    _edgeBottom.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.26];
    [_bgView addSubview:_edgeBottom];

    _avatarView = [[UIView alloc] initWithFrame:CGRectZero];
    _avatarView.layer.cornerRadius = 20.0;              // 40pt 圆形头像
    _avatarView.layer.cornerCurve = kCACornerCurveContinuous;
    _avatarView.layer.masksToBounds = YES;
    [self.contentView addSubview:_avatarView];

    _avatarImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _avatarImageView.contentMode = UIViewContentModeScaleAspectFill;
    _avatarImageView.clipsToBounds = YES;
    [_avatarView addSubview:_avatarImageView];

    _avatarLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _avatarLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    _avatarLabel.textAlignment = NSTextAlignmentCenter;
    _avatarLabel.textColor = [UIColor colorWithWhite:0.35 alpha:1.0];
    [_avatarView addSubview:_avatarLabel];

    _nameLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _nameLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    [self.contentView addSubview:_nameLabel];

    _detailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _detailLabel.font = [UIFont systemFontOfSize:13];
    [self.contentView addSubview:_detailLabel];

    _timeLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _timeLabel.font = [UIFont systemFontOfSize:12];
    _timeLabel.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:_timeLabel];

    // 0.5pt 分隔线，从头像右侧开始，不顶到边。
    _separator = [[UIView alloc] initWithFrame:CGRectZero];
    [self.contentView addSubview:_separator];

    // 1.7.9：长按切换置顶覆盖（0.55s，避免和点击 / 展开手势打架）。
    UILongPressGestureRecognizer *longPress =
        [[UILongPressGestureRecognizer alloc] initWithTarget:self
                                                      action:@selector(wc_togglePinOverride:)];
    longPress.minimumPressDuration = 0.55;
    [self.contentView addGestureRecognizer:longPress];
    return self;
}

- (void)wc_togglePinOverride:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    NSString *user = self.pinUser;
    if (user.length == 0 || [user isEqualToString:@"__fold__"]) return;
    WCLogLine(@"info", @"group", @"长按置顶 user=%@", user);
    WCGroupTogglePinOverride(user);
}

- (void)wc_applyTheme:(BOOL)dark lastInSection:(BOOL)last {
    // 1.7.2：外壳液态玻璃；内容用官方 cell 快照，壳内不再画第二套文字。
    _blurView.effect = [UIBlurEffect effectWithStyle:
                        (dark ? UIBlurEffectStyleSystemUltraThinMaterialDark
                              : UIBlurEffectStyleSystemUltraThinMaterialLight)];
    // 1.8.4：组行也走共用液态玻璃配方（面板档：轻一档的 tint + 顶部 sheen + 极细描边），
    // 不再用「模糊 1.0 + 白 0.05」叠两层的旧参数（那两层叠出来就是图二那块灰面）。
    _bgView.backgroundColor = [UIColor clearColor];
    WCApplyLiquidGlass(_blurView, WCGroupHeaderCorner, WCLiquidGlassStylePanel, NO);
    // 1.8.2：行内 0.5pt 描边同样会在底边形成灰线，去掉。
    _bgView.layer.borderWidth = 0.0;
    _bgView.layer.borderColor = [UIColor clearColor].CGColor;
    if (last) {
        _bgView.layer.cornerRadius = WCGroupHeaderCorner;
        _bgView.layer.cornerCurve = kCACornerCurveContinuous;
        _bgView.layer.maskedCorners = kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner;
        _blurView.layer.cornerRadius = WCGroupHeaderCorner;
        _blurView.layer.cornerCurve = kCACornerCurveContinuous;
        _blurView.layer.maskedCorners = kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner;
    } else {
        _bgView.layer.cornerRadius = 0.0;
        _bgView.layer.maskedCorners = 0;
        _blurView.layer.cornerRadius = 0.0;
        _blurView.layer.maskedCorners = 0;
    }
    self.contentView.backgroundColor = [UIColor clearColor];
    // 1.8.0：去掉分组时那条灰色横杠 —— 底边 1px 与行内 0.5pt 分割线全部不显示。
    _edgeBottom.hidden = YES;
    _separator.hidden = YES;
    _avatarView.backgroundColor = dark ? [UIColor colorWithWhite:0.26 alpha:1.0]
                                      : [UIColor colorWithWhite:0.92 alpha:1.0];
    _nameLabel.textColor = WCGroupPrimaryText(self);
    _detailLabel.textColor = WCGroupSecondaryText(self);
    _timeLabel.textColor = WCGroupTertiaryText(self);
    _separator.backgroundColor = [UIColor clearColor];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    // 只排自己新增的子视图，绝不改动外部视图树。
    CGFloat w = self.contentView.bounds.size.width;
    CGFloat h = self.contentView.bounds.size.height;
    _bgView.frame = CGRectMake(0.0, 0.0, w, h);
    _blurView.frame = _bgView.bounds;
    _snapshotView.frame = CGRectMake(0.0, 0.0, w, h);
    _edgeLeft.frame = CGRectMake(0.0, 0.0, 1.0, h);
    _edgeRight.frame = CGRectMake(MAX(0.0, w - 1.0), 0.0, 1.0, h);
    _edgeBottom.frame = CGRectMake(0.0, MAX(0.0, h - 1.0), w, 1.0);
    _avatarView.frame = CGRectMake(16.0, (h - 40.0) / 2.0, 40.0, 40.0);
    _avatarImageView.frame = _avatarView.bounds;
    _avatarLabel.frame = _avatarView.bounds;
    CGFloat textLeft = CGRectGetMaxX(_avatarView.frame) + 12.0;
    CGFloat timeW = 64.0;
    _timeLabel.frame = CGRectMake(w - 16.0 - timeW, 10.0, timeW, 16.0);
    _nameLabel.frame = CGRectMake(textLeft, 9.0,
                                  MAX(40.0, w - textLeft - timeW - 24.0), 20.0);
    _detailLabel.frame = CGRectMake(textLeft, 31.0,
                                    MAX(40.0, w - textLeft - 16.0), 17.0);
    _separator.frame = CGRectMake(textLeft, MAX(0.0, h - 0.5), MAX(0.0, w - textLeft - 16.0), 0.5);
}
@end

@interface WCGroupFoldView : UIView <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UIView *base;
@property (nonatomic, strong) UITableView *list;
@property (nonatomic, copy) NSArray<NSDictionary *> *sections;
@property (nonatomic, strong) NSMutableSet<NSString *> *expanded;
- (void)updateSections:(NSArray<NSDictionary *> *)sections;
- (void)wc_toggleSection:(UIButton *)sender;
- (void)wc_headerTouchDown:(UIButton *)sender;
- (void)wc_headerTouchUp:(UIButton *)sender;
@end

static void WCGroupBuildNow(BOOL force);

@implementation WCGroupFoldView
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    _expanded = [NSMutableSet set];

    self.backgroundColor = [UIColor clearColor];

    // 1.7.4：面板容器不再有独立白卡 —— 背景 clear，直接坐在页面底色上；
    // 只有每一条胶囊自己有玻璃质感（模糊 + tint + 描边）。
    self.layer.masksToBounds = NO;
    self.layer.shadowOpacity = 0.0;

    _base = [[UIView alloc] initWithFrame:CGRectZero];
    // 1.8.0：面板容器改玻璃 —— clear 底 + blur 0.90 + 白/黑 tint 0.12，壁纸透上来。
    _base.backgroundColor = [UIColor clearColor];
    _base.layer.cornerRadius = WCGroupPanelCorner;
    _base.layer.cornerCurve = kCACornerCurveContinuous;
    _base.layer.masksToBounds = YES;
    [self addSubview:_base];

    UIVisualEffectView *panelBlur = [[UIVisualEffectView alloc] initWithEffect:
        [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialLight]];
    panelBlur.tag = WCGroupPanelBlurTag;
    panelBlur.alpha = 0.90;
    panelBlur.userInteractionEnabled = NO;
    panelBlur.layer.cornerRadius = WCGroupPanelCorner;
    panelBlur.layer.cornerCurve = kCACornerCurveContinuous;
    panelBlur.layer.masksToBounds = YES;
    [_base addSubview:panelBlur];

    UIView *panelTint = [[UIView alloc] initWithFrame:CGRectZero];
    panelTint.tag = WCGroupPanelTintTag;
    panelTint.userInteractionEnabled = NO;
    panelTint.layer.cornerRadius = WCGroupPanelCorner;
    panelTint.layer.cornerCurve = kCACornerCurveContinuous;
    panelTint.layer.masksToBounds = YES;
    [_base addSubview:panelTint];

    _list = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    _list.backgroundColor = [UIColor clearColor];
    _list.separatorStyle = UITableViewCellSeparatorStyleNone;
    _list.separatorInset = UIEdgeInsetsZero;
    _list.rowHeight = WCGroupFoldRowHeight;
    _list.dataSource = self;
    _list.delegate = self;
    _list.showsVerticalScrollIndicator = NO;
    _list.contentInset = UIEdgeInsetsMake(0, 0, 16, 0);
    [_base addSubview:_list];

    // 1.7.2：面板内部搜索条已删除 —— 全局只保留浮岛上方那一条搜索胶囊。
    return self;
}

- (void)wc_headerTouchDown:(UIButton *)sender {
    UIView *press = [sender viewWithTag:9913];
    [UIView animateWithDuration:0.12 delay:0 options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         sender.transform = CGAffineTransformMakeScale(0.98, 0.98);
                         press.alpha = 1.0;
                     } completion:nil];
}

- (void)wc_headerTouchUp:(UIButton *)sender {
    UIView *press = [sender viewWithTag:9913];
    [UIView animateWithDuration:0.18 delay:0 options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         sender.transform = CGAffineTransformIdentity;
                         press.alpha = 0.0;
                     } completion:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    _base.frame = self.bounds;
    BOOL dark = WCGroupDarkTheme(self);
    _base.backgroundColor = [UIColor clearColor];
    _base.layer.cornerRadius = WCGroupPanelCorner;

    // 1.8.0：容器玻璃随系统模式刷新。
    UIVisualEffectView *panelBlur = (UIVisualEffectView *)[_base viewWithTag:WCGroupPanelBlurTag];
    if (panelBlur) {
        panelBlur.frame = _base.bounds;
        panelBlur.effect = [UIBlurEffect effectWithStyle:
            (dark ? UIBlurEffectStyleSystemUltraThinMaterialDark : UIBlurEffectStyleSystemUltraThinMaterialLight)];
        panelBlur.alpha = 0.72;   // 1.8.2：再降一档，避免整块盖成白卡
    }
    UIView *panelTint = [_base viewWithTag:WCGroupPanelTintTag];
    if (panelTint) {
        panelTint.frame = _base.bounds;
        panelTint.backgroundColor = dark ? [UIColor colorWithWhite:0.0 alpha:0.06]
                                         : [UIColor colorWithWhite:1.0 alpha:0.06];
    }

    // 1.8.3：面板背后那圈灰框 = 面板级玻璃底（blur + tint）+ 容器外层阴影。
    // 开关默认开：整层透明，只保留每条胶囊自己的玻璃；关掉恢复原生玻璃底与阴影。
    BOOL hideFrame = [WCPrefs shared].groupHideFrame;
    self.backgroundColor = [UIColor clearColor];
    self.layer.backgroundColor = NULL;
    _base.backgroundColor = [UIColor clearColor];
    _base.layer.backgroundColor = NULL;
    _list.backgroundColor = [UIColor clearColor];
    _list.backgroundView = nil;
    if (panelBlur) {
        panelBlur.hidden = hideFrame;
        panelBlur.alpha = hideFrame ? 0.0 : 0.72;
    }
    if (panelTint) panelTint.hidden = hideFrame;

    if (hideFrame) {
        self.layer.shadowOpacity = 0.0;
        self.layer.shadowPath = nil;
    } else {
        // 1.7.6：容器只留极轻外阴影（black 0.05 / r6 / (0,2)），避免「肿」。
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOpacity = 0.05;
        self.layer.shadowRadius = 6.0;
        self.layer.shadowOffset = CGSizeMake(0.0, 2.0);
        self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                                           cornerRadius:WCGroupPanelCorner].CGPath;
    }

    // 容器内顶部/底部各留 8pt，胶囊左右再内缩 12pt（面板 12 → 胶囊 24）。
    _list.frame = CGRectMake(WCGroupChipInset, WCGroupPanelPaddingV,
                             MAX(0.0, w - WCGroupChipInset * 2.0),
                             MAX(0.0, h - WCGroupPanelPaddingV * 2.0));
    _list.contentInset = UIEdgeInsetsMake(0, 0, 16, 0);

    // 1.8.2：行高是否比内容高出一截（余量露出来就是那条灰杠）+ 细线视图扫描。
    CGFloat contentH = 0.0;
    for (NSUInteger i = 0; i < self.sections.count; i++) {
        contentH += WCGroupFoldHeaderHeight;
        if (i > 0) contentH += gGroupSpacingV;
        NSString *ident = self.sections[i][@"group"];
        if (ident && [self.expanded containsObject:ident]) {
            contentH += [self.sections[i][@"items"] count] * WCGroupFoldRowHeight;
        }
    }
    CGFloat residual = _list.bounds.size.height - contentH;
    NSString *diagSignature = [NSString stringWithFormat:@"%.0f#%.0f#%.0f#%lu#%.0f",
        _list.bounds.size.height, contentH, residual,
        (unsigned long)self.sections.count, _list.contentSize.height];
    if (![diagSignature isEqualToString:(gGroupHeightSignature ?: @"")]) {
        gGroupHeightSignature = [diagSignature copy];
        WCLogLine(@"info", @"group",
                  @"行高 表=%.0f cell=%.0f 内容=%.0f 余量=%.1f 分隔=%d footer=%.0f header=%.0f",
                  _list.bounds.size.height, (CGFloat)WCGroupFoldRowHeight, contentH, residual,
                  _list.separatorStyle == UITableViewCellSeparatorStyleNone ? 0 : 1,
                  _list.tableFooterView ? _list.tableFooterView.bounds.size.height : 0.0,
                  _list.tableHeaderView ? _list.tableHeaderView.bounds.size.height : 0.0);
        NSMutableArray<NSString *> *hits = [NSMutableArray array];
        NSUInteger scanned = 0;
        WCGroupScanHairlines(self, hits, &scanned, 0);
        WCLogLine(@"info", @"group", @"灰杠 扫描=%lu 命中=%@",
                  (unsigned long)scanned,
                  hits.count ? [hits componentsJoinedByString:@","] : @"无");
    }

    // 1.8.3：灰框开关 / 背后灰框 —— 只在取值变化时打印。
    UIVisualEffectView *frameBlur = (UIVisualEffectView *)[_base viewWithTag:WCGroupPanelBlurTag];
    NSString *frameHit = frameBlur
        ? [NSString stringWithFormat:@"%@(%.0fx%.0f)", NSStringFromClass([frameBlur class]),
           _base.bounds.size.width, _base.bounds.size.height]
        : @"无";
    NSString *frameSignature = [NSString stringWithFormat:@"%d#%d#%@#%.0fx%.0f",
                                hideFrame ? 1 : 0, panelBlur ? (panelBlur.hidden ? 1 : 0) : -1,
                                frameHit, w, h];
    if (![frameSignature isEqualToString:(gGroupFrameLogSignature ?: @"")]) {
        gGroupFrameLogSignature = [frameSignature copy];
        WCLogLine(@"info", @"group", @"灰框 hidden=%d 开关=%d 命中=%@",
                  panelBlur ? (panelBlur.hidden ? 1 : 0) : -1, hideFrame ? 1 : 0, frameHit);
    }

    UIColor *containerBG = _base.backgroundColor;
    NSString *containerName = @"nil";
    if (containerBG) {
        CGFloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
        if ([containerBG getRed:&r green:&g blue:&b alpha:&a]) {
            containerName = (a < 0.01) ? @"clear" : [NSString stringWithFormat:@"#%02X%02X%02X a=%.2f",
                (unsigned int)(r * 255), (unsigned int)(g * 255), (unsigned int)(b * 255), a];
        } else {
            containerName = @"other";
        }
    }
    NSString *behindSignature = [NSString stringWithFormat:@"%d#%d#%@#%@#%d",
                                 hideFrame ? 1 : 0, panelBlur ? (panelBlur.hidden ? 1 : 0) : -1,
                                 frameHit, containerName, self.layer.shadowOpacity > 0.01 ? 1 : 0];
    if (![behindSignature isEqualToString:(gGroupBehindLogSignature ?: @"")]) {
        gGroupBehindLogSignature = [behindSignature copy];
        WCLogLine(@"info", @"group", @"背后 灰框=%d 命中=%@ 容器bg=%@",
                  hideFrame ? 0 : 1, frameHit, containerName);
    }
}

- (void)updateSections:(NSArray<NSDictionary *> *)sections {
    self.sections = sections ?: @[];
    NSMutableSet<NSString *> *keep = [NSMutableSet set];
    for (NSDictionary *section in self.sections) {
        NSString *group = section[@"group"];
        if ([self.expanded containsObject:group]) [keep addObject:group];
    }
    [self.expanded intersectSet:keep];
    [self.list reloadData];
    [self setNeedsLayout];
}

- (void)wc_toggleSection:(UIButton *)sender {
    NSUInteger index = (NSUInteger)sender.tag;
    if (index >= self.sections.count) return;
    NSString *group = self.sections[index][@"group"];
    if (group.length == 0) return;
    BOOL willExpand = ![self.expanded containsObject:group];
    if (willExpand) [self.expanded addObject:group];
    else [self.expanded removeObject:group];
    // 首次展开：组内行做自上而下的液滴入场（逐行 0.04s stagger，最多 6 行）。
    gGroupDropletSection = willExpand ? (NSInteger)index : -1;
    // 0.28s 高度动画（UIViewPropertyAnimator / EaseInOut）+ 原生 reloadSections:Fade。
    UIViewPropertyAnimator *animator =
        [[UIViewPropertyAnimator alloc] initWithDuration:0.28
                                                   curve:UIViewAnimationCurveEaseInOut
                                              animations:^{
        [self.list beginUpdates];
        [self.list reloadSections:[NSIndexSet indexSetWithIndex:index]
                 withRowAnimation:UITableViewRowAnimationFade];
        [self.list endUpdates];
    }];
    [animator addCompletion:^(UIViewAnimatingPosition finalPosition) {
        if (gGroupDropletSection == (NSInteger)index) gGroupDropletSection = -1;
        // 1.8.4：面板高度贴合内容，展开 / 收起后重新算一次高度（动画结束后再重建）。
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            WCGroupBuildNow(YES);
        });
    }];
    [animator startAnimation];
    WCLogLine(@"info", @"group", @"折叠切换 组=%@ 展开=%d", group, willExpand ? 1 : 0);
}

#pragma mark UITableViewDataSource / Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return (NSInteger)self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section < 0 || (NSUInteger)section >= self.sections.count) return 0;
    NSDictionary *info = self.sections[(NSUInteger)section];
    if (![self.expanded containsObject:info[@"group"]]) return 0;
    return (NSInteger)[info[@"items"] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return WCGroupFoldHeaderHeight + (section == 0 ? 0.0 : gGroupSpacingV);
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return WCGroupFoldRowHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section < 0 || (NSUInteger)section >= self.sections.count) return nil;
    NSDictionary *info = self.sections[(NSUInteger)section];
    NSString *group = info[@"group"] ?: @"other";      // ident，折叠状态 key
    NSString *name = info[@"name"] ?: group;           // 显示名，用户自定义名原样显示
    NSArray<NSDictionary *> *items = info[@"items"];
    BOOL expanded = [self.expanded containsObject:group];
    BOOL dark = WCGroupDarkTheme(self);
    CGFloat gap = (section == 0 ? 0.0 : gGroupSpacingV);

    UIButton *header = [UIButton buttonWithType:UIButtonTypeCustom];
    header.frame = CGRectMake(0.0, gap, tableView.bounds.size.width, WCGroupFoldHeaderHeight);
    header.backgroundColor = [UIColor clearColor];
    header.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    // 收起：完整半圆胶囊；展开：只保留上圆角，下面与组内行连成一整块。
    // 描边 / 三线高光 / 阴影统一由 WCGroupApplyGlass 处理。
    WCGroupApplyGlass(header, WCGroupHeaderCorner, expanded);
    header.tag = section;
    [header addTarget:self action:@selector(wc_headerTouchDown:)
      forControlEvents:UIControlEventTouchDown];
    [header addTarget:self action:@selector(wc_headerTouchUp:)
      forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside |
                       UIControlEventTouchCancel];
    [header addTarget:self action:@selector(wc_toggleSection:)
      forControlEvents:UIControlEventTouchUpInside];
    // 1.7.3：长按组头弹出「上移 / 下移 / 隐藏」，顺序存自有 suite。
    UILongPressGestureRecognizer *longPress =
        [[UILongPressGestureRecognizer alloc] initWithTarget:self
                                                      action:@selector(wc_longPressHeader:)];
    longPress.minimumPressDuration = 0.55;
    [header addGestureRecognizer:longPress];

    UILabel *chevron = [[UILabel alloc] initWithFrame:CGRectMake(14.0, 0.0, 20.0,
                                                                 WCGroupFoldHeaderHeight)];
    chevron.text = expanded ? @"∨" : @"›";
    chevron.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightMedium];
    chevron.textColor = WCGroupDarkTheme(self) ? [UIColor colorWithWhite:1.0 alpha:0.55]
                                               : [UIColor colorWithWhite:0.0 alpha:0.45];
    chevron.userInteractionEnabled = NO;
    [header addSubview:chevron];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(40.0, 0.0,
                                                               MAX(60.0, tableView.bounds.size.width - 96.0),
                                                               WCGroupFoldHeaderHeight)];
    title.text = name.length ? name : @"未命名";
    // 1.7.3：组名跟随动态字体，最大 1.2 倍。
    title.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleHeadline]
                  scaledFontForFont:[UIFont systemFontOfSize:18.0 weight:UIFontWeightSemibold]
                maximumPointSize:21.6];
    title.textColor = WCGroupPrimaryText(self);
    title.userInteractionEnabled = NO;
    [header addSubview:title];

    UILabel *count = [[UILabel alloc] initWithFrame:CGRectMake(tableView.bounds.size.width - 60.0,
                                                              0.0, 44.0, WCGroupFoldHeaderHeight)];
    count.text = [NSString stringWithFormat:@"%lu", (unsigned long)items.count];
    count.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleCaption1]
                  scaledFontForFont:[UIFont systemFontOfSize:14.0]
                maximumPointSize:16.8];
    count.textColor = [UIColor colorWithRed:0.541 green:0.541 blue:0.557 alpha:1.0]; // #8A8A8E
    count.textAlignment = NSTextAlignmentRight;
    count.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    count.userInteractionEnabled = NO;
    [header addSubview:count];

    // 按压反馈：tint 加深 0.06（用独立覆盖层，避免破坏玻璃层）。
    UIView *press = [[UIView alloc] initWithFrame:header.bounds];
    press.tag = 9913;
    press.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    press.backgroundColor = dark ? [UIColor colorWithWhite:1.0 alpha:0.06]
                                 : [UIColor colorWithWhite:0.0 alpha:0.06];
    press.userInteractionEnabled = NO;
    press.alpha = 0.0;
    press.layer.cornerRadius = WCGroupHeaderCorner;
    press.layer.cornerCurve = kCACornerCurveContinuous;
    press.layer.maskedCorners = expanded
        ? (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner)
        : (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner |
           kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner);
    press.layer.masksToBounds = YES;
    [header addSubview:press];
    return header;
}

- (UIViewController *)wc_topViewController {
    UIViewController *vc = self.window.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    return vc;
}

- (void)wc_longPressHeader:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    NSInteger section = gesture.view.tag;
    if (section < 0 || (NSUInteger)section >= self.sections.count) return;
    NSDictionary *info = self.sections[(NSUInteger)section];
    NSString *ident = info[@"group"];
    NSString *name = info[@"name"] ?: ident;

    UIViewController *top = [self wc_topViewController];
    if (!top) return;
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:name
                                                                  message:@"调整分组顺序 / 隐藏"
                                                           preferredStyle:UIAlertControllerStyleActionSheet];
    if (section > 0) {
        [sheet addAction:[UIAlertAction actionWithTitle:@"上移" style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *action) {
            WCGroupMoveIdent(ident, -1);
            WCGroupBuildNow(YES);
        }]];
    }
    if (section + 1 < (NSInteger)self.sections.count) {
        [sheet addAction:[UIAlertAction actionWithTitle:@"下移" style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *action) {
            WCGroupMoveIdent(ident, 1);
            WCGroupBuildNow(YES);
        }]];
    }
    NSString *hideKey = WCGroupHidePrefKey(ident);
    if (hideKey) {
        [sheet addAction:[UIAlertAction actionWithTitle:@"隐藏此组" style:UIAlertActionStyleDestructive
                                                handler:^(UIAlertAction *action) {
            WCSetPrefBool(hideKey, YES);
            WCLogLine(@"info", @"group", @"隐藏组 %@", ident);
            WCGroupBuildNow(YES);
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel
                                            handler:nil]];
    if (sheet.popoverPresentationController) {
        sheet.popoverPresentationController.sourceView = gesture.view;
        sheet.popoverPresentationController.sourceRect = gesture.view.bounds;
    }
    [top presentViewController:sheet animated:YES completion:nil];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    WCGroupFoldCell *cell = [tableView dequeueReusableCellWithIdentifier:@"WCGroupFoldCell"];
    if (!cell) {
        cell = [[WCGroupFoldCell alloc] initWithStyle:UITableViewCellStyleDefault
                                     reuseIdentifier:@"WCGroupFoldCell"];
    }
    NSDictionary *info = self.sections[(NSUInteger)indexPath.section];
    NSArray<NSDictionary *> *items = info[@"items"];
    if ((NSUInteger)indexPath.row >= items.count) return cell;
    NSDictionary *item = items[(NSUInteger)indexPath.row];

    NSString *title = item[@"title"] ?: @"";
    cell.nameLabel.text = title;
    // 1.7.9：记住 userName，供长按写自持置顶集合。
    NSString *pinUser = [item[@"user"] isKindOfClass:[NSString class]] ? item[@"user"] : nil;
    cell.pinUser = ([pinUser isEqualToString:@"__fold__"] ? nil : pinUser);
    cell.detailLabel.text = item[@"summary"] ?: @"";
    cell.timeLabel.text = item[@"time"] ?: @"";
    [cell wc_applyTheme:WCGroupDarkTheme(self)
           lastInSection:(indexPath.row == (NSInteger)items.count - 1)];

    // 1.7.2：内容用官方 cell 的真实快照（头像/标题/摘要/时间/红点原样），
    // 我们只外面包一层液态玻璃壳；取不到快照时才退回自绘文字。
    NSIndexPath *nativeIndex = item[@"indexPath"];
    UIImage *official = WCGroupOfficialCellImage(nativeIndex,
                                                 tableView.bounds.size.width,
                                                 (CGFloat)WCGroupFoldRowHeight);
    cell.snapshotView.image = official;
    cell.snapshotView.hidden = (official == nil);
    BOOL fallback = (official == nil);
    cell.nameLabel.hidden = !fallback;
    cell.detailLabel.hidden = !fallback;
    cell.timeLabel.hidden = !fallback;
    cell.avatarView.hidden = !fallback;
    // 1.8.0：任何情况下都不显示灰色分割线（含自绘文字回退行）。
    cell.separator.hidden = YES;

    // 1.7.0：优先真实会话头像（采集时从原生 cell 截图缓存），取不到用首字。
    UIImage *avatar = [item[@"avatar"] isKindOfClass:[UIImage class]] ? item[@"avatar"] : nil;
    cell.avatarImageView.image = avatar;
    cell.avatarLabel.hidden = (avatar != nil);
    cell.avatarLabel.text = title.length ? [title substringToIndex:1] : @"?";
    cell.avatarView.backgroundColor = avatar
        ? [UIColor clearColor]
        : (WCGroupDarkTheme(self) ? [UIColor colorWithWhite:0.26 alpha:1.0]
                                  : [UIColor colorWithWhite:0.92 alpha:1.0]);
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell
forRowAtIndexPath:(NSIndexPath *)indexPath {
    // 液滴入场：alpha 0→1 + translateY(-6)→0，逐行 0.04s stagger，最多 6 行。
    if (gGroupDropletSection == indexPath.section && indexPath.row < 6) {
        cell.alpha = 0.0;
        cell.transform = CGAffineTransformMakeTranslation(0.0, -6.0);
        [UIView animateWithDuration:0.24
                              delay:0.04 * (double)indexPath.row
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             cell.alpha = 1.0;
                             cell.transform = CGAffineTransformIdentity;
                         } completion:nil];
    } else {
        cell.alpha = 1.0;
        cell.transform = CGAffineTransformIdentity;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    if (indexPath.section < 0 || (NSUInteger)indexPath.section >= self.sections.count) return;
    NSArray<NSDictionary *> *items = self.sections[(NSUInteger)indexPath.section][@"items"];
    if ((NSUInteger)indexPath.row >= items.count) return;
    WCGroupOpenIndexPath(items[(NSUInteger)indexPath.row][@"indexPath"]);
}

@end

static void WCGroupWaitForListNotify(void);

#pragma mark - 1.7.3 自定义标题（去掉独立卡片，浮在白底上）

/// 把导航栏 / 首页顶部那些「微信(6)」标题 label 隐藏，但别碰我们自己的标题区。
/// 1.7.3：titleView 置空（保留导航栏高度、不再占位），并把 navigationItem.title 清空，
/// 避免微信在后续刷新时把「微信(6)」再写回来。
static void WCGroupSetNativeTitleHidden(UIViewController *controller, UIView *host, BOOL hide) {
    if (!controller) return;
    if (hide) {
        if (!controller.navigationItem.titleView) {
            controller.navigationItem.titleView = [[UIView alloc] initWithFrame:CGRectZero];
        }
        controller.navigationItem.title = @"";
    }

    NSMutableArray<UIView *> *roots = [NSMutableArray array];
    UINavigationBar *bar = controller.navigationController.navigationBar;
    if (bar) [roots addObject:bar];
    if (host) [roots addObject:host];

    NSUInteger hidden = 0;
    for (UIView *root in roots) {
        NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
        NSUInteger budget = 300;
        while (queue.count && budget > 0) {
            budget -= 1;
            UIView *view = queue.firstObject;
            [queue removeObjectAtIndex:0];
            if (view.tag == WCGroupTitleCardTag) continue;
            if ([view isKindOfClass:[UILabel class]]) {
                UILabel *label = (UILabel *)view;
                NSString *text = label.text ?: @"";
                BOOL looksTitle = ([text isEqualToString:@"微信"] ||
                                   [text hasPrefix:@"微信("] ||
                                   [text hasPrefix:@"微信（"]);
                if (looksTitle) {
                    CGRect rect = [label convertRect:label.bounds toView:root];
                    if (rect.origin.y < 240.0) {
                        label.alpha = hide ? 0.0 : 1.0;
                        hidden += 1;
                        continue;
                    }
                }
            }
            [queue addObjectsFromArray:view.subviews];
        }
    }
    WCLogLine(@"info", @"title", @"%@原生标题 labels=%lu title=%@",
              hide ? @"隐藏" : @"恢复", (unsigned long)hidden, hide ? @"空" : @"原样");
}

/// 标题区是否显示：关闭开关、或用户把标题文字显式清空 → 整块不占高度。
static BOOL WCGroupTitleVisible(void) {
    if (![WCPrefs shared].titleCardEnabled) return NO;
    id raw = [[WCPrefs shared] valueForKey:WCKeyTitleText];
    if (![raw isKindOfClass:[NSString class]]) return YES;   // 未设置 → 默认「微信」
    NSString *trim = [(NSString *)raw stringByTrimmingCharactersInSet:
                      [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return trim.length > 0;
}

static NSString *WCGroupTitleTextValue(void) {
    id raw = [[WCPrefs shared] valueForKey:WCKeyTitleText];
    if ([raw isKindOfClass:[NSString class]]) {
        NSString *trim = [(NSString *)raw stringByTrimmingCharactersInSet:
                          [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (trim.length > 0) return trim;
    }
    return @"微信";
}

/// 首页内容顶边：有导航栏时用导航栏底 + 8pt（导航栏高度保留），否则 safeArea + 8pt。
static CGFloat WCGroupContentTop(UIView *host, UIViewController *controller) {
    UINavigationBar *nav = controller.navigationController.navigationBar;
    if (nav && nav.window && !nav.hidden) {
        CGRect rect = [nav convertRect:nav.bounds toView:host];
        CGFloat maxY = CGRectGetMaxY(rect);
        if (maxY > 0.0) return maxY + 8.0;
    }
    return host.safeAreaInsets.top + 8.0;
}

/// 1.7.3：标题不再是一张玻璃卡 —— 22pt semibold + 可选 13pt 副标题，直接浮在白底上，
/// 左对齐到 x=24（面板 12 + 内缩 12），与第一组胶囊左边缘一致。
/// 返回值 = 面板应该顶到的 y（标题底 + 16；标题隐藏时 = 内容顶）。
static CGFloat WCGroupApplyTitle(UIView *host, UIViewController *controller) {
    if (!host) return 0.0;
    UIView *old = [host viewWithTag:WCGroupTitleCardTag];
    CGFloat contentTop = WCGroupContentTop(host, controller);

    if (!WCGroupTitleVisible()) {
        [old removeFromSuperview];
        // 标题关闭 / 文字为空：整块不占高度，但原生「微信(6)」仍保持隐藏（导航栏高度保留）。
        WCGroupSetNativeTitleHidden(controller, host, YES);
        return contentTop;
    }

    WCGroupSetNativeTitleHidden(controller, host, YES);

    UIView *block = old;
    if (!block || block.superview != host) {
        [block removeFromSuperview];
        block = [[UIView alloc] initWithFrame:CGRectZero];
        block.tag = WCGroupTitleCardTag;
        block.backgroundColor = [UIColor clearColor];   // 不再有玻璃卡
        [host addSubview:block];

        UILabel *title = [[UILabel alloc] initWithFrame:CGRectZero];
        title.tag = 101;
        title.userInteractionEnabled = NO;
        [block addSubview:title];

        UILabel *subtitle = [[UILabel alloc] initWithFrame:CGRectZero];
        subtitle.tag = 102;
        subtitle.userInteractionEnabled = NO;
        [block addSubview:subtitle];
    }

    NSString *text = WCGroupTitleTextValue();
    NSString *sub = [WCPrefs shared].titleSubtitle ?: @"";
    BOOL showsSub = (sub.length > 0);

    UIFont *titleFont = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleTitle2]
                         scaledFontForFont:[UIFont systemFontOfSize:26.0 weight:UIFontWeightSemibold]
                       maximumPointSize:31.2];   // 最大 1.2 倍
    UIFont *subFont = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleCaption1]
                       scaledFontForFont:[UIFont systemFontOfSize:13.0]
                     maximumPointSize:15.6];
    CGFloat titleH = ceil(titleFont.lineHeight);
    CGFloat subH = showsSub ? ceil(subFont.lineHeight) : 0.0;
    CGFloat blockH = titleH + (showsSub ? 4.0 : 0.0) + subH;
    CGFloat hostW = host.bounds.size.width;

    // 1.7.4：自定义标签位置（0=关闭，保持默认左上 / 1=左上 / 2=右上 / 3=底部左侧）。
    NSInteger placement = [WCPrefs shared].customLabelPlacement;
    if (placement < 0 || placement > 3) placement = 0;
    if (placement == 0) placement = 1;   // 关闭 = 不额外改位置，沿用默认左上

    CGSize titleSize = [text sizeWithAttributes:@{ NSFontAttributeName: titleFont }];
    CGSize subSize = showsSub ? [sub sizeWithAttributes:@{ NSFontAttributeName: subFont }]
                              : CGSizeZero;
    CGFloat width = MAX(80.0, hostW - WCGroupTitleInset * 2.0);
    CGFloat originX = WCGroupTitleInset;
    CGFloat originY = contentTop;
    NSTextAlignment align = NSTextAlignmentLeft;

    if (placement == 2) {
        // 右上：按内容宽度贴右边，避免整块拉满后右对齐换行。
        CGFloat natural = MAX(titleSize.width, subSize.width) + 8.0;
        width = MIN(hostW - WCGroupTitleInset * 2.0, MAX(80.0, natural));
        originX = hostW - WCGroupTitleInset - width;
        align = NSTextAlignmentRight;
    } else if (placement == 3) {
        // 底部左侧：贴在底栏上方，横竖屏都按实时 bounds + safeArea 计算。
        originY = host.bounds.size.height - WCDockReservedBottom(host) - blockH - 8.0;
        originY = MAX(contentTop, originY);
    }

    block.frame = CGRectMake(originX, originY, width, blockH);
    block.layer.zPosition = 800003.0;

    UILabel *title = [block viewWithTag:101];
    title.text = text;
    title.font = titleFont;
    title.textAlignment = align;
    title.textColor = WCGroupDarkTheme(block) ? [UIColor colorWithRed:0.949 green:0.949
                                                                  blue:0.949 alpha:1.0]  // #F2F2F2
                                              : [UIColor colorWithRed:0.067 green:0.067
                                                                  blue:0.067 alpha:1.0]; // #111
    title.frame = CGRectMake(0.0, 0.0, width, titleH);

    UILabel *subtitle = [block viewWithTag:102];
    subtitle.hidden = !showsSub;
    subtitle.text = sub;
    subtitle.font = subFont;
    subtitle.textAlignment = align;
    subtitle.textColor = [UIColor colorWithRed:0.541 green:0.541 blue:0.557 alpha:1.0];  // #8A8A8E
    subtitle.frame = CGRectMake(0.0, titleH + 4.0, width, subH);

    static NSString *const kPlacementNames[] = { @"关闭", @"左上", @"右上", @"底部左侧" };
    WCLogLine(@"info", @"title", @"标签位置=%@ frame=(%.0f,%.0f,%.0f,%.0f) host=%.0fx%.0f safe=(%.0f,%.0f)",
              kPlacementNames[placement], block.frame.origin.x, block.frame.origin.y,
              block.frame.size.width, block.frame.size.height, hostW, host.bounds.size.height,
              host.safeAreaInsets.top, host.safeAreaInsets.bottom);
    WCLogLine(@"info", @"title", @"标题 text=%@ 副标题=%@ frame=(%.0f,%.0f,%.0f,%.0f)",
              text, showsSub ? sub : @"-",
              block.frame.origin.x, block.frame.origin.y,
              block.frame.size.width, block.frame.size.height);

    // 底部左侧：标签在底部，面板仍从内容顶开始；左上 / 右上：面板在标签底 + 16。
    if (placement == 3) return contentTop;
    return CGRectGetMaxY(block.frame) + 16.0;
}

/// 1.7.6：面板宿主统一换成 keyWindow 最上层容器（和微信 + 菜单同层），
/// 拿不到窗口才退回首页控制器 view。
static UIView *WCGroupMountHost(void) {
    UIView *overlay = WCDockOverlayHost();
    if (overlay && overlay.window) return overlay;
    return gGroupHost;
}

static void WCGroupRemovePanelEverywhere(void) {
    [[gGroupHost viewWithTag:WCGroupPanelTag] removeFromSuperview];
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        [[window viewWithTag:WCGroupPanelTag] removeFromSuperview];
    }
}

/// 1.8.1：把原生列表彻底变成「透明底板」，避免它在自建面板下面透出白色。
static void WCGroupClearNativeTable(UITableView *table) {
    if (!table) return;
    table.backgroundColor = [UIColor clearColor];
    table.backgroundView = nil;
    table.separatorStyle = UITableViewCellSeparatorStyleNone;
    table.separatorInset = UIEdgeInsetsZero;
    for (UIView *sub in table.subviews) {
        if ([sub isKindOfClass:[UIScrollView class]]) {
            ((UIScrollView *)sub).backgroundColor = [UIColor clearColor];
        }
    }
}

/// 统计面板树里还剩多少个不透明白/黑底（0 才合格）。
static NSUInteger WCGroupOpaqueBackgroundCount(UIView *view, NSUInteger depth) {
    if (!view || depth > 12) return 0;
    NSUInteger count = 0;
    UIColor *bg = view.backgroundColor;
    if (bg) {
        CGFloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
        if ([bg getRed:&r green:&g blue:&b alpha:&a] && a >= 0.6 &&
            ((r > 0.97 && g > 0.97 && b > 0.97) || (r < 0.04 && g < 0.04 && b < 0.04))) {
            count += 1;
        }
    }
    for (UIView *sub in view.subviews) {
        count += WCGroupOpaqueBackgroundCount(sub, depth + 1);
    }
    return count;
}

/// 统计已挂上玻璃的组行（tag 9914 = WCGroupApplyGlass 的 blur 层）。
static NSUInteger WCGroupGlassRowCount(UIView *view, NSUInteger depth) {
    if (!view || depth > 12) return 0;
    NSUInteger count = (view.tag == 9914) ? 1 : 0;
    for (UIView *sub in view.subviews) {
        count += WCGroupGlassRowCount(sub, depth + 1);
    }
    return count;
}

static NSString *WCGroupTableBackgroundName(UITableView *table) {
    if (!table) return @"no-table";
    UIColor *bg = table.backgroundColor;
    if (!bg) return @"nil";
    CGFloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
    if (![bg getRed:&r green:&g blue:&b alpha:&a]) return @"other";
    if (a < 0.01) return @"clear";
    return [NSString stringWithFormat:@"#%02X%02X%02X a=%.2f",
            (unsigned int)(r * 255), (unsigned int)(g * 255), (unsigned int)(b * 255), a];
}

static NSString *gGroupGlassLogSignature = nil;
static NSString *gGroupPanelFrameSignature = nil;

static void WCGroupBuildPanel(void) {
    gGroupBuildResult = @"FAIL";
    gGroupBuildReason = @"unknown";
    UIView *host = gGroupHost;
    if (!host) {
        gGroupBuildReason = @"宿主nil";
        WCLogLine(@"info", @"group", @"跳过：宿主为 nil（首页尚未出现）");
        return;
    }
    if (!host.window) {
        gGroupBuildReason = @"宿主不在window";
        WCLogLine(@"info", @"group", @"跳过：宿主不在 window");
        return;
    }

    BOOL active = WCGroupPrefsEnabled();
    if (!active) {
        gGroupBuildReason = @"模块未启用";
        WCGroupRemovePanelEverywhere();
        [[host viewWithTag:WCGroupSegmentTag] removeFromSuperview];
        [[host viewWithTag:WCGroupTitleCardTag] removeFromSuperview];
        if (gGroupController.navigationController.view) {
            [[gGroupController.navigationController.view viewWithTag:WCGroupTitleCardTag]
             removeFromSuperview];
        }
        if (gGroupTable) gGroupTable.hidden = NO;   // 1.6.4：关闭分组必须把原生列表还回来
        gGroupMessagesMode = NO;
        return;
    }

    // 1.7.3：标题区返回面板应该顶到的 y（标题底 + 16，或直接是内容顶）。
    CGFloat panelTop = WCGroupApplyTitle(host, gGroupController);

    CGFloat hostWidth = host.bounds.size.width;
    if (hostWidth <= 0) {
        gGroupBuildReason = @"宿主宽度0";
        return;
    }

    // 1.7.4：页面底色与全局同色 —— home 的 view / MainFrameTableView / 标题区 /
    // 分段条都直接坐在这层白（深色黑）上，面板不再额外贴一层白卡。
    UIColor *paper = WCGlobalBackgroundColor(host);
    host.backgroundColor = paper;
    UITableView *mainTable = gGroupTable;
    if (mainTable) {
        mainTable.backgroundColor = paper;
        mainTable.backgroundView = nil;
    }

    NSArray<NSArray<NSDictionary *> *> *buckets = gGroupBuckets;
    // 1.6.0 关键修复：只有「列表已在 window 内且确实取到 cell」才允许置缓存。
    // 1.6.2：追加「至少采到一个会话」才允许置缓存 —— 旧逻辑把空结果也缓存成有效，
    // 之后签名一直为空，面板永远不建。
    if ((!gGroupCacheValid || !buckets) && gGroupTable && gGroupTable.window) {
        NSArray<NSArray<NSDictionary *> *> *collected = WCGroupCollect(gGroupTable);
        NSUInteger collectedTotal = 0;
        for (NSArray<NSDictionary *> *bucket in collected) collectedTotal += bucket.count;
        WCLogLine(@"info", @"group", @"采集 cells=%lu 候选=%lu 分组=%lu 总数=%lu 头像缺失=%lu table=%@",
                  (unsigned long)gGroupCellsSeen, (unsigned long)gGroupCandidates,
                  (unsigned long)collected.count, (unsigned long)collectedTotal,
                  (unsigned long)gGroupAvatarMisses,
                  NSStringFromClass([gGroupTable class]));
        // 1.7.1：头像可能晚于 cell 创建才设置，缺失只补采一次（0.3s 后）。
        if (gGroupAvatarMisses > 0 && !gGroupAvatarRetried) {
            gGroupAvatarRetried = YES;
            WCLogLine(@"info", @"group", @"头像缺失 %lu，0.3s 后重采一次",
                      (unsigned long)gGroupAvatarMisses);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                gGroupCacheValid = NO;
                WCGroupBuildNow(YES);
            });
        }
        if (collected.count == WCGroupIdents().count && collectedTotal > 0) {
            buckets = collected;
            gGroupBuckets = collected;
            gGroupCacheValid = YES;
        } else {
            buckets = nil;
            gGroupCacheValid = NO;
        }
    }
    if (buckets.count != WCGroupIdents().count) {
        // 列表尚未完成布局：等列表更新通知，不再空转重试。
        gGroupBuildReason = @"列表未就绪";
        WCGroupWaitForListNotify();
        return;
    }

    NSUInteger total = 0;
    for (NSArray<NSDictionary *> *bucket in buckets) {
        total += bucket.count;
    }
    if (total == 0) {
        WCGroupRemovePanelEverywhere();
        // 1.6.4：采集为空时绝不能让原生列表保持隐藏（否则首页一片空白）。
        if (gGroupTable) gGroupTable.hidden = NO;
        gGroupSignature = nil;
        gGroupLoggedSignature = nil;
        gGroupBuildReason = @"无会话";
        WCLogLine(@"info", @"group", @"空：cells=%lu 候选=%lu（等列表更新通知）",
                  (unsigned long)gGroupCellsSeen, (unsigned long)gGroupCandidates);
        WCGroupWaitForListNotify();
        return;
    }

    NSMutableString *signature = [NSMutableString string];
    for (NSArray<NSDictionary *> *bucket in buckets) {
        [signature appendFormat:@"%lu|", (unsigned long)bucket.count];
        for (NSDictionary *item in bucket) {
            [signature appendString:item[@"title"]];
            [signature appendString:@","];
        }
    }
    // 1.7.0：组名可被 prefs 改名，名字变化也要触发重建。
    for (NSString *ident in WCGroupIdents()) {
        [signature appendFormat:@"%@|", WCGroupIdentName(ident)];
    }
    // 1.7.3：顺序 / 单组隐藏变化也要触发重建。
    for (NSString *ident in WCGroupOrderedIdents()) {
        [signature appendFormat:@"%@=%d|", ident,
         [[WCPrefs shared] groupHiddenForIdent:ident] ? 1 : 0];
    }
    [signature appendFormat:@"%@|%.0f|%.0f|%.0f|%.0f|%@", gGroupExpanded ?: @"-",
                              gGroupOffset, gGroupSpacing, gGroupCorner, gGroupSpacingV,
                              gGroupChipHex ?: @"-"];

    // 1.6.4：分组接管列表 —— 面板与原生 MainFrameTableView 同区域、背景不透明。
    UITableView *table = gGroupTable;
    BOOL hasTable = (table != nil && table.window != nil);
    CGRect tableRect = hasTable ? [table convertRect:table.bounds toView:host] : CGRectZero;

    // 1.7.3：面板几何不再跟随 table bounds —— 左右固定 12pt 屏幕内缩，
    // 顶边由标题/内容顶决定，底边停在浮岛上方 8pt。这就是「凸出来」的根因修复。
    CGFloat safeTop = host.safeAreaInsets.top;
    CGFloat left = WCGroupPanelInset;
    CGFloat width = MAX(0.0, hostWidth - WCGroupPanelInset * 2.0);
    CGFloat top = MAX(safeTop + 8.0, panelTop);
    CGFloat bottom = WCDockReservedBottom(host);
    if (hasTable && CGRectGetMaxY(tableRect) > 0.0) {
        bottom = MIN(CGRectGetMaxY(tableRect), bottom);
    }
    if (bottom < top + 120.0) {
        bottom = MIN(host.bounds.size.height - 8.0, top + 240.0);
    }
    // 1.8.2：面板仍需足够高以容纳展开后的会话行（展开后列表可滚动）。
    CGFloat availableHeight = MAX(180.0, bottom - top);

    NSArray<NSString *> *idents = WCGroupIdents();          // 采集桶的固定下标
    NSArray<NSString *> *ordered = WCGroupOrderedIdents();  // 用户排序后的展示顺序
    NSMutableArray<NSDictionary *> *sections = [NSMutableArray array];
    NSUInteger sectionsCount = 0;
    NSUInteger totalItems = 0;
    NSMutableArray<NSString *> *groupCounts = [NSMutableArray array];
    for (NSString *ident in ordered) {
        NSUInteger bucketIndex = [idents indexOfObject:ident];
        if (bucketIndex == NSNotFound || bucketIndex >= buckets.count) continue;
        if (buckets[bucketIndex].count == 0) continue;   // 空组不显示 section
        // 1.7.3：单组隐藏开关。
        if ([[WCPrefs shared] groupHiddenForIdent:ident]) continue;
        // 1.7.1：自定义组没有名字（用户清空）就整组隐藏，不显示占位串。
        if ([ident hasPrefix:@"custom"] && !WCGroupIdentHasCustomName(ident)) continue;
        sectionsCount += 1;
        totalItems += buckets[bucketIndex].count;
        NSString *name = WCGroupIdentName(ident);
        BOOL custom = WCGroupIdentHasCustomName(ident);
        WCLogLine(@"info", @"group", @"组名 ident=%@ name=%@ src=%@",
                  ident, name, custom ? @"custom" : @"default");
        [groupCounts addObject:[NSString stringWithFormat:@"%@=%lu", name,
                                (unsigned long)buckets[bucketIndex].count]];
        // 「group」用 ident 作为折叠状态的稳定 key，显示名单独放 name。
        [sections addObject:@{ @"group": ident, @"name": name,
                               @"items": buckets[bucketIndex],
                               @"hex": gGroupChipHex ?: @"#1E70E6" }];
    }

    if (sectionsCount == 0) {
        // 全部组被隐藏 / 无会话：不显示空面板，也不占位。
        WCGroupRemovePanelEverywhere();
        gGroupBuildReason = @"无可显示分组";
        WCLogLine(@"info", @"group", @"无可显示分组（全部隐藏或无会话）");
        return;
    }

    // 1.8.4：面板高度改成「贴合内容」，折叠态不再留一大块空灰面板；
    // 只有展开组内容超过可用高度时才铺满并滚动（改前=584 → 改后=188 这类）。
    CGFloat contentH = 0.0;
    for (NSUInteger i = 0; i < sections.count; i++) {
        contentH += WCGroupFoldHeaderHeight;
        if (i > 0) contentH += gGroupSpacingV;
        NSString *ident = sections[i][@"group"];
        if (ident.length && [gGroupExpanded isEqualToString:ident]) {
            contentH += [sections[i][@"items"] count] * WCGroupFoldRowHeight;
        }
    }
    CGFloat hugHeight = contentH + WCGroupPanelPaddingV * 2.0 + 16.0;   // 16 = list 底部 inset
    CGFloat panelHeight = MIN(availableHeight, MAX(180.0, hugHeight));

    // 1.8.4：几何自证日志（只在数值变化时打印）。
    NSString *geoSignature = [NSString stringWithFormat:@"%.0f,%.0f,%.0f,%.0f#%.1f#%.0f#%.1f#%.1f#%.0f",
        left, top, width, panelHeight, (CGFloat)WCGroupPanelPaddingV,
        (CGFloat)WCGroupFoldRowHeight, gGroupSpacingV,
        (CGFloat)WCGroupPanelInset, width - WCGroupPanelInset * 2.0];
    if (![geoSignature isEqualToString:(gGroupGeometrySignature ?: @"")]) {
        gGroupGeometrySignature = [geoSignature copy];
        WCLogLine(@"info", @"group",
                  @"几何 面板=(%.0f,%.0f,%.0f,%.0f) 内边距=%.1f 行高=%.0f 头像=40.0 行距=%.1f 左右=(%.1f,%.1f) 内容宽=%.1f 改前=%.0f→改后=%.0f",
                  left, top, width, panelHeight, (CGFloat)WCGroupPanelPaddingV,
                  (CGFloat)WCGroupFoldRowHeight, gGroupSpacingV,
                  (CGFloat)WCGroupPanelInset, (CGFloat)WCGroupPanelInset,
                  width - WCGroupPanelInset * 2.0, availableHeight, panelHeight);
    }

    // 1.7.6：面板挂到 keyWindow 最上层容器（宿主切换时把旧副本清掉）。
    UIView *mountHost = WCGroupMountHost();
    if (mountHost != host) [[host viewWithTag:WCGroupPanelTag] removeFromSuperview];
    WCGroupFoldView *panel = (WCGroupFoldView *)[mountHost viewWithTag:WCGroupPanelTag];
    if (![panel isKindOfClass:[WCGroupFoldView class]]) {
        [panel removeFromSuperview];
        panel = [[WCGroupFoldView alloc] initWithFrame:CGRectZero];
        panel.tag = WCGroupPanelTag;
        [mountHost addSubview:panel];
    }
    [panel updateSections:sections];
    // 几何在首页控制器坐标系里算，挂到窗口浮层时再换算一次。
    CGRect panelFrame = CGRectMake(left, top, width, panelHeight);
    panel.frame = (mountHost == host) ? panelFrame
                                      : [host convertRect:panelFrame toView:mountHost];
    // 1.7.6：面板 z 降到 100；菜单在同一宿主里是 1000000+，
    // 跨窗口时靠「菜单出现即让位」兜底（见 WCGroupYieldForMenu）。
    panel.layer.zPosition = 100.0;
    panel.hidden = gGroupMessagesMode || gGroupYielded || gGroupPanelForceHidden ||
                   !gGroupPageVisible;
    // 1.8.1：frame 日志只在几何变化时打印一次。
    NSString *frameSignature =
        [NSString stringWithFormat:@"%.1f,%.1f,%.1f,%.1f#%d",
         panel.frame.origin.x, panel.frame.origin.y,
         panel.frame.size.width, panel.frame.size.height, panel.hidden ? 1 : 0];
    if (![frameSignature isEqualToString:(gGroupPanelFrameSignature ?: @"")]) {
        gGroupPanelFrameSignature = [frameSignature copy];
        WCLogLine(@"info", @"group",
                  @"面板 frame=(%.0f,%.0f,%.0f,%.0f) z=100 mount=%@ safe=%.0f top=%.0f bottom=%.0f table=(%.0f,%.0f,%.0f,%.0f) host=%.0fx%.0f",
                  panel.frame.origin.x, panel.frame.origin.y,
                  panel.frame.size.width, panel.frame.size.height,
                  NSStringFromClass([mountHost class]),
                  safeTop, top, bottom,
                  tableRect.origin.x, tableRect.origin.y,
                  tableRect.size.width, tableRect.size.height,
                  host.bounds.size.width, host.bounds.size.height);
    }

    // 1.8.1：确认自建面板已可见且 frame 非零后，才允许把原生列表藏掉；
    // 同时把原生表彻底透明化，避免它在玻璃下面透出白底。
    BOOL panelVisible = (!panel.hidden &&
                         panel.frame.size.width > 2.0 && panel.frame.size.height > 2.0);
    if (table) {
        WCGroupClearNativeTable(table);
        table.hidden = (gGroupPageVisible && !gGroupMessagesMode && panelVisible);
        if (!panel.hidden) [mountHost bringSubviewToFront:panel];
    }

    // 1.8.1：玻璃/不透明底证明日志（值变化才打印）。
    UIView *blurView = [panel viewWithTag:WCGroupPanelBlurTag];
    UIView *tintView = [panel viewWithTag:WCGroupPanelTintTag];
    BOOL blurOK = ([blurView isKindOfClass:[UIVisualEffectView class]] &&
                   ((UIVisualEffectView *)blurView).effect != nil);
    CGFloat tintAlpha = 0.0;
    if (tintView.backgroundColor) {
        CGFloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
        if ([tintView.backgroundColor getRed:&r green:&g blue:&b alpha:&a]) tintAlpha = a;
    }
    NSUInteger glassRows = WCGroupGlassRowCount(panel, 0);
    NSUInteger opaque = WCGroupOpaqueBackgroundCount(panel, 0);
    NSString *glassSignature =
        [NSString stringWithFormat:@"%d#%.2f#%lu#%lu#%lu#%d#%@",
         blurOK ? 1 : 0, tintAlpha, (unsigned long)glassRows,
         (unsigned long)sectionsCount, (unsigned long)opaque,
         table ? (table.hidden ? 1 : 0) : -1, WCGroupTableBackgroundName(table)];
    if (![glassSignature isEqualToString:(gGroupGlassLogSignature ?: @"")]) {
        gGroupGlassLogSignature = [glassSignature copy];
        WCLogLine(@"info", @"group",
                  @"玻璃 面板 blur=%d tint=%.2f 组行玻璃=%lu/%lu 不透明底=%lu 原生表 hidden=%d bg=%@",
                  blurOK ? 1 : 0, tintAlpha,
                  (unsigned long)glassRows, (unsigned long)sectionsCount,
                  (unsigned long)opaque,
                  table ? (table.hidden ? 1 : 0) : -1, WCGroupTableBackgroundName(table));
    }

    // 顶部分段控件「分组 / 消息」：两种模式都保留，取代 1.6.3 的小胶囊入口。
    // 1.7.1：顶部标题区不做卡片，分段切换改成右上角纯文字，不再压「Hey .」。
    UIView *segment = [host viewWithTag:WCGroupSegmentTag];
    if (!segment) {
        segment = [[UIView alloc] initWithFrame:CGRectZero];
        segment.tag = WCGroupSegmentTag;
        segment.backgroundColor = [UIColor clearColor];
        segment.layer.masksToBounds = YES;

        NSArray<NSString *> *titles = @[@"分组", @"消息"];
        for (NSInteger i = 0; i < 2; i++) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.tag = i;
            [button setTitle:titles[(NSUInteger)i] forState:UIControlStateNormal];
            button.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
            [button addTarget:WCGroupTarget()
                        action:@selector(wc_switchMode:)
              forControlEvents:UIControlEventTouchUpInside];
            [segment addSubview:button];
        }
        [host addSubview:segment];
    }
    // 1.7.3：分段不再压在第一组胶囊上 —— 放到标题行右侧的留白区（标题底 → 面板顶的 16pt 间隙）。
    CGFloat segmentY = MAX(safeTop + 4.0, top - 34.0);
    segment.frame = CGRectMake(left + width - 148.0, segmentY, 140.0, 28.0);
    segment.layer.zPosition = 800002.0;
    NSUInteger idx = 0;
    for (UIButton *button in segment.subviews) {
        if (![button isKindOfClass:[UIButton class]]) continue;
        button.frame = CGRectMake(idx * 70.0, 0.0, 70.0, 28.0);
        BOOL selected = (gGroupMessagesMode ? (idx == 1) : (idx == 0));
        UIColor *accent = WCGroupColorFromHex(gGroupChipHex ?: @"#1E70E6", 1.0);
        [button setTitleColor:selected ? accent : WCGroupTertiaryText(segment)
                     forState:UIControlStateNormal];
        idx += 1;
    }
    [host bringSubviewToFront:segment];

    gGroupSignature = [signature copy];
    gGroupRetryCount = 0;
    gGroupLoggedSignature = [signature copy];
    gGroupBuildResult = @"OK";
    gGroupBuildReason = @"-";
    WCLogLine(@"info", @"group", @"接管列表 table.hidden=%d mode=%@ 组=%lu 行=%lu 桶[%@] frame=(%.0f,%.0f,%.0f,%.0f) super=(%.0f,%.0f)",
              table ? (table.hidden ? 1 : 0) : -1,
              gGroupMessagesMode ? @"消息" : @"分组",
              (unsigned long)sectionsCount, (unsigned long)totalItems,
              groupCounts.count ? [groupCounts componentsJoinedByString:@" "] : @"空",
              panel.frame.origin.x, panel.frame.origin.y,
              panel.frame.size.width, panel.frame.size.height,
              host.bounds.size.width, host.bounds.size.height);
}

/// 1.7.6：列表还没数据时不再空转重试，等一条 updateMainSessionListNotify 再构建。
static void WCGroupWaitForListNotify(void) {
    static id observer = nil;
    if (observer) return;
    WCLogLine(@"info", @"group", @"列表无数据，等待 updateMainSessionListNotify 通知");
    observer = [[NSNotificationCenter defaultCenter]
        addObserverForName:@"updateMainSessionListNotify"
                    object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *note) {
        WCLogLine(@"info", @"group", @"收到 updateMainSessionListNotify，重建");
        if (!gGroupActive) return;
        WCGroupInvalidate();
        WCGroupBuildNow(YES);
    }];
}

/// 唯一构建入口。主线程 + 重入保护 + 0.4s 节流。
static void WCGroupBuildNow(BOOL force) {
    if (!gGroupActive) return;
    if (gGroupBuilding) return;
    if (!force && [NSDate timeIntervalSinceReferenceDate] - gGroupLastBuild < 0.4) return;

    gGroupLastBuild = [NSDate timeIntervalSinceReferenceDate];
    gGroupBuilding = YES;
    @try {
        WCGroupBuildPanel();
    } @catch (NSException *exception) {
        gGroupBuildResult = @"FAIL";
        gGroupBuildReason = @"异常";
        WCLogLine(@"warn", @"group", @"构建失败：%@", exception.reason);
    } @finally {
        gGroupBuilding = NO;
    }
}

/// 1.7.4：统一重建入口 —— 每次触发都重置重试计数，并打一行可追的日志：
/// [group] 重建 触发=viewDidAppear|foreground|window|scroll|rotate|refresh 结果=OK|FAIL 原因=..
static void WCGroupRebuild(NSString *trigger) {
    if (!gGroupActive) return;
    gGroupRetryCount = 0;
    gGroupRetryPending = NO;
    WCGroupInvalidate();
    WCGroupBuildNow(YES);
    WCLogLine([gGroupBuildResult isEqualToString:@"OK"] ? @"info" : @"warn",
              @"group", @"重建 触发=%@ 结果=%@ 原因=%@",
              trigger, gGroupBuildResult, gGroupBuildReason);
}

#pragma mark - 滚动触发（1.7.4）

static NSTimeInterval gGroupIncrementalLast = 0.0;

/// 1.7.8：只做增量 —— 扫当前 visibleCells，upsert 进常驻表再发布一次，绝不整表重建。
static void WCGroupIncrementalRefresh(NSString *trigger) {
    if (!gGroupActive || !WCGroupPrefsEnabled()) return;
    UITableView *table = gGroupTable;
    if (!table || !table.window) return;

    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now - gGroupIncrementalLast < 0.5) return;
    gGroupIncrementalLast = now;

    NSUInteger before = gGroupKnownOrder.count;
    NSUInteger scanned = 0;
    NSArray<NSString *> *idents = WCGroupIdents();
    for (UITableViewCell *cell in table.visibleCells) {
        NSIndexPath *indexPath = [table indexPathForCell:cell];
        if (!indexPath) continue;
        NSDictionary *item = WCGroupItemFromCell(cell, indexPath, idents, NULL);
        if (!item) continue;
        WCGroupKnownUpsert(item);
        WCGroupIndexCache()[indexPath] = item;
        scanned += 1;
    }
    NSUInteger after = gGroupKnownOrder.count;
    NSArray<NSArray<NSDictionary *> *> *buckets = WCGroupPublishBuckets();
    WCLogLine(@"info", @"group", @"增量 触发=%@ 前=%lu 后=%lu cells=%lu 桶[%@]",
              trigger, (unsigned long)before, (unsigned long)after,
              (unsigned long)scanned, WCGroupBucketSummary(buckets));
    gGroupBuckets = buckets;
    gGroupCacheValid = YES;
    gGroupSignature = nil;
    WCGroupBuildNow(YES);
}

static IMP gGroupScrollOrigIMP = NULL;
static IMP gGroupScrollMoveOrigIMP = NULL;
static IMP gGroupListNotifyOrigIMP = NULL;

static void WCGroupScrollEnded(id self, SEL _cmd, id scrollView) {
    if (gGroupScrollOrigIMP) {
        ((void (*)(id, SEL, id))gGroupScrollOrigIMP)(self, _cmd, scrollView);
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        WCGroupIncrementalRefresh(@"scroll-end");
    });
}

static void WCGroupScrollMoved(id self, SEL _cmd, id scrollView) {
    if (gGroupScrollMoveOrigIMP) {
        ((void (*)(id, SEL, id))gGroupScrollMoveOrigIMP)(self, _cmd, scrollView);
    }
    // 0.5s 节流由 WCGroupIncrementalRefresh 内部统一处理。
    WCGroupIncrementalRefresh(@"scroll");
}

static void WCGroupListNotifyUpdated(id self, SEL _cmd, id note) {
    if (gGroupListNotifyOrigIMP) {
        ((void (*)(id, SEL, id))gGroupListNotifyOrigIMP)(self, _cmd, note);
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        WCGroupIncrementalRefresh(@"list-notify");
    });
}

static void WCGroupInstallScrollHook(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        Class cls = NSClassFromString(@"NewMainFrameViewController");
        if (!cls) return;

        Method move = class_getInstanceMethod(cls, @selector(scrollViewDidScroll:));
        if (move) {
            gGroupScrollMoveOrigIMP = method_getImplementation(move);
            method_setImplementation(move, (IMP)WCGroupScrollMoved);
            WCLogLine(@"info", @"group", @"已挂钩 scrollViewDidScroll（0.5s 节流，增量）");
        } else {
            WCLogLine(@"warn", @"group", @"未找到 scrollViewDidScroll:，跳过滚动增量");
        }

        Method end = class_getInstanceMethod(cls, @selector(scrollViewDidEndDecelerating:));
        if (end) {
            gGroupScrollOrigIMP = method_getImplementation(end);
            method_setImplementation(end, (IMP)WCGroupScrollEnded);
            WCLogLine(@"info", @"group", @"已挂钩 scrollViewDidEndDecelerating（增量）");
        } else {
            WCLogLine(@"warn", @"group", @"未找到 scrollViewDidEndDecelerating:，跳过");
        }

        // 微信自己的列表更新方法，可能带一个参数；找不到就只靠滚动增量。
        Method notify = class_getInstanceMethod(cls, NSSelectorFromString(@"updateMainSessionListNotify:"));
        if (notify) {
            gGroupListNotifyOrigIMP = method_getImplementation(notify);
            method_setImplementation(notify, (IMP)WCGroupListNotifyUpdated);
            WCLogLine(@"info", @"group", @"已挂钩 updateMainSessionListNotify:（增量）");
        } else {
            WCLogLine(@"warn", @"group", @"未找到 updateMainSessionListNotify:，跳过");
        }
    });
}

#pragma mark - 生命周期

static void WCGroupObserve(BOOL on) {
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    NSOperationQueue *queue = [NSOperationQueue mainQueue];

    if (!on) {
        if (gGroupKeyObserver) [center removeObserver:gGroupKeyObserver];
        if (gGroupActiveObserver) [center removeObserver:gGroupActiveObserver];
        if (gGroupRotateObserver) [center removeObserver:gGroupRotateObserver];
        gGroupKeyObserver = nil;
        gGroupActiveObserver = nil;
        gGroupRotateObserver = nil;
        return;
    }
    if (gGroupKeyObserver && gGroupActiveObserver) return;
    gGroupKeyObserver = [center addObserverForName:UIWindowDidBecomeKeyNotification
                                             object:nil
                                              queue:queue
                                         usingBlock:^(NSNotification *note) {
                                             WCGroupRebuild(@"window");
                                         }];
    gGroupActiveObserver = [center addObserverForName:UIApplicationDidBecomeActiveNotification
                                               object:nil
                                                queue:queue
                                           usingBlock:^(NSNotification *note) {
                                               WCGroupRebuild(@"foreground");
                                           }];
    // 1.7.4：横竖屏切换时按实时 bounds + safeArea 重算标签 / 面板位置。
    gGroupRotateObserver = [center addObserverForName:UIDeviceOrientationDidChangeNotification
                                               object:nil
                                                queue:queue
                                           usingBlock:^(NSNotification *note) {
                                               WCGroupRebuild(@"rotate");
                                           }];
}

static void WCGroupStop(void) {
    gGroupActive = NO;
    WCGroupObserve(NO);

    UIView *host = gGroupHost;
    if (gGroupTable) gGroupTable.hidden = NO;   // 1.6.4：停用分组时恢复原生列表
    [[host viewWithTag:WCGroupPanelTag] removeFromSuperview];
    [[host viewWithTag:WCGroupSegmentTag] removeFromSuperview];
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        [[window viewWithTag:WCGroupPanelTag] removeFromSuperview];
        [[window viewWithTag:WCGroupSegmentTag] removeFromSuperview];
    }

    gGroupMessagesMode = NO;
    gGroupYielded = NO;
    gGroupPanelForceHidden = NO;
    gGroupPageVisible = NO;
    gGroupPageClass = nil;
    gGroupProgressiveRunning = NO;
    [gGroupYieldTimer invalidate];
    gGroupYieldTimer = nil;
    gGroupBuckets = nil;
    gGroupSignature = nil;
    gGroupCacheValid = NO;
    gGroupExpanded = nil;
    gGroupBuilding = NO;
    gGroupTable = nil;
    WCLogLine(@"info", @"group", @"已停用：overlay / 监听 / 缓存全部清理");
}

/// 只认首页控制器自己的 view：不往 keyWindow 上挂，避免面板浮在聊天页之上。
static UIView *WCGroupFindHost(void) {
    UIView *host = gGroupHost;
    if (host && host.window) return host;
    return nil;
}

static UITableView *WCGroupFirstTable(UIView *root) {
    if (!root) return nil;

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 240;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if (view.tag == WCGroupPanelTag) continue;
        if ([view isKindOfClass:[UITableView class]]) {
            return (UITableView *)view;
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return nil;
}

void WCGroupHandleController(UIViewController *controller) {
    WCGroupHandleControllerTrigger(controller, @"willAppear");
}

void WCGroupHandleControllerTrigger(UIViewController *controller, NSString *trigger) {
    if (!controller || !WCGroupPrefsEnabled()) return;
    NSString *name = NSStringFromClass([controller class]);
    if ([name rangeOfString:@"MainFrame"].location == NSNotFound) return;

    UIView *view = controller.view;
    if (!view || view.bounds.size.width <= 0) return;

    gGroupActive = YES;
    gGroupController = controller;
    gGroupHost = view;
    UITableView *table = WCGroupFirstTable(view);
    if (table) gGroupTable = table;
    WCLogLine(@"info", @"group", @"控制器 %@ host=%.0fx%.0f table=%@ window=%d 触发=%@",
              name, view.bounds.size.width, view.bounds.size.height,
              table ? NSStringFromClass([table class]) : @"-",
              view.window ? 1 : 0, trigger);

    gGroupExpanded = [[NSUserDefaults standardUserDefaults] stringForKey:WCGroupExpandedKey()];
    if (gGroupExpanded.length == 0) gGroupExpanded = nil;

    WCGroupInstallScrollHook();
    WCGroupInstallMenuYield();
    WCGroupObserve(YES);
    WCGroupInvalidate();
    gGroupRetryCount = 0;   // 每次触发都重新给重试机会（不是全局 3 次上限）
    WCGroupBuildNow(YES);
    WCLogLine([gGroupBuildResult isEqualToString:@"OK"] ? @"info" : @"warn",
              @"group", @"重建 触发=%@ 结果=%@ 原因=%@",
              trigger, gGroupBuildResult, gGroupBuildReason);
}

void WCGroupHandleMainTable(UIView *table) {
    // 1.5.0 起显式不做任何事：分组构建绝不在列表 layoutSubviews 里发生。
    (void)table;
}

void WCGroupRefresh(void) {
    BOOL active = WCGroupPrefsEnabled();

    dispatch_async(dispatch_get_main_queue(), ^{
        WCPrefs *prefs = [WCPrefs shared];
        gGroupOffset = prefs.groupOffset;
        gGroupSpacing = prefs.groupSpacing;
        gGroupCorner = prefs.groupCorner;
        // 1.7.2：组间上下间距 6–24，默认 12；点「显示效果」立即生效。
        double spacingV = prefs.groupSpacingV;
        if (spacingV < 6.0) spacingV = 6.0;
        if (spacingV > 24.0) spacingV = 24.0;
        gGroupSpacingV = spacingV;
        gGroupChipHex = prefs.groupChipHex ?: @"#1E70E6";

        if (!active) {
            if (gGroupActive) WCGroupStop();
            return;
        }

        gGroupActive = YES;
        UIView *host = WCGroupFindHost();
        if (!host) return;
        gGroupHost = host;

        if (!gGroupTable || !gGroupTable.window) {
            gGroupTable = WCGroupFirstTable(host);
        }
        gGroupExpanded = [[NSUserDefaults standardUserDefaults]
                          stringForKey:WCGroupExpandedKey()];
        if (gGroupExpanded.length == 0) gGroupExpanded = nil;

        WCGroupObserve(YES);
        WCGroupInstallScrollHook();
        WCGroupInvalidate();
        WCGroupBuildNow(NO);
        WCLogLine([gGroupBuildResult isEqualToString:@"OK"] ? @"info" : @"warn",
                  @"group", @"重建 触发=refresh 结果=%@ 原因=%@",
                  gGroupBuildResult, gGroupBuildReason);
    });
}

void WCGroupEnsureMessagesMode(void) {
    if (!gGroupActive) return;
    if (gGroupMessagesMode) return;
    gGroupMessagesMode = YES;
    WCLogLine(@"info", @"group", @"搜索前切回消息模式");
    WCGroupBuildNow(YES);
}

#pragma mark - 1.7.6 面板让位 / 二级页隐藏

static WCGroupFoldView *WCGroupExistingPanel(void) {
    UIView *panel = gGroupHost ? [gGroupHost viewWithTag:WCGroupPanelTag] : nil;
    if ([panel isKindOfClass:[WCGroupFoldView class]]) return (WCGroupFoldView *)panel;
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        UIView *candidate = [window viewWithTag:WCGroupPanelTag];
        if ([candidate isKindOfClass:[WCGroupFoldView class]]) {
            return (WCGroupFoldView *)candidate;
        }
    }
    return nil;
}

// 1.7.8：让位日志只在状态变化时打，0.6s 轮询 home=0 不再重复刷屏。
static BOOL gGroupHiddenLogValid = NO;
static BOOL gGroupHiddenLogYield = NO;
static BOOL gGroupHiddenLogHidden = NO;
static BOOL gGroupHiddenLogHome = NO;

static void WCGroupApplyPanelHidden(void) {
    BOOL hidden = gGroupMessagesMode || gGroupYielded || gGroupPanelForceHidden ||
                  !gGroupPageVisible;
    WCGroupFoldView *panel = WCGroupExistingPanel();
    if (panel) panel.hidden = hidden;
    // 1.8.3：面板隐藏时必须同时置底，避免玻璃层还在模态下方露出一条边。
    if (panel) panel.layer.zPosition = hidden ? 0.0 : 100.0;
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        UIView *other = [window viewWithTag:WCGroupPanelTag];
        if (other) other.hidden = hidden;
    }
    // 1.7.7：面板隐藏时把原生列表恢复出来（消息列表不能因为面板隐藏而消失）。
    if (gGroupTable) gGroupTable.hidden = hidden ? NO : !gGroupMessagesMode;

    BOOL yield = gGroupYielded ? YES : NO;
    BOOL home = gGroupPageVisible ? YES : NO;
    if (!gGroupHiddenLogValid ||
        yield != gGroupHiddenLogYield ||
        hidden != gGroupHiddenLogHidden ||
        home != gGroupHiddenLogHome) {
        gGroupHiddenLogValid = YES;
        gGroupHiddenLogYield = yield;
        gGroupHiddenLogHidden = hidden;
        gGroupHiddenLogHome = home;
        WCLogLine(@"info", @"group", @"面板让位 菜单=%d hidden=%d home=%d",
                  yield ? 1 : 0, hidden ? 1 : 0, home ? 1 : 0);
    }
}

void WCGroupSetPanelHidden(BOOL hidden) {
    if (!gGroupActive) return;
    if (gGroupPanelForceHidden == hidden) return;
    gGroupPanelForceHidden = hidden;
    WCGroupApplyPanelHidden();
}

/// 1.7.7：只有首页允许出现分组面板；其它主 tab / push 页调用时立即隐藏并还原列表。
void WCGroupSetPageVisible(BOOL visible, NSString *cls) {
    NSString *key = cls.length ? cls : @"-";
    BOOL changed = (gGroupPageVisible != visible);
    gGroupPageVisible = visible;
    if (!changed && [gGroupPageClass isEqualToString:key]) return;
    gGroupPageClass = [key copy];
    WCLogLine(@"info", @"group", @"页面 home=%d cls=%@", visible ? 1 : 0, key);
    if (!changed) return;

    if (visible && gGroupActive) {
        // 回首页：面板之前可能被移除 / 隐藏，重建一次再交给 ApplyPanelHidden 恢复显示。
        WCGroupInvalidate();
        WCGroupBuildNow(YES);
    }
    WCGroupApplyPanelHidden();
}

void WCGroupYieldForMenu(BOOL menuOpen) {
    if (!gGroupActive) return;
    if (gGroupYielded == menuOpen) return;
    gGroupYielded = menuOpen;
    // 1.8.3：分组面板和悬浮搜索胶囊一起让位，收起后一起恢复。
    WCDockSetSceneObscured(menuOpen);
    WCGroupApplyPanelHidden();
}

/// 1.7.6：弹层类名过滤 —— 只在明显是菜单 / 弹层时让位，避免误伤普通页面。
/// 1.8.3：补充分享 / 转发 / 选联系人 / 选图面板；不用裸 "Contact"，
/// 避免把「通讯录」ContactsViewController 误判成弹层。
static BOOL WCGroupMenuLikeClass(NSString *name) {
    static NSArray<NSString *> *keys;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keys = @[@"Menu", @"Sheet", @"Action", @"Alert", @"Popup", @"Popover",
                 @"Share", @"Forward", @"Picker", @"ContactSelect", @"SelectContact",
                 @"ContactPicker"];
    });
    if (name.length == 0) return NO;
    for (NSString *key in keys) {
        if ([name rangeOfString:key options:NSCaseInsensitiveSearch].location != NSNotFound) {
            return YES;
        }
    }
    return NO;
}

/// 当前最上层「菜单 / 分享 / 选择器」控制器类名；命中返回 YES，并带出命中类名。
static BOOL WCGroupModalOverlayVisible(NSString **clsOut) {
    if (clsOut) *clsOut = nil;
    for (UIWindow *window in [UIApplication sharedApplication].windows.reverseObjectEnumerator) {
        UIViewController *top = window.rootViewController;
        NSUInteger guard = 0;
        while (top.presentedViewController && guard < 8) {
            top = top.presentedViewController;
            guard += 1;
        }
        if (!top) continue;

        NSMutableArray<NSString *> *candidates = [NSMutableArray array];
        [candidates addObject:NSStringFromClass([top class])];
        // 分享面板常被包在导航控制器里：再看它的 topViewController 与直接子控制器。
        if ([top isKindOfClass:[UINavigationController class]]) {
            UIViewController *inner = ((UINavigationController *)top).topViewController;
            if (inner) [candidates addObject:NSStringFromClass([inner class])];
        }
        for (UIViewController *child in top.childViewControllers) {
            [candidates addObject:NSStringFromClass([child class])];
        }

        for (NSString *name in candidates) {
            if (!WCGroupMenuLikeClass(name)) continue;
            // 通讯录页本身不是弹层（双保险：类名含 ContactsViewController 直接跳过）。
            if ([name rangeOfString:@"ContactsViewController"].location != NSNotFound) continue;
            if (clsOut) *clsOut = name;
            return YES;
        }
    }
    return NO;
}

/// 0.6s 轻量轮询（只查 presented 链，不 hook 任何方法），
/// 微信 + 菜单 / 分享 / 转发 / 选联系人 / 系统相弹出时也能让位；只切一次状态。
static void WCGroupStartYieldWatcher(void) {
    if (gGroupYieldTimer) return;
    gGroupYieldTimer = [NSTimer scheduledTimerWithTimeInterval:0.6
                                                       repeats:YES
                                                         block:^(NSTimer *timer) {
        (void)timer;
        if (!gGroupActive) return;
        NSString *cls = nil;
        BOOL overlay = WCGroupModalOverlayVisible(&cls);
        if (overlay == gGroupYielded) return;
        if (overlay) {
            WCLogLine(@"info", @"group", @"遮挡 隐藏=1 原因=模态 cls=%@", cls ?: @"-");
        } else {
            WCLogLine(@"info", @"group", @"遮挡 隐藏=0 原因=恢复 cls=-");
        }
        WCGroupYieldForMenu(overlay);
    }];
}

/// 微信 + 菜单 / 弹层会新开一个 UIWindow，监听它出现就把面板让位，
/// 窗口消失再恢复；拿不到就什么都不做，绝不瞎 hook。
static void WCGroupInstallMenuYield(void) {
    static BOOL installed = NO;
    if (installed) return;
    installed = YES;

    WCGroupStartYieldWatcher();

    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserverForName:UIWindowDidBecomeVisibleNotification
                        object:nil
                         queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification *note) {
        UIWindow *window = note.object;
        if (![window isKindOfClass:[UIWindow class]]) return;
        if (!gGroupActive) return;
        if (window == gGroupHost.window) return;
        if (gGroupYielded) return;
        WCLogLine(@"info", @"group", @"遮挡 隐藏=1 原因=窗口 cls=%@",
                  NSStringFromClass([window class]));
        WCGroupYieldForMenu(YES);
    }];
    [center addObserverForName:UIWindowDidBecomeHiddenNotification
                        object:nil
                         queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification *note) {
        if (!gGroupYielded) return;
        WCLogLine(@"info", @"group", @"遮挡 隐藏=0 原因=恢复 cls=-");
        WCGroupYieldForMenu(NO);
    }];
    [center addObserverForName:UIWindowDidResignKeyNotification
                        object:nil
                         queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification *note) {
        if (!gGroupYielded) return;
        WCLogLine(@"info", @"group", @"遮挡 隐藏=0 原因=恢复 cls=-");
        WCGroupYieldForMenu(NO);
    }];
}

void WCGroupStart(void) {
    // 默认关闭：进程启动时不注册任何监听、不构建任何视图。
    WCGroupRefresh();
}
