#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 布局微调（UIKit 通用层）。所有函数内部都检查 layoutEnabled 开关，
// 关闭时直接返回；调用方可以无条件调用。

#ifdef __cplusplus
extern "C" {
#endif

void WCLayoutApplyToCell(UITableViewCell *cell);
void WCLayoutApplyToNavBar(UINavigationBar *bar);
void WCLayoutApplyToTabBar(UITabBar *bar);
UIStatusBarStyle WCLayoutPreferredStatusBarStyle(UIStatusBarStyle fallback);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
