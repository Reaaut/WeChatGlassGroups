#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 首页会话分组（QQ 式折叠分组）。
//
// 设计原则（视觉纪律）：
// - 不改微信的数据源、不重排列表，只在首页叠加一层"分组面板"；
// - 分组面板默认收成一个小胶囊，展开后是若干半透明圆角卡片；
// - 折叠状态写 NSUserDefaults，重启微信后保持；
// - 所有视图都挂在首页根视图上，关闭开关时整体移除，不留残余。

#ifdef __cplusplus
extern "C" {
#endif

/// 注册窗口 / 激活通知。进程内只需调用一次。
void WCGroupStart(void);

/// 重新读取偏好并刷新（关闭时移除面板）。
void WCGroupRefresh(void);

/// 首页出现时调用：记录宿主视图并构建面板。
void WCGroupHandleController(UIViewController *controller);

/// 1.7.4：带触发来源的重建（viewDidAppear / foreground / scroll / rotate），日志可追。
void WCGroupHandleControllerTrigger(UIViewController *controller, NSString *trigger);

/// 首页列表布局时调用：刷新分组内容（内部有节流 + 内容签名比对）。
void WCGroupHandleMainTable(UIView *table);

/// 1.7.5：搜索前把面板切回「消息」模式，避免分组面板挡住搜索。
void WCGroupEnsureMessagesMode(void);

/// 1.7.6：二级页 / 非首页时隐藏面板（浮岛隐藏逻辑同步调用）。
void WCGroupSetPanelHidden(BOOL hidden);

/// 1.7.7：分组面板只在首页出现。首页 appear 传 YES，四个主 tab 与任何 push 页传 NO。
void WCGroupSetPageVisible(BOOL visible, NSString *cls);

/// 1.7.6：菜单打开期间面板让位（宁可短暂隐藏，也不挡微信 + 菜单）。
void WCGroupYieldForMenu(BOOL menuOpen);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
