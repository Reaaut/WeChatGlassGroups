#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 微信宿主 UI 锚点表。
//
// 类名来源：参考包 WCGlass 4.1.6 的 __objc_classname 字符串里公开存在的
// 微信宿主类（不是抄代码，只复用"微信自己本来就有的类名"）。
// 所有锚点都必须运行时校验：类/方法不存在就跳过并写日志，
// 微信改版导致类名变化时只是丢对应模块，不影响注入本身，也不会崩。

#ifdef __cplusplus
extern "C" {
#endif

/// 解析锚点类；不存在返回 Nil。结果会缓存，只在第一次查表并写日志。
Class WCAnchorClass(NSString *_Nullable name);

/// 锚点类是否存在。
BOOL WCAnchorExists(NSString *_Nullable name);

/// 启动时打印所有锚点的命中情况（OK / SKIP）+ 命中数量。
void WCAnchorLogAll(void);

/// 安装锚点 hook（首页 / 聊天页 / 搜索页 / 首页列表 / 搜索栏）。
/// 每个 hook 都有类、方法存在性校验；失败只丢对应锚点。
void WCAnchorInstallAll(void);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
