#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 按表面处理的毛玻璃（iOS 16 上模拟 iOS 26 的"半透明 + 模糊 + 高光边"）。
//
// 设计原则：
// - 不全局刷底色。导航栏 / 底栏 / 搜索栏各自插 UIVisualEffectView + 白色 tint + 1px 高光边；
// - 列表只做"页面背景模糊 + cell 卡片化"，不把 cell 变透明；
// - 所有挂载都按 tag 幂等复用，重复调用不会叠加视图；
// - 任何失败只影响视觉，不影响微信本身。

/// 1.8.4：液态玻璃共用配方（底栏浮岛 / 分组面板与组行 / 头像菜单都走这一套）。
typedef enum {
    WCLiquidGlassStyleDock = 0,   // 底栏：已有原生模糊底，只补 tint / 高光 / 羽化
    WCLiquidGlassStylePanel = 1,  // 面板 / 组行：backdrop 模糊 + tint + sheen + 描边 + 羽化
} WCLiquidGlassStyle;

/// 对 view 应用（或复用）液态玻璃分层，幂等；topOnly=YES 时只圆上面两角。
void WCApplyLiquidGlass(UIView *view, CGFloat corner, WCLiquidGlassStyle style, BOOL topOnly);

#ifdef __cplusplus
extern "C" {
#endif

/// 注册窗口/激活通知，保证新出现的表面也能被刷新。进程内只需调用一次。
void WCSurfaceGlassStart(void);

/// 重新读取偏好并刷新所有已存在的表面（导航栏 / 底栏 / 搜索栏 / 已标记列表）。
void WCSurfaceGlassRefresh(void);

/// 移除所有由本模块挂载的模糊视图（关闭功能时调用）。
void WCSurfaceGlassRemoveAll(void);

/// 页面级处理：给 controller.view 背后挂模糊层，并把其中的 UITableView 标记为"可卡片化"。
void WCSurfaceGlassHandleController(UIViewController *controller);

/// 首页列表：透明化 + 在父视图第 0 层挂模糊。
void WCSurfaceGlassHandleMainTable(UIView *table);

/// 导航栏 / 底栏：在 UIKit 背景视图内插模糊 + 上下高光描边。
void WCSurfaceGlassApplyToNavBar(UINavigationBar *bar);
void WCSurfaceGlassApplyToTabBar(UITabBar *bar);

/// 搜索栏容器：圆角 + 模糊 + 1px 描边。
void WCSurfaceGlassApplyToSearchHost(UIView *host);

/// cell 卡片化：只对"已被本模块标记的列表"生效，避免影响微信其他页面。
void WCSurfaceCardApplyToCell(UITableViewCell *cell);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
