#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 这些函数同时被 Objective-C(.x) 和 Objective-C++(.mm) 调用，
// 必须固定 C linkage，否则 .mm 里的定义会被 C++ 名称修饰，.x 链接时找不到。
#ifdef __cplusplus
extern "C" {
#endif

/// 读取偏好并刷新毛玻璃状态（安装 / 移除 blur view）。
/// 偏好面板发来 Darwin 通知后由 Tweak.xm 调用。
void WCGlassRefresh(void);

/// 注册 UIWindow 通知（key window / visible / app active），
/// 保证新创建的窗口也能挂上 blur。进程内只需调用一次。
void WCGlassStart(void);

/// 把毛玻璃背景挂到指定 window 的第 0 层。
/// 内部做 window 级别 / 尺寸 / 类名校验，失败时静默返回。
void WCGlassAttachToWindow(UIWindow *window);

/// 移除所有已挂载的 blur view。
void WCGlassRemoveAll(void);

/// 把"接近纯白且不透明"的背景色改成半透明白，露出后面的 blur。
/// 不是白色 / 透明 / 动态色失败时返回 nil（调用方沿用原色）。
/// 这是 UIKit 通用层实现，不依赖任何微信私有类名。
UIColor *_Nullable WCGlassAdjustedColor(UIView *view, UIColor *_Nullable color);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
