#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#ifdef __cplusplus
extern "C" {
#endif

// 1.7.5 全局自定义壁纸。
//
// - 固定路径：<WCTheme>/bg-light.png、bg-dark.png（也接受同名 .jpg）；
// - 主 VC 的 view 最底层插一个 UIImageView（tag 0x57434247），列表 / 页面底色转 clear；
// - traitCollection 变化时按 userInterfaceStyle 自动换图；
// - 未设置的模式回落到另一张；两张都没有则不插图，恢复纯白 / 纯黑。

/// 壁纸文件目录（rootless 为 /var/jb/var/mobile/Library/WCTheme）。
NSString *WCWallpaperDirectory(void);

/// 指定模式当前实际存在的文件路径（优先 png，其次 jpg）；不存在返回 nil。
NSString *_Nullable WCWallpaperExistingPath(BOOL dark);

/// 保存到指定模式：统一转 PNG 落盘，成功后返回 YES 并写日志。
BOOL WCWallpaperSaveImage(UIImage *_Nullable image, BOOL dark, NSString *_Nullable *_Nullable message);

/// 删除浅色 / 深色两张壁纸，返回是否删掉了至少一张。
BOOL WCWallpaperClear(void);

/// 是否任意一张壁纸存在。
BOOL WCWallpaperActive(void);

/// 把壁纸插到某个控制器的 view 最底层；无壁纸时移除并恢复纯白 / 纯黑。
void WCWallpaperApplyToController(UIViewController *controller);

/// 重新应用到最后一次登记的控制器（设置页保存 / 清除后调用）。
void WCWallpaperRefresh(void);

/// 1.7.7：安装 UITableViewCell 背景 hook（进程内只装一次）。
void WCWallpaperInstallCellHook(void);

/// 壁纸存在时把玻璃 tint alpha 减 0.1。
CGFloat WCWallpaperTintAlpha(CGFloat alpha);

/// 壁纸存在时把阴影强度减半。
CGFloat WCWallpaperShadowOpacity(CGFloat opacity);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
