#import "WCLog.h"

#import <objc/runtime.h>
#import <os/log.h>
#import <unistd.h>

static const unsigned long long WCLogMaxBytes = 512 * 1024;
static const NSUInteger WCLogTailBytesAfterTrim = 256 * 1024;
static NSString *const WCLogVersionPlaceholder = @"unknown";
static NSString *gWCLogVersion = nil;
static BOOL gWCLogFileBroken = NO;
static NSDateFormatter *gWCLogFormatter = nil;

static NSObject *WCLogLockObject(void) {
    static NSObject *lock;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        lock = [[NSObject alloc] init];
    });
    return lock;
}

/// 异步批量落盘：主线程只把行追加到内存缓冲，真正的文件 IO 在串行队列上做。
static dispatch_queue_t WCLogSerialQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        queue = dispatch_queue_create("com.wctheme.dev.log", DISPATCH_QUEUE_SERIAL);
    });
    return queue;
}

static NSMutableString *WCLogBuffer(void) {
    static NSMutableString *buffer;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        buffer = [NSMutableString string];
    });
    return buffer;
}

static BOOL gWCLogFlushScheduled = NO;

NSString *WCLogDirectory(void) {
    static NSString *dir;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        BOOL rootless = [[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"];
        NSString *base = rootless ? @"/var/jb" : @"";
        dir = [base stringByAppendingPathComponent:@"var/mobile/Library/WCTheme"];
    });
    return dir;
}

NSString *WCLogFilePath(void) {
    return [WCLogDirectory() stringByAppendingPathComponent:@"wctheme.log"];
}

static NSString *WCLogTimestamp(void) {
    @synchronized (WCLogLockObject()) {
        if (gWCLogFormatter == nil) {
            NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
            fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss.SSS";
            fmt.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
            gWCLogFormatter = fmt;
        }
        return [gWCLogFormatter stringFromDate:[NSDate date]];
    }
}

/// 超限时按行边界截断，保留最近约 256 KB，避免无限增长。
static void WCLogTrimIfNeeded(NSString *path, unsigned long long size) {
    if (size <= WCLogMaxBytes) return;

    NSData *data = [NSData dataWithContentsOfFile:path];
    if (data.length == 0) return;

    NSUInteger keep = MIN((NSUInteger)data.length, WCLogTailBytesAfterTrim);
    NSData *tail = [data subdataWithRange:NSMakeRange(data.length - keep, keep)];

    // 从第一个换行之后开始，保证不把半行写进文件。
    NSRange nl = [tail rangeOfData:[NSData dataWithBytes:"\n" length:1]
                            options:0
                              range:NSMakeRange(0, tail.length)];
    if (nl.location != NSNotFound && nl.location + 1 < tail.length) {
        tail = [tail subdataWithRange:NSMakeRange(nl.location + 1, tail.length - nl.location - 1)];
    }

    NSString *marker = [NSString stringWithFormat:@"%@ [warn ][log   ] 日志超过 %llu KB，已截断旧内容\n",
                        WCLogTimestamp(), WCLogMaxBytes / 1024];
    NSMutableData *merged = [NSMutableData dataWithData:[marker dataUsingEncoding:NSUTF8StringEncoding]];
    [merged appendData:tail];
    [merged writeToFile:path atomically:NO];
}

static BOOL WCLogEnsureFile(NSString *path) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *dir = [path stringByDeletingLastPathComponent];

    if (![fm fileExistsAtPath:dir]) {
        [fm createDirectoryAtPath:dir
       withIntermediateDirectories:YES
                        attributes:@{NSFilePosixPermissions : @0755}
                             error:NULL];
    }
    if (![fm fileExistsAtPath:path]) {
        [fm createFileAtPath:path
                     contents:[NSData data]
                   attributes:@{NSFilePosixPermissions : @0644}];
    }
    return [fm isWritableFileAtPath:path];
}

static void WCLogAppendLocked(NSString *line) {
    NSString *path = WCLogFilePath();

    if (!WCLogEnsureFile(path)) {
        if (!gWCLogFileBroken) {
            gWCLogFileBroken = YES;
            NSLog(@"[WCTheme] 日志写入失败，降级到 NSLog：%@", path);
        }
        return;
    }

    NSDictionary *attrs = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:NULL];
    unsigned long long size = [attrs fileSize];
    if (size > WCLogMaxBytes) {
        @try {
            WCLogTrimIfNeeded(path, size);
        } @catch (NSException *exception) {
            // 截断失败不影响继续追加。
        }
    }

    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    if (!handle) {
        if (!gWCLogFileBroken) {
            gWCLogFileBroken = YES;
            NSLog(@"[WCTheme] 日志句柄打开失败，降级到 NSLog：%@", path);
        }
        return;
    }

    @try {
        [handle seekToEndOfFile];
        [handle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
    } @catch (NSException *exception) {
        if (!gWCLogFileBroken) {
            gWCLogFileBroken = YES;
            NSLog(@"[WCTheme] 日志写入异常，降级到 NSLog：%@", exception.reason);
        }
    } @finally {
        [handle closeFile];
    }
}

/// 触发一次异步刷盘；已经有排队的 flush 时不再重复入队，天然按批合并。
static void WCLogFlushAsync(void) {
    @synchronized (WCLogLockObject()) {
        if (gWCLogFlushScheduled) return;
        gWCLogFlushScheduled = YES;
    }
    dispatch_async(WCLogSerialQueue(), ^{
        NSString *chunk = nil;
        @synchronized (WCLogLockObject()) {
            NSMutableString *buffer = WCLogBuffer();
            if (buffer.length > 0) {
                chunk = [buffer copy];
                [buffer setString:@""];
            }
            gWCLogFlushScheduled = NO;
        }
        if (chunk.length > 0) {
            WCLogAppendLocked(chunk);
        }
    });
}

void WCLogBoot(NSString *version) {
    @synchronized (WCLogLockObject()) {
        gWCLogVersion = [version copy] ?: WCLogVersionPlaceholder;
        NSString *line = [NSString stringWithFormat:@"%@ [boot ][core  ] loaded v%@ pid=%d\n",
                          WCLogTimestamp(), gWCLogVersion, getpid()];
        WCLogAppendLocked(line);

        os_log_t log = os_log_create("com.wctheme.dev", "core");
        os_log(log, "WCTheme %{public}s loaded, pid=%d", gWCLogVersion.UTF8String, getpid());
    }
}

void WCLogLine(NSString *level, NSString *module, NSString *format, ...) {
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);

    NSString *line = [NSString stringWithFormat:@"%@ [%-5s][%-6s] %@\n",
                      WCLogTimestamp(), level.UTF8String, module.UTF8String, message];

    // 只写内存，文件 IO 全部交给后台串行队列批量完成。
    @synchronized (WCLogLockObject()) {
        [WCLogBuffer() appendString:line];
    }
    WCLogFlushAsync();

    os_log_t log = os_log_create("com.wctheme.dev", module.UTF8String);
    os_log(log, "%{public}s", message.UTF8String);
}

NSArray<NSString *> *WCLogTail(NSUInteger maxLines) {
    NSData *data = [NSData dataWithContentsOfFile:WCLogFilePath()];
    if (data.length == 0) return @[];

    NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    if (text.length == 0) return @[];

    NSMutableArray<NSString *> *lines = [[text componentsSeparatedByString:@"\n"] mutableCopy];
    // 末尾通常有一个空元素（文件以 \n 结尾）。
    while (lines.count && [lines.lastObject length] == 0) {
        [lines removeLastObject];
    }

    if (lines.count <= maxLines) return lines;
    return [lines subarrayWithRange:NSMakeRange(lines.count - maxLines, maxLines)];
}

BOOL WCHookProbe(NSString *module, NSString *className, NSString *selectorName) {
    Class cls = NSClassFromString(className);
    if (cls == Nil) {
        WCLogLine(@"hook", module, @"SKIP %@（类不存在）", className);
        return NO;
    }
    SEL sel = NSSelectorFromString(selectorName);
    if (sel == NULL || !class_getInstanceMethod(cls, sel)) {
        WCLogLine(@"hook", module, @"SKIP %@.%@（方法不存在）", className, selectorName);
        return NO;
    }
    WCLogLine(@"hook", module, @"OK %@.%@", className, selectorName);
    return YES;
}
