#import "WCLayout.h"
#import "WCPrefs.h"

static BOOL WCLayoutActive(void) {
    WCPrefs *prefs = [WCPrefs shared];
    // 1.5.1：旧布局模块（cell 内缩 / 导航栏改色）风险最高，必须显式打开 moduleLayout。
    return prefs.enabled && prefs.moduleLayout && prefs.layoutEnabled;
}

void WCLayoutApplyToCell(UITableViewCell *cell) {
    if (!cell || !WCLayoutActive()) return;

    WCPrefs *prefs = [WCPrefs shared];
    UIView *content = cell.contentView;
    if (!content) return;

    double radius = prefs.cellCornerRadius;
    if (radius > 0.0) {
        content.layer.cornerRadius = (CGFloat)radius;
        content.layer.masksToBounds = YES;
    }

    double inset = prefs.cellInset;
    if (inset > 0.0) {
        CGRect bounds = cell.bounds;
        CGRect frame = content.frame;
        frame.origin.x = (CGFloat)inset;
        frame.size.width = MAX(0.0, bounds.size.width - (CGFloat)inset * 2.0);
        content.frame = frame;
    }
}

void WCLayoutApplyToNavBar(UINavigationBar *bar) {
    if (!bar || !WCLayoutActive()) return;

    double alpha = [WCPrefs shared].navBarAlpha;
    if (alpha >= 1.0) return;

    if (!bar.isTranslucent) {
        bar.translucent = YES;
    }

    // 只改 UIKit 背景视图（类名含 Background），不碰微信自定义视图。
    for (UIView *subview in bar.subviews) {
        NSString *className = NSStringFromClass([subview class]);
        if ([className rangeOfString:@"Background"].location != NSNotFound) {
            subview.alpha = (CGFloat)alpha;
        }
    }
}

void WCLayoutApplyToTabBar(UITabBar *bar) {
    if (!bar || !WCLayoutActive()) return;

    double alpha = [WCPrefs shared].tabBarAlpha;
    if (alpha >= 1.0) return;

    for (UIView *subview in bar.subviews) {
        NSString *className = NSStringFromClass([subview class]);
        if ([className rangeOfString:@"Background"].location != NSNotFound) {
            subview.alpha = (CGFloat)alpha;
        }
    }
}

UIStatusBarStyle WCLayoutPreferredStatusBarStyle(UIStatusBarStyle fallback) {
    if (!WCLayoutActive()) return fallback;

    NSInteger style = [WCPrefs shared].statusBarStyle;
    if (style == 2) return UIStatusBarStyleLightContent;
    if (style == 1) return UIStatusBarStyleDarkContent;
    return fallback;
}
