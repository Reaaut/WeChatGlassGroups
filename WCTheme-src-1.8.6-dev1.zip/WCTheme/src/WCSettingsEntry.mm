#import "WCSettingsEntry.h"
#import "WCPrefs.h"
#import "WCLog.h"
#import "WCDock.h"
#import "WCWallpaper.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreFoundation/CoreFoundation.h>
#if __has_include(<PhotosUI/PhotosUI.h>)
#import <PhotosUI/PhotosUI.h>
#define WC_HAS_PHOTOSUI 1
#else
#define WC_HAS_PHOTOSUI 0
#endif

static BOOL gWallpaperDarkTarget = NO;
static BOOL gLegacyPickerForWallpaper = NO;
/// 1.8.4：从头像菜单打开设置面板时，用于滚动到对应分区（nil=不跳转）。
static NSString *gWCPanelJumpKeyword = nil;

static const NSInteger WCEntryButtonTag = 0x57434542; // 'WCEB'
static const NSInteger WCEntryRowTag = 0x57434632;    // 'WCEF'

// 「我」页候选类名：MoreViewController 已在真机日志中确认命中；
// 其余为微信改版后的备选。全部运行时校验，一个都不命中也不影响悬浮入口。
static NSArray<NSString *> *WCProfileCandidates(void) {
    static NSArray<NSString *> *names;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        names = @[@"MoreViewController", @"NewMineViewController", @"MineViewController",
                  @"WCAccountViewController", @"WCSettingViewController", @"NewSettingViewController"];
    });
    return names;
}

#pragma mark - 偏好

static BOOL WCEntryAllowed(void) {
    WCPrefs *prefs = [WCPrefs shared];
    return prefs.enabled && prefs.entryButtonEnabled;
}

#pragma mark - 诊断页

@interface WCInWeChatDiagnosticsController : UIViewController
@property (nonatomic, copy) NSString *text;
@end

@implementation WCInWeChatDiagnosticsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"诊断";

    UITextView *textView = [[UITextView alloc] initWithFrame:self.view.bounds];
    textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    textView.editable = NO;
    textView.alwaysBounceVertical = YES;
    textView.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    textView.text = self.text ?: @"";
    [self.view addSubview:textView];

    self.navigationItem.rightBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:@"复制"
                                         style:UIBarButtonItemStylePlain
                                        target:self
                                        action:@selector(wc_copy)];
}

- (void)wc_copy {
    [UIPasteboard generalPasteboard].string = self.text ?: @"";
}

@end

#pragma mark - 微信内设置面板（纯 UIKit，不依赖 PreferenceLoader）

@interface WCInWeChatSettingsController : UITableViewController
    <UIImagePickerControllerDelegate, UINavigationControllerDelegate
#if WC_HAS_PHOTOSUI
    , PHPickerViewControllerDelegate
#endif
    >
@end

static NSString *const WCPanelKeyRowKind = @"kind";
static NSString *const WCPanelKeyRowTitle = @"title";
static NSString *const WCPanelKeyRowKey = @"key";
static NSString *const WCPanelKeyRowDefault = @"def";
static NSString *const WCPanelKeyRowMin = @"min";
static NSString *const WCPanelKeyRowMax = @"max";
static NSString *const WCPanelKeyRowTitles = @"titles";
static NSString *const WCPanelKeyRowValues = @"values";

/// 1.7.5：组名 / 标题 / 自定义关键词支持中文，不走 ASCII 键盘与等宽字体。
static BOOL WCPanelIsPlainTextKey(NSString *key) {
    if (![key isKindOfClass:[NSString class]]) return NO;
    return [key hasPrefix:@"groupName"] || [key hasPrefix:@"customGroup"] ||
           [key isEqualToString:@"titleText"] || [key isEqualToString:@"titleSubtitle"];
}

static BOOL WCPanelIsGroupNameKey(NSString *key) {
    if (![key isKindOfClass:[NSString class]]) return NO;
    if ([key hasPrefix:@"groupName"]) return YES;
    return [key hasPrefix:@"customGroup"] && [key containsString:@"Name"];
}

static NSArray<NSDictionary *> *WCPanelSections(void) {
    static NSArray<NSDictionary *> *sections;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sections = @[
            @{ @"title": @"总开关",
               @"footer": @"入口在微信里：屏幕右下角齿轮按钮；部分版本会额外尝试插入到「我」页。",
               @"rows": @[
                   @{ @"kind": @"switch", @"title": @"启用 WCTheme", @"key": WCKeyEnabled, @"def": @YES },
                   @{ @"kind": @"switch", @"title": @"显示微信内入口", @"key": WCKeyEntryButtonEnabled, @"def": @YES },
               ] },
            @{ @"title": @"模块开关",
               @"footer": @"默认全部关闭，只保留 core。每次只打开一个模块再重启微信，确认不卡再开下一个。若卡死：用电脑在 /var/jb/var/mobile/Library/WCTheme/ 下新建空文件 disable，重启微信即可恢复（详见 README）。「安全启动」开启时所有模块都不加载。",
               @"rows": @[
                   @{ @"kind": @"switch", @"title": @"安全启动（只加载 core+日志）", @"key": WCKeySafeBoot, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"模块：玻璃 / 搜索栏", @"key": WCKeyModuleGlass, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"模块：底栏 dock", @"key": WCKeyModuleDock, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"模块：首页分组", @"key": WCKeyModuleGroup, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"模块：未读角标", @"key": WCKeyModuleBadge, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"模块：布局微调 / 卡片 / 标题（实验性）", @"key": WCKeyModuleLayout, @"def": @NO },
               ] },
            @{ @"title": @"全局壁纸（浅 / 深自动切换）",
               @"footer": @"浅色壁纸用于浅色模式、深色壁纸用于深色模式，未设置的模式自动回落到另一张。图片统一转 PNG 存到 /var/jb/var/mobile/Library/WCTheme/（bg-light.png / bg-dark.png）。设置后页面底色与列表转 clear，玻璃 tint 自动减 0.1，避免压黑壁纸。",
               @"rows": @[
                   @{ @"kind": @"wallpaper", @"title": @"浅色壁纸", @"dark": @NO },
                   @{ @"kind": @"wallpaper", @"title": @"深色壁纸", @"dark": @YES },
                   @{ @"kind": @"wallpaperClear", @"title": @"清除壁纸" },
               ] },
            @{ @"title": @"材质（磨砂档位）",
               @"footer": @"三档材质同时作用于底栏胶囊、搜索胶囊、导航栏和页面背景模糊层。强度滑块就是白色 tint 的 alpha（0.04–0.16）。轻量版关闭阴影与多层描边，只保留单层模糊。旧版全局换色默认关闭。",
               @"rows": @[
                   @{ @"kind": @"preview", @"style": @"glass" },
                   @{ @"kind": @"switch", @"title": @"开启毛玻璃", @"key": WCKeyGlassEnabled, @"def": @YES },
                   @{ @"kind": @"choice", @"title": @"模糊材质", @"key": WCKeyGlassStyle, @"def": @0 },
                   @{ @"kind": @"slider", @"title": @"白色 tint 强度（alpha）", @"key": WCKeyGlassIntensity,
                      @"def": @0.08, @"min": @0.04, @"max": @0.16 },
                   @{ @"kind": @"switch", @"title": @"轻量版（只保留单层模糊）", @"key": WCKeyLiteMode, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"旧版全局换色（fallback）", @"key": WCKeyLegacyGlassEnabled, @"def": @NO },
               ] },
            @{ @"title": @"液态卡片",
               @"footer": @"只对首页会话列表生效：圆角 12–16、水平内缩、白底半透明卡片。聊天页不做卡片，保留微信原生气泡。",
               @"rows": @[
                   @{ @"kind": @"switch", @"title": @"开启卡片化", @"key": WCKeyCardEnabled, @"def": @NO },
                   @{ @"kind": @"slider", @"title": @"卡片圆角", @"key": WCKeyCardCornerRadius,
                      @"def": @14, @"min": @8, @"max": @20 },
                   @{ @"kind": @"slider", @"title": @"卡片左右内缩", @"key": WCKeyCardInset,
                      @"def": @12, @"min": @0, @"max": @20 },
                   @{ @"kind": @"switch", @"title": @"性能优先（关闭阴影）", @"key": WCKeyPerformanceFirst, @"def": @NO },
               ] },
            @{ @"title": @"首页（分组 / 顶栏）",
               @"footer": @"1.8.3：默认隐藏分组面板背后的灰框（面板级玻璃底 + 阴影全部透明），只保留每条胶囊自己的玻璃；关掉「隐藏分组灰框」可恢复原生外观。顶栏恒为透明，不随该开关变化。1.7.4：面板容器不再有独立白卡（backgroundColor=clear），直接坐在页面底色上，页面 view / MainFrameTableView 与标题区、分段条统一用同一常量（浅色 #FFFFFF / 深色 #000）。胶囊删掉底部 1px 暗边并 masksToBounds=YES，下方不再出现灰杠；容器上下仍留 10pt、列表 separatorStyle=None。自定义标签（标题文字）位置可选 关闭 / 左上 / 右上 / 底部左侧，按实时 bounds + safeArea 计算，横竖屏跟随。重建触发增加 viewDidAppear / 回前台 / 滚动停止 / 旋转 / 偏好变化，每次都重置重试计数。组间上下间距 6–24 可调，长按组头可上移/下移/隐藏。",
               @"rows": @[
                   @{ @"kind": @"preview", @"style": @"group" },
                   @{ @"kind": @"switch", @"title": @"首页分组（折叠面板）", @"key": WCKeyGroupEnabled, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"分组安全模式（彻底停用）", @"key": WCKeyGroupSafeMode, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"隐藏分组灰框 Hide panel frame", @"key": WCKeyGroupHideFrame, @"def": @YES },
                   @{ @"kind": @"switch", @"title": @"自定义标题（关闭后整块不占高度）", @"key": WCKeyTitleCardEnabled, @"def": @YES },
                   @{ @"kind": @"segment", @"title": @"自定义标签位置", @"key": WCKeyCustomLabelPlacement,
                      @"def": @0, @"titles": @[@"关闭", @"左上", @"右上", @"底部左侧"] },
                   @{ @"kind": @"text", @"title": @"标题文字（默认「微信」）", @"key": WCKeyTitleText, @"def": @"微信" },
                   @{ @"kind": @"text", @"title": @"标题副标题（空=不显示）", @"key": WCKeyTitleSubtitle, @"def": @"" },
                   @{ @"kind": @"slider", @"title": @"组间上下间距", @"key": WCKeyGroupSpacingV,
                      @"def": @12, @"min": @6, @"max": @24 },
                   @{ @"kind": @"switch", @"title": @"隐藏置顶组", @"key": WCKeyGroupHidePinned, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"隐藏好友组", @"key": WCKeyGroupHideFriends, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"隐藏群聊组", @"key": WCKeyGroupHideGroups, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"隐藏服务号组", @"key": WCKeyGroupHideService, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"隐藏公众号组", @"key": WCKeyGroupHideOfficial, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"隐藏其他组", @"key": WCKeyGroupHideOther, @"def": @NO },
                   @{ @"kind": @"text", @"title": @"置顶组名（空=默认）", @"key": WCKeyGroupNamePinned, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"好友组名（空=默认）", @"key": WCKeyGroupNameFriends, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"群聊组名（空=默认）", @"key": WCKeyGroupNameGroups, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"服务号组名（空=默认）", @"key": WCKeyGroupNameService, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"公众号组名（空=默认）", @"key": WCKeyGroupNameOfficial, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"其他组名（空=默认）", @"key": WCKeyGroupNameOther, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"自定义1 组名", @"key": WCKeyCustomGroup1Name, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"自定义1 关键词", @"key": WCKeyCustomGroup1Keyword, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"自定义2 组名", @"key": WCKeyCustomGroup2Name, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"自定义2 关键词", @"key": WCKeyCustomGroup2Keyword, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"自定义3 组名", @"key": WCKeyCustomGroup3Name, @"def": @"" },
                   @{ @"kind": @"text", @"title": @"自定义3 关键词", @"key": WCKeyCustomGroup3Keyword, @"def": @"" },
               ] },
            @{ @"title": @"底栏（液态玻璃浮岛）",
               @"footer": @"1.7.4：四个图标只用一套 —— 先统计四个原生图，4/4 才走 uniform-native（并统一染色，禁止彩色原图混入）；否则四个统一走 SF Symbols 非 fill 细线版（message / person.2 / safari / person.crop.circle，28pt，#1A1A1A / 深色 #EDEDED，选中仅换主题色），日志打「图标方案=uniform-native|uniform-symbol」。位置改为 UIStackView fillEqually + spacing 8 四格均布（中心落在 1/8、3/8、5/8、7/8），头像固定 46pt 在最右（内边 12），内容区 = 宽 − 24 − 46 − 12；选中块 = 格宽 − 8、高 44、圆角 16。每个 UITabBarButton 的层级只打一次：btn i cls=.. sub=..。搜索胶囊严格等于浮岛宽、高 44 / 圆角 22，点击走官方 showSearchBar:searchBar:autoStartGreenMic:。",
               @"rows": @[
                   @{ @"kind": @"preview", @"style": @"dock" },
                   @{ @"kind": @"switch", @"title": @"底栏浮岛（液态玻璃）", @"key": WCKeyDockEnabled, @"def": @NO },
                   @{ @"kind": @"choiceString", @"title": @"底栏样式 Dock style",
                      @"key": WCKeyDockStyle,
                      @"values": @[@"floating", @"bar"],
                      @"titles": @[@"悬浮胶囊 Floating pill", @"贴边整条 Edge bar"] },
                   @{ @"kind": @"avatar", @"title": @"自定义头像" },
                   @{ @"kind": @"slider", @"title": @"浮岛高度", @"key": WCKeyDockHeight,
                      @"def": @64, @"min": @48, @"max": @76 },
                   @{ @"kind": @"choice", @"title": @"宽度模式", @"key": WCKeyDockWidthMode, @"def": @0 },
                   @{ @"kind": @"slider", @"title": @"固定宽度（240–420）", @"key": WCKeyDockFixedWidth,
                      @"def": @300, @"min": @240, @"max": @420 },
                   @{ @"kind": @"slider", @"title": @"左右偏移（拖动可写回）", @"key": WCKeyDockOffsetX,
                      @"def": @14, @"min": @0, @"max": @80 },
                   @{ @"kind": @"slider", @"title": @"距底部手势条偏移", @"key": WCKeyDockOffsetY,
                      @"def": @10, @"min": @0, @"max": @80 },
                   @{ @"kind": @"slider", @"title": @"液态强度（0=普通磨砂）", @"key": WCKeyDockLiquidIntensity,
                      @"def": @60, @"min": @0, @"max": @100 },
                   @{ @"kind": @"switch", @"title": @"图标下方显示标题", @"key": WCKeyDockShowTitle, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"显示搜索胶囊", @"key": WCKeyDockSearchEnabled, @"def": @NO },
                   @{ @"kind": @"choiceString", @"title": @"搜索胶囊位置", @"key": WCKeyDockSearchPlacement,
                      @"def": @"above",
                      @"titles": @[@"浮岛上方一侧（默认）", @"浮岛内左侧", @"不显示"],
                      @"values": @[@"above", @"insideLeft", @"none"] },
               ] },
            @{ @"title": @"角标（未读改色）",
               @"footer": @"只改颜色与描边，不改位置和尺寸。预设 0–4 直接生效；选「自定义」时读取填写的 #RRGGBB 色值。",
               @"rows": @[
                   @{ @"kind": @"switch", @"title": @"开启角标改色", @"key": WCKeyBadgeColorEnabled, @"def": @NO },
                   @{ @"kind": @"choice", @"title": @"角标颜色", @"key": WCKeyBadgePreset, @"def": @0 },
                   @{ @"kind": @"text", @"title": @"自定义色值", @"key": WCKeyBadgeHex, @"def": @"#FA5151" },
               ] },
            @{ @"title": @"布局微调",
               @"footer": @"通用 UIKit 层，默认关闭。",
               @"rows": @[
                   @{ @"kind": @"switch", @"title": @"开启布局微调", @"key": WCKeyLayoutEnabled, @"def": @NO },
                   @{ @"kind": @"slider", @"title": @"Cell 圆角", @"key": WCKeyCellCornerRadius,
                      @"def": @0, @"min": @0, @"max": @20 },
                   @{ @"kind": @"slider", @"title": @"Cell 左右内缩", @"key": WCKeyCellInset,
                      @"def": @0, @"min": @0, @"max": @12 },
                   @{ @"kind": @"choice", @"title": @"状态栏样式", @"key": WCKeyStatusBarStyle, @"def": @0 },
               ] },
            @{ @"title": @"其他",
               @"footer": @"去广告的 hook 表默认为空，需要先用运行时类名发现确认。",
               @"rows": @[
                   @{ @"kind": @"switch", @"title": @"开启去广告", @"key": WCKeyAdBlockEnabled, @"def": @NO },
                   @{ @"kind": @"switch", @"title": @"运行时类名发现", @"key": WCKeyDiscoveryEnabled, @"def": @NO },
               ] },
            @{ @"title": @"诊断",
               @"footer": @"日志写在 /var/jb/var/mobile/Library/WCTheme/wctheme.log；文件不存在 = dylib 从未被加载。",
               @"rows": @[
                   @{ @"kind": @"button", @"title": @"查看诊断日志", @"key": @"diagnostics" },
                   @{ @"kind": @"button", @"title": @"恢复默认值", @"key": @"reset" },
               ] },
        ];
    });
    return sections;
}

static id WCPanelValue(NSDictionary *row) {
    NSString *key = row[WCPanelKeyRowKey];
    id value = (__bridge_transfer id)CFPreferencesCopyAppValue(
        (__bridge CFStringRef)WCStorageKey(key), (__bridge CFStringRef)WCThemeDomain);
    if (!value) {
        value = (__bridge_transfer id)CFPreferencesCopyAppValue(
            (__bridge CFStringRef)key, (__bridge CFStringRef)WCThemeDomain);
    }
    return value ?: row[WCPanelKeyRowDefault];
}

static NSArray<NSString *> *WCPanelGlassStyleTitles(void) {
    return @[@"System Material", @"Thin Material", @"Ultra Thin Material"];
}

static NSArray<NSString *> *WCPanelStatusBarTitles(void) {
    return @[@"不修改", @"深色文字", @"浅色文字"];
}

static NSArray<NSString *> *WCPanelBadgeTitles(void) {
    return @[@"微信红 #FA5151", @"默认蓝 #1989FA", @"紫色 #7B61FF",
             @"绿色 #00B578", @"橙色 #FF8F1F", @"自定义（用右侧色值）"];
}

static NSArray<NSString *> *WCPanelChoiceTitlesForKey(NSString *key) {
    if ([key isEqualToString:WCKeyStatusBarStyle]) return WCPanelStatusBarTitles();
    if ([key isEqualToString:WCKeyBadgePreset]) return WCPanelBadgeTitles();
    if ([key isEqualToString:WCKeyDockWidthMode]) return @[@"自适应（内容宽、居中）", @"固定宽度"];
    return WCPanelGlassStyleTitles();
}

#pragma mark - 效果预览

static const NSInteger WCPanelPreviewTag = 3001;

/// 1.6.0：每组顶部一块效果预览（浅灰底 + 白色胶囊 demo），值为静态示意。
@interface WCPanelPreviewCell : UITableViewCell
- (void)configureStyle:(NSString *)style;
@end

@implementation WCPanelPreviewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.backgroundColor = [UIColor clearColor];
    return self;
}

- (void)configureStyle:(NSString *)style {
    [[self.contentView viewWithTag:WCPanelPreviewTag] removeFromSuperview];

    CGFloat width = MAX(0.0, self.contentView.bounds.size.width - 24.0);
    CGFloat height = 58.0;
    UIView *demo = [[UIView alloc] initWithFrame:CGRectMake(12, 8, width, height)];
    demo.tag = WCPanelPreviewTag;
    demo.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    demo.backgroundColor = [UIColor colorWithWhite:0.93 alpha:1.0];
    demo.layer.cornerRadius = 12.0;
    demo.layer.cornerCurve = kCACornerCurveContinuous;
    demo.clipsToBounds = YES;
    [self.contentView addSubview:demo];

    if ([style isEqualToString:@"dock"]) {
        UIView *capsule = [[UIView alloc] initWithFrame:CGRectMake(10, (height - 34) / 2.0,
                                                                  MAX(0, width - 20), 34)];
        capsule.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.92];
        capsule.layer.cornerRadius = 17.0;
        capsule.layer.masksToBounds = YES;
        [demo addSubview:capsule];

        for (NSUInteger i = 0; i < 4; i++) {
            UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(14 + i * 34, 8, 18, 18)];
            dot.backgroundColor = [UIColor colorWithWhite:(i == 0 ? 0.62 : 0.80) alpha:1.0];
            dot.layer.cornerRadius = 9.0;
            [capsule addSubview:dot];
        }
        UIView *avatar = [[UIView alloc] initWithFrame:CGRectMake(capsule.bounds.size.width - 30,
                                                                6, 22, 22)];
        avatar.backgroundColor = [UIColor colorWithWhite:0.70 alpha:1.0];
        avatar.layer.cornerRadius = 11.0;
        [capsule addSubview:avatar];
        return;
    }

    if ([style isEqualToString:@"group"]) {
        NSArray<NSString *> *titles = @[@"家人 3", @"群聊 5", @"服务号 2"];
        CGFloat x = 10.0;
        for (NSUInteger i = 0; i < titles.count; i++) {
            UILabel *chip = [[UILabel alloc] initWithFrame:CGRectMake(x, (height - 26) / 2.0, 66, 26)];
            chip.text = titles[i];
            chip.textAlignment = NSTextAlignmentCenter;
            chip.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightSemibold];
            chip.textColor = (i == 0) ? [UIColor whiteColor] : [UIColor darkGrayColor];
            chip.backgroundColor = (i == 0) ? [UIColor colorWithRed:0.12 green:0.44 blue:0.90 alpha:1.0]
                                           : [UIColor colorWithWhite:1.0 alpha:0.92];
            chip.layer.cornerRadius = 13.0;
            chip.layer.masksToBounds = YES;
            [demo addSubview:chip];
            x += 74.0;
        }
        return;
    }

    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(10, 8, MAX(0, width - 20), height - 16)];
    card.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.88];
    card.layer.cornerRadius = 14.0;
    card.layer.cornerCurve = kCACornerCurveContinuous;
    card.layer.masksToBounds = YES;
    [demo addSubview:card];
}

@end


@implementation WCInWeChatSettingsController

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"WCTheme 设置";
    self.tableView.rowHeight = 48.0;
    // 1.6.0：浅灰底 + 白色圆角卡片，无分隔线。
    self.tableView.backgroundColor = [UIColor systemGroupedBackgroundColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.tableFooterView = [self wc_footerView];
    self.navigationItem.leftBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:@"关闭"
                                         style:UIBarButtonItemStylePlain
                                        target:self
                                        action:@selector(wc_close)];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSString *keyword = gWCPanelJumpKeyword;
    gWCPanelJumpKeyword = nil;
    if (keyword.length == 0) return;
    NSArray<NSDictionary *> *sections = WCPanelSections();
    for (NSUInteger i = 0; i < sections.count; i++) {
        NSString *title = sections[i][@"title"] ?: @"";
        if ([title rangeOfString:keyword].location == NSNotFound) continue;
        NSInteger rows = [self tableView:self.tableView numberOfRowsInSection:(NSInteger)i];
        if (rows <= 0) continue;
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:(NSInteger)i]
                              atScrollPosition:UITableViewScrollPositionTop
                                      animated:NO];
        break;
    }
}

#pragma mark - 底部「显示效果」按钮

- (UIView *)wc_footerView {
    UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0,
                                                             self.tableView.bounds.size.width, 88)];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(20, 14, MAX(0, footer.bounds.size.width - 40), 48);
    button.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    button.backgroundColor = self.view.tintColor ?: [UIColor systemBlueColor];
    [button setTitle:@"显示效果（立即应用）" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightSemibold];
    button.layer.cornerRadius = 24.0;
    button.layer.cornerCurve = kCACornerCurveContinuous;
    [button addTarget:self action:@selector(wc_applyNow) forControlEvents:UIControlEventTouchUpInside];
    [footer addSubview:button];
    return footer;
}

- (void)wc_applyNow {
    WCPostPrefsChangedNotification();
    UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
        initWithStyle:UIImpactFeedbackStyleLight];
    [gen impactOccurred];

    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:@"已请求立即应用"
                                             message:@"材质 / 分组 / 浮岛会在下一个 runloop 刷新，不用重启微信。若浮岛还没出现，切到「通讯录」再切回「微信」会自动重挂。"
                                      preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好"
                                              style:UIAlertActionStyleDefault
                                            handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)wc_close {
    UINavigationController *nav = self.navigationController;
    if (nav && nav.viewControllers.count > 1) {
        [nav popViewControllerAnimated:YES];
    } else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return (NSInteger)WCPanelSections().count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return (NSInteger)[WCPanelSections()[(NSUInteger)section][@"rows"] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return WCPanelSections()[(NSUInteger)section][@"title"];
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return WCPanelSections()[(NSUInteger)section][@"footer"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *row = WCPanelSections()[(NSUInteger)indexPath.section][@"rows"][(NSUInteger)indexPath.row];
    NSString *kind = row[WCPanelKeyRowKind];

    if ([kind isEqualToString:@"preview"]) {
        static NSString *identifier = @"wc-preview";
        WCPanelPreviewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[WCPanelPreviewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                             reuseIdentifier:identifier];
        }
        [cell configureStyle:row[@"style"]];
        return cell;
    }

    if ([kind isEqualToString:@"switch"]) {
        static NSString *identifier = @"wc-switch";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:identifier];
            UISwitch *toggle = [[UISwitch alloc] init];
            [toggle addTarget:self
                        action:@selector(wc_switchChanged:)
              forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = toggle;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        UISwitch *toggle = (UISwitch *)cell.accessoryView;
        toggle.accessibilityIdentifier = row[WCPanelKeyRowKey];
        toggle.on = [WCPanelValue(row) boolValue];
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];
        return cell;
    }

    if ([kind isEqualToString:@"slider"]) {
        static NSString *identifier = @"wc-slider";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:identifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;

            UIView *box = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 170, 34)];
            UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(0, 2, 108, 30)];
            slider.tag = 2002;
            [slider addTarget:self
                        action:@selector(wc_sliderChanged:)
              forControlEvents:UIControlEventValueChanged];
            [box addSubview:slider];

            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(112, 2, 58, 30)];
            label.tag = 2001;
            label.font = [UIFont monospacedDigitSystemFontOfSize:12.0
                                                          weight:UIFontWeightRegular];
            label.textColor = [UIColor secondaryLabelColor];
            label.textAlignment = NSTextAlignmentRight;
            [box addSubview:label];

            cell.accessoryView = box;
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];

        UIView *box = cell.accessoryView;
        UISlider *slider = (UISlider *)[box viewWithTag:2002];
        UILabel *label = (UILabel *)[box viewWithTag:2001];

        slider.accessibilityIdentifier = row[WCPanelKeyRowKey];
        slider.minimumValue = [row[WCPanelKeyRowMin] floatValue];
        slider.maximumValue = [row[WCPanelKeyRowMax] floatValue];
        slider.value = [WCPanelValue(row) floatValue];
        label.text = [self wc_formatValue:slider.value max:slider.maximumValue];
        return cell;
    }

    if ([kind isEqualToString:@"segment"]) {
        static NSString *identifier = @"wc-segment";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:identifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;

            NSArray<NSString *> *titles = row[WCPanelKeyRowTitles] ?: @[];
            UISegmentedControl *seg = [[UISegmentedControl alloc] initWithItems:titles];
            seg.tag = 2004;
            seg.apportionsSegmentWidthsByContent = YES;
            [seg setTitleTextAttributes:@{ NSFontAttributeName: [UIFont systemFontOfSize:11.0] }
                                forState:UIControlStateNormal];
            [seg addTarget:self
                      action:@selector(wc_segmentChanged:)
            forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = seg;
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];

        UISegmentedControl *seg = (UISegmentedControl *)cell.accessoryView;
        seg.accessibilityIdentifier = row[WCPanelKeyRowKey];
        NSInteger value = [WCPanelValue(row) integerValue];
        if (value < 0 || value >= (NSInteger)seg.numberOfSegments) value = 0;
        seg.selectedSegmentIndex = value;
        return cell;
    }

    if ([kind isEqualToString:@"choice"]) {
        static NSString *identifier = @"wc-choice";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1
                                          reuseIdentifier:identifier];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];

        NSInteger value = [WCPanelValue(row) integerValue];
        NSArray<NSString *> *titles = WCPanelChoiceTitlesForKey(row[WCPanelKeyRowKey]);
        if (value < 0 || value >= (NSInteger)titles.count) value = 0;
        cell.detailTextLabel.text = titles[(NSUInteger)value];
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
        return cell;
    }

    if ([kind isEqualToString:@"choiceString"]) {
        static NSString *identifier = @"wc-choicestring";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1
                                          reuseIdentifier:identifier];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];

        NSArray<NSString *> *values = row[WCPanelKeyRowValues];
        NSArray<NSString *> *titles = row[WCPanelKeyRowTitles];
        id current = WCPanelValue(row);
        NSInteger index = [values indexOfObject:current];
        if (index < 0 || index >= (NSInteger)titles.count) index = 0;
        cell.detailTextLabel.text = titles[(NSUInteger)index];
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
        return cell;
    }

    if ([kind isEqualToString:@"wallpaper"]) {
        static NSString *identifier = @"wc-wallpaper";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1
                                          reuseIdentifier:identifier];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];
        BOOL dark = [row[@"dark"] boolValue];
        BOOL has = WCWallpaperExistingPath(dark) != nil;
        cell.detailTextLabel.text = has ? @"已设置，点按更换" : @"未设置，点按选择";
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
        return cell;
    }

    if ([kind isEqualToString:@"wallpaperClear"]) {
        static NSString *identifier = @"wc-wallpaper-clear";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:identifier];
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.textColor = [UIColor systemRedColor];
        return cell;
    }

    if ([kind isEqualToString:@"avatar"]) {
        static NSString *identifier = @"wc-avatar";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                          reuseIdentifier:identifier];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        UIImage *image = [UIImage imageWithContentsOfFile:WCDockAvatarPath()];
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];
        cell.detailTextLabel.text = image ? @"已自定义（点按更换 / 恢复默认）" : @"默认中性占位";
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
        cell.imageView.image = image ?: [UIImage systemImageNamed:@"person.crop.circle"];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFill;
        return cell;
    }

    if ([kind isEqualToString:@"text"]) {
        static NSString *identifier = @"wc-text";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:identifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;

            UITextField *field = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 110, 30)];
            field.tag = 2003;
            field.borderStyle = UITextBorderStyleRoundedRect;
            field.font = [UIFont monospacedSystemFontOfSize:13.0 weight:UIFontWeightRegular];
            field.textAlignment = NSTextAlignmentCenter;
            field.placeholder = @"#RRGGBB";
            field.autocapitalizationType = UITextAutocapitalizationTypeNone;
            field.autocorrectionType = UITextAutocorrectionTypeNo;
            field.keyboardType = UIKeyboardTypeASCIICapable;
            [field addTarget:self
                       action:@selector(wc_textChanged:)
             forControlEvents:UIControlEventEditingDidEnd | UIControlEventEditingDidEndOnExit];
            cell.accessoryView = field;
        }
        cell.textLabel.text = row[WCPanelKeyRowTitle];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];

        NSString *rowKey = row[WCPanelKeyRowKey];
        BOOL plain = WCPanelIsPlainTextKey(rowKey);
        UITextField *field = (UITextField *)cell.accessoryView;
        field.accessibilityIdentifier = rowKey;
        field.font = plain ? [UIFont systemFontOfSize:13.0]
                           : [UIFont monospacedSystemFontOfSize:13.0 weight:UIFontWeightRegular];
        field.placeholder = plain ? @"支持中文" : @"#RRGGBB";
        field.keyboardType = plain ? UIKeyboardTypeDefault : UIKeyboardTypeASCIICapable;
        id value = WCPanelValue(row);
        field.text = [value isKindOfClass:[NSString class]] ? value : @"";
        return cell;
    }

    static NSString *identifier = @"wc-button";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:identifier];
    }
    cell.textLabel.text = row[WCPanelKeyRowTitle];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.textColor = self.view.tintColor;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *row = WCPanelSections()[(NSUInteger)indexPath.section][@"rows"][(NSUInteger)indexPath.row];
    if ([row[WCPanelKeyRowKind] isEqualToString:@"preview"]) return 76.0;
    if ([row[WCPanelKeyRowKind] isEqualToString:@"avatar"]) return 64.0;
    if ([row[WCPanelKeyRowKind] isEqualToString:@"segment"]) return 52.0;
    return tableView.rowHeight;
}

/// 白色圆角卡片：浅灰表底 + 每个条目一块 16pt 圆角白卡。
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell
forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *row = WCPanelSections()[(NSUInteger)indexPath.section][@"rows"][(NSUInteger)indexPath.row];
    if ([row[WCPanelKeyRowKind] isEqualToString:@"preview"]) {
        cell.backgroundColor = [UIColor clearColor];
        return;
    }

    UIView *card = [[UIView alloc] init];
    card.backgroundColor = [UIColor whiteColor];
    card.layer.cornerRadius = 16.0;
    card.layer.cornerCurve = kCACornerCurveContinuous;
    cell.backgroundView = card;

    UIView *selected = [[UIView alloc] init];
    selected.backgroundColor = [UIColor colorWithWhite:0.90 alpha:1.0];
    selected.layer.cornerRadius = 16.0;
    selected.layer.cornerCurve = kCACornerCurveContinuous;
    cell.selectedBackgroundView = selected;
    cell.backgroundColor = [UIColor clearColor];
}

- (NSString *)wc_formatValue:(float)value max:(float)max {
    return (max <= 1.0) ? [NSString stringWithFormat:@"%.2f", value]
                        : [NSString stringWithFormat:@"%.0f", value];
}

- (void)wc_switchChanged:(UISwitch *)sender {
    NSString *key = sender.accessibilityIdentifier;
    if (key.length == 0) return;
    WCSetPrefBool(key, sender.on);
}

- (void)wc_sliderChanged:(UISlider *)sender {
    NSString *key = sender.accessibilityIdentifier;
    if (key.length == 0) return;
    WCSetPrefDouble(key, (double)sender.value);

    UIView *box = sender.superview;
    UILabel *label = (UILabel *)[box viewWithTag:2001];
    label.text = [self wc_formatValue:sender.value max:sender.maximumValue];
}

- (void)wc_textChanged:(UITextField *)sender {
    NSString *key = sender.accessibilityIdentifier;
    if (key.length == 0) return;
    NSString *text = sender.text ?: @"";
    if (WCPanelIsPlainTextKey(key)) {
        // 1.7.5：不做 ASCII 限制；保存时去首尾空白，组名按 UTF-16 限 12 个字符。
        text = [text stringByTrimmingCharactersInSet:
                [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (WCPanelIsGroupNameKey(key) && text.length > 12) {
            text = [text substringToIndex:12];
        }
        if (![sender.text isEqualToString:text]) sender.text = text;
        WCLogLine(@"info", @"group", @"组名保存 key=%@ value=%@", key, text);
    }
    WCSetPrefString(key, text);
}

/// 1.7.4：分段控件即时写偏好（偏好通知会触发首页按新位置重算）。
- (void)wc_segmentChanged:(UISegmentedControl *)sender {
    NSString *key = sender.accessibilityIdentifier;
    if (key.length == 0) return;
    WCSetPrefDouble(key, (double)sender.selectedSegmentIndex);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    NSDictionary *row = WCPanelSections()[(NSUInteger)indexPath.section][@"rows"][(NSUInteger)indexPath.row];
    NSString *kind = row[WCPanelKeyRowKind];
    NSString *key = row[WCPanelKeyRowKey];

    if ([kind isEqualToString:@"choice"]) {
        [self wc_presentChoiceForKey:key];
        return;
    }
    if ([kind isEqualToString:@"choiceString"]) {
        [self wc_presentStringChoiceForRow:row];
        return;
    }
    if ([kind isEqualToString:@"wallpaper"]) {
        [self wc_pickWallpaperForDark:[row[@"dark"] boolValue]];
        return;
    }
    if ([kind isEqualToString:@"wallpaperClear"]) {
        [self wc_clearWallpaper];
        return;
    }
    if ([kind isEqualToString:@"avatar"]) {
        [self wc_presentAvatarOptions];
        return;
    }
    if ([kind isEqualToString:@"button"]) {
        if ([key isEqualToString:@"diagnostics"]) {
            [self wc_showDiagnostics];
        } else if ([key isEqualToString:@"reset"]) {
            WCPrefsResetToDefaults();
            [self.tableView reloadData];
        }
    }
}

- (void)wc_presentStringChoiceForRow:(NSDictionary *)row {
    NSString *key = row[WCPanelKeyRowKey];
    NSArray<NSString *> *titles = row[WCPanelKeyRowTitles];
    NSArray<NSString *> *values = row[WCPanelKeyRowValues];

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:nil
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSUInteger i = 0; i < titles.count && i < values.count; i++) {
        [sheet addAction:[UIAlertAction actionWithTitle:titles[i]
                                                  style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *action) {
                                                    WCSetPrefString(key, values[i]);
                                                    [self.tableView reloadData];
                                                }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = self.view.bounds;
    [self presentViewController:sheet animated:YES completion:nil];
}

#pragma mark - 全局壁纸（PHPicker）

- (void)wc_pickWallpaperForDark:(BOOL)dark {
    gWallpaperDarkTarget = dark;
#if WC_HAS_PHOTOSUI
    if ([PHPickerViewController class]) {
        PHPickerConfiguration *configuration = [[PHPickerConfiguration alloc] init];
        configuration.filter = [PHPickerFilter imagesFilter];
        configuration.selectionLimit = 1;
        PHPickerViewController *picker =
            [[PHPickerViewController alloc] initWithConfiguration:configuration];
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:nil];
        return;
    }
#endif
    // 老系统兜底：UIImagePickerController。
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        [self wc_alertTitle:@"相册不可用" message:@"当前设备或权限不允许访问相册。"];
        return;
    }
    gLegacyPickerForWallpaper = YES;
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.allowsEditing = NO;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

#if WC_HAS_PHOTOSUI
- (void)picker:(PHPickerViewController *)picker
didFinishPicking:(NSArray<PHPickerResult *> *)results {
    [picker dismissViewControllerAnimated:YES completion:nil];
    PHPickerResult *result = results.firstObject;
    if (!result) {
        WCLogLine(@"info", @"bg", @"壁纸选择已取消");
        return;
    }
    NSItemProvider *provider = result.itemProvider;
    if (![provider canLoadObjectOfClass:[UIImage class]]) {
        [self wc_alertTitle:@"无法读取图片" message:@"这张素材不是可用的图片格式。"];
        return;
    }
    __weak typeof(self) weakSelf = self;
    BOOL dark = gWallpaperDarkTarget;
    [provider loadObjectOfClass:[UIImage class]
              completionHandler:^(id<NSItemProviderReading> object, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIImage *image = [object isKindOfClass:[UIImage class]] ? (UIImage *)object : nil;
            [weakSelf wc_finishWallpaperImage:image dark:dark error:error];
        });
    }];
}
#endif

- (void)wc_finishWallpaperImage:(UIImage *)image dark:(BOOL)dark error:(NSError *)error {
    if (!image) {
        [self wc_alertTitle:@"读取失败" message:error.localizedDescription ?: @"没有取到图片数据。"];
        return;
    }
    NSString *message = nil;
    BOOL ok = WCWallpaperSaveImage(image, dark, &message);
    WCPostPrefsChangedNotification();
    WCWallpaperRefresh();
    [self.tableView reloadData];
    if (ok) {
        [self wc_alertTitle:(dark ? @"深色壁纸已保存" : @"浅色壁纸已保存")
                     message:message ?: @""];
    } else {
        [self wc_alertTitle:@"保存失败" message:message ?: @"PNG 写盘失败"];
    }
}

- (void)wc_clearWallpaper {
    BOOL removed = WCWallpaperClear();
    WCPostPrefsChangedNotification();
    WCWallpaperRefresh();
    [self.tableView reloadData];
    [self wc_alertTitle:removed ? @"壁纸已清除" : @"没有壁纸"
                 message:removed ? @"页面已恢复纯白 / 纯黑。" : @"当前没有已保存的壁纸文件。"];
}

#pragma mark - 自定义头像

- (void)wc_presentAvatarOptions {
    BOOL hasCustom = [[NSFileManager defaultManager] fileExistsAtPath:WCDockAvatarPath()];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"自定义头像"
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[UIAlertAction actionWithTitle:@"从相册选择"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
                                                [self wc_pickAvatar];
                                            }]];
    if (hasCustom) {
        [sheet addAction:[UIAlertAction actionWithTitle:@"恢复默认"
                                                  style:UIAlertActionStyleDestructive
                                                handler:^(UIAlertAction *action) {
                                                    WCDockClearCustomAvatar();
                                                    WCPostPrefsChangedNotification();
                                                    [self.tableView reloadData];
                                                }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = self.view.bounds;
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)wc_pickAvatar {
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        [self wc_alertTitle:@"相册不可用" message:@"当前设备或权限不允许访问相册。"];
        return;
    }
    gLegacyPickerForWallpaper = NO;
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.allowsEditing = YES;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary<NSString *, id> *)info {
    UIImage *image = info[UIImagePickerControllerEditedImage] ?: info[UIImagePickerControllerOriginalImage];
    BOOL forWallpaper = gLegacyPickerForWallpaper;
    gLegacyPickerForWallpaper = NO;
    [picker dismissViewControllerAnimated:YES completion:nil];
    if (!image) return;
    if (forWallpaper) {
        [self wc_finishWallpaperImage:image dark:gWallpaperDarkTarget error:nil];
    } else {
        [self wc_saveAvatarImage:image];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

/// 裁剪成圆形 → 256×256 PNG → /var/jb/var/mobile/Library/WCTheme/avatar.png
- (void)wc_saveAvatarImage:(UIImage *)image {
    CGFloat side = 256.0;
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side)];
    UIImage *round = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
        [[UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, side, side)] addClip];
        CGFloat scale = MAX(side / MAX(image.size.width, 1.0), side / MAX(image.size.height, 1.0));
        CGSize size = CGSizeMake(image.size.width * scale, image.size.height * scale);
        [image drawInRect:CGRectMake((side - size.width) / 2.0, (side - size.height) / 2.0,
                                     size.width, size.height)];
    }];

    NSString *path = WCDockAvatarPath();
    NSString *directory = [path stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:directory
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    NSData *png = UIImagePNGRepresentation(round);
    BOOL ok = [png writeToFile:path atomically:YES];
    WCLogLine(@"info", @"settings", @"保存头像 ok=%d path=%@", ok, path);
    if (ok) {
        WCPostPrefsChangedNotification();
        [self.tableView reloadData];
        [self wc_alertTitle:@"头像已更新" message:@"浮岛与菜单头像都会使用这张图。"];
    } else {
        [self wc_alertTitle:@"保存失败" message:path];
    }
}

- (void)wc_alertTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)wc_presentChoiceForKey:(NSString *)key {
    NSArray<NSString *> *titles = WCPanelChoiceTitlesForKey(key);

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:nil
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSUInteger i = 0; i < titles.count; i++) {
        NSInteger value = (NSInteger)i;
        [sheet addAction:[UIAlertAction actionWithTitle:titles[i]
                                                  style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *action) {
                                                    WCSetPrefInteger(key, value);
                                                    [self.tableView reloadData];
                                                }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:[self.tableView indexPathForSelectedRow]];
    sheet.popoverPresentationController.sourceView = cell ?: self.view;
    sheet.popoverPresentationController.sourceRect = (cell ?: self.view).bounds;
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)wc_showDiagnostics {
    NSMutableArray<NSString *> *lines = [NSMutableArray array];
    NSString *path = WCLogFilePath();
    BOOL exists = [[NSFileManager defaultManager] fileExistsAtPath:path];
    [lines addObject:[NSString stringWithFormat:@"日志文件：%@", path]];
    [lines addObject:exists ? @"文件存在：dylib 至少加载过一次"
                            : @"文件不存在：WCTheme.dylib 从未被 dyld 加载"];
    [lines addObject:[NSString stringWithFormat:@"日志尾部 %lu 行：", (unsigned long)WCLogTail(200).count]];
    [lines addObjectsFromArray:WCLogTail(200)];

    WCInWeChatDiagnosticsController *vc = [[WCInWeChatDiagnosticsController alloc] init];
    vc.text = [lines componentsJoinedByString:@"\n"];
    [self.navigationController pushViewController:vc animated:YES];
}

@end

#pragma mark - 入口（悬浮按钮 + 「我」页候选行）

#pragma mark - 入口点击目标

@interface WCEntryActionTarget : NSObject
- (void)wc_tapped;
@end

@implementation WCEntryActionTarget
- (void)wc_tapped {
    WCSettingsEntryPresentPanel();
}
@end

static UIButton *gEntryButton = nil;
static WCEntryActionTarget *gEntryTarget = nil;
static NSMutableSet<NSString *> *gLoggedClasses = nil;

static WCEntryActionTarget *WCEntryTarget(void) {
    if (!gEntryTarget) gEntryTarget = [[WCEntryActionTarget alloc] init];
    return gEntryTarget;
}

static void WCSettingsEntryLogClassOnce(NSString *name) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gLoggedClasses = [NSMutableSet set];
    });
    if (gLoggedClasses.count >= 80) return;
    if ([gLoggedClasses containsObject:name]) return;
    [gLoggedClasses addObject:name];
    WCLogLine(@"info", @"entry", @"vc appear %@", name);
}

static UIViewController *WCTopViewController(void) {
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (!window) {
        for (UIWindow *candidate in [UIApplication sharedApplication].windows) {
            if (candidate.windowLevel == UIWindowLevelNormal && !candidate.hidden) {
                window = candidate;
                break;
            }
        }
    }

    UIViewController *controller = window.rootViewController;
    while (controller) {
        UIViewController *next = controller.presentedViewController;
        if (next && !next.isBeingDismissed) {
            controller = next;
            continue;
        }
        if ([controller isKindOfClass:[UINavigationController class]]) {
            UIViewController *visible = ((UINavigationController *)controller).visibleViewController;
            if (visible && visible != controller) {
                controller = visible;
                continue;
            }
        }
        if ([controller isKindOfClass:[UITabBarController class]]) {
            UIViewController *selected = ((UITabBarController *)controller).selectedViewController;
            if (selected && selected != controller) {
                controller = selected;
                continue;
            }
        }
        break;
    }
    return controller;
}

void WCSettingsEntryPresentPanelSection(NSString *sectionKeyword) {
    gWCPanelJumpKeyword = [sectionKeyword copy];
    WCSettingsEntryPresentPanel();
}

void WCSettingsEntryPresentPanel(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *top = WCTopViewController();
        if (!top) return;

        WCInWeChatSettingsController *panel = [[WCInWeChatSettingsController alloc] init];
        if (top.navigationController && !top.presentedViewController) {
            [top.navigationController pushViewController:panel animated:YES];
            return;
        }

        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:panel];
        nav.modalPresentationStyle = UIModalPresentationFullScreen;
        [top presentViewController:nav animated:YES completion:nil];
    });
}

static BOOL WCWindowIsUsable(UIWindow *window) {
    if (![window isKindOfClass:[UIWindow class]]) return NO;
    if (window.windowLevel != UIWindowLevelNormal) return NO;
    if (window.bounds.size.width < 200.0 || window.bounds.size.height < 300.0) return NO;

    NSString *className = NSStringFromClass([window class]).lowercaseString;
    NSArray<NSString *> *skip = @[@"keyboard", @"statusbar", @"iconsole", @"console", @"hud"];
    for (NSString *token in skip) {
        if ([className rangeOfString:token].location != NSNotFound) return NO;
    }
    return YES;
}

static CGRect WCEntryButtonFrame(UIWindow *window) {
    CGFloat safeBottom = window.safeAreaInsets.bottom;
    CGFloat y = window.bounds.size.height - safeBottom - 49.0 - 44.0 - 12.0;
    if (y < 140.0) y = 140.0;
    return CGRectMake(window.bounds.size.width - 44.0 - 12.0, y, 44.0, 44.0);
}

static void WCSettingsEntryAttachToWindow(UIWindow *window) {
    if (!window || !WCWindowIsUsable(window) || !WCEntryAllowed()) return;

    UIButton *button = gEntryButton;
    if (button && button.superview == window) {
        button.frame = WCEntryButtonFrame(window);
        button.hidden = NO;
        return;
    }

    if (!button) {
        button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = WCEntryButtonTag;
        button.backgroundColor = [UIColor colorWithWhite:0.05 alpha:0.55];
        button.tintColor = [UIColor colorWithWhite:1.0 alpha:0.92];
        button.layer.cornerRadius = 22.0;
        button.layer.masksToBounds = YES;
        [button setImage:[UIImage systemImageNamed:@"gearshape.fill"]
                 forState:UIControlStateNormal];
        [button addTarget:WCEntryTarget()
                    action:@selector(wc_tapped)
          forControlEvents:UIControlEventTouchUpInside];
        gEntryButton = button;
    }

    @try {
        button.frame = WCEntryButtonFrame(window);
        button.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin |
                                  UIViewAutoresizingFlexibleTopMargin;
        [window addSubview:button];
        WCLogLine(@"info", @"entry", @"悬浮入口 attach %@",
                  NSStringFromClass([window class]));
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"entry", @"悬浮入口失败：%@", exception.reason);
    }
}

/// 场景化 App 里 keyWindow 经常是 nil（iOS 13+），改成"面积最大的正常窗口"。
static UIWindow *WCMainWindowForEntry(void) {
    UIWindow *best = nil;
    CGFloat bestArea = 0.0;
    for (UIWindow *candidate in [UIApplication sharedApplication].windows) {
        if (!WCWindowIsUsable(candidate)) continue;
        CGFloat area = candidate.bounds.size.width * candidate.bounds.size.height;
        if (area > bestArea) {
            bestArea = area;
            best = candidate;
        }
    }
    return best ?: [UIApplication sharedApplication].keyWindow;
}

void WCSettingsEntryRefresh(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIButton *button = gEntryButton;
        if (!WCEntryAllowed()) {
            [button removeFromSuperview];
            return;
        }
        WCSettingsEntryAttachToWindow(WCMainWindowForEntry());
    });
}

BOOL WCSettingsEntryHandleViewControllerAppear(UIViewController *controller) {
    if (!controller) return NO;

    NSString *className = NSStringFromClass([controller class]);
    WCSettingsEntryLogClassOnce(className);

    if (!WCEntryAllowed()) return NO;

    // 兜底：每次 VC 出现都尝试一次挂载（幂等）。上一版只依赖窗口通知，
    // 场景化 App 里 keyWindow 为 nil 会导致齿轮一直不出现。
    UIWindow *mainWindow = WCMainWindowForEntry();
    if (mainWindow && (!gEntryButton || gEntryButton.superview != mainWindow)) {
        WCSettingsEntryAttachToWindow(mainWindow);
    }

    UIView *view = controller.view;
    if (!view) return NO;

    BOOL isProfilePage = NO;
    for (NSString *candidate in WCProfileCandidates()) {
        if ([className isEqualToString:candidate]) {
            isProfilePage = YES;
            break;
        }
    }
    if (!isProfilePage) return NO;

    WCLogLine(@"info", @"entry", @"命中「我」页 %@", className);

    if ([view viewWithTag:WCEntryRowTag]) return YES;

    @try {
        UIButton *row = [UIButton buttonWithType:UIButtonTypeSystem];
        row.tag = WCEntryRowTag;
        [row setTitle:@"WCTheme 设置" forState:UIControlStateNormal];
        [row setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
        row.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightMedium];
        row.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.92];
        row.layer.cornerRadius = 12.0;
        row.layer.masksToBounds = YES;
        row.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;

        CGFloat safeBottom = view.safeAreaInsets.bottom;
        CGFloat tabBar = 49.0;
        CGRect frame = CGRectMake(16.0,
                                 view.bounds.size.height - safeBottom - tabBar - 56.0,
                                 view.bounds.size.width - 32.0,
                                 46.0);
        row.frame = frame;

        [row addTarget:WCEntryTarget()
                 action:@selector(wc_tapped)
       forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:row];
        return YES;
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"entry", @"「我」页入口失败：%@", exception.reason);
        return NO;
    }
}

void WCSettingsEntryStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        WCEntryTarget();

        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        NSOperationQueue *mainQueue = [NSOperationQueue mainQueue];

        [center addObserverForName:UIWindowDidBecomeKeyNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            WCSettingsEntryRefresh();
                        }];

        [center addObserverForName:UIApplicationDidBecomeActiveNotification
                            object:nil
                             queue:mainQueue
                        usingBlock:^(NSNotification *note) {
                            WCSettingsEntryRefresh();
                        }];

        WCSettingsEntryRefresh();
    });
}
