#import "WCPrefs.h"

NSString *const WCThemeDomain = @"com.wctheme.dev";
NSString *const WCThemePrefsChangedNotification = @"com.wctheme.dev/prefsChanged";
NSString *const WCThemeDumpHierarchyNotification = @"com.wctheme.dev/dumpHierarchy";

NSString *const WCKeyEnabled = @"enabled";
NSString *const WCKeyGlassEnabled = @"glassEnabled";
NSString *const WCKeyGlassIntensity = @"glassIntensity";
NSString *const WCKeyGlassStyle = @"glassStyle";
NSString *const WCKeyAdBlockEnabled = @"adBlockEnabled";
NSString *const WCKeyDiscoveryEnabled = @"discoveryEnabled";
NSString *const WCKeyLayoutEnabled = @"layoutEnabled";
NSString *const WCKeyCellCornerRadius = @"cellCornerRadius";
NSString *const WCKeyCellInset = @"cellInset";
NSString *const WCKeyNavBarAlpha = @"navBarAlpha";
NSString *const WCKeyTabBarAlpha = @"tabBarAlpha";
NSString *const WCKeyStatusBarStyle = @"statusBarStyle";

NSString *const WCKeyCardEnabled = @"cardEnabled";
NSString *const WCKeyCardCornerRadius = @"cardCornerRadius";
NSString *const WCKeyCardInset = @"cardInset";
NSString *const WCKeyPerformanceFirst = @"performanceFirst";
NSString *const WCKeyLegacyGlassEnabled = @"legacyGlassEnabled";
NSString *const WCKeyEntryButtonEnabled = @"entryButtonEnabled";

NSString *const WCKeyGroupEnabled = @"groupEnabled";
NSString *const WCKeyDockEnabled = @"dockEnabled";
NSString *const WCKeyBigTitleEnabled = @"bigTitleEnabled";
NSString *const WCKeyDockInset = @"dockInset";

NSString *const WCKeyDockPlusEnabled = @"dockPlusEnabled";
NSString *const WCKeySearchFloatBottom = @"searchFloatBottom";
NSString *const WCKeyLiteMode = @"liteMode";
NSString *const WCKeyBadgeColorEnabled = @"badgeColorEnabled";
NSString *const WCKeyBadgePreset = @"badgePreset";
NSString *const WCKeyBadgeHex = @"badgeHex";

NSString *const WCKeyGroupSafeMode = @"groupSafeMode";
NSString *const WCKeyGroupOffset = @"groupOffset";
NSString *const WCKeyGroupSpacing = @"groupSpacing";
NSString *const WCKeyGroupCorner = @"groupCorner";

NSString *const WCKeyDockHeight = @"dockHeight";
NSString *const WCKeyDockWidth = @"dockWidth";
NSString *const WCKeyDockShowTitle = @"dockShowTitle";
NSString *const WCKeyDockSearchEnabled = @"dockSearchEnabled";
NSString *const WCKeyGroupChipHex = @"groupChipHex";

NSString *const WCKeyDockOffsetX = @"dockOffsetX";
NSString *const WCKeyDockOffsetY = @"dockOffsetY";
NSString *const WCKeyDockWidthMode = @"dockWidthMode";
NSString *const WCKeyDockFixedWidth = @"dockFixedWidth";
NSString *const WCKeyDockSearchPlacement = @"dockSearchPlacement";
NSString *const WCKeyDockLiquidIntensity = @"dockLiquidIntensity";

NSString *const WCKeyGroupNamePinned = @"groupNamePinned";
NSString *const WCKeyGroupNameFriends = @"groupNameFriends";
NSString *const WCKeyGroupNameGroups = @"groupNameGroups";
NSString *const WCKeyGroupNameService = @"groupNameService";
NSString *const WCKeyGroupNameOfficial = @"groupNameOfficial";
NSString *const WCKeyGroupNameOther = @"groupNameOther";
NSString *const WCKeyCustomGroup1Name = @"customGroup1Name";
NSString *const WCKeyCustomGroup1Keyword = @"customGroup1Keyword";
NSString *const WCKeyCustomGroup2Name = @"customGroup2Name";
NSString *const WCKeyCustomGroup2Keyword = @"customGroup2Keyword";
NSString *const WCKeyCustomGroup3Name = @"customGroup3Name";
NSString *const WCKeyCustomGroup3Keyword = @"customGroup3Keyword";
NSString *const WCKeySearchMode = @"searchMode";
NSString *const WCKeySearchCardHTML = @"searchCardHTML";
NSString *const WCKeySearchCardHeight = @"searchCardHeight";
NSString *const WCKeyGroupSubtitle = @"groupSubtitle";
NSString *const WCKeyGroupSpacingV = @"groupSpacingV";
NSString *const WCKeyTitleText = @"titleText";
NSString *const WCKeyTitleSubtitle = @"titleSubtitle";
NSString *const WCKeyTitleCardEnabled = @"titleCardEnabled";
NSString *const WCKeyCustomLabelPlacement = @"customLabelPlacement";

NSString *const WCKeyGroupHideFrame = @"groupHideFrame";
NSString *const WCKeyDockStyle = @"dockStyle";

NSString *const WCKeyGroupHidePinned = @"groupHidePinned";
NSString *const WCKeyGroupHideFriends = @"groupHideFriends";
NSString *const WCKeyGroupHideGroups = @"groupHideGroups";
NSString *const WCKeyGroupHideService = @"groupHideService";
NSString *const WCKeyGroupHideOfficial = @"groupHideOfficial";
NSString *const WCKeyGroupHideOther = @"groupHideOther";

NSString *WCStorageKey(NSString *key) {
    if (key.length == 0) return key;
    if ([key hasPrefix:@"wxgb."]) return key;
    return [@"wxgb." stringByAppendingString:key];
}

NSString *const WCKeySafeBoot = @"safeBoot";
NSString *const WCKeyModuleGlass = @"moduleGlass";
NSString *const WCKeyModuleDock = @"moduleDock";
NSString *const WCKeyModuleGroup = @"moduleGroup";
NSString *const WCKeyModuleBadge = @"moduleBadge";
NSString *const WCKeyModuleLayout = @"moduleLayout";

static NSArray<NSString *> *WCAllKeys(void) {
    static NSArray<NSString *> *keys;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keys = @[
            WCKeyEnabled, WCKeyGlassEnabled, WCKeyGlassIntensity, WCKeyGlassStyle,
            WCKeyAdBlockEnabled, WCKeyDiscoveryEnabled, WCKeyLayoutEnabled,
            WCKeyCellCornerRadius, WCKeyCellInset, WCKeyNavBarAlpha,
            WCKeyTabBarAlpha, WCKeyStatusBarStyle,
            WCKeyCardEnabled, WCKeyCardCornerRadius, WCKeyCardInset,
            WCKeyPerformanceFirst, WCKeyLegacyGlassEnabled, WCKeyEntryButtonEnabled
            , WCKeyGroupEnabled, WCKeyDockEnabled, WCKeyBigTitleEnabled, WCKeyDockInset
            , WCKeyDockPlusEnabled, WCKeySearchFloatBottom, WCKeyLiteMode
            , WCKeyBadgeColorEnabled, WCKeyBadgePreset, WCKeyBadgeHex
            , WCKeyGroupSafeMode, WCKeyGroupOffset, WCKeyGroupSpacing, WCKeyGroupCorner
            , WCKeySafeBoot, WCKeyModuleGlass, WCKeyModuleDock, WCKeyModuleGroup
            , WCKeyModuleBadge, WCKeyModuleLayout
            , WCKeyDockHeight, WCKeyDockWidth, WCKeyDockShowTitle, WCKeyDockSearchEnabled
            , WCKeyGroupChipHex
            , WCKeyDockOffsetX, WCKeyDockOffsetY, WCKeyDockWidthMode, WCKeyDockFixedWidth
            , WCKeyDockSearchPlacement, WCKeyDockLiquidIntensity
            // 1.7.0：分组改名 / 自定义组 / 搜索条
            , WCKeyGroupNamePinned, WCKeyGroupNameFriends, WCKeyGroupNameGroups
            , WCKeyGroupNameService, WCKeyGroupNameOfficial, WCKeyGroupNameOther
            , WCKeyCustomGroup1Name, WCKeyCustomGroup1Keyword
            , WCKeyCustomGroup2Name, WCKeyCustomGroup2Keyword
            , WCKeyCustomGroup3Name, WCKeyCustomGroup3Keyword
            , WCKeySearchMode, WCKeySearchCardHTML, WCKeySearchCardHeight
            , WCKeyGroupSubtitle
            // 1.7.2：组间间距 / 首页标题卡
            , WCKeyGroupSpacingV, WCKeyTitleText, WCKeyTitleSubtitle, WCKeyTitleCardEnabled
            // 1.7.4：自定义标签位置
            , WCKeyCustomLabelPlacement
            // 1.7.3：单组隐藏
            , WCKeyGroupHidePinned, WCKeyGroupHideFriends, WCKeyGroupHideGroups
            , WCKeyGroupHideService, WCKeyGroupHideOfficial, WCKeyGroupHideOther
            // 1.8.3：分组面板背后灰框
            , WCKeyGroupHideFrame
            // 1.8.5：底栏样式（floating / bar）
            , WCKeyDockStyle
        ];
    });
    return keys;
}

void WCPostPrefsChangedNotification(void) {
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                        (__bridge CFNotificationName)WCThemePrefsChangedNotification,
                                        NULL, NULL, true);
}

static void WCSetPrefObject(NSString *key, id value) {
    if (key.length == 0) return;
    CFPreferencesSetAppValue((__bridge CFStringRef)WCStorageKey(key),
                             (__bridge CFPropertyListRef)value,
                             (__bridge CFStringRef)WCThemeDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)WCThemeDomain);
    WCPostPrefsChangedNotification();
}

void WCSetPrefBool(NSString *key, BOOL value) {
    WCSetPrefObject(key, @(value));
}

void WCSetPrefDouble(NSString *key, double value) {
    WCSetPrefObject(key, @(value));
}

void WCSetPrefInteger(NSString *key, NSInteger value) {
    WCSetPrefObject(key, @(value));
}

void WCSetPrefString(NSString *key, NSString *value) {
    WCSetPrefObject(key, value);
}

void WCPrefsResetToDefaults(void) {
    for (NSString *key in WCAllKeys()) {
        CFPreferencesSetAppValue((__bridge CFStringRef)WCStorageKey(key), NULL,
                                 (__bridge CFStringRef)WCThemeDomain);
        // 兼容 1.7.2 及以前的旧键，恢复默认时一并清掉。
        CFPreferencesSetAppValue((__bridge CFStringRef)key, NULL,
                                 (__bridge CFStringRef)WCThemeDomain);
    }
    CFPreferencesAppSynchronize((__bridge CFStringRef)WCThemeDomain);
    [WCPrefs reload];
    WCPostPrefsChangedNotification();
}

/// Dopamine 为 rootless，偏好文件在 /var/jb 下；rootful 作为兜底。
static NSString *WCThemePrefsFilePath(void) {
    static NSString *path;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        BOOL rootless = [[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"];
        NSString *base = rootless ? @"/var/jb" : @"";
        path = [base stringByAppendingPathComponent:
                @"var/mobile/Library/Preferences/com.wctheme.dev.plist"];
    });
    return path;
}

@implementation WCPrefs {
    NSDictionary *_values;
}

+ (instancetype)shared {
    static WCPrefs *shared;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        shared = [[WCPrefs alloc] init];
    });
    return shared;
}

+ (void)reload {
    NSMutableDictionary *values = [NSMutableDictionary dictionary];

    CFPreferencesAppSynchronize((__bridge CFStringRef)WCThemeDomain);
    for (NSString *key in WCAllKeys()) {
        id value = (__bridge_transfer id)CFPreferencesCopyAppValue(
            (__bridge CFStringRef)WCStorageKey(key),
            (__bridge CFStringRef)WCThemeDomain);
        if (!value) {
            // 升级兼容：1.7.2 写入的是不带 wxgb. 前缀的旧键。
            value = (__bridge_transfer id)CFPreferencesCopyAppValue(
                (__bridge CFStringRef)key,
                (__bridge CFStringRef)WCThemeDomain);
        }
        if (value) {
            values[key] = value;
        }
    }

    // CFPreferences 在部分越狱环境下读不到时，直接读 plist 作为兜底。
    if (values.count == 0) {
        NSDictionary *fileValues = [NSDictionary dictionaryWithContentsOfFile:WCThemePrefsFilePath()];
        if ([fileValues isKindOfClass:[NSDictionary class]]) {
            for (NSString *key in fileValues) {
                NSString *plain = [key hasPrefix:@"wxgb."] ? [key substringFromIndex:5] : key;
                values[plain] = fileValues[key];
            }
        }
    }

    WCPrefs *shared = [self shared];
    @synchronized (shared) {
        shared->_values = [values copy];
    }
    // 首次读取（构造函数里调用）时 _values 为空，会走上面的赋值；之后
    // getter 都能拿到一份完整快照。
}

- (NSDictionary *)valuesSnapshot {
    @synchronized (self) {
        return _values ?: @{};
    }
}

- (id)valueForKey:(NSString *)key {
    return [self valuesSnapshot][key];
}

- (BOOL)boolForKey:(NSString *)key defaultValue:(BOOL)fallback {
    id value = [self valueForKey:key];
    return value ? [value boolValue] : fallback;
}

- (double)doubleForKey:(NSString *)key defaultValue:(double)fallback {
    id value = [self valueForKey:key];
    return value ? [value doubleValue] : fallback;
}

- (NSInteger)integerForKey:(NSString *)key defaultValue:(NSInteger)fallback {
    id value = [self valueForKey:key];
    return value ? [value integerValue] : fallback;
}

- (BOOL)enabled { return [self boolForKey:WCKeyEnabled defaultValue:YES]; }
// 1.5.1：默认只留 core，所有模块总闸默认关，由用户逐个打开。
- (BOOL)safeBoot { return [self boolForKey:WCKeySafeBoot defaultValue:NO]; }
- (BOOL)moduleGlass { return [self boolForKey:WCKeyModuleGlass defaultValue:NO]; }
- (BOOL)moduleDock { return [self boolForKey:WCKeyModuleDock defaultValue:NO]; }
- (BOOL)moduleGroup { return [self boolForKey:WCKeyModuleGroup defaultValue:NO]; }
- (BOOL)moduleBadge { return [self boolForKey:WCKeyModuleBadge defaultValue:NO]; }
- (BOOL)moduleLayout { return [self boolForKey:WCKeyModuleLayout defaultValue:NO]; }
- (BOOL)glassEnabled { return [self boolForKey:WCKeyGlassEnabled defaultValue:YES]; }
- (double)glassIntensity { return [self doubleForKey:WCKeyGlassIntensity defaultValue:0.08]; }
- (NSInteger)glassStyle { return [self integerForKey:WCKeyGlassStyle defaultValue:0]; }
- (BOOL)adBlockEnabled { return [self boolForKey:WCKeyAdBlockEnabled defaultValue:NO]; }
- (BOOL)discoveryEnabled { return [self boolForKey:WCKeyDiscoveryEnabled defaultValue:NO]; }
- (BOOL)layoutEnabled { return [self boolForKey:WCKeyLayoutEnabled defaultValue:NO]; }
- (double)cellCornerRadius { return [self doubleForKey:WCKeyCellCornerRadius defaultValue:0.0]; }
- (double)cellInset { return [self doubleForKey:WCKeyCellInset defaultValue:0.0]; }
- (double)navBarAlpha { return [self doubleForKey:WCKeyNavBarAlpha defaultValue:1.0]; }
- (double)tabBarAlpha { return [self doubleForKey:WCKeyTabBarAlpha defaultValue:1.0]; }
- (NSInteger)statusBarStyle { return [self integerForKey:WCKeyStatusBarStyle defaultValue:0]; }

- (BOOL)cardEnabled { return [self boolForKey:WCKeyCardEnabled defaultValue:YES]; }
- (double)cardCornerRadius { return [self doubleForKey:WCKeyCardCornerRadius defaultValue:14.0]; }
- (double)cardInset { return [self doubleForKey:WCKeyCardInset defaultValue:12.0]; }
- (BOOL)performanceFirst { return [self boolForKey:WCKeyPerformanceFirst defaultValue:NO]; }
- (BOOL)legacyGlassEnabled { return [self boolForKey:WCKeyLegacyGlassEnabled defaultValue:NO]; }
- (BOOL)entryButtonEnabled { return [self boolForKey:WCKeyEntryButtonEnabled defaultValue:YES]; }

- (BOOL)groupEnabled { return [self boolForKey:WCKeyGroupEnabled defaultValue:NO]; }
- (BOOL)groupSafeMode { return [self boolForKey:WCKeyGroupSafeMode defaultValue:NO]; }
- (double)groupOffset { return [self doubleForKey:WCKeyGroupOffset defaultValue:0.0]; }
- (double)groupSpacing { return [self doubleForKey:WCKeyGroupSpacing defaultValue:9.0]; }
- (double)groupCorner { return [self doubleForKey:WCKeyGroupCorner defaultValue:22.0]; }
- (BOOL)dockEnabled { return [self boolForKey:WCKeyDockEnabled defaultValue:NO]; }
- (BOOL)bigTitleEnabled { return [self boolForKey:WCKeyBigTitleEnabled defaultValue:YES]; }
- (double)dockInset { return [self doubleForKey:WCKeyDockInset defaultValue:14.0]; }
- (double)dockHeight { return [self doubleForKey:WCKeyDockHeight defaultValue:60.0]; }
- (double)dockWidth { return [self doubleForKey:WCKeyDockWidth defaultValue:0.0]; }
- (BOOL)dockShowTitle { return [self boolForKey:WCKeyDockShowTitle defaultValue:NO]; }
- (BOOL)dockSearchEnabled { return [self boolForKey:WCKeyDockSearchEnabled defaultValue:NO]; }
- (double)dockOffsetX { return [self doubleForKey:WCKeyDockOffsetX defaultValue:12.0]; }
- (double)dockOffsetY { return [self doubleForKey:WCKeyDockOffsetY defaultValue:10.0]; }
- (NSInteger)dockWidthMode { return [self integerForKey:WCKeyDockWidthMode defaultValue:0]; }
- (double)dockFixedWidth { return [self doubleForKey:WCKeyDockFixedWidth defaultValue:300.0]; }
- (NSString *)dockSearchPlacement {
    id value = [self valueForKey:WCKeyDockSearchPlacement];
    if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) {
        return (NSString *)value;
    }
    return @"above";
}
- (double)dockLiquidIntensity {
    return [self doubleForKey:WCKeyDockLiquidIntensity defaultValue:60.0];
}
/// 1.8.5：底栏样式。floating=悬浮胶囊（默认，保持 1.8.3 观感）；bar=贴边气泡底栏。
- (NSString *)dockStyle {
    id value = [self valueForKey:WCKeyDockStyle];
    if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) {
        return (NSString *)value;
    }
    return @"floating";
}
- (NSString *)groupChipHex {
    id value = [self valueForKey:WCKeyGroupChipHex];
    return [value isKindOfClass:[NSString class]] ? (NSString *)value : @"#1E70E6";
}

/// 1.7.0：字符串偏好统一读取（去空白，空串视为未设置）。
static NSString *WCPrefString(WCPrefs *prefs, NSString *key) {
    id value = [prefs valueForKey:key];
    if (![value isKindOfClass:[NSString class]]) return nil;
    NSString *text = [(NSString *)value stringByTrimmingCharactersInSet:
                      [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return text.length ? text : nil;
}

- (NSString *)groupNamePinned { return WCPrefString(self, WCKeyGroupNamePinned); }
- (NSString *)groupNameFriends { return WCPrefString(self, WCKeyGroupNameFriends); }
- (NSString *)groupNameGroups { return WCPrefString(self, WCKeyGroupNameGroups); }
- (NSString *)groupNameService { return WCPrefString(self, WCKeyGroupNameService); }
- (NSString *)groupNameOfficial { return WCPrefString(self, WCKeyGroupNameOfficial); }
- (NSString *)groupNameOther { return WCPrefString(self, WCKeyGroupNameOther); }
- (NSString *)groupSubtitle { return WCPrefString(self, WCKeyGroupSubtitle); }
- (double)groupSpacingV { return [self doubleForKey:WCKeyGroupSpacingV defaultValue:12.0]; }
- (NSString *)titleText {
    NSString *text = WCPrefString(self, WCKeyTitleText);
    return text.length ? text : @"微信";
}
- (NSString *)titleSubtitle { return WCPrefString(self, WCKeyTitleSubtitle); }
- (BOOL)titleCardEnabled { return [self boolForKey:WCKeyTitleCardEnabled defaultValue:YES]; }
- (NSInteger)customLabelPlacement {
    return [self integerForKey:WCKeyCustomLabelPlacement defaultValue:0];
}

- (BOOL)groupHideFrame { return [self boolForKey:WCKeyGroupHideFrame defaultValue:YES]; }

- (BOOL)groupHiddenForIdent:(NSString *)ident {
    if ([ident isEqualToString:@"pinned"]) return [self boolForKey:WCKeyGroupHidePinned defaultValue:NO];
    if ([ident isEqualToString:@"friends"]) return [self boolForKey:WCKeyGroupHideFriends defaultValue:NO];
    if ([ident isEqualToString:@"groups"]) return [self boolForKey:WCKeyGroupHideGroups defaultValue:NO];
    if ([ident isEqualToString:@"service"]) return [self boolForKey:WCKeyGroupHideService defaultValue:NO];
    if ([ident isEqualToString:@"official"]) return [self boolForKey:WCKeyGroupHideOfficial defaultValue:NO];
    if ([ident isEqualToString:@"other"]) return [self boolForKey:WCKeyGroupHideOther defaultValue:NO];
    return NO;
}

- (NSArray<NSDictionary *> *)customGroupRules {
    NSMutableArray<NSDictionary *> *rules = [NSMutableArray array];
    NSArray<NSArray<NSString *> *> *specs = @[
        @[@"custom1", WCKeyCustomGroup1Name, WCKeyCustomGroup1Keyword],
        @[@"custom2", WCKeyCustomGroup2Name, WCKeyCustomGroup2Keyword],
        @[@"custom3", WCKeyCustomGroup3Name, WCKeyCustomGroup3Keyword],
    ];
    for (NSArray<NSString *> *spec in specs) {
        NSString *name = WCPrefString(self, spec[1]);
        NSString *keyword = WCPrefString(self, spec[2]);
        if (!name && !keyword) continue;
        NSMutableDictionary *rule = [NSMutableDictionary dictionary];
        rule[@"ident"] = spec[0];
        if (name) rule[@"name"] = name;
        if (keyword) rule[@"keyword"] = keyword;
        [rules addObject:[rule copy]];
    }
    return rules;
}

- (NSString *)searchMode {
    NSString *mode = WCPrefString(self, WCKeySearchMode);
    return [mode isEqualToString:@"html"] ? @"html" : @"input";
}

- (NSString *)searchCardHTML { return WCPrefString(self, WCKeySearchCardHTML); }

- (double)searchCardHeight {
    return [self doubleForKey:WCKeySearchCardHeight defaultValue:48.0];
}

- (BOOL)dockPlusEnabled { return [self boolForKey:WCKeyDockPlusEnabled defaultValue:YES]; }
- (BOOL)searchFloatBottom { return [self boolForKey:WCKeySearchFloatBottom defaultValue:NO]; }
- (BOOL)liteMode { return [self boolForKey:WCKeyLiteMode defaultValue:NO]; }
- (BOOL)badgeColorEnabled { return [self boolForKey:WCKeyBadgeColorEnabled defaultValue:NO]; }
- (NSInteger)badgePreset { return [self integerForKey:WCKeyBadgePreset defaultValue:0]; }
- (NSString *)badgeHex {
    id value = [self valueForKey:WCKeyBadgeHex];
    return [value isKindOfClass:[NSString class]] ? (NSString *)value : @"#FA5151";
}

@end
