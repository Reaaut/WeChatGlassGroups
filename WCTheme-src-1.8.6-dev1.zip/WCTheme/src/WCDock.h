#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 悬浮胶囊底栏（静态版）。
//
// 做法：
// - 原生 UITabBar 保留（不删除，微信内部仍按原生 tab 逻辑工作），只隐藏它的"底"：
//   背景条、分隔线；
// - 在图标层下面插一个左右留边、圆角=高度一半的胶囊模糊视图，图标/徽标仍在原位；
// - 右侧圆形「＋」挂在 tab bar 的父视图上（可点），点击转发到微信导航栏的原生「＋」；
// - 关闭开关时 WCDockRestore 把原生外观与视图全部还原，不需要重启微信。
//
// 所有锚点都做存在性校验，类名变化时只丢这个模块。

#ifdef __cplusplus
extern "C" {
#endif

void WCDockStart(void);
void WCDockRefresh(void);

/// UITabBar.layoutSubviews 时调用（幂等）。
void WCDockApplyToTabBar(UITabBar *bar);

/// 关闭 / 卸载时还原原生底栏外观。
void WCDockRestore(UITabBar *bar);

/// 首页出现时调用：记录宿主，按需挂悬浮搜索胶囊与「＋」。
void WCDockHandleHome(UIViewController *controller);

/// 1.6.4：只有主 TabBar 子控制器（首页 / 通讯录 / 发现 / 我）显示浮岛。
/// 聊天 / 搜索页隐藏浮岛并恢复原生底栏 alpha=1；首页的 appear 回调在聊天页
/// 期间仍会触发，因此统一由顶层 VC 类型判定兜底。
void WCDockSetHomeVisible(BOOL visible, NSString *reason, BOOL restoreNative);

/// 1.6.4：0.15s 后按顶层 VC 再判定一次（非定时器循环，单次派发）。
void WCDockScheduleVerdictCheck(void);

/// 1.8.3：分享 / 转发 / 选联系人等模态弹出时，临时隐藏悬浮搜索胶囊。
void WCDockSetSceneObscured(BOOL obscured);

/// 1.6.3：分组折叠面板底部可用的 y（浮岛可见时取浮岛 minY - 10，否则留出原生底栏）。
CGFloat WCDockReservedBottom(UIView *host);

/// 1.7.6：keyWindow 最上层透明容器（tag 'WCOH'），分组面板 / 浮岛 / 搜索胶囊统一挂这里。
/// 找不到窗口返回 nil。
UIView * _Nullable WCDockOverlayHost(void);

/// 1.7.6：移除所有自建浮层容器（关闭模块 / 安全模式 / 熔断时调用，避免残影）。
void WCDockRemoveOverlayHosts(void);

/// 1.6.2：自定义头像文件路径（rootless 为 /var/jb/...）。
NSString *WCDockAvatarPath(void);
/// 1.6.2：删除自定义头像，恢复默认占位。
BOOL WCDockClearCustomAvatar(void);

/// 1.7.0：从「我」页原生头像视图截一张 42×42，作为底栏右侧真实头像。
void WCDockCaptureProfileAvatar(UIViewController *controller);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
