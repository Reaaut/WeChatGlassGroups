#import "WCDock.h"
#import "WCPrefs.h"
#import "WCLog.h"
#import "WCWallpaper.h"
#import "WCGroup.h"
#import "WCSettingsEntry.h"
#import "WCSurfaceGlass.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>

// 1.6.0 底栏浮岛 + 头像菜单。
//
// 结构：
// - 原生 UITabBar 只把视觉隐藏（alpha=0.02，保留对象与 delegate），微信内部切页逻辑不变；
// - 在首页控制器 view 上挂一条悬浮胶囊（4 个线性图标 + 右侧圆形头像）；
// - 点图标走 setSelectedIndex: + tabBar:didSelectItem:；
// - 角标直接读 UITabBarItem.badgeValue 复制到胶囊图标右上角；
// - 点头像向上展开卡片菜单（12 项，可长按拖动排序，点击转发原生入口）。
//
// 1.6.2：
// - 无文字标签，SF Symbols 线性图标，内容宽度自适应 / 固定宽度可选；
// - 液态玻璃用「模糊 + 白色 tint + 折射渐变 + 径向高光 + 2px 渐变描边 + 阴影」分层模拟；
// - 位置参数化（offsetX / offsetY），长按 0.6s 可拖动浮岛并写回偏好；
// - 搜索胶囊独立浮在浮岛上方一侧，不撑开浮岛；
// - 只在首页显示，非首页隐藏并还原原生底栏。
//
// 所有应用动作都在下一个 runloop 执行（1.5.1 卡死根因是布局回调里改视图树）。

static const NSInteger WCDockIslandTag = 0x57434449;   // 'WCDI'
static const NSInteger WCDockMenuTag   = 0x5743444D;   // 'WCDM'
static const NSInteger WCDockBlurTag   = 0x57434442;   // 'WCDB'
static const NSInteger WCDockShadowTag = 0x57434453;   // 'WCDS'
static const NSInteger WCDockSearchTag = 999;
static const NSInteger WCDockSearchCapsuleTag = 997;
static const NSInteger WCDockAvatarTag = 998;
static const NSInteger WCDockHighlightBase = 910;
static const NSInteger WCDockBadgeBase = 900;
static const NSInteger WCDockAdoptedIconTag = 9921;   // 1.7.2：复用进来的原生 imageView
static const NSInteger WCDockTabsStackTag = 9922;     // 1.7.4：四格均布 stack
// 1.8.5：贴边样式（bar）的选中气泡，浮在整条上沿，压不住浮岛。
static const NSInteger WCDockBarBubbleTag = 0x57444242;  // 'WDBB'
// 1.7.6：所有自建浮层统一挂到窗口最上层容器（和微信自己的 + 菜单处于同一层级）。
static const NSInteger WCDockOverlayHostTag = 0x57434F48;  // 'WCOH'
// 1.7.5 的「原生透明 + 底层玻璃」结构在 1.7.6 停用（保留代码仅用于回滚），
// 注意它曾经有个 tag 冲突：tint 9931 和 badge[1] 撞了，导致 badge.text 打到 UIView 上。
static const NSInteger WCDockNativeGlassTag = 0x5744474E;  // 'WDGN'
static const NSInteger WCDockNativeBlockTag = 9923;
static const NSInteger WCDockNativeBadgeBase = 9930;
static const NSInteger WCDockNativeTintTag = 9939;         // 1.7.6：避开 badge 区间
static const BOOL WCDockNativeStructure = NO;              // 1.7.6：回到悬浮版

// 1.7.7：头像独立胶囊直径 52，头像图按 52pt 渲染避免放大糊。
static const CGFloat WCDockAvatarSide = 52.0;
static const CGFloat WCDockSearchCapsuleHeight = 44.0; // 搜索胶囊高 44

// 1.8.3：图标基准 28pt，按 0.86 缩放（≈24pt）；只缩图标，胶囊 / 间距不变。
static const CGFloat WCDockIconBaseSide = 28.0;
static const CGFloat WCDockIconScale = 0.86;
static CGFloat WCDockIconSide(void) {
    CGFloat side = WCDockIconBaseSide * WCDockIconScale;
    return round(side * 2.0) / 2.0;
}
static NSString *gDockIconSizeSignature = nil;
static BOOL gDockSceneObscured = NO;
// 1.7.7：头像独立成圆形胶囊，浮岛只放 4 个 tab。
static const NSInteger WCDockAvatarCapsuleTag = 0x57444143;  // 'WDAC'
static const CGFloat WCDockAvatarCapsuleSide = 52.0;

static NSUInteger gDockExceptionCount = 0;
static BOOL gDockDisabled = NO;            // 1.7.6：熔断后整个底栏停用
static __weak UIView *gDockOverlay = nil;  // 1.7.6：自建浮层容器

static const void *WCDockMenuItemKey = &WCDockMenuItemKey;

static BOOL gDockEnabled = NO;
static BOOL gShowTitle = NO;
static BOOL gSearchEnabled = NO;
static BOOL gLite = NO;
static BOOL gApplying = NO;
static BOOL gApplyPending = NO;
static BOOL gHomeVisible = NO;      // 1.6.3：当前页面是否属于主 TabBar 子控制器
static BOOL gRestoreNativeWhenHidden = NO;  // 只有非 TabBar 场景才还原原生底栏
static BOOL gDragging = NO;
static BOOL gIslandFresh = NO;      // 新挂载 → 播一次淡入
static double gDockInset = 14.0;
static double gDockHeight = 60.0;
static double gDockWidth = 0.0;
static double gOffsetX = 12.0;   // 1.7.7：浮岛默认 X=12
static double gOffsetY = 10.0;
static double gFixedWidth = 300.0;
static double gLiquid = 60.0;
static NSInteger gWidthMode = 0;
static NSString *gSearchPlacement = @"above";
static double gIntensity = 0.08;
static NSInteger gStyle = 0;
// 1.8.5：底栏样式（floating = 悬浮胶囊，默认；bar = 贴边整条气泡底栏）。
static NSString *gDockStyle = @"floating";

static __weak UIView *gDockHost = nil;
static __weak UITabBar *gDockBar = nil;
static NSString *gBuiltSignature = nil;
// 1.8.1：高频日志去重签名（值不变绝不打印）。
static NSString *gDockMountLogSignature = nil;
static NSString *gDockIslandLogSignature = nil;
static NSString *gDockStructureLogSignature = nil;
static NSString *gDockWatchdogLogSignature = nil;
static BOOL gDockWatchdogPending = NO;
static NSTimeInterval gDockWatchdogLastRun = 0.0;

static void WCDockLayoutIsland(UIView *island, UITabBar *bar);
static void WCDockRemoveVisualsFromHost(UIView *host);
static void WCDockAnimateSelection(void);
static void WCDockPlayAppearIfNeeded(void);
static void WCDockShowNativeBar(UITabBar *bar);
static void WCDockRemoveIslandEverywhere(void);
static void WCDockBarRestoreChrome(UITabBar *bar);
static void WCDockBarTransparent(UITabBar *bar);   // 1.7.8：整条 bar 快照前临时透明
static UIView *WCDockFindSearchBarView(UIView *root);   // 1.8.0：搜索三级兜底
static BOOL WCDockSendTouch(UIView *view);
static UIImage *WCDockItemViewIcon(NSUInteger index, UITabBar *bar, CGFloat side, NSString **reason); // 1.8.1
static UIImage *WCDockExtractIcon(NSUInteger index, UITabBar *bar, CGFloat side,
                                  NSString **sourceOut, NSString **reasonOut); // 1.8.2
static UIImage *WCDockTrimOpaqueIcon(UIImage *image, CGFloat side, NSString **reason); // 1.8.2
static UIImage *WCDockSymbolIcon(NSUInteger index, BOOL selected, CGFloat side, BOOL dark); // 1.8.2

#pragma mark - 1.7.6 浮层宿主 / 异常熔断

/// 铺满窗口的容器只接管子视图的点击，空白区域一律穿透 ——
/// 否则首页的滚动 / 点击会被这层假透明视图全部吃掉。
@interface WCOverlayContainerView : UIView
@end

@implementation WCOverlayContainerView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    return (hit == self) ? nil : hit;
}

@end

static UIWindow *WCDockOverlayWindow(void) {
    UIApplication *app = [UIApplication sharedApplication];
    UIWindow *key = app.keyWindow;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in app.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
                if (candidate.isKeyWindow) { key = candidate; break; }
            }
            if (key) break;
        }
    }
    if (key) return key;
    NSArray<UIWindow *> *windows = app.windows;
    for (UIWindow *window in windows.reverseObjectEnumerator) {
        if (!window.hidden && window.alpha > 0.01) return window;
    }
    return windows.lastObject;
}

/// 1.7.6：分组面板 / 浮岛 / 搜索胶囊统一挂在这一层，
/// 和微信自己的 + 菜单处于同一个窗口，zPosition 才真正有意义。
UIView *WCDockOverlayHost(void) {
    UIWindow *window = WCDockOverlayWindow();
    if (!window) return nil;

    UIView *host = [window viewWithTag:WCDockOverlayHostTag];
    if (!host) {
        host = [[WCOverlayContainerView alloc] initWithFrame:window.bounds];
        host.tag = WCDockOverlayHostTag;
        host.backgroundColor = [UIColor clearColor];
        host.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [window addSubview:host];
        WCLogLine(@"info", @"dock", @"浮层宿主挂载 window=%@", NSStringFromClass([window class]));
    }
    host.frame = window.bounds;
    [window bringSubviewToFront:host];
    gDockOverlay = host;
    return host;
}

void WCDockRemoveOverlayHosts(void) {
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        [[window viewWithTag:WCDockOverlayHostTag] removeFromSuperview];
    }
    gDockOverlay = nil;
}

BOOL WCDockIsHomeVisible(void) {
    return gHomeVisible;
}

/// 1.7.6：异常一律记全 name / reason / 前 6 帧，方便下次直接定位。
static void WCDockLogException(NSString *stage, NSException *exception) {
    NSArray<NSString *> *stack = exception.callStackSymbols;
    NSMutableArray<NSString *> *head = [NSMutableArray array];
    for (NSUInteger i = 0; i < stack.count && i < 6; i++) {
        [head addObject:stack[i]];
    }
    WCLogLine(@"warn", @"dock", @"exception stage=%@ name=%@ reason=%@ stack=%@",
              stage ?: @"-", exception.name ?: @"-", exception.reason ?: @"-",
              [head componentsJoinedByString:@" <- "]);
}

/// 同一进程内 apply 失败累计 3 次就停用整个底栏，绝不允许 2000+ 次循环。
static void WCDockTripBreaker(void) {
    if (gDockDisabled) return;
    gDockDisabled = YES;
    WCDockShowNativeBar(gDockBar);
    if (gDockBar) WCDockBarRestoreChrome(gDockBar);
    WCDockRemoveIslandEverywhere();
    WCDockRemoveOverlayHosts();
    // 分组面板也挂在浮层宿主上，宿主被移除后让分组自己重建一次（分组关着就什么也不做）。
    WCGroupRefresh();
    WCLogLine(@"error", @"dock", @"熔断：异常累计3次，已停用");
}

static void WCDockNoteException(NSString *stage, NSException *exception) {
    WCDockLogException(stage, exception);
    gDockExceptionCount += 1;
    if (gDockExceptionCount >= 3) WCDockTripBreaker();
}

#pragma mark - 基础

/// 1.7.6：浮岛统一按浅色 / 深色磨砂两种材质，不再跟随「液态强度」换材质。
static BOOL WCDockDarkTheme(void) {
    UIUserInterfaceStyle style = UITraitCollection.currentTraitCollection.userInterfaceStyle;
    UIView *host = gDockHost;
    if (host) style = host.traitCollection.userInterfaceStyle;
    return style == UIUserInterfaceStyleDark;
}

static UIBlurEffectStyle WCDockEffectStyle(void) {
    return WCDockDarkTheme() ? UIBlurEffectStyleSystemMaterialDark
                             : UIBlurEffectStyleSystemMaterialLight;
}

/// 浅色白 tint 0.14，深色白 tint 0.06；有壁纸时由 WCWallpaperTintAlpha 再降 0.1。
static double WCDockTintAlpha(void) {
    return WCWallpaperTintAlpha(WCDockDarkTheme() ? 0.06 : 0.14);
}

#pragma mark - 头像

NSString *WCDockAvatarPath(void) {
    static NSString *path;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *base = @"/var/jb/var/mobile/Library/WCTheme";
        if (![[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"]) {
            base = @"/var/mobile/Library/WCTheme";
        }
        path = [base stringByAppendingPathComponent:@"avatar.png"];
    });
    return path;
}

BOOL WCDockClearCustomAvatar(void) {
    NSString *path = WCDockAvatarPath();
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) return NO;
    NSError *error = nil;
    BOOL ok = [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
    WCLogLine(@"info", @"dock", @"清除自定义头像 ok=%d path=%@", ok, path);
    return ok;
}

/// 默认头像：中性灰圆 + 人形剪影，不用微信「我」那个蓝色人像。
static UIImage *WCDockDefaultAvatar(void) {
    static UIImage *image;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        CGFloat side = WCDockAvatarSide;
        UIGraphicsImageRenderer *renderer =
            [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side)];
        image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
            CGContextRef ctx = context.CGContext;
            CGRect rect = CGRectMake(0, 0, side, side);
            [[UIColor colorWithWhite:0.93 alpha:1.0] setFill];
            UIBezierPath *circle = [UIBezierPath bezierPathWithRoundedRect:rect
                                                             cornerRadius:side / 2.0];
            [circle fill];

            [[UIColor colorWithWhite:0.48 alpha:1.0] setFill];
            CGContextSaveGState(ctx);
            CGContextAddPath(ctx, circle.CGPath);
            CGContextClip(ctx);
            UIBezierPath *head = [UIBezierPath bezierPathWithOvalInRect:
                                  CGRectMake(side * 0.32, side * 0.20, side * 0.36, side * 0.36)];
            [head fill];
            UIBezierPath *body = [UIBezierPath bezierPathWithRoundedRect:
                                  CGRectMake(side * 0.22, side * 0.60, side * 0.56, side * 0.42)
                                                           cornerRadius:side * 0.20];
            [body fill];
            CGContextRestoreGState(ctx);
        }];
    });
    return image;
}

/// 1.7.0：当前登录账号头像缓存（从「我」页原生头像视图截一张 42×42）。
static UIImage *gProfileAvatar = nil;
static NSUInteger gProfileCaptureRetryCount = 0;   // 最多补采 2 次，避免死循环

static UIImage *WCDockRoundedAvatar(UIImage *source) {
    if (!source) return nil;
    CGFloat side = WCDockAvatarSide;
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side)];
    return [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
        CGRect rect = CGRectMake(0, 0, side, side);
        [[UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:side / 2.0] addClip];
        CGFloat scale = MAX(side / MAX(source.size.width, 1.0),
                            side / MAX(source.size.height, 1.0));
        CGSize size = CGSizeMake(source.size.width * scale, source.size.height * scale);
        [source drawInRect:CGRectMake((side - size.width) / 2.0,
                                      (side - size.height) / 2.0,
                                      size.width, size.height)];
    }];
}

void WCDockCaptureProfileAvatar(UIViewController *controller) {
    UIView *root = controller.view;
    if (!root) return;
    // 「我」页刚出现时 cell 可能还没 layout，头像 image 仍是空的。
    [root setNeedsLayout];
    [root layoutIfNeeded];

    UIImageView *found = nil;
    UIImageView *loose = nil;
    UIImage *buttonImage = nil;
    CGRect bounds = root.bounds;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 400;
    while (queue.count && budget > 0 && !found) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UIImageView class]]) {
            UIImageView *imageView = (UIImageView *)view;
            NSString *name = NSStringFromClass([imageView class]);
            if (imageView.image && imageView.bounds.size.width >= 28.0) {
                BOOL named = ([name containsString:@"HeadImage"] ||
                              [name containsString:@"Avatar"]);
                if (named) { found = imageView; break; }
                // 兜底：左上角区域、接近正方形的小图（「我」页头像在顶部第一行）。
                // 1.7.3：排除封面/海报这类长方形缩略图，避免把整块 cell 内容裁成圆形。
                CGRect rect = [imageView convertRect:imageView.bounds toView:root];
                CGFloat sideW = imageView.bounds.size.width;
                CGFloat sideH = imageView.bounds.size.height;
                BOOL nearlySquare = (sideH > 1.0 && fabs(sideW / sideH - 1.0) <= 0.12);
                if (!loose && sideW >= 36.0 && sideW <= 120.0 && nearlySquare &&
                    rect.origin.y < CGRectGetHeight(bounds) * 0.30 &&
                    rect.origin.x < CGRectGetWidth(bounds) * 0.55) {
                    loose = imageView;
                }
            }
        } else if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            UIImage *image = [button imageForState:UIControlStateNormal];
            // 1.7.3：排除 1×1 占位图（上一版「我」页头像被采成 1×1，放大后就是黑色圆形剪影）。
            if (!buttonImage && image && button.bounds.size.width >= 36.0 &&
                image.size.width >= 24.0 && image.size.height >= 24.0) {
                buttonImage = image;
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }
    UIImage *source = found.image ?: loose.image ?: buttonImage;
    if (!source) {
        WCLogLine(@"warn", @"dock", @"「我」页未找到原生头像视图，继续用占位头像");
        // 1.7.1：最多补采 2 次，避免 layout 时机错过导致永远拿不到。
        if (gProfileCaptureRetryCount < 2) {
            gProfileCaptureRetryCount += 1;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                if (!gProfileAvatar) WCDockCaptureProfileAvatar(controller);
            });
        }
        return;
    }

    UIImage *snapshot = WCDockRoundedAvatar(source);
    gProfileAvatar = snapshot;
    gProfileCaptureRetryCount = 0;
    WCLogLine(@"info", @"dock", @"账号头像已缓存 cls=%@ src=%@ size=(%.0fx%.0f)",
              NSStringFromClass([(found ?: loose) class]),
              found ? @"account-headimage" : (loose ? @"account-loose" : @"account-button"),
              source.size.width, source.size.height);

    // 已经建好浮岛时立即换上新头像，不必等下一次布局。
    UIView *island = [gDockHost viewWithTag:WCDockIslandTag];
    UIButton *avatar = nil;
    NSMutableArray<UIView *> *stack = [NSMutableArray array];
    // 1.7.7：头像在独立胶囊里，从宿主整棵树里找。
    if (gDockHost) [stack addObject:gDockHost];
    if (island) [stack addObject:island];
    while (stack.count && !avatar) {
        UIView *view = stack.lastObject;
        [stack removeLastObject];
        if (view.tag == WCDockAvatarTag && [view isKindOfClass:[UIButton class]]) {
            avatar = (UIButton *)view;
            break;
        }
        [stack addObjectsFromArray:view.subviews];
    }
    if (avatar && snapshot) {
        [avatar setImage:[snapshot imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                 forState:UIControlStateNormal];
    }
}

/// 1.7.1：头像来源 custom → account → none（灰色剪影），并打日志。
static NSString *gDockAvatarLastSrc = nil;

static UIImage *WCDockAvatarRendered(UITabBar *bar) {
    NSString *src = @"none";
    UIImage *result = nil;
    NSString *path = WCDockAvatarPath();
    UIImage *custom = [UIImage imageWithContentsOfFile:path];
    if (custom) {
        result = WCDockRoundedAvatar(custom);
        src = @"custom";
    }
    if (!result && gProfileAvatar) {
        result = gProfileAvatar;
        src = @"account";
    }
    if (!result) {
        result = WCDockDefaultAvatar();
        src = @"none";
    }
    if (![src isEqualToString:(gDockAvatarLastSrc ?: @"")]) {
        gDockAvatarLastSrc = [src copy];
        WCLogLine(@"info", @"dock", @"头像 src=%@ size=%.0fx%.0f",
                  src, result.size.width, result.size.height);
    }
    return result;
}

/// 1.7.0：等比缩放到边长 side 以内（aspect-fit），不再只按高度缩放导致宽图标压扁。
static UIImage *WCDockResizeImage(UIImage *image, CGFloat side) {
    if (!image) return nil;
    CGSize original = image.size;
    if (original.width <= 0.0 || original.height <= 0.0) return image;
    CGFloat longest = MAX(original.width, original.height);
    if (fabs(longest - side) < 0.5) return image;
    CGFloat scale = side / longest;
    CGSize size = CGSizeMake(round(original.width * scale), round(original.height * scale));
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:size];
    return [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
        [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    }];
}

/// 1.8.0：裁切结果居中贴到正方形画布（不拉伸、不留灰底），scale 跟随屏幕。
static UIImage *WCDockSquareIcon(UIImage *image, CGFloat side) {
    if (!image) return nil;
    UIImage *fit = WCDockResizeImage(image, side);
    if (!fit) return nil;
    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.opaque = NO;
    format.scale = [UIScreen mainScreen].scale;
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side) format:format];
    UIImage *canvas = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGRect rect = CGRectMake((side - fit.size.width) / 2.0, (side - fit.size.height) / 2.0,
                                 fit.size.width, fit.size.height);
        [fit drawInRect:rect];
    }];
    return [canvas imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

/// 1.8.2：微信底栏是「UITabBarButton（空壳，只有 Label）」+「MMTabBarItemView（真图标）」
/// 成对出现的（真机日志 8 个候选交替）。旧实现按 x 取前 4 个，正好取到 2 个空壳，
/// 所以永远只有 2/4 有图。这里只保留子树里带 UIImage / MMTabBarItemView 的真按钮。
static BOOL WCDockButtonHasImageInSubtree(UIView *view, NSUInteger depth) {
    if (!view || depth > 5) return NO;
    for (UIView *sub in view.subviews) {
        if ([sub isKindOfClass:[UIImageView class]] && ((UIImageView *)sub).image) return YES;
        if ([sub isKindOfClass:[UIButton class]] && ((UIButton *)sub).currentImage) return YES;
        if (WCDockButtonHasImageInSubtree(sub, depth + 1)) return YES;
    }
    return NO;
}

static NSArray<UIView *> *WCDockTabBarButtons(UITabBar *bar) {
    NSMutableArray<UIView *> *all = [NSMutableArray array];
    NSMutableArray<UIView *> *real = [NSMutableArray array];
    for (UIView *sub in bar.subviews) {
        NSString *cls = NSStringFromClass([sub class]);
        if (!([cls containsString:@"TabBarButton"] || [cls containsString:@"TabBarItem"] ||
              ([sub isKindOfClass:[UIControl class]] && sub.bounds.size.width >= 20.0))) {
            continue;
        }
        [all addObject:sub];
        if ([cls containsString:@"TabBarItem"] ||
            WCDockButtonHasImageInSubtree(sub, 0)) {
            [real addObject:sub];
        }
    }
    static NSString *loggedSignature = nil;
    NSString *signature = [NSString stringWithFormat:@"%lu#%lu#%.0f",
                           (unsigned long)all.count, (unsigned long)real.count,
                           bar.bounds.size.width];
    if (![signature isEqualToString:(loggedSignature ?: @"")]) {
        loggedSignature = [signature copy];
        WCLogLine(@"info", @"dock", @"原生按钮 候选=%lu 有效=%lu",
                  (unsigned long)all.count, (unsigned long)real.count);
    }

    NSMutableArray<UIView *> *buttons = [(real.count ? real : all) mutableCopy];
    [buttons sortUsingComparator:^NSComparisonResult(UIView *a, UIView *b) {
        if (a.frame.origin.x < b.frame.origin.x) return NSOrderedAscending;
        if (a.frame.origin.x > b.frame.origin.x) return NSOrderedDescending;
        return NSOrderedSame;
    }];
    return buttons;
}

/// 1.7.3：每个 UITabBarButton 的完整层级只打一次 —— 用来确认另外两个 tab 到底有没有
/// UIImageView / UIButton 图，还是微信用自绘字形。
static void WCDockLogButtonHierarchy(UITabBar *bar) {
    static NSMutableSet<NSNumber *> *logged;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ logged = [NSMutableSet set]; });

    NSArray<UIView *> *buttons = WCDockTabBarButtons(bar);
    for (NSUInteger i = 0; i < buttons.count; i++) {
        if ([logged containsObject:@(i)]) continue;
        UIView *button = buttons[i];
        [button setNeedsLayout];
        [button layoutIfNeeded];

        NSMutableArray<NSString *> *parts = [NSMutableArray array];
        NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:button];
        NSUInteger budget = 80;
        while (queue.count && budget > 0) {
            budget -= 1;
            UIView *view = queue.firstObject;
            [queue removeObjectAtIndex:0];
            NSString *desc = NSStringFromClass([view class]);
            if ([view isKindOfClass:[UIImageView class]]) {
                desc = [desc stringByAppendingFormat:@"(image=%d)",
                        ((UIImageView *)view).image ? 1 : 0];
            } else if ([view isKindOfClass:[UIButton class]]) {
                UIButton *buttonView = (UIButton *)view;
                desc = [desc stringByAppendingFormat:@"(cur=%d,bg=%d)",
                        buttonView.currentImage ? 1 : 0,
                        buttonView.currentBackgroundImage ? 1 : 0];
            }
            [parts addObject:desc];
            [queue addObjectsFromArray:view.subviews];
        }
        [logged addObject:@(i)];
        WCLogLine(@"info", @"dock", @"btn %lu cls=%@ sub=%@",
                  (unsigned long)i, NSStringFromClass([button class]),
                  [parts componentsJoinedByString:@" > "]);
    }
}

/// 1.7.3：递归找 button 里第一个非空 UIImageView.image。
static UIImage *WCDockImageViewImage(UIView *button) {
    if (!button) return nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:button];
    NSUInteger budget = 80;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UIImageView class]]) {
            UIImage *image = ((UIImageView *)view).image;
            if (image && ((UIImageView *)view).bounds.size.width >= 8.0) return image;
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return nil;
}

/// 1.8.2：bundle 图标目录（deb 资源 / 运行时自缓存都放这里）。
static NSString *WCDockIconDir(void) {
    NSString *base = @"/var/jb/var/mobile/Library/WCTheme";
    if (![[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"]) {
        base = @"/var/mobile/Library/WCTheme";
    }
    return [base stringByAppendingPathComponent:@"icons"];
}

/// 运行时把取到的官方图标落盘，下一次即使微信对象拿不到图也能直接读 bundle。
static void WCDockPersistIcon(UIImage *image, NSUInteger index) {
    if (!image) return;
    NSString *dir = WCDockIconDir();
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:dir]) {
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    NSData *png = UIImagePNGRepresentation(image);
    if (png.length == 0) return;
    NSString *path = [dir stringByAppendingPathComponent:
                      [NSString stringWithFormat:@"tab%lu.png", (unsigned long)index]];
    [png writeToFile:path atomically:YES];
}

/// bundle 兜底：tab0..tab3.png（也接受 wechat/contacts/discover/me 命名）。
static UIImage *WCDockBundleIcon(NSUInteger index, CGFloat side, NSString **pathOut) {
    static NSArray<NSString *> *names;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        names = @[@"wechat", @"contacts", @"discover", @"me"];
    });
    NSString *dir = WCDockIconDir();
    NSString *base = (index < names.count) ?
        names[index] : [NSString stringWithFormat:@"tab%lu", (unsigned long)index];
    NSMutableArray<NSString *> *candidates = [NSMutableArray array];
    [candidates addObject:[NSString stringWithFormat:@"tab%lu.png", (unsigned long)index]];
    [candidates addObject:[NSString stringWithFormat:@"%@.png", base]];
    [candidates addObject:[NSString stringWithFormat:@"%@@3x.png", base]];
    for (NSString *name in candidates) {
        NSString *path = [dir stringByAppendingPathComponent:name];
        UIImage *image = [UIImage imageWithContentsOfFile:path];
        if (image && image.size.width >= 4.0) {
            if (pathOut) *pathOut = path;
            return WCDockSquareIcon(image, side);
        }
    }
    return nil;
}

/// 1.8.2：运行时扫 ivar —— 名称里含 icon/image 的 UIImage 属性。
static UIImage *WCDockIconFromIvars(UIView *view) {
    if (!view) return nil;
    for (Class cls = [view class]; cls && cls != [UIView class];
         cls = class_getSuperclass(cls)) {
        unsigned int count = 0;
        Ivar *ivars = class_copyIvarList(cls, &count);
        if (!ivars) continue;
        UIImage *found = nil;
        for (unsigned int i = 0; i < count; i++) {
            const char *name = ivar_getName(ivars[i]);
            const char *type = ivar_getTypeEncoding(ivars[i]);
            if (!name || !type || type[0] != '@') continue;
            NSString *lower = [NSString stringWithUTF8String:name].lowercaseString;
            if (!([lower containsString:@"icon"] || [lower containsString:@"image"])) continue;
            @try {
                id value = object_getIvar(view, ivars[i]);
                if ([value isKindOfClass:[UIImage class]] &&
                    ((UIImage *)value).size.width >= 8.0) {
                    found = value;
                    break;
                }
            } @catch (NSException *exception) {
            }
        }
        free(ivars);
        if (found) return found;
    }
    return nil;
}

/// 1.8.2：在 button 子树里挑「最大、非 Badge」的 UIImageView.image ——
/// MMTabBarItemView 里有 MMWebImageView / UIImageView / MMBadgeView 三张图，
/// 直接取第一张会拿到徽标或底色块，所以按 bounds 面积挑最大的那张。
static UIImage *WCDockBestIconImage(UIView *button, NSString **clsOut) {
    if (!button) return nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:button];
    NSUInteger budget = 80;
    CGFloat bestArea = 0.0;
    UIImage *best = nil;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UIImageView class]]) {
            NSString *cls = NSStringFromClass([view class]);
            UIImage *image = ((UIImageView *)view).image;
            if (image && image.size.width >= 8.0 && image.size.height >= 8.0 &&
                ![cls containsString:@"Badge"]) {
                CGFloat area = view.bounds.size.width * view.bounds.size.height;
                if (area <= 0.0) area = image.size.width * image.size.height;
                if (area > bestArea) {
                    bestArea = area;
                    best = image;
                    if (clsOut) *clsOut = cls;
                }
            }
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return best;
}

/// 1.8.2：图标硬取图链路 —— imgview → tabbaritem → ivar → itemview 快照 → bundle。
/// 谁先取到合法图就用谁，日志固定打一行「图标取图 i=.. 来源=.. size=(w×h)」。
static UIImage *WCDockExtractIcon(NSUInteger index, UITabBar *bar, CGFloat side,
                                  NSString **sourceOut, NSString **reasonOut) {
    NSString *source = @"none";
    NSString *reason = @"-";
    UIImage *result = nil;
    NSArray<UIView *> *buttons = WCDockTabBarButtons(bar);
    UIView *button = (index < buttons.count) ? buttons[index] : nil;

    // 1) 子树里的 UIImageView.image（真机日志里 MMTabBarItemView 的 image=1）。
    NSString *viewCls = @"-";
    UIImage *raw = WCDockBestIconImage(button, &viewCls);
    if (raw) {
        result = WCDockTrimOpaqueIcon(raw, side, &reason);
        if (result) source = @"imgview";
    }

    // 2) UITabBarItem.image / selectedImage。
    if (!result && index < bar.items.count) {
        UITabBarItem *item = bar.items[index];
        UIImage *itemImage = item.image ?: item.selectedImage;
        if (itemImage) {
            result = WCDockTrimOpaqueIcon(itemImage, side, &reason);
            if (result) source = @"tabbaritem";
        }
    }

    // 3) 运行时 ivar / 属性名含 icon / image（MMTabBarItemView 私有字段）。
    if (!result) {
        UIImage *ivarImage = WCDockIconFromIvars(button);
        if (!ivarImage) {
            for (UIView *sub in button.subviews) {
                ivarImage = WCDockIconFromIvars(sub);
                if (ivarImage) break;
            }
        }
        if (ivarImage) {
            result = WCDockTrimOpaqueIcon(ivarImage, side, &reason);
            if (result) source = @"ivar";
        }
    }

    // 4) itemview 快照回退（旧路径，仍可能拿到实心块）。
    if (!result) {
        UIImage *snap = WCDockItemViewIcon(index, bar, side, &reason);
        if (snap) {
            result = snap;
            source = @"snapshot";
        }
    }

    // 5) bundle PNG 兜底（deb 资源 / 运行时自缓存）。
    if (!result) {
        NSString *path = nil;
        UIImage *bundle = WCDockBundleIcon(index, side, &path);
        if (bundle) {
            result = bundle;
            source = @"bundle";
        } else {
            reason = reason.length && ![reason isEqualToString:@"-"] ? reason : @"bundle-miss";
        }
    }

    if (result && ([source isEqualToString:@"imgview"] || [source isEqualToString:@"tabbaritem"] ||
                   [source isEqualToString:@"ivar"])) {
        // 官方图一旦取到就落盘，下次 bundle 直接可用。
        WCDockPersistIcon(result, index);
    }

    WCLogLine(@"info", @"dock",
              @"图标取图 i=%lu 来源=%@ size=(%.0fx%.0f) cls=%@ 原因=%@",
              (unsigned long)index, source,
              result ? result.size.width : 0.0, result ? result.size.height : 0.0,
              viewCls, reason ?: @"-");
    if (sourceOut) *sourceOut = source;
    if (reasonOut) *reasonOut = reason;
    return result;
}

/// 1.7.8：单项快照在两个未显示的 tab 上拍不到（blank），改为整条 UITabBar 一次快照，
/// 再按 items.count 等分裁切；同一个 tab 的图标永远来自同一次绘制，不会串位。
static NSArray<UIImage *> *gDockBarIcons = nil;
static NSString *gDockBarIconsKey = nil;
static NSString *gDockBarIconsFailedKey = nil;
static NSString *gDockBarIconsReason = @"-";

static NSString *WCDockBarSnapshotKey(UITabBar *bar, BOOL dark) {
    NSUInteger count = bar.items.count;
    // 1.8.1：选中项不参与 key —— 官方彩色图标不随选中变色，避免每次切 tab 重拍整条 bar。
    return [NSString stringWithFormat:@"%.0fx%.0f#%lu#%d#%.2f",
            bar.bounds.size.width, bar.bounds.size.height,
            (unsigned long)count, dark ? 1 : 0,
            [UIScreen mainScreen].scale];
}

/// 整条 bar 绘制成一张图：先临时透明化背景、alpha 拉回 1（可能被旧逻辑藏成 0.02），
/// 并藏掉自建浮岛 / 头像胶囊 / 搜索条 / 阴影，拍完立即恢复原样。
static UIImage *WCDockRenderWholeBar(UITabBar *bar, NSString **reason) {
    if (!bar) { *reason = @"no-bar"; return nil; }
    CGRect bounds = bar.bounds;
    if (bounds.size.width < 40.0 || bounds.size.height < 20.0) {
        *reason = @"bar-bounds";
        return nil;
    }

    [bar setNeedsLayout];
    [bar layoutIfNeeded];
    for (UIView *button in WCDockTabBarButtons(bar)) {
        [button setNeedsLayout];
        [button layoutIfNeeded];
    }

    CGFloat savedAlpha = bar.alpha;
    BOOL savedHidden = bar.hidden;
    BOOL savedInteraction = bar.userInteractionEnabled;
    UIColor *savedBg = bar.backgroundColor;
    UIImage *savedBgImage = bar.backgroundImage;
    UIImage *savedShadow = bar.shadowImage;
    UITabBarAppearance *savedStd = nil;
    UITabBarAppearance *savedScroll = nil;
    if (@available(iOS 13.0, *)) {
        savedStd = bar.standardAppearance;
        savedScroll = bar.scrollEdgeAppearance;
    }

    UIView *island = [gDockHost viewWithTag:WCDockIslandTag];
    UIView *shadow = [gDockHost viewWithTag:WCDockShadowTag];
    UIView *capsule = [gDockHost viewWithTag:WCDockSearchCapsuleTag];
    UIView *avatarCapsule = [gDockHost viewWithTag:WCDockAvatarCapsuleTag];
    BOOL islandHidden = island.hidden;
    BOOL shadowHidden = shadow.hidden;
    BOOL capsuleHidden = capsule.hidden;
    BOOL avatarHidden = avatarCapsule.hidden;
    island.hidden = YES;
    shadow.hidden = YES;
    capsule.hidden = YES;
    avatarCapsule.hidden = YES;

    // 只留图标：背景 / 阴影 / 毛玻璃全部临时关掉，避免裁切时把整条底栏当内容。
    WCDockBarTransparent(bar);

    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.opaque = NO;
    format.scale = [UIScreen mainScreen].scale;
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:bounds.size format:format];
    UIImage *full = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        @try {
            [bar.layer renderInContext:ctx.CGContext];
        } @catch (NSException *exception) {
            WCDockLogException(@"bar-snapshot", exception);
        }
    }];

    island.hidden = islandHidden;
    shadow.hidden = shadowHidden;
    capsule.hidden = capsuleHidden;
    avatarCapsule.hidden = avatarHidden;

    bar.alpha = savedAlpha;
    bar.hidden = savedHidden;
    bar.userInteractionEnabled = savedInteraction;
    bar.backgroundColor = savedBg;
    bar.backgroundImage = savedBgImage;
    bar.shadowImage = savedShadow;
    if (@available(iOS 13.0, *)) {
        if (savedStd) bar.standardAppearance = savedStd;
        if (savedScroll) bar.scrollEdgeAppearance = savedScroll;
    }

    if (!full) {
        *reason = @"render-nil";
        return nil;
    }
    return full;
}

/// 1.8.1：逐段诊断日志，必须能看出每段是 bar 裁切还是 itemview 回退。
static void WCDockLogSegment(NSUInteger index, CGRect segment, CGFloat pct,
                             CGRect bbox, BOOL blank, NSString *source) {
    WCLogLine(@"info", @"dock",
              @"图标段 i=%lu 段=(%.0f,%.0f,%.0f,%.0f) 非透明=%.1f%% 外接矩形=(%.0f,%.0f,%.0f,%.0f) blank=%d 来源=%@",
              (unsigned long)index,
              segment.origin.x, segment.origin.y, segment.size.width, segment.size.height,
              pct, bbox.origin.x, bbox.origin.y, bbox.size.width, bbox.size.height,
              blank ? 1 : 0, source);
}

/// 按 items.count 等分，每列取「中心区域内最大非透明外接矩形」，去掉上下留白后缩放。
static NSArray<UIImage *> *WCDockSplitBarImage(UIImage *image, NSUInteger count,
                                               CGFloat side, NSString **reason, BOOL verbose) {
    CGImageRef cg = image.CGImage;
    if (!cg) { *reason = @"no-cgimage"; return nil; }
    NSUInteger W = CGImageGetWidth(cg);
    NSUInteger H = CGImageGetHeight(cg);
    if (count == 0 || W < count * 12 || H < 12) {
        *reason = @"image-small";
        return nil;
    }

    size_t stride = W * 4;
    unsigned char *pixels = (unsigned char *)calloc(H, stride);
    if (!pixels) { *reason = @"oom"; return nil; }
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctx = CGBitmapContextCreate(pixels, W, H, 8, stride, space,
                                             kCGImageAlphaPremultipliedLast);
    CGColorSpaceRelease(space);
    if (!ctx) {
        free(pixels);
        *reason = @"no-context";
        return nil;
    }
    CGContextDrawImage(ctx, CGRectMake(0, 0, W, H), cg);
    CGContextRelease(ctx);

    NSMutableArray *icons = [NSMutableArray array];
    NSUInteger sy0 = (NSUInteger)floor(H * 0.06);
    NSUInteger sy1 = (NSUInteger)ceil(H * 0.94);
    if (sy1 > H) sy1 = H;
    for (NSUInteger i = 0; i < count; i++) {
        NSUInteger x0 = (NSUInteger)floor((double)W * i / count);
        NSUInteger x1 = (NSUInteger)floor((double)W * (i + 1) / count);
        if (x1 > W) x1 = W;
        NSUInteger inset = MAX(2, (x1 - x0) / 20);
        NSUInteger sx0 = x0 + inset;
        NSUInteger sx1 = x1 - inset;
        CGRect segment = CGRectMake((CGFloat)x0, (CGFloat)sy0,
                                    (CGFloat)(x1 - x0), (CGFloat)(sy1 - sy0));
        if (sx1 <= sx0) {
            if (verbose) WCDockLogSegment(i, segment, 0.0, CGRectZero, YES, @"bar");
            [icons addObject:[NSNull null]];
            continue;
        }

        NSUInteger minX = sx1, maxX = sx0, minY = sy1, maxY = sy0, hits = 0;
        for (NSUInteger y = sy0; y < sy1; y++) {
            unsigned char *row = pixels + y * stride;
            for (NSUInteger x = sx0; x < sx1; x++) {
                if (row[x * 4 + 3] < 24) continue;
                hits += 1;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        double pct = (double)hits * 100.0 / (double)((sx1 - sx0) * (sy1 - sy0));
        if (hits < 8 || maxX < minX || maxY < minY) {
            if (verbose) WCDockLogSegment(i, segment, pct, CGRectZero, YES, @"bar");
            [icons addObject:[NSNull null]];
            continue;
        }

        CGRect rect = CGRectMake((CGFloat)minX, (CGFloat)minY,
                                 (CGFloat)(maxX - minX + 1), (CGFloat)(maxY - minY + 1));
        // 背景没被透明掉时整列都会「非透明」，这种结果宁可不要。
        if (rect.size.width > (CGFloat)(sx1 - sx0) * 0.92 &&
            rect.size.height > (CGFloat)(sy1 - sy0) * 0.92) {
            if (verbose) WCDockLogSegment(i, segment, pct, rect, YES, @"bar");
            [icons addObject:[NSNull null]];
            continue;
        }

        CGImageRef piece = CGImageCreateWithImageInRect(cg, rect);
        if (!piece) {
            if (verbose) WCDockLogSegment(i, segment, pct, rect, YES, @"bar");
            [icons addObject:[NSNull null]];
            continue;
        }
        UIImage *crop = [UIImage imageWithCGImage:piece scale:image.scale
                                        orientation:UIImageOrientationUp];
        CGImageRelease(piece);
        // 1.8.0：最大非透明外接矩形 → 居中贴正方形画布，避免绿圆 / 蓝圆错位。
        UIImage *icon = WCDockSquareIcon(crop, side);
        if (verbose) WCDockLogSegment(i, segment, pct, rect, icon ? NO : YES, @"bar");
        [icons addObject:icon ?: [NSNull null]];
    }
    free(pixels);
    return (NSArray<UIImage *> *)icons;
}

static NSUInteger WCDockBarIconCount(NSArray *icons) {
    NSUInteger ok = 0;
    for (id icon in icons) {
        if ([icon isKindOfClass:[UIImage class]]) ok += 1;
    }
    return ok;
}

/// 1.8.1：整条快照只在 bar 尺寸 / items / 深色变化时重拍；每段先按 bar 裁切，
/// blank 段立刻用该段 MMTabBarItemView 单独重拍回退，收尾打印 k/4 与失败明细。
static NSArray<UIImage *> *WCDockBarSnapshotIcons(UITabBar *bar, CGFloat side, BOOL dark) {
    if (!bar) return @[];
    NSUInteger count = MIN((NSUInteger)4, bar.items.count);
    if (count == 0) return @[];

    NSString *key = WCDockBarSnapshotKey(bar, dark);
    if (gDockBarIcons && gDockBarIconsKey && [key isEqualToString:gDockBarIconsKey]) {
        return gDockBarIcons;
    }
    if (gDockBarIconsFailedKey && [key isEqualToString:gDockBarIconsFailedKey]) {
        return @[];
    }

    // 1.8.2：先逐项硬取图（imgview / tabbaritem / ivar），只有缺项才退回整条 bar 快照；
    // 仍缺就整条换 bundle PNG；最后统一 SF Symbols 占位。绝不返回 2/4 半成品。
    NSMutableArray *icons = [NSMutableArray array];
    NSMutableArray<NSString *> *sources = [NSMutableArray array];
    NSMutableArray<NSString *> *failures = [NSMutableArray array];
    for (NSUInteger i = 0; i < count; i++) {
        NSString *source = @"none";
        NSString *why = @"-";
        UIImage *icon = WCDockExtractIcon(i, bar, side, &source, &why);
        if (!icon) {
            [failures addObject:[NSString stringWithFormat:@"%lu(%@)", (unsigned long)i,
                                 why.length && ![why isEqualToString:@"-"] ? why : @"none"]];
        }
        [icons addObject:icon ?: [NSNull null]];
        [sources addObject:source];
    }
    NSUInteger usable = WCDockBarIconCount(icons);
    BOOL hadBar = NO;

    if (usable < count) {
        NSString *reason = @"-";
        UIImage *full = WCDockRenderWholeBar(bar, &reason);
        NSArray *raw = full ? WCDockSplitBarImage(full, count, side, &reason, YES) : nil;
        for (NSUInteger i = 0; i < count && i < raw.count; i++) {
            if ([icons[i] isKindOfClass:[UIImage class]]) continue;
            if ([raw[i] isKindOfClass:[UIImage class]]) {
                icons[i] = raw[i];
                sources[i] = @"bar";
                hadBar = YES;
            }
        }
        usable = WCDockBarIconCount(icons);
    }

    if (usable < count) {
        NSMutableArray *bundleIcons = [NSMutableArray array];
        NSUInteger bundleOK = 0;
        for (NSUInteger i = 0; i < count; i++) {
            UIImage *icon = WCDockBundleIcon(i, side, NULL);
            if (icon) bundleOK += 1;
            [bundleIcons addObject:icon ?: [NSNull null]];
        }
        if (bundleOK == count) {
            icons = bundleIcons;
            [sources removeAllObjects];
            for (NSUInteger i = 0; i < count; i++) [sources addObject:@"bundle"];
            usable = count;
        }
    }

    BOOL usedSymbol = NO;
    if (usable < count) {
        // 兜底一定是 4/4：全段 SF Symbols，颜色跟选中态。
        for (NSUInteger i = 0; i < count; i++) {
            if ([icons[i] isKindOfClass:[UIImage class]]) continue;
            BOOL selected = (bar.selectedItem == bar.items[i]);
            icons[i] = WCDockSymbolIcon(i, selected, side, dark) ?: [NSNull null];
            sources[i] = @"symbol";
            usedSymbol = YES;
        }
        usable = WCDockBarIconCount(icons);
    }

    NSString *scheme = @"direct";
    if (usedSymbol) scheme = @"symbol";
    else if ([sources containsObject:@"bundle"]) scheme = @"bundle";
    else if (hadBar || [sources containsObject:@"bar"]) scheme = @"bar-snapshot";

    NSMutableArray<NSString *> *still = [NSMutableArray array];
    for (NSUInteger i = 0; i < icons.count; i++) {
        if (![icons[i] isKindOfClass:[UIImage class]]) {
            [still addObject:[NSString stringWithFormat:@"%lu", (unsigned long)i]];
        }
    }
    WCLogLine(@"info", @"dock",
              @"图标方案=%@ %lu/%lu 尺寸=%.0f 彩色=1 来源=[%@] 失败=[%@]",
              scheme, (unsigned long)usable, (unsigned long)count, side,
              [sources componentsJoinedByString:@","],
              still.count ? [still componentsJoinedByString:@","]
                          : (failures.count ? [failures componentsJoinedByString:@","] : @"无"));

    // 1.8.3：图标缩放证据 —— 只在尺寸 / 方案 / 命中数变化时打印。
    NSString *sizeSignature = [NSString stringWithFormat:@"%.1f#%@#%lu/%lu",
                               side, scheme, (unsigned long)usable, (unsigned long)count];
    if (![sizeSignature isEqualToString:(gDockIconSizeSignature ?: @"")]) {
        gDockIconSizeSignature = [sizeSignature copy];
        WCLogLine(@"info", @"dock", @"图标尺寸=%.0fpt 缩放=%.2f 方案=%@ %lu/%lu",
                  side, WCDockIconScale, scheme, (unsigned long)usable, (unsigned long)count);
    }

    if (usable == 0) {
        gDockBarIconsFailedKey = [key copy];
        gDockBarIconsReason = @"all-miss";
        return @[];
    }
    gDockBarIcons = [icons copy];
    gDockBarIconsKey = [key copy];
    gDockBarIconsFailedKey = nil;
    gDockBarIconsReason = @"-";
    return gDockBarIcons;
}

/// 1.7.3：官方图完全取不到时按参考包的做法回落 SF Symbols，单色渲染、绝不画色块。
/// 未选中用线稿，选中用 .fill 变体；tint #1A1A1A / 深色 #F2F2F2，26pt。
/// 1.7.6：未选中 #1A1A1A（深色 #EDEDED），选中统一主题绿 #07C160。
static UIColor *WCDockIconTint(BOOL selected, BOOL dark) {
    if (selected) {
        return [UIColor colorWithRed:0.027 green:0.757 blue:0.376 alpha:1.0]; // #07C160
    }
    return dark ? [UIColor colorWithRed:0.929 green:0.929 blue:0.929 alpha:1.0]  // #EDEDED
                : [UIColor colorWithRed:0.102 green:0.102 blue:0.102 alpha:1.0]; // #1A1A1A
}

/// 1.7.4：统一 SF Symbols 套（非 fill 细线版），28pt。
static UIImage *WCDockSymbolIcon(NSUInteger index, BOOL selected, CGFloat side, BOOL dark) {
    static NSArray<NSString *> *names;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        names = @[@"message", @"person.2", @"safari", @"person.crop.circle"];
    });
    NSString *base = names[index % names.count];
    UIImage *image = [UIImage systemImageNamed:base];
    if (!image) return nil;
    UIImage *tinted = [image imageWithTintColor:WCDockIconTint(selected, dark)
                                   renderingMode:UIImageRenderingModeAlwaysOriginal];
    return WCDockResizeImage(tinted, side);
}

/// 1.7.2：把 item.image 的实际值打出来（nil / renderingMode / size），
/// 这是判断「色块」是没图还是被染色的唯一依据。
static void WCDockLogItemImage(NSUInteger index, UITabBarItem *item) {
    static NSMutableSet<NSNumber *> *logged;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ logged = [NSMutableSet set]; });
    if ([logged containsObject:@(index)]) return;
    [logged addObject:@(index)];

    UIImage *image = item.image;
    UIImage *sel = item.selectedImage;
    WCLogLine(@"info", @"dock",
              @"item %lu image=%@ mode=%lu size=%.0fx%.0f selected=%@ selMode=%lu selSize=%.0fx%.0f",
              (unsigned long)index,
              (id)image ?: @"nil",
              (unsigned long)(image ? image.renderingMode : 0),
              image ? image.size.width : 0.0, image ? image.size.height : 0.0,
              (id)sel ?: @"nil",
              (unsigned long)(sel ? sel.renderingMode : 0),
              sel ? sel.size.width : 0.0, sel ? sel.size.height : 0.0);
}

/// 1.7.4：单个 index 的原生图候选（item image → UITabBarButton 内 UIImageView），
/// 取到后统一染色成同一套颜色（禁止彩色原图混入）。
static UIImage *WCDockNativeIcon(NSUInteger index, BOOL selected, UITabBarItem *item,
                                 UITabBar *bar, CGFloat side, BOOL dark) {
    UIImage *original = selected ? (item.selectedImage ?: item.image)
                                 : (item.image ?: item.selectedImage);
    if (!original) {
        NSArray<UIView *> *buttons = WCDockTabBarButtons(bar);
        UIView *button = (index < buttons.count) ? buttons[index] : nil;
        original = WCDockImageViewImage(button);
    }
    if (!original || original.size.width < 8.0 || original.size.height < 8.0) return nil;
    UIImage *templateImage = [original imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    UIImage *tinted = [templateImage imageWithTintColor:WCDockIconTint(selected, dark)
                                           renderingMode:UIImageRenderingModeAlwaysOriginal];
    return WCDockResizeImage(tinted, side);
}

/// 1.8.0：裁出最大非透明外接矩形后居中贴正方形画布（单项回退用）。
static UIImage *WCDockTrimOpaqueIcon(UIImage *image, CGFloat side, NSString **reason) {
    CGImageRef cg = image ? image.CGImage : NULL;
    if (!cg) { *reason = @"item-no-cg"; return nil; }
    NSUInteger W = CGImageGetWidth(cg);
    NSUInteger H = CGImageGetHeight(cg);
    if (W < 8 || H < 8) { *reason = @"item-small"; return nil; }

    size_t stride = W * 4;
    unsigned char *pixels = (unsigned char *)calloc(H, stride);
    if (!pixels) { *reason = @"item-oom"; return nil; }
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctx = CGBitmapContextCreate(pixels, W, H, 8, stride, space,
                                             kCGImageAlphaPremultipliedLast);
    CGColorSpaceRelease(space);
    if (!ctx) { free(pixels); *reason = @"item-no-context"; return nil; }
    CGContextDrawImage(ctx, CGRectMake(0, 0, W, H), cg);
    CGContextRelease(ctx);

    NSUInteger minX = W, maxX = 0, minY = H, maxY = 0, hits = 0;
    for (NSUInteger y = 0; y < H; y++) {
        unsigned char *row = pixels + y * stride;
        for (NSUInteger x = 0; x < W; x++) {
            if (row[x * 4 + 3] < 24) continue;
            hits += 1;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
    }
    free(pixels);
    if (hits < 6 || maxX <= minX || maxY <= minY) { *reason = @"item-blank"; return nil; }

    CGRect rect = CGRectMake((CGFloat)minX, (CGFloat)minY,
                             (CGFloat)(maxX - minX + 1), (CGFloat)(maxY - minY + 1));
    CGImageRef piece = CGImageCreateWithImageInRect(cg, rect);
    if (!piece) { *reason = @"item-crop"; return nil; }
    UIImage *crop = [UIImage imageWithCGImage:piece scale:image.scale
                                    orientation:UIImageOrientationUp];
    CGImageRelease(piece);
    return WCDockSquareIcon(crop, side);
}

/// 1.8.0：整条裁切某段为空时，回退到该 MMTabBarItemView 自带的 icon view 快照。
/// 先 layoutIfNeeded + 一次 CATransaction flush，保证该 tab 已完成布局再拍。
static UIImage *WCDockItemViewIcon(NSUInteger index, UITabBar *bar, CGFloat side, NSString **reason) {
    [bar setNeedsLayout];
    [bar layoutIfNeeded];
    [CATransaction flush];

    NSArray<UIView *> *buttons = WCDockTabBarButtons(bar);
    if (index >= buttons.count) { *reason = @"item-no-button"; return nil; }
    UIView *button = buttons[index];
    [button setNeedsLayout];
    [button layoutIfNeeded];

    // 自带 imageView 的官方图优先（彩色原图，不做染色）。
    UIImage *image = WCDockImageViewImage(button);
    if (image) {
        UIImage *icon = WCDockTrimOpaqueIcon(image, side, reason);
        if (icon) return icon;
    }

    // 找不到 UIImageView 时直接快照 item view（MMTabBarItemView / 最大子视图）。
    UIView *iconView = nil;
    for (UIView *sub in button.subviews) {
        NSString *cls = NSStringFromClass([sub class]);
        if ([cls containsString:@"MMTabBarItemView"] ||
            [cls containsString:@"TabBarItemView"]) {
            iconView = sub;
            break;
        }
    }
    if (!iconView) {
        CGFloat best = 0.0;
        for (UIView *sub in button.subviews) {
            CGFloat area = sub.bounds.size.width * sub.bounds.size.height;
            if (area > best) { best = area; iconView = sub; }
        }
    }
    if (!iconView) iconView = button;
    if (iconView.bounds.size.width < 4.0 || iconView.bounds.size.height < 4.0) {
        *reason = @"item-zero";
        return nil;
    }

    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.opaque = NO;
    format.scale = [UIScreen mainScreen].scale;
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:iconView.bounds.size format:format];
    UIImage *snap = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        @try {
            [iconView.layer renderInContext:ctx.CGContext];
        } @catch (NSException *exception) {
            WCDockLogException(@"item-snapshot", exception);
        }
    }];
    return WCDockTrimOpaqueIcon(snap, side, reason);
}

/// 1.7.8：整条快照失败时才走这里 —— item view 快照 → 原生 item 图（染色）→ SF Symbols。
static UIImage *WCDockIconForIndex(NSUInteger index, BOOL selected, UITabBarItem *item,
                                   UITabBar *bar, CGFloat side, BOOL dark) {
    WCDockLogItemImage(index, item);

    NSString *reason = @"-";
    UIImage *result = WCDockItemViewIcon(index, bar, side, &reason);
    if (!result) result = WCDockNativeIcon(index, selected, item, bar, side, dark);
    if (!result) result = WCDockSymbolIcon(index, selected, side, dark);
    return result;
}

static NSString *const WCDockMenuOrderKey = @"dockMenuOrder";   // 兼容旧版本已写入的排序键

/// 1.8.4：头像菜单改成固定 9 项「真功能」：标题 -> 动作 key。
/// 顺序固定（两列 5 行），不再读取旧的 12 项拖动排序，避免升级后顺序错乱。
static NSArray<NSArray<NSString *> *> *WCDockMenuDefaults(void) {
    return @[
        @[@"个人信息", @"person.crop.circle", @"profile"],
        @[@"我的二维码", @"qrcode", @"qrcode"],
        @[@"扫一扫", @"qrcode.viewfinder", @"scan"],
        @[@"收付款", @"creditcard", @"pay"],
        @[@"朋友圈", @"photo.on.rectangle", @"moments"],
        @[@"主题设置", @"gearshape", @"theme"],
        @[@"壁纸设置", @"photo", @"wallpaper"],
        @[@"分组设置", @"square.grid.2x2", @"group"],
        @[@"关闭浮层", @"xmark.circle", @"hideDock"],
    ];
}

static NSString *WCDockMenuActionKey(NSString *title) {
    for (NSArray<NSString *> *row in WCDockMenuDefaults()) {
        if ([row.firstObject isEqualToString:title]) return row.lastObject;
    }
    return nil;
}

static NSArray<NSString *> *WCDockMenuOrder(void) {
    NSMutableArray<NSString *> *order = [NSMutableArray array];
    for (NSArray<NSString *> *row in WCDockMenuDefaults()) {
        [order addObject:row.firstObject];
    }
    return order;
}

static NSDictionary<NSString *, NSString *> *WCDockMenuSymbols(void) {
    NSMutableDictionary<NSString *, NSString *> *symbols = [NSMutableDictionary dictionary];
    for (NSArray<NSString *> *row in WCDockMenuDefaults()) {
        symbols[row.firstObject] = row[1];   // 1.8.4：第二项才是 SF Symbol，第三项是动作 key
    }
    return symbols;
}

#pragma mark - 点按

/// 1.8.0：第三级兜底 —— accessibilityActivate → 私有触摸事件 → hitTest 后的控件点击。
static BOOL WCDockSimulateSearchTap(UIView *root) {
    UIView *barView = WCDockFindSearchBarView(root);
    if (!barView) return NO;
    @try {
        if ([barView accessibilityActivate]) {
            WCLogLine(@"info", @"dock", @"搜索 模拟点击 accessibility OK cls=%@",
                      NSStringFromClass([barView class]));
            return YES;
        }
    } @catch (NSException *exception) {
    }

    UIView *hit = [barView hitTest:CGPointMake(CGRectGetMidX(barView.bounds),
                                             CGRectGetMidY(barView.bounds))
                           withEvent:nil];
    if (WCDockSendTouch(hit ?: barView)) {
        WCLogLine(@"info", @"dock", @"搜索 模拟点击 touch cls=%@",
                  NSStringFromClass([(hit ?: barView) class]));
        return YES;
    }

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:barView.subviews];
    NSUInteger budget = 200;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *sub = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([sub isKindOfClass:[UIControl class]] || [sub isKindOfClass:[UITextField class]]) {
            if (WCDockSendTouch(sub)) {
                WCLogLine(@"info", @"dock", @"搜索 模拟点击 inner cls=%@",
                          NSStringFromClass([sub class]));
                return YES;
            }
        }
        [queue addObjectsFromArray:sub.subviews];
    }
    return NO;
}

@interface WCDockTapTarget : NSObject
- (void)wc_tapTab:(UIButton *)sender;
- (void)wc_tapAvatar:(UIButton *)sender;
- (void)wc_tapSearch:(UIButton *)sender;
- (void)wc_tapMenuItem:(UIButton *)sender;
- (void)wc_barTapped:(UITapGestureRecognizer *)sender;
- (void)wc_longPressDock:(UILongPressGestureRecognizer *)sender;
@end

static void WCDockToggleMenu(void);
static BOOL WCDockForwardKeyword(NSString *keyword);
static void WCDockRunAvatarAction(NSString *key);
static void WCDockRefreshNow(void);
static void WCDockLayoutNativeGlass(UITabBar *bar);

/// 沿响应链找这个 UITabBar 所属的 UITabBarController（微信也可能不用它）。
static UITabBarController *WCDockTabControllerForBar(UITabBar *bar) {
    UIResponder *responder = bar.nextResponder;
    for (NSUInteger depth = 0; depth < 12 && responder; depth++) {
        if ([responder isKindOfClass:[UITabBarController class]]) {
            return (UITabBarController *)responder;
        }
        responder = responder.nextResponder;
    }
    return nil;
}

/// 切换 tab：优先进 UITabBarController，其次走 delegate，最后点原生 item。
static void WCDockSelectTab(UITabBar *bar, NSUInteger index) {
    if (!bar || index >= bar.items.count) return;
    UITabBarItem *item = bar.items[index];

    UITabBarController *controller = WCDockTabControllerForBar(bar);
    if (controller && index < controller.viewControllers.count) {
        [controller setSelectedIndex:index];
        return;
    }

    id<UITabBarDelegate> delegate = bar.delegate;
    if ([delegate respondsToSelector:@selector(tabBar:didSelectItem:)]) {
        bar.selectedItem = item;
        [delegate tabBar:bar didSelectItem:item];
        return;
    }

    // 兜底：微信自绘的 tab 常常是 UIControl，直接给它发一次点击。
    NSInteger wanted = (NSInteger)index;
    NSMutableArray<UIControl *> *items = [NSMutableArray array];
    for (UIView *sub in bar.subviews) {
        if ([sub isKindOfClass:[UIControl class]]) {
            [items addObject:(UIControl *)sub];
        }
    }
    if (wanted < (NSInteger)items.count) {
        [items[(NSUInteger)wanted] sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
}

/// 1.7.2：找首页控制器（NewMainFrameViewController）用于调用官方搜索入口。
static UIViewController *WCDockNewMainFrameController(void) {
    NSMutableArray<UIViewController *> *roots = [NSMutableArray array];
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        if (window.rootViewController) [roots addObject:window.rootViewController];
    }
    if (gDockHost) {
        UIResponder *responder = gDockHost;
        while (responder && ![responder isKindOfClass:[UIViewController class]]) {
            responder = responder.nextResponder;
        }
        if ([responder isKindOfClass:[UIViewController class]]) {
            [roots addObject:(UIViewController *)responder];
        }
    }
    NSMutableArray<UIViewController *> *queue = [NSMutableArray arrayWithArray:roots];
    NSUInteger budget = 220;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIViewController *controller = queue.firstObject;
        [queue removeObjectAtIndex:0];
        NSString *name = NSStringFromClass([controller class]);
        if ([name containsString:@"NewMainFrame"]) return controller;
        for (UIViewController *child in controller.childViewControllers) {
            [queue addObject:child];
        }
        if (controller.presentedViewController) [queue addObject:controller.presentedViewController];
    }
    return nil;
}

/// 1.8.0：在页面里找 WCSearchBar / UISearchBar 实体。
static UIView *WCDockFindSearchBarView(UIView *root) {
    if (!root) return nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 500;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        NSString *name = NSStringFromClass([view class]);
        if ([view isKindOfClass:[UISearchBar class]] ||
            [name containsString:@"WCSearchBar"] ||
            [name containsString:@"SearchBar"]) {
            return view;
        }
        [queue addObjectsFromArray:view.subviews];
    }
    return nil;
}

/// 1.8.0：优先从控制器 view 里找，其次读 `searchBar` / `_searchBar` 属性。
static UIView *WCDockControllerSearchBar(UIViewController *controller) {
    if (!controller) return nil;
    UIView *found = WCDockFindSearchBarView(controller.view);
    if (found) return found;
    for (NSString *key in @[@"searchBar", @"_searchBar", @"wcSearchBar"]) {
        @try {
            id value = [controller valueForKey:key];
            if ([value isKindOfClass:[UIView class]]) return (UIView *)value;
        } @catch (NSException *exception) {
        }
    }
    return nil;
}

/// 1.8.0：按方法签名安全调用 `showSearchBar:searchBar:autoStartGreenMic:`，
/// 把真实的 WCSearchBar 一并传进去（上一版传 nil，官方入口根本没反应）。
static BOOL WCDockCallShowSearchBar(UIViewController *controller, UIView *searchBar) {
    SEL selector = @selector(showSearchBar:searchBar:autoStartGreenMic:);
    if (!controller || ![controller respondsToSelector:selector]) return NO;
    NSMethodSignature *signature = [controller methodSignatureForSelector:selector];
    if (!signature || signature.numberOfArguments < 3) return NO;
    @try {
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
        invocation.target = controller;
        invocation.selector = selector;
        NSInteger argc = (NSInteger)signature.numberOfArguments;
        for (NSInteger i = 2; i < argc; i++) {
            const char *type = [signature getArgumentTypeAtIndex:(NSUInteger)i];
            if (type[0] == 'B' || type[0] == 'c') {
                BOOL yes = (i == 2);   // showSearchBar:YES, autoStartGreenMic:NO
                [invocation setArgument:&yes atIndex:i];
            } else {
                id value = searchBar;  // 真实搜索栏
                [invocation setArgument:&value atIndex:i];
            }
        }
        [invocation invoke];
        return YES;
    } @catch (NSException *exception) {
        WCLogLine(@"warn", @"dock", @"showSearchBar 调用失败：%@", exception.reason);
        return NO;
    }
}

/// 1.8.0：二级 —— 对 WCSearchBar 里的 UITextField / UISearchBar 发控件事件。
static BOOL WCDockActivateSearchControl(UIView *root, NSString **detail) {
    UIView *barView = WCDockFindSearchBarView(root);
    if (!barView) { *detail = @"no-searchbar"; return NO; }

    BOOL touched = NO;
    if ([barView isKindOfClass:[UISearchBar class]]) {
        UISearchBar *searchBar = (UISearchBar *)barView;
        [searchBar becomeFirstResponder];
        id<UISearchBarDelegate> delegate = searchBar.delegate;
        if ([delegate respondsToSelector:@selector(searchBarTextDidBeginEditing:)]) {
            [delegate searchBarTextDidBeginEditing:searchBar];
        }
        if ([searchBar respondsToSelector:@selector(sendActionsForControlEvents:)]) {
            [(UIControl *)searchBar sendActionsForControlEvents:UIControlEventTouchUpInside];
        }
        touched = YES;
    }

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:barView];
    NSUInteger budget = 200;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UITextField class]]) {
            UITextField *field = (UITextField *)view;
            [field becomeFirstResponder];
            [field sendActionsForControlEvents:UIControlEventTouchUpInside];
            [field sendActionsForControlEvents:UIControlEventEditingDidBegin];
            touched = YES;
        } else if ([view isKindOfClass:[UISearchBar class]]) {
            [(UISearchBar *)view becomeFirstResponder];
            if ([view respondsToSelector:@selector(sendActionsForControlEvents:)]) {
                [(UIControl *)view sendActionsForControlEvents:UIControlEventTouchUpInside];
            }
            touched = YES;
        } else if ([view isKindOfClass:[UIControl class]]) {
            [(UIControl *)view sendActionsForControlEvents:UIControlEventTouchUpInside];
            touched = YES;
        }
        [queue addObjectsFromArray:view.subviews];
    }
    *detail = [NSString stringWithFormat:@"%@ ", NSStringFromClass([barView class])];
    return touched;
}

/// 1.8.0：三级 —— 安全地调一个无参 / 单 id 参数的私有触摸方法。
static BOOL WCDockInvokeTouch(UIResponder *target, NSString *selectorName) {
    if (!target) return NO;
    SEL selector = NSSelectorFromString(selectorName);
    if (![target respondsToSelector:selector]) return NO;
    @try {
        NSMethodSignature *signature = [target methodSignatureForSelector:selector];
        if (!signature || signature.numberOfArguments < 2) return NO;
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
        invocation.target = target;
        invocation.selector = selector;
        if (signature.numberOfArguments >= 3) {
            id value = nil;
            [invocation setArgument:&value atIndex:2];
        }
        [invocation invoke];
        return YES;
    } @catch (NSException *exception) {
        return NO;
    }
}

static BOOL WCDockSendTouch(UIView *view) {
    if (!view) return NO;
    CGPoint center = CGPointMake(CGRectGetMidX(view.bounds), CGRectGetMidY(view.bounds));
    UIView *hit = [view hitTest:center withEvent:nil];
    UIResponder *target = hit ?: view;
    if (WCDockInvokeTouch(target, @"_sendTouchDown") &&
        WCDockInvokeTouch(target, @"_sendTouchUp")) {
        return YES;
    }
    if ([target isKindOfClass:[UIControl class]]) {
        UIControl *control = (UIControl *)target;
        [control sendActionsForControlEvents:UIControlEventTouchDown];
        [control sendActionsForControlEvents:UIControlEventTouchUpInside];
        [control sendActionsForControlEvents:UIControlEventTouchUpOutside];
        return YES;
    }
    if ([target isKindOfClass:[UITextField class]]) {
        [(UITextField *)target becomeFirstResponder];
        return YES;
    }
    return NO;
}

/// 1.7.2：兜底模拟点击原生 WCSearchBar。
static BOOL WCDockTapNativeSearchBar(UIView *root) {
    UIView *barView = WCDockFindSearchBarView(root);
    if (!barView) return NO;
    BOOL sent = NO;
    if ([barView isKindOfClass:[UIControl class]]) {
        [(UIControl *)barView sendActionsForControlEvents:UIControlEventTouchUpInside];
        sent = YES;
    } else if (WCDockSendTouch(barView)) {
        sent = YES;
    }
    WCLogLine(@"info", @"dock", @"搜索 官方入口=tap-wcsearchbar cls=%@ sent=%d",
              NSStringFromClass([barView class]), sent ? 1 : 0);
    return sent;
}

@implementation WCDockTapTarget

- (void)wc_tapTab:(UIButton *)sender {
    UITabBar *bar = gDockBar;
    if (!bar) return;
    NSInteger index = sender.tag;
    if (index < 0 || index >= (NSInteger)bar.items.count) return;

    @try {
        WCDockSelectTab(bar, (NSUInteger)index);
    } @catch (NSException *exception) {
        WCDockLogException(@"tab", exception);
    }
    WCLogLine(@"info", @"dock", @"tab 点击 index=%ld", (long)index);
    WCDockAnimateSelection();
}

- (void)wc_tapAvatar:(UIButton *)sender {
    @try {
        WCDockToggleMenu();
    } @catch (NSException *exception) {
        WCDockLogException(@"avatar", exception);
    }
}

/// 1.7.5：原生 tab 被点后回读 selectedIndex，同步玻璃层里的选中块。
- (void)wc_barTapped:(UITapGestureRecognizer *)sender {
    if (sender.state != UIGestureRecognizerStateEnded) return;
    UITabBar *bar = gDockBar;
    if (!bar) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.12 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        WCDockLayoutNativeGlass(bar);
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        WCDockLayoutNativeGlass(bar);
    });
}

- (void)wc_longPressDock:(UILongPressGestureRecognizer *)sender {
    if (sender.state != UIGestureRecognizerStateBegan) return;
    if (!gHomeVisible) return;
    @try {
        WCDockToggleMenu();
    } @catch (NSException *exception) {
        WCDockLogException(@"menu", exception);
    }
}

- (void)wc_tapSearch:(UIButton *)sender {
    @try {
        // 1.7.5：分组面板开着时先切回「消息」，避免搜索被面板挡住。
        WCGroupEnsureMessagesMode();

        // 1.8.0：点击前先切回「消息」tab（原生搜索只挂在首页）。
        UITabBar *bar = gDockBar;
        NSInteger selected = -1;
        for (NSUInteger i = 0; bar && i < bar.items.count; i++) {
            if (bar.selectedItem == bar.items[i]) { selected = (NSInteger)i; break; }
        }
        if (bar && selected > 0) {
            WCDockSelectTab(bar, 0);
            WCLogLine(@"info", @"dock", @"搜索 前置 tab=消息 原=%ld", (long)selected);
        }

        UIViewController *controller = WCDockNewMainFrameController();
        if (!controller) {
            WCLogLine(@"error", @"dock", @"搜索 进入=0 原因=未找到首页控制器");
            return;
        }

        UIView *searchBar = WCDockControllerSearchBar(controller);
        WCLogLine(@"info", @"dock", @"搜索 搜索栏=%@",
                  searchBar ? NSStringFromClass([searchBar class]) : @"nil");

        // 1) 官方 showSearchBar:searchBar:autoStartGreenMic:（主控制器 → 导航栈顶 → 当前 tab）
        NSMutableArray<UIViewController *> *candidates = [NSMutableArray array];
        [candidates addObject:controller];
        UIViewController *navTop = controller.navigationController.topViewController;
        if (navTop) [candidates addObject:navTop];
        UITabBarController *tab = WCDockTabControllerForBar(bar);
        if (tab.selectedViewController) [candidates addObject:tab.selectedViewController];
        for (UIViewController *candidate in candidates) {
            BOOL ok = WCDockCallShowSearchBar(candidate, searchBar);
            WCLogLine(@"info", @"dock", @"搜索 尝试=selector cls=%@ 结果=%d",
                      NSStringFromClass([candidate class]), ok ? 1 : 0);
            if (ok) {
                WCLogLine(@"info", @"dock", @"搜索 进入=1 方式=selector cls=%@",
                          NSStringFromClass([candidate class]));
                return;
            }
        }

        // 2) WCSearchBar 内部的 UITextField / UISearchBar 发控件事件
        NSString *detail = @"-";
        BOOL tapped = WCDockActivateSearchControl(controller.view, &detail);
        WCLogLine(@"info", @"dock", @"搜索 尝试=button cls=%@ 结果=%d", detail, tapped ? 1 : 0);
        if (!tapped) {
            detail = @"-";
            tapped = WCDockActivateSearchControl([UIApplication sharedApplication].keyWindow, &detail);
            WCLogLine(@"info", @"dock", @"搜索 尝试=button window cls=%@ 结果=%d",
                      detail, tapped ? 1 : 0);
        }
        if (tapped) {
            WCLogLine(@"info", @"dock", @"搜索 进入=1 方式=button");
            return;
        }

        // 2b) 直接点 WCSearchBar 控件本身
        BOOL direct = WCDockTapNativeSearchBar(controller.view) ||
                      WCDockTapNativeSearchBar([UIApplication sharedApplication].keyWindow);
        WCLogLine(@"info", @"dock", @"搜索 尝试=tap-wcsearchbar 结果=%d", direct ? 1 : 0);
        if (direct) {
            WCLogLine(@"info", @"dock", @"搜索 进入=1 方式=button");
            return;
        }

        // 3) accessibilityActivate / 私有触摸事件
        BOOL simulated = WCDockSimulateSearchTap(controller.view) ||
                         WCDockSimulateSearchTap([UIApplication sharedApplication].keyWindow);
        WCLogLine(@"info", @"dock", @"搜索 尝试=simulated 结果=%d", simulated ? 1 : 0);
        if (simulated) {
            WCLogLine(@"info", @"dock", @"搜索 进入=1 方式=simulated");
            return;
        }

        WCLogLine(@"error", @"dock",
                  @"搜索 进入=0 原因=selector/button/simulated 全部不可用");
    } @catch (NSException *exception) {
        // 点击回调绝不能把异常抛出去（上一版就是这里闪退）。
        WCDockLogException(@"search", exception);
        WCLogLine(@"error", @"dock", @"搜索 进入=0 原因=exception name=%@",
                  exception.name ?: @"-");
    }
}

- (void)wc_tapMenuItem:(UIButton *)sender {
    @try {
        NSString *title = objc_getAssociatedObject(sender, WCDockMenuItemKey);
        UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
            initWithStyle:UIImpactFeedbackStyleLight];
        [gen impactOccurred];

        NSString *key = WCDockMenuActionKey(title);
        [[gDockHost viewWithTag:WCDockMenuTag] removeFromSuperview];
        WCGroupYieldForMenu(NO);
        if (key.length) WCDockRunAvatarAction(key);
    } @catch (NSException *exception) {
        WCDockLogException(@"menuItem", exception);
    }
}

@end

static WCDockTapTarget *WCDockTap(void) {
    static WCDockTapTarget *target;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ target = [[WCDockTapTarget alloc] init]; });
    return target;
}

/// 在 keyWindow 里找文字包含 keyword 的控件；找到就点一下。
static BOOL WCDockForwardKeyword(NSString *keyword) {
    if (keyword.length == 0) return NO;
    UIApplication *app = [UIApplication sharedApplication];
    NSArray<UIWindow *> *windows = app.windows;
    UIWindow *key = app.keyWindow;
    if (key) {
        NSMutableArray<UIWindow *> *ordered = [NSMutableArray arrayWithObject:key];
        for (UIWindow *window in windows) {
            if (window != key) [ordered addObject:window];
        }
        windows = ordered;
    }

    for (UIWindow *window in windows) {
        if (window.hidden || window.alpha < 0.01) continue;
        NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:window];
        NSUInteger budget = 800;
        while (queue.count && budget > 0) {
            budget -= 1;
            UIView *view = queue.firstObject;
            [queue removeObjectAtIndex:0];

            NSString *text = nil;
            if ([view isKindOfClass:[UILabel class]]) {
                text = ((UILabel *)view).text;
            } else if ([view isKindOfClass:[UIButton class]]) {
                text = [((UIButton *)view) titleForState:UIControlStateNormal];
            }
            if (text.length && [text rangeOfString:keyword].location != NSNotFound) {
                UIView *current = view;
                for (NSUInteger depth = 0; depth < 4 && current; depth++) {
                    if ([current isKindOfClass:[UIControl class]]) {
                        [(UIControl *)current sendActionsForControlEvents:UIControlEventTouchUpInside];
                        return YES;
                    }
                    current = current.superview;
                }
            }
            [queue addObjectsFromArray:view.subviews];
        }
    }
    return NO;
}

#pragma mark - 1.8.4 头像菜单动作

static void WCDockActionLog(NSString *action, NSString *way, BOOL ok, NSString *reason) {
    WCLogLine(@"info", @"dock", @"头像 动作=%@ 方式=%@ ok=%d 失败原因=%@",
              action ?: @"-", way ?: @"-", ok ? 1 : 0, reason.length ? reason : @"-");
}

static UIViewController *WCDockActionTop(void) {
    UIViewController *top = nil;
    for (UIWindow *window in [UIApplication sharedApplication].windows.reverseObjectEnumerator) {
        UIViewController *vc = window.rootViewController;
        NSUInteger guard = 0;
        while (vc.presentedViewController && guard < 8) {
            vc = vc.presentedViewController;
            guard += 1;
        }
        if (!vc) continue;
        if (!top) top = vc;
        NSString *cls = NSStringFromClass([vc class]);
        if (![cls hasPrefix:@"WC"] && ![cls containsString:@"WCDock"]) {
            // 微信真实页面优先（排除我们自己的菜单/面板）。
            if ([cls containsString:@"MainFrame"] || [cls containsString:@"ViewController"]) {
                top = vc;
            }
        }
    }
    return top;
}

static UINavigationController *WCDockActionNav(void) {
    UIViewController *top = WCDockActionTop();
    if (top.navigationController) return top.navigationController;
    for (UIWindow *window in [UIApplication sharedApplication].windows.reverseObjectEnumerator) {
        UIViewController *root = window.rootViewController;
        if ([root isKindOfClass:[UINavigationController class]]) {
            return (UINavigationController *)root;
        }
        if ([root isKindOfClass:[UITabBarController class]]) {
            UIViewController *sel = ((UITabBarController *)root).selectedViewController;
            if (sel.navigationController) return sel.navigationController;
        }
    }
    return nil;
}

static UITabBar *WCDockActionBar(void) {
    if (gDockBar) return gDockBar;
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        if (window.hidden) continue;
        NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:window];
        NSUInteger budget = 500;
        while (queue.count && budget > 0) {
            budget -= 1;
            UIView *view = queue.firstObject;
            [queue removeObjectAtIndex:0];
            if ([view isKindOfClass:[UITabBar class]]) return (UITabBar *)view;
            [queue addObjectsFromArray:view.subviews];
        }
    }
    return nil;
}

/// 运行时探测：按类名列表挨个尝试 init 并 push；返回命中类名，失败原因写进 reason。
static BOOL WCDockActionPushClass(NSArray<NSString *> *names, NSString **clsOut, NSString **reason) {
    for (NSString *name in names) {
        Class cls = NSClassFromString(name);
        if (!cls) {
            if (reason) *reason = @"类不存在";
            continue;
        }
        UIViewController *vc = nil;
        @try {
            vc = [[cls alloc] init];
        } @catch (NSException *exception) {
            vc = nil;
        }
        if (![vc isKindOfClass:[UIViewController class]]) {
            if (reason) *reason = @"实例化失败";
            continue;
        }
        UINavigationController *nav = WCDockActionNav();
        if (!nav) {
            if (reason) *reason = @"无导航控制器";
            return NO;
        }
        @try {
            [nav pushViewController:vc animated:YES];
        } @catch (NSException *exception) {
            if (reason) *reason = @"push失败";
            continue;
        }
        if (clsOut) *clsOut = name;
        return YES;
    }
    return NO;
}

static BOOL WCDockActionOpenScheme(NSString *urlString, NSString **reason) {
    NSURL *url = urlString.length ? [NSURL URLWithString:urlString] : nil;
    if (!url) { if (reason) *reason = @"scheme非法"; return NO; }
    UIApplication *app = [UIApplication sharedApplication];
    if (![app canOpenURL:url]) { if (reason) *reason = @"scheme未注册"; return NO; }
    @try {
        if ([app respondsToSelector:@selector(openURL:options:completionHandler:)]) {
            [app openURL:url options:@{} completionHandler:nil];
        } else {
            [app openURL:url];
        }
        return YES;
    } @catch (NSException *exception) {
        if (reason) *reason = @"scheme打开异常";
        return NO;
    }
}

/// 页面驱动：切到指定 tab，等页面加载后按文字找入口点一下。
static void WCDockActionTabThenTap(NSUInteger tabIndex, NSString *label,
                                   NSString *action, NSString *scheme) {
    UITabBar *bar = WCDockActionBar();
    if (!bar || tabIndex >= bar.items.count) {
        NSString *reason = nil;
        if (WCDockActionOpenScheme(scheme, &reason)) {
            WCDockActionLog(action, @"scheme", YES, nil);
        } else {
            WCDockActionLog(action, @"-", NO, reason ?: @"tab不可用");
        }
        return;
    }
    WCDockSelectTab(bar, tabIndex);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.45 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        @try {
            if (WCDockForwardKeyword(label)) {
                WCDockActionLog(action, @"入口点击", YES, nil);
                return;
            }
            NSString *reason = nil;
            if (scheme.length && WCDockActionOpenScheme(scheme, &reason)) {
                WCDockActionLog(action, @"scheme", YES, nil);
            } else {
                WCDockActionLog(action, @"入口点击", NO, reason ?: @"入口没找到");
            }
        } @catch (NSException *exception) {
            WCDockActionLog(action, @"入口点击", NO, @"点击异常");
        }
    });
}

static void WCDockRunAvatarAction(NSString *key) {
    @try {
        if ([key isEqualToString:@"hideDock"]) {
            WCSetPrefBool(WCKeyModuleDock, NO);
            WCDockActionLog(key, @"settings", YES, nil);
            return;
        }
        if ([key isEqualToString:@"theme"] || [key isEqualToString:@"wallpaper"] ||
            [key isEqualToString:@"group"]) {
            NSString *kw = [key isEqualToString:@"wallpaper"] ? @"壁纸"
                         : ([key isEqualToString:@"group"] ? @"首页" : @"总开关");
            WCSettingsEntryPresentPanelSection(kw);
            WCDockActionLog(key, @"settings", YES, nil);
            return;
        }

        NSArray<NSString *> *names = nil;
        NSString *label = nil;
        NSUInteger tab = 0;
        NSString *scheme = nil;
        if ([key isEqualToString:@"profile"]) {
            names = @[@"WCAccountInfoViewController", @"SettingPersonalInfoViewController",
                      @"PersonalInfoViewController", @"MyInfoViewController"];
            label = @"个人信息"; tab = 3;
        } else if ([key isEqualToString:@"qrcode"]) {
            names = @[@"WCAccountQRCodeViewController", @"MyQRCodeViewController",
                      @"QRCodeViewController", @"WCQRCodeViewController"];
            label = @"我的二维码"; tab = 3;
        } else if ([key isEqualToString:@"scan"]) {
            names = @[@"ScanQRCodeViewController", @"QRCodeScanViewController",
                      @"WCScanQRCodeViewController", @"NewScanQRCodeViewController",
                      @"ScanViewController"];
            label = @"扫一扫"; tab = 2; scheme = @"weixin://scanqrcode";
        } else if ([key isEqualToString:@"pay"]) {
            names = @[@"WCPayViewController", @"CollectMoneyViewController",
                      @"WCCollectMoneyViewController", @"PayViewController"];
            label = @"收付款"; tab = 3; scheme = @"weixin://dl/payments";
        } else if ([key isEqualToString:@"moments"]) {
            names = @[@"WCTimeLineViewController", @"SNSViewController",
                      @"MomentViewController", @"MomentsViewController"];
            label = @"朋友圈"; tab = 2; scheme = @"weixin://dl/moments";
        }

        NSString *cls = nil;
        NSString *reason = nil;
        if (names.count && WCDockActionPushClass(names, &cls, &reason)) {
            WCLogLine(@"info", @"dock", @"头像 动作=%@ 方式=vc ok=1 cls=%@", key, cls);
            return;
        }
        WCDockActionTabThenTap(tab, label, key, scheme);
    } @catch (NSException *exception) {
        WCDockLogException(@"avatarAction", exception);
        WCDockActionLog(key, @"-", NO, @"动作异常");
    }
}

#pragma mark - 图标按钮

@interface WCDockTabButton : UIButton
@end

static BOOL gDockTapLogDone = NO;

@implementation WCDockTabButton

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    // 1.8.3：点击不再出现任何透明底 / 高亮蒙层（图四那个透明框），
    // 只保留图标自身 0.94 的轻微缩放反馈。
    self.backgroundColor = [UIColor clearColor];
    self.opaque = NO;
    [self setBackgroundImage:nil forState:UIControlStateNormal];
    [self setBackgroundImage:nil forState:UIControlStateHighlighted];
    [self setBackgroundImage:nil forState:UIControlStateSelected];
    self.adjustsImageWhenHighlighted = NO;
    self.showsTouchWhenHighlighted = NO;
    self.tintColor = [UIColor clearColor];
    if (!gDockTapLogDone) {
        gDockTapLogDone = YES;
        WCLogLine(@"info", @"dock", @"点击 反馈=scale 底色=clear 蒙层=0");
    }
    return self;
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    // UIButton 默认会给图片压暗 / 叠加高亮层，这里强制恢复为无底色。
    self.backgroundColor = [UIColor clearColor];
    self.imageView.alpha = 1.0;
    [UIView animateWithDuration:0.14
                          delay:0.0
                        options:(UIViewAnimationOptionBeginFromCurrentState |
                                 UIViewAnimationOptionCurveEaseOut)
                     animations:^{
        self.transform = highlighted ? CGAffineTransformMakeScale(0.94, 0.94)
                                     : CGAffineTransformIdentity;
    } completion:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat height = self.bounds.size.height;
    CGSize imageSize = self.imageView.image.size;
    if (imageSize.width <= 0 || self.bounds.size.width <= 0) return;

    // 1.8.3：图标按 WCDockIconSide()（28pt × 0.86 ≈ 24pt），等比缩放已在
    // WCDockResizeImage 完成，这里只负责居中；胶囊尺寸不受影响。
    CGFloat side = MIN(WCDockIconSide(), MIN(imageSize.width, imageSize.height));
    if (side <= 0) return;

    if (self.titleLabel.text.length == 0) {
        self.imageView.frame = CGRectMake((self.bounds.size.width - side) / 2.0,
                                          (height - side) / 2.0, side, side);
        return;
    }
    self.imageView.frame = CGRectMake((self.bounds.size.width - side) / 2.0,
                                      height - side - 14.0, side, side);
    self.titleLabel.frame = CGRectMake(0, height - 13.0, self.bounds.size.width, 12.0);
}

@end

#pragma mark - 菜单卡片

@interface WCDockMenuView : UIView
- (void)layoutAboveFrame:(CGRect)dockFrame;
@end

@interface WCDockMenuView () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIVisualEffectView *blur;
@property (nonatomic, strong) UIView *tint;
@property (nonatomic, strong) NSMutableArray<UIView *> *headerViews;
@property (nonatomic, strong) NSMutableArray<UIButton *> *itemButtons;
@property (nonatomic, weak) UIButton *dragButton;
@property (nonatomic, strong) UILabel *toast;

- (void)buildHeader;
- (void)buildGrid;
- (void)copyWxid;
- (void)showToast:(NSString *)text;
- (void)handleDrag:(UILongPressGestureRecognizer *)gesture;
- (NSUInteger)indexForPoint:(CGPoint)point count:(NSUInteger)count;
@end

static const CGFloat WCDockMenuHeaderHeight = 64.0;
static const CGFloat WCDockMenuCellHeight = 62.0;

@implementation WCDockMenuView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    self.backgroundColor = [UIColor clearColor];
    _headerViews = [NSMutableArray array];
    _itemButtons = [NSMutableArray array];

    _blur = [[UIVisualEffectView alloc]
        initWithEffect:[UIBlurEffect effectWithStyle:WCDockEffectStyle()]];
    _blur.tag = WCDockBlurTag;
    _blur.frame = self.bounds;
    _blur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _blur.userInteractionEnabled = NO;
    _blur.layer.cornerRadius = 20.0;
    _blur.layer.cornerCurve = kCACornerCurveContinuous;
    _blur.clipsToBounds = YES;
    [self addSubview:_blur];

    // 1.8.4：头像菜单与分组面板共用同一套液态玻璃配方（tint 比底栏轻一档）。
    WCApplyLiquidGlass(_blur, 20.0, WCLiquidGlassStylePanel, NO);

    [self buildHeader];
    [self buildGrid];
    return self;
}

- (void)buildHeader {
    for (UIView *view in _headerViews) {
        [view removeFromSuperview];
    }
    [_headerViews removeAllObjects];

    CGFloat width = self.bounds.size.width;

    UIImageView *avatar = [[UIImageView alloc] initWithFrame:CGRectMake(14, 12, 36, 36)];
    avatar.layer.cornerRadius = 18.0;
    avatar.layer.masksToBounds = YES;
    avatar.image = WCDockAvatarRendered(gDockBar);
    avatar.contentMode = UIViewContentModeScaleAspectFill;
    avatar.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    [self addSubview:avatar];
    [_headerViews addObject:avatar];

    UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(60, 11, MAX(60, width - 140), 20)];
    name.text = @"微信用户";
    name.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightSemibold];
    name.textColor = [UIColor labelColor];
    [self addSubview:name];
    [_headerViews addObject:name];

    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"MM-dd";
    UILabel *date = [[UILabel alloc] initWithFrame:CGRectMake(width - 70, 13, 56, 16)];
    date.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    date.text = [fmt stringFromDate:[NSDate date]];
    date.font = [UIFont systemFontOfSize:11.0];
    date.textColor = [UIColor secondaryLabelColor];
    date.textAlignment = NSTextAlignmentRight;
    [self addSubview:date];
    [_headerViews addObject:date];

    UILabel *wxid = [[UILabel alloc] initWithFrame:CGRectMake(60, 31, MAX(60, width - 140), 16)];
    wxid.text = @"点击复制 wxid";
    wxid.font = [UIFont systemFontOfSize:11.0];
    wxid.textColor = [UIColor secondaryLabelColor];
    wxid.userInteractionEnabled = YES;
    [wxid addGestureRecognizer:[[UITapGestureRecognizer alloc]
                                initWithTarget:self action:@selector(copyWxid)]];
    [self addSubview:wxid];
    [_headerViews addObject:wxid];
}

- (void)copyWxid {
    UIPasteboard *paste = [UIPasteboard generalPasteboard];
    paste.string = @"wxid";
    [self showToast:@"已复制"];
    UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
        initWithStyle:UIImpactFeedbackStyleLight];
    [gen impactOccurred];
}

- (void)showToast:(NSString *)text {
    if (!_toast) {
        _toast = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, 26)];
        _toast.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.72];
        _toast.textColor = [UIColor whiteColor];
        _toast.font = [UIFont systemFontOfSize:12.0];
        _toast.textAlignment = NSTextAlignmentCenter;
        _toast.layer.cornerRadius = 13.0;
        _toast.layer.masksToBounds = YES;
        [self addSubview:_toast];
    }
    _toast.text = text;
    _toast.center = CGPointMake(self.bounds.size.width / 2.0, self.bounds.size.height - 24.0);
    _toast.hidden = NO;
    __weak WCDockMenuView *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ weakSelf.toast.hidden = YES; });
}

- (void)buildGrid {
    for (UIButton *button in _itemButtons) {
        [button removeFromSuperview];
    }
    [_itemButtons removeAllObjects];

    NSArray<NSString *> *order = WCDockMenuOrder();
    NSDictionary<NSString *, NSString *> *symbols = WCDockMenuSymbols();

    // 1.8.4：9 项 → 两列 5 行；超过 6 项自动两列，不再 3×4 挤压。
    CGFloat gridTop = WCDockMenuHeaderHeight;
    CGFloat gridHeight = self.bounds.size.height - gridTop - 12.0;
    NSUInteger cols = 2;
    NSUInteger rows = MAX(1, (order.count + cols - 1) / cols);
    CGFloat cellW = self.bounds.size.width / cols;
    CGFloat cellH = MAX(1.0, gridHeight / rows);

    for (NSUInteger i = 0; i < order.count; i++) {
        NSString *title = order[i];
        NSUInteger col = i % cols;
        NSUInteger row = i / cols;

        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(col * cellW, gridTop + row * cellH, cellW, cellH);
        button.tag = (NSInteger)i;
        button.accessibilityIdentifier = title;
        UIImage *icon = [UIImage systemImageNamed:symbols[title] ?: @"circle"];
        [button setImage:icon forState:UIControlStateNormal];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:[UIColor labelColor] forState:UIControlStateNormal];
        [button setTintColor:[UIColor labelColor]];
        button.titleLabel.font = [UIFont systemFontOfSize:12.0];
        [button addTarget:WCDockTap() action:@selector(wc_tapMenuItem:)
          forControlEvents:UIControlEventTouchUpInside];
        objc_setAssociatedObject(button, WCDockMenuItemKey, title, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        [self addSubview:button];
        [_itemButtons addObject:button];
    }
}

- (void)layoutAboveFrame:(CGRect)dockFrame {
    NSUInteger rows = (WCDockMenuOrder().count + 1) / 2;   // 1.8.4：两列，动态行数
    CGFloat height = WCDockMenuHeaderHeight + MAX(rows, 3) * WCDockMenuCellHeight + 12.0;
    height = MIN(height, MAX(240.0, dockFrame.origin.y - 16.0));
    self.frame = CGRectMake(dockFrame.origin.x,
                            MAX(0, dockFrame.origin.y - height - 8.0),
                            dockFrame.size.width, height);
    _blur.frame = self.bounds;
    // 1.8.4：底层玻璃分层由 WCApplyLiquidGlass 的 autoresizing 层自己跟随，无需再手排 tint。

    // 只重建 header / grid，模糊底板与 toast 保留。
    [self buildHeader];
    [self buildGrid];
    if (_toast) {
        _toast.center = CGPointMake(self.bounds.size.width / 2.0, self.bounds.size.height - 24.0);
        [self bringSubviewToFront:_toast];
    }
}

- (void)handleDrag:(UILongPressGestureRecognizer *)gesture {
    UIButton *button = (UIButton *)gesture.view;
    if (![button isKindOfClass:[UIButton class]]) return;

    if (gesture.state == UIGestureRecognizerStateBegan) {
        _dragButton = button;
        [self bringSubviewToFront:button];
        UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
            initWithStyle:UIImpactFeedbackStyleMedium];
        [gen impactOccurred];
        return;
    }
    if (gesture.state != UIGestureRecognizerStateChanged &&
        gesture.state != UIGestureRecognizerStateEnded) {
        return;
    }

    CGPoint point = [gesture locationInView:self];
    button.center = point;

    if (gesture.state == UIGestureRecognizerStateEnded) {
        NSArray<NSString *> *order = WCDockMenuOrder();
        NSUInteger from = (NSUInteger)button.tag;
        NSUInteger to = [self indexForPoint:point count:order.count];
        if (from < order.count && to < order.count && from != to) {
            NSMutableArray<NSString *> *updated = [order mutableCopy];
            NSString *title = updated[from];
            [updated removeObjectAtIndex:from];
            if (to > from) to -= 1;
            to = MIN(to, updated.count);
            [updated insertObject:title atIndex:to];
            [[NSUserDefaults standardUserDefaults] setObject:updated forKey:WCDockMenuOrderKey];
            WCLogLine(@"info", @"dock", @"菜单排序 %@ -> %lu", title, (unsigned long)to);
        }
        _dragButton = nil;
        [self buildGrid];
    }
}

- (NSUInteger)indexForPoint:(CGPoint)point count:(NSUInteger)count {
    if (count == 0) return 0;
    CGFloat gridTop = WCDockMenuHeaderHeight;
    CGFloat gridHeight = self.bounds.size.height - gridTop - 12.0;
    CGFloat cellW = self.bounds.size.width / 3.0;
    CGFloat cellH = MAX(1.0, gridHeight / 4.0);
    if (cellW <= 0) return 0;

    NSInteger col = (NSInteger)(point.x / cellW);
    NSInteger row = (NSInteger)((point.y - gridTop) / cellH);
    col = MAX(0, MIN(2, col));
    row = MAX(0, MIN(3, row));
    NSUInteger index = (NSUInteger)(row * 3 + col);
    return MIN(index, count - 1);
}

@end

#pragma mark - 菜单展开 / 收起

static void WCDockToggleMenu(void) {
    UIView *host = gDockHost;
    if (!host) return;

    UIView *existing = [host viewWithTag:WCDockMenuTag];
    if (existing) {
        [existing removeFromSuperview];
        WCGroupYieldForMenu(NO);
        WCLogLine(@"info", @"dock", @"菜单收起");
        return;
    }

    UIView *island = [host viewWithTag:WCDockIslandTag];
    if (!island || !island.superview) {
        WCLogLine(@"warn", @"dock", @"菜单：浮岛不存在，忽略");
        return;
    }
    CGRect anchorFrame = [island.superview convertRect:island.frame toView:host];

    WCDockMenuView *menu = [[WCDockMenuView alloc] initWithFrame:CGRectZero];
    menu.tag = WCDockMenuTag;
    menu.layer.zPosition = 1000000.0;
    WCLogLine(@"info", @"dock", @"头像 菜单 弹出=1 项数=%lu",
              (unsigned long)WCDockMenuOrder().count);
    [host addSubview:menu];
    [menu layoutAboveFrame:anchorFrame];
    dispatch_async(dispatch_get_main_queue(), ^{
        [host bringSubviewToFront:menu];
    });
    // 1.7.6：菜单打开期间分组面板让位（微信 + 菜单在更上层窗口，zPosition 压不过）。
    WCGroupYieldForMenu(YES);
    WCLogLine(@"info", @"dock", @"菜单展开 z=1000000 panel=100 w=%.0f h=%.0f",
              menu.frame.size.width, menu.frame.size.height);
}

#pragma mark - 液态玻璃

/// 1.6.2 液态玻璃模拟：模糊 + 白色 tint + 45° 折射渐变 + 径向高光 + 2px 渐变描边 + 内侧亮线。
/// iOS 26 有 UIGlassEffect 时只记日志走真玻璃分支（此处仍以模拟层兜底，避免未知 API 崩溃）。
static BOOL WCDockNativeGlassAvailable(void) {
    Class glass = NSClassFromString(@"UIGlassEffect");
    return glass != Nil && [glass respondsToSelector:@selector(effectWithStyle:)];
}

@interface WCDockGlassIsland : UIVisualEffectView
@property (nonatomic, strong) CAGradientLayer *refractionLayer;
@property (nonatomic, strong) CAGradientLayer *radialLayer;
@property (nonatomic, strong) CAGradientLayer *borderGradient;
@property (nonatomic, strong) CAShapeLayer *borderMask;
@property (nonatomic, strong) CAShapeLayer *innerLine;
- (void)updateGlassForRadius:(CGFloat)radius;
@end

@implementation WCDockGlassIsland

- (instancetype)initWithEffect:(UIVisualEffect *)effect {
    self = [super initWithEffect:effect];
    if (!self) return nil;

    self.clipsToBounds = YES;
    self.layer.cornerCurve = kCACornerCurveContinuous;
    self.contentView.layer.masksToBounds = YES;

    // 折射：白色 0.18 → 0.02 → 0.10，45° 斜向。
    _refractionLayer = [CAGradientLayer layer];
    _refractionLayer.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:0.18].CGColor,
                                (id)[UIColor colorWithWhite:1.0 alpha:0.02].CGColor,
                                (id)[UIColor colorWithWhite:1.0 alpha:0.10].CGColor];
    _refractionLayer.locations = @[@0.0, @0.5, @1.0];
    _refractionLayer.startPoint = CGPointMake(0.0, 0.0);
    _refractionLayer.endPoint = CGPointMake(1.0, 1.0);
    [self.contentView.layer addSublayer:_refractionLayer];

    // 径向高光：中心偏左上，白色 0.22 → 透明。
    _radialLayer = [CAGradientLayer layer];
    _radialLayer.type = kCAGradientLayerRadial;
    _radialLayer.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:0.22].CGColor,
                            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor];
    _radialLayer.locations = @[@0.0, @1.0];
    _radialLayer.startPoint = CGPointMake(0.30, 0.05);
    _radialLayer.endPoint = CGPointMake(1.0, 0.95);
    [self.contentView.layer addSublayer:_radialLayer];

    // 2px 渐变描边（上白 0.55、下白 0.12），用 CAShapeLayer 描边做 mask。
    _borderGradient = [CAGradientLayer layer];
    _borderGradient.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:0.55].CGColor,
                               (id)[UIColor colorWithWhite:1.0 alpha:0.12].CGColor];
    _borderGradient.startPoint = CGPointMake(0.0, 0.0);
    _borderGradient.endPoint = CGPointMake(0.0, 1.0);

    _borderMask = [CAShapeLayer layer];
    _borderMask.fillColor = [UIColor clearColor].CGColor;
    _borderMask.strokeColor = [UIColor whiteColor].CGColor;
    _borderMask.lineWidth = 2.0;
    _borderGradient.mask = _borderMask;
    [self.contentView.layer addSublayer:_borderGradient];

    // 内侧 0.5px 亮线，做玻璃厚度的「边」。
    _innerLine = [CAShapeLayer layer];
    _innerLine.fillColor = [UIColor clearColor].CGColor;
    _innerLine.strokeColor = [UIColor colorWithWhite:1.0 alpha:0.35].CGColor;
    _innerLine.lineWidth = 0.5;
    [self.contentView.layer addSublayer:_innerLine];

    return self;
}

- (void)updateGlassForRadius:(CGFloat)radius {
    CGRect bounds = self.bounds;
    self.layer.cornerRadius = radius;
    self.contentView.layer.cornerRadius = radius;
    self.contentView.layer.masksToBounds = YES;
    self.contentView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:WCDockTintAlpha()];

    _refractionLayer.frame = bounds;
    _radialLayer.frame = bounds;
    _borderGradient.frame = bounds;
    _borderMask.frame = bounds;
    _innerLine.frame = bounds;

    // 1.7.6：去掉折射 / 径向高光 / 双层描边，只留磨砂 + 1px 细边。
    _refractionLayer.hidden = YES;
    _radialLayer.hidden = YES;
    _borderGradient.hidden = YES;
    _innerLine.hidden = YES;

    self.layer.borderWidth = 1.0;
    self.layer.borderColor = [UIColor colorWithWhite:1.0
                                                alpha:(WCDockDarkTheme() ? 0.14 : 0.35)].CGColor;
}

@end

/// 1.7.6 选中态：图标后 40×40 圆角 14 的浅色块（不再整格高亮、不再渐变双层）。
@interface WCDockSelectBlock : UIView
@end

@implementation WCDockSelectBlock

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.userInteractionEnabled = NO;
    self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.55];
    self.layer.cornerRadius = 14.0;
    self.layer.cornerCurve = kCACornerCurveContinuous;
    return self;
}

@end

static WCDockSelectBlock *WCDockHighlight(UIButton *button, NSInteger index) {
    UIView *view = [button viewWithTag:WCDockHighlightBase + index];
    if (!view || ![view isKindOfClass:[WCDockSelectBlock class]]) {
        [view removeFromSuperview];
        view = [[WCDockSelectBlock alloc] initWithFrame:CGRectZero];
        view.tag = WCDockHighlightBase + index;
        [button insertSubview:view atIndex:0];
    }
    return (WCDockSelectBlock *)view;
}

/// 浮岛宽度：1.7.6 默认全宽 = 屏宽 − 24（左右各 12），固定模式才用 dockFixedWidth。
static CGFloat WCDockIslandWidth(CGFloat hostW) {
    // 主导航胶囊与右侧头像分离；默认填满可用宽度，避免大屏仍被 305pt 限死。
    // 左右边距各 12pt，头像与主胶囊间距 8pt。
    CGFloat reserved = WCDockAvatarCapsuleSide + 8.0;
    CGFloat available = MAX(200.0, hostW - 24.0 - reserved);

    if (gWidthMode == 1) {
        CGFloat fixed = gFixedWidth;
        if (fixed < 240.0) fixed = 240.0;
        if (fixed > 420.0) fixed = 420.0;
        return MIN(fixed, available);
    }

    if (gDockWidth > 0.0) {
        return MIN(gDockWidth, available);
    }

    // 自适应模式：不同 iPhone 宽度都使用完整可用空间。
    return available;
}

#pragma mark - 拖动

@interface WCDockDragTarget : NSObject
- (void)wc_dragIsland:(UILongPressGestureRecognizer *)gesture;
@end

@implementation WCDockDragTarget

- (void)wc_dragIsland:(UILongPressGestureRecognizer *)gesture {
    UIView *island = gesture.view;
    UIView *host = gDockHost;
    if (!island || !host) return;

    CGPoint point = [gesture locationInView:host];
    CGFloat hostW = host.bounds.size.width;
    CGFloat hostH = host.bounds.size.height;

    if (gesture.state == UIGestureRecognizerStateBegan) {
        gDragging = YES;
        UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
            initWithStyle:UIImpactFeedbackStyleMedium];
        [gen impactOccurred];
        WCLogLine(@"info", @"dock", @"拖动开始 frame=(%.0f,%.0f,%.0f,%.0f)",
                  island.frame.origin.x, island.frame.origin.y,
                  island.frame.size.width, island.frame.size.height);
        return;
    }

    if (gesture.state == UIGestureRecognizerStateChanged) {
        CGFloat width = island.bounds.size.width;
        CGFloat height = island.bounds.size.height;
        CGFloat x = point.x - width / 2.0;
        CGFloat y = point.y - height / 2.0;
        x = MAX(0.0, MIN(hostW - width, x));
        y = MAX(host.safeAreaInsets.top + 4.0, MIN(hostH - height - 4.0, y));
        island.frame = CGRectMake(x, y, width, height);
        UIView *shadow = [host viewWithTag:WCDockShadowTag];
        shadow.frame = island.frame;
        shadow.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:shadow.bounds
                                                              cornerRadius:height / 2.0].CGPath;
        return;
    }

    if (gesture.state == UIGestureRecognizerStateEnded ||
        gesture.state == UIGestureRecognizerStateCancelled) {
        gDragging = NO;
        CGRect frame = island.frame;
        CGFloat width = frame.size.width;

        // 吸附：靠近左右安全边（16pt 内）就贴边。
        CGFloat minX = 0.0;
        CGFloat maxX = MAX(0.0, hostW - width);
        CGFloat x = frame.origin.x;
        if (x - minX < 16.0) x = minX;
        if (maxX - x < 16.0) x = maxX;

        // dockOffsetX 的量程是 0–80，写回后必须用同一量程重排，
        // 否则会出现「松手贴右边缘、下一帧又跳回 80」的位移。
        x = MAX(0.0, MIN(80.0, x));
        CGFloat offsetX = x;
        CGFloat offsetY = hostH - host.safeAreaInsets.bottom - CGRectGetMaxY(frame);
        offsetY = MAX(0.0, MIN(80.0, offsetY));

        gOffsetX = offsetX;
        gOffsetY = offsetY;
        WCSetPrefDouble(WCKeyDockOffsetX, offsetX);
        WCSetPrefDouble(WCKeyDockOffsetY, offsetY);
        WCLogLine(@"info", @"dock", @"拖动保存 offsetX=%.0f offsetY=%.0f", offsetX, offsetY);

        island.frame = CGRectMake(x, frame.origin.y, width, frame.size.height);
        WCDockLayoutIsland(island, gDockBar);
    }
}

@end

static WCDockDragTarget *WCDockDrag(void) {
    static WCDockDragTarget *target;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ target = [[WCDockDragTarget alloc] init]; });
    return target;
}


static UIView *WCDockIslandContent(UIView *island) {
    if ([island isKindOfClass:[UIVisualEffectView class]]) {
        return ((UIVisualEffectView *)island).contentView;
    }
    return island;
}

/// 浮岛宿主：优先 tabBar 所属控制器的 view（整屏、不被裁），其次 keyWindow。
/// 1.6.0 的 bug：挂到 bar.superview（只有 49pt 高）→ 浮岛被裁 / frame 为 0。
static UIView *WCDockHostForBar(UITabBar *bar) {
    UIResponder *responder = bar.nextResponder;
    for (NSUInteger depth = 0; depth < 12 && responder; depth++) {
        if ([responder isKindOfClass:[UIViewController class]]) {
            UIViewController *controller = (UIViewController *)responder;
            if (controller.view && controller.view.window) return controller.view;
        }
        responder = responder.nextResponder;
    }
    if (bar.window) return bar.window;
    return bar.superview;
}

/// 1.7.2：搜索胶囊严格等于浮岛宽度、左右对齐；高 44、圆角 22，液态同款。
static void WCDockLayoutSearchCapsule(UIView *host, CGRect islandFrame) {
    static CGRect lastLoggedFrame = { {0, 0}, {0, 0} };
    UIView *capsule = [host viewWithTag:WCDockSearchCapsuleTag];

    // 1.8.3：分享 / 转发 / 选联系人等模态弹出时，搜索胶囊一起让位；
    // 保留视图只设 hidden，模态收起后原地恢复（不重建）。
    if (gDockSceneObscured) {
        if (capsule) capsule.hidden = YES;
        lastLoggedFrame = CGRectZero;
        return;
    }

    BOOL wants = gSearchEnabled && gHomeVisible &&
                 [gSearchPlacement isEqualToString:@"above"];

    if (!wants) {
        [capsule removeFromSuperview];
        lastLoggedFrame = CGRectZero;
        return;
    }

    CGFloat width = islandFrame.size.width;
    CGFloat height = WCDockSearchCapsuleHeight;
    CGFloat x = islandFrame.origin.x;
    CGFloat y = islandFrame.origin.y - 8.0 - height;
    CGFloat minY = host.safeAreaInsets.top + 4.0;
    if (y < minY) y = CGRectGetMaxY(islandFrame) + 8.0;
    x = MAX(0.0, MIN(host.bounds.size.width - width, x));

    if (!capsule) {
        UIVisualEffectView *view = [[UIVisualEffectView alloc]
            initWithEffect:[UIBlurEffect effectWithStyle:WCDockEffectStyle()]];
        view.tag = WCDockSearchCapsuleTag;
        view.clipsToBounds = YES;

        UIView *tint = [[UIView alloc] initWithFrame:view.bounds];
        tint.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        tint.backgroundColor = [UIColor colorWithWhite:1.0 alpha:WCDockTintAlpha()];
        tint.userInteractionEnabled = NO;
        [view.contentView addSubview:tint];

        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 0, view.bounds.size.width, 1.0)];
        line.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        line.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.35];
        line.userInteractionEnabled = NO;
        [view.contentView addSubview:line];

        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = WCDockSearchTag;
        button.accessibilityIdentifier = @"searchCapsule";
        [button setImage:[UIImage systemImageNamed:@"magnifyingglass"] forState:UIControlStateNormal];
        [button setTitle:@"搜索" forState:UIControlStateNormal];
        [button setTintColor:[UIColor colorWithWhite:0.35 alpha:1.0]];
        [button setTitleColor:[UIColor colorWithWhite:0.35 alpha:1.0] forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        button.imageEdgeInsets = UIEdgeInsetsMake(0, 6, 0, -2);
        button.titleEdgeInsets = UIEdgeInsetsMake(0, 8, 0, -8);
        [button addTarget:WCDockTap() action:@selector(wc_tapSearch:)
          forControlEvents:UIControlEventTouchUpInside];
        [view.contentView addSubview:button];
        capsule = view;

        [host addSubview:capsule];
        WCLogLine(@"info", @"dock", @"搜索胶囊创建 placement=above");
    } else {
        UIView *button = [capsule viewWithTag:WCDockSearchTag];
        button.frame = capsule.bounds;
    }

    capsule.hidden = NO;
    capsule.frame = CGRectMake(x, y, width, height);
    capsule.layer.cornerRadius = height / 2.0;
    capsule.layer.cornerCurve = kCACornerCurveContinuous;
    capsule.layer.zPosition = 310.0;
    [host bringSubviewToFront:capsule];

    CGRect frame = capsule.frame;
    if (!CGRectEqualToRect(frame, lastLoggedFrame)) {
        lastLoggedFrame = frame;
        WCLogLine(@"info", @"dock", @"搜索胶囊 frame=(%.0f,%.0f,%.0f,%.0f) super=(%.0f,%.0f)",
                  frame.origin.x, frame.origin.y, frame.size.width, frame.size.height,
                  host.bounds.size.width, host.bounds.size.height);
    }
}

/// 1.8.3：分享 / 转发 / 选联系人 / 系统相册等模态出现时，临时隐藏悬浮搜索胶囊；
/// 模态收起后原地恢复。分组面板由 WCGroup 同步隐藏。
void WCDockSetSceneObscured(BOOL obscured) {
    if (gDockSceneObscured == obscured) return;
    gDockSceneObscured = obscured;

    for (UIWindow *window in [UIApplication sharedApplication].windows.reverseObjectEnumerator) {
        UIView *capsule = [window viewWithTag:WCDockSearchCapsuleTag];
        if (![capsule isKindOfClass:[UIView class]]) continue;
        capsule.hidden = obscured;
    }
    if (!obscured && gDockHost) {
        UIView *island = [gDockHost viewWithTag:WCDockIslandTag];
        if (island) WCDockLayoutSearchCapsule(gDockHost, island.frame);
    }
}

/// 浮岛是否真的可见：有 window、尺寸合理、至少 80% 面积落在窗口内。
static BOOL WCDockIslandVisible(UIView *island) {
    if (!island || !island.window || island.hidden) return NO;
    if (island.bounds.size.width < 120.0 || island.bounds.size.height < 30.0) return NO;
    if (CGRectIsNull(island.frame) || CGRectIsEmpty(island.frame)) return NO;

    CGPoint origin = [island convertPoint:CGPointZero toView:nil];
    CGRect rect = CGRectMake(origin.x, origin.y, island.bounds.size.width, island.bounds.size.height);
    CGRect windowBounds = island.window.bounds;
    if (CGRectIsNull(windowBounds) || CGRectIsEmpty(windowBounds)) return NO;

    CGRect clipped = CGRectIntersection(rect, windowBounds);
    if (CGRectIsNull(clipped) || CGRectIsEmpty(clipped)) return NO;

    CGFloat area = rect.size.width * rect.size.height;
    if (area <= 0.0) return NO;
    CGFloat ratio = (clipped.size.width * clipped.size.height) / area;
    return ratio >= 0.8;
}

/// 1.8.4：底栏灰底取证 —— 谁在胶囊外面画了灰：阴影 / 原生栏 / 宿主 / 浮岛自身底色。
/// 只在变化时打印，避免刷屏。
static void WCDockLogBottomGray(UIView *island, UITabBar *bar, UIView *host) {
    if (!island || !host) return;
    UIView *shadow = [host viewWithTag:WCDockShadowTag];
    int flags = 0;
    NSString *hit = @"无";
    if (shadow.superview && shadow.layer.shadowOpacity > 0.01) {
        flags |= 1;
        hit = NSStringFromClass([shadow class]);
    }
    if (bar && !bar.hidden && bar.alpha > 0.05) {
        flags |= 2;
        if ([hit isEqualToString:@"无"]) hit = NSStringFromClass([bar class]);
    }
    UIColor *hostBG = host.backgroundColor;
    CGFloat hAlpha = hostBG ? CGColorGetAlpha(hostBG.CGColor) : 0.0;
    if (hostBG && hAlpha > 0.01) {
        flags |= 4;
        if ([hit isEqualToString:@"无"]) hit = NSStringFromClass([host class]);
    }
    UIColor *islandBG = island.backgroundColor;
    CGFloat iAlpha = islandBG ? CGColorGetAlpha(islandBG.CGColor) : 0.0;
    if (islandBG && iAlpha > 0.01) {
        flags |= 8;
        if ([hit isEqualToString:@"无"]) hit = NSStringFromClass([island class]);
    }
    NSString *islandName = islandBG ? ((iAlpha < 0.01) ? @"clear" : @"other") : @"nil";
    NSString *hostName = hostBG ? ((hAlpha < 0.01) ? @"clear" : @"other") : @"nil";
    NSString *signature = [NSString stringWithFormat:@"%d#%@#%@#%@#%d#%.2f",
                           flags, hit, islandName, hostName,
                           bar ? (bar.hidden ? 1 : 0) : -1, bar ? bar.alpha : -1.0];
    static NSString *lastSignature = nil;
    if ([signature isEqualToString:(lastSignature ?: @"")]) return;
    lastSignature = [signature copy];
    WCLogLine(@"info", @"dock",
              @"底 灰源=%d 命中=%@ 浮岛bg=%@ 容器bg=%@ 原生栏 hidden=%d alpha=%.2f",
              flags, hit, islandName, hostName,
              bar ? (bar.hidden ? 1 : 0) : -1, bar ? bar.alpha : 0.0);
}

/// 1.8.5：贴边样式的选中气泡 —— 圆形玻璃球，半个压在整条上沿，跟着选中项横向移动。
/// 只在 bar 样式存在，切回 floating 时直接移除，避免残留旧视图。
static void WCDockLayoutBarBubble(UIView *host, BOOL barStyle, CGRect frame, CGFloat tabsLeft,
                                  CGFloat cellWidth, NSUInteger selectedIndex) {
    UIView *bubble = [host viewWithTag:WCDockBarBubbleTag];
    if (!barStyle || !host) {
        [bubble removeFromSuperview];
        return;
    }
    CGFloat side = 44.0;
    if (!bubble) {
        bubble = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, side, side)];
        bubble.tag = WCDockBarBubbleTag;
        bubble.userInteractionEnabled = NO;
        bubble.backgroundColor = [UIColor clearColor];
        bubble.layer.cornerRadius = side / 2.0;
        bubble.layer.cornerCurve = kCACornerCurveContinuous;
        bubble.layer.masksToBounds = YES;
        bubble.layer.borderWidth = 1.0;
        bubble.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.55].CGColor;
        bubble.layer.zPosition = 290.0;   // 低于浮岛(300)，图标仍在上面
        WCApplyLiquidGlass(bubble, side / 2.0, WCLiquidGlassStyleDock, NO);
        [host addSubview:bubble];
    }
    CGFloat cx = frame.origin.x + tabsLeft + cellWidth * ((CGFloat)selectedIndex + 0.5);
    // 只露上半圆：圆心压在上沿，视觉上像从条里"顶"出来。
    CGRect target = CGRectMake(cx - side / 2.0, frame.origin.y - side / 2.0 + 6.0, side, side);
    if (CGRectEqualToRect(bubble.frame, target)) return;
    [UIView animateWithDuration:0.28
                          delay:0.0
                        options:(UIViewAnimationOptionBeginFromCurrentState |
                                 UIViewAnimationOptionCurveEaseOut)
                     animations:^{ bubble.frame = target; }
                     completion:nil];
}

static void WCDockLayoutIsland(UIView *island, UITabBar *bar) {
    UIView *host = gDockHost;
    if (!island || !bar || !host) return;

    CGFloat hostW = host.bounds.size.width;
    CGFloat hostH = host.bounds.size.height;
    if (hostW < 100.0 || hostH < 100.0) {
        // 宿主还没成型：不写 frame，交给看门狗重排 / 回滚。
        return;
    }

    CGFloat height = gDockHeight > 0 ? gDockHeight : 60.0;
    // 1.8.0：目标高固定 60（截图里 50 的塌高来自旧偏好），高宽比保证圆角 30。
    if (height < 60.0) height = 60.0;
    if (height > 76.0) height = 76.0;

    // 1.8.5：两套样式只在容器几何上分支，取图 / 图标 / 点击全链路共用。
    // floating = 悬浮胶囊（x=12，左右留白，圆角=高/2）；
    // bar = 贴边整条（x=0、宽=屏宽、底边贴屏、只圆上面两角、下方垫安全区）。
    BOOL barStyle = [gDockStyle isEqualToString:@"bar"];
    CGFloat safeBottom = host.safeAreaInsets.bottom;
    CGFloat width = barStyle ? hostW : WCDockIslandWidth(hostW);
    CGFloat corner = barStyle ? 10.0 : height / 2.0;
    CGFloat frameH = barStyle ? (height + safeBottom) : height;
    CGFloat x = 0.0;
    CGFloat y = 0.0;
    if (barStyle) {
        y = hostH - frameH;
    } else {
        // 1.8.0：底部距安全区固定 8pt。
        y = hostH - safeBottom - 8.0 - height;
        CGFloat maxY = hostH - height - 4.0;
        CGFloat minY = host.safeAreaInsets.top + 4.0;
        if (y > maxY) y = maxY;
        if (y < minY) y = minY;
        // 1.8.0：左边缘锁定 12（截图里 17 来自旧偏好 dockOffsetX），拖拽仍可在本次停留时移动。
        x = 12.0;
        x = MAX(0.0, MIN(hostW - width, x));
    }

    CGRect frame = CGRectMake(x, y, width, frameH);
    island.frame = frame;
    island.hidden = !gHomeVisible;
    island.layer.zPosition = 300.0;
    if ([island isKindOfClass:[WCDockGlassIsland class]]) {
        [(WCDockGlassIsland *)island updateGlassForRadius:corner];
    }
    if (barStyle) {
        if (@available(iOS 11.0, *)) {
            island.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
            [(WCDockGlassIsland *)island contentView].layer.maskedCorners =
                kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
        } else {
            island.layer.masksToBounds = NO;
        }
    }

    UIView *shadow = [host viewWithTag:WCDockShadowTag];
    if (shadow) {
        shadow.frame = frame;
        shadow.layer.shadowRadius = 14.0;
        shadow.layer.shadowOpacity = 0.12;
        shadow.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:shadow.bounds
                                                              cornerRadius:height / 2.0].CGPath;
    }

    // 1.7.3：每次 apply 时把四个原生 UITabBarButton 的层级各打一次。
    WCDockLogButtonHierarchy(bar);

    UIView *content = WCDockIslandContent(island);
    UIStackView *tabs = (UIStackView *)[content viewWithTag:WCDockTabsStackTag];
    NSMutableArray<UIButton *> *buttons = [NSMutableArray array];
    if ([tabs isKindOfClass:[UIStackView class]]) {
        for (UIView *sub in tabs.arrangedSubviews) {
            if ([sub isKindOfClass:[UIButton class]]) [buttons addObject:(UIButton *)sub];
        }
    } else {
        for (UIView *sub in content.subviews) {
            if ([sub isKindOfClass:[UIButton class]] &&
                [sub.accessibilityIdentifier hasPrefix:@"tab"]) {
                [buttons addObject:(UIButton *)sub];
            }
        }
    }
    if (buttons.count < 4) return;

    BOOL insideSearch = gSearchEnabled && [gSearchPlacement isEqualToString:@"insideLeft"];
    // 1.7.4：四格均布 —— 内容区 = 宽 − 24 − 46 − 12，4 等分后图标中心落在 1/8、3/8、5/8、7/8。
    CGFloat sidePadding = 12.0;
    CGFloat iconGap = 8.0;
    // 1.7.7：头像已经拆成独立胶囊，浮岛四格铺满整条。
    CGFloat tabsLeft = sidePadding + (insideSearch ? 34.0 : 0.0);
    // 1.8.5：贴边样式里头像胶囊在条内右侧，四格右侧让出 52 + 8 + 8。
    CGFloat tabsRight = width - (barStyle ? (WCDockAvatarCapsuleSide + 20.0) : sidePadding);
    CGFloat iconSide = WCDockIconSide();   // 1.8.3：28 × 0.86 ≈ 24
    CGFloat tabsArea = MAX(0.0, tabsRight - tabsLeft);
    CGFloat cellWidth = MAX(24.0, (tabsArea - iconGap * 3.0) / 4.0);
    CGFloat blockSide = 40.0;
    CGFloat blockH = MIN(blockSide, height - 4.0);
    CGFloat blockW = MIN(blockSide, cellWidth - 2.0);
    CGFloat blockY = (height - blockH) / 2.0;

    tabs.frame = CGRectMake(tabsLeft, 0.0, tabsArea, height);

    // 1.8.5：贴边样式给选中项做一颗浮在条上沿的玻璃气泡。
    NSUInteger selIdx = 0;
    for (NSUInteger i = 0; i < bar.items.count && i < 4; i++) {
        if (bar.selectedItem == bar.items[i]) { selIdx = i; break; }
    }
    WCDockLayoutBarBubble(host, barStyle, frame, tabsLeft, cellWidth, selIdx);

    BOOL dark = (bar.traitCollection ?: UITraitCollection.currentTraitCollection)
                    .userInterfaceStyle == UIUserInterfaceStyleDark;
    // 1.7.8：整条 bar 一次快照 + 等分裁切；1.8.1 的逐段日志与 k/4 汇总在内部打印。
    NSArray<UIImage *> *barIcons = WCDockBarSnapshotIcons(bar, iconSide, dark);

    for (NSUInteger i = 0; i < 4; i++) {
        UIButton *button = buttons[i];
        button.tag = (NSInteger)i;

        if (i >= (NSUInteger)bar.items.count) {
            button.hidden = YES;
            continue;
        }
        button.hidden = NO;

        BOOL selected = (bar.selectedItem == bar.items[i]);
        button.backgroundColor = [UIColor clearColor];

        WCDockSelectBlock *highlight = WCDockHighlight(button, (NSInteger)i);
        highlight.frame = CGRectMake((cellWidth - blockW) / 2.0, blockY, blockW, blockH);
        highlight.layer.cornerRadius = 14.0;
        // 1.8.3：选中 / 按压的白色蒙层彻底关掉（图四的透明框就是它），只留图标缩放反馈。
        highlight.backgroundColor = [UIColor clearColor];
        highlight.hidden = YES;
        highlight.alpha = 0.0;

        UITabBarItem *item = bar.items[i];
        // 1.7.8：优先用整条快照裁出来的官方彩色图；缺失的项才回落原生图 / SF Symbols。
        UIImage *icon = (i < barIcons.count &&
                         [barIcons[i] isKindOfClass:[UIImage class]]) ? barIcons[i] : nil;
        if (!icon) {
            // 1.8.1：该段已在快照阶段重拍过；仍空则用线稿占位，绝不画白圆/色块，也不逐帧重拍。
            icon = (barIcons.count > 0)
                       ? WCDockSymbolIcon(i, selected, iconSide, dark)
                       : WCDockIconForIndex(i, selected, item, bar, iconSide, dark);
        }
        if (icon.renderingMode != UIImageRenderingModeAlwaysOriginal) {
            icon = [icon imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        [button setImage:icon forState:UIControlStateNormal];
        button.imageView.tintColor = [UIColor clearColor];
        // 清掉 1.7.2 遗留的复用视图，避免叠两层。
        UIView *adopted = [button viewWithTag:WCDockAdoptedIconTag];
        if (adopted && adopted.superview == button) [adopted removeFromSuperview];
        [button setTitle:((gShowTitle || barStyle) ? item.title : @"") forState:UIControlStateNormal];
        [button setTitleColor:selected ? WCDockIconTint(YES, dark)
                                      : [UIColor colorWithWhite:0.45 alpha:1.0]
                     forState:UIControlStateNormal];

        UILabel *badge = nil;
        UIView *badgeView = [button viewWithTag:WCDockBadgeBase + (NSInteger)i];
        if ([badgeView isKindOfClass:[UILabel class]]) badge = (UILabel *)badgeView;
        if (!badge) {
            badge = [[UILabel alloc] initWithFrame:CGRectZero];
            badge.tag = WCDockBadgeBase + (NSInteger)i;
            badge.font = [UIFont systemFontOfSize:9.0 weight:UIFontWeightSemibold];
            badge.textColor = [UIColor whiteColor];
            badge.backgroundColor = [UIColor colorWithRed:0.98 green:0.32 blue:0.32 alpha:1.0];
            badge.textAlignment = NSTextAlignmentCenter;
            badge.layer.cornerRadius = 8.0;
            badge.layer.masksToBounds = YES;
            [button addSubview:badge];
        }
        NSString *value = item.badgeValue;
        badge.hidden = (value.length == 0);
        badge.text = value;
        if (value.length) {
            CGSize size = [value sizeWithAttributes:@{NSFontAttributeName: badge.font}];
            CGFloat badgeW = MAX(16.0, MIN(26.0, size.width + 8.0));
            badge.frame = CGRectMake(cellWidth / 2.0 + 9.0, MAX(0, blockY - 4.0),
                                     badgeW, 16.0);
        }
    }

    // 搜索入口只在 insideLeft 模式下占浮岛内左侧一格，高度 28，不撑开浮岛。
    UIButton *search = (UIButton *)[content viewWithTag:WCDockSearchTag];
    if (search && search.superview == content) {
        search.hidden = !insideSearch;
        search.frame = CGRectMake(sidePadding, (height - 28.0) / 2.0, 34.0, 28.0);
        search.layer.cornerRadius = 14.0;
        search.layer.cornerCurve = kCACornerCurveContinuous;
        search.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.30];
        search.layer.masksToBounds = YES;
    }

    // 1.7.7：头像搬到独立圆形胶囊，旧版残留在浮岛里的按钮先摘掉。
    UIButton *legacyAvatar = (UIButton *)[content viewWithTag:WCDockAvatarTag];
    if (legacyAvatar && legacyAvatar.superview == content) [legacyAvatar removeFromSuperview];

    UIView *avatarCapsule = [host viewWithTag:WCDockAvatarCapsuleTag];
    if ([avatarCapsule isKindOfClass:[WCDockGlassIsland class]]) {
        CGFloat side = WCDockAvatarCapsuleSide;
        CGRect capsuleFrame;
        if (barStyle) {
            // 1.8.5：贴边样式里头像并到整条右侧（不在条外），垂直居中在图标区。
            capsuleFrame = CGRectMake(width - side - 8.0, MAX(0.0, (height - side) / 2.0),
                                      side, side);
        } else {
            // 1.8.0：头像胶囊紧贴浮岛右侧，间距固定 8，右边缘不再贴屏幕。
            capsuleFrame = CGRectMake(CGRectGetMaxX(frame) + 8.0,
                                      CGRectGetMidY(frame) - side / 2.0, side, side);
        }
        avatarCapsule.frame = capsuleFrame;
        avatarCapsule.hidden = !gHomeVisible;
        // 1.8.5：贴边样式里头像压在整条上（浮岛 z=300），必须抬到 310 才看得见。
        avatarCapsule.layer.zPosition = barStyle ? 310.0 : 300.0;
        avatarCapsule.layer.cornerRadius = side / 2.0;
        [(WCDockGlassIsland *)avatarCapsule updateGlassForRadius:side / 2.0];
        UIButton *avatar = (UIButton *)[((WCDockGlassIsland *)avatarCapsule).contentView
            viewWithTag:WCDockAvatarTag];
        if (!avatar) {
            avatar = [UIButton buttonWithType:UIButtonTypeCustom];
            avatar.tag = WCDockAvatarTag;
            [((WCDockGlassIsland *)avatarCapsule).contentView addSubview:avatar];
        }
        avatar.frame = avatarCapsule.bounds;
        avatar.layer.cornerRadius = side / 2.0;
        avatar.layer.masksToBounds = YES;
        avatar.clipsToBounds = YES;
        [avatar setImage:[WCDockAvatarRendered(bar) imageWithRenderingMode:
                         UIImageRenderingModeAlwaysOriginal]
                 forState:UIControlStateNormal];
        avatar.imageView.contentMode = UIViewContentModeScaleAspectFill;
        avatar.imageView.clipsToBounds = YES;

        static CGRect loggedIsland;
        static CGRect loggedAvatar;
        if (!CGRectEqualToRect(loggedIsland, frame) ||
            !CGRectEqualToRect(loggedAvatar, capsuleFrame)) {
            loggedIsland = frame;
            loggedAvatar = capsuleFrame;
            WCLogLine(@"info", @"dock", @"浮岛 frame=(%.0f,%.0f,%.0f,%.0f) 头像胶囊 frame=(%.0f,%.0f,%.0f,%.0f)",
                      frame.origin.x, frame.origin.y, frame.size.width, frame.size.height,
                      capsuleFrame.origin.x, capsuleFrame.origin.y,
                      capsuleFrame.size.width, capsuleFrame.size.height);
        }
    }

    WCDockLayoutSearchCapsule(host, frame);
    WCDockLogBottomGray(island, bar, host);

    // 1.8.5：样式自证 —— 切换后只打一条，含高度 / 宽度 / 圆角 / 列表留白。
    CGFloat reserve = barStyle ? (frameH + 10.0) : (height + 8.0 + 10.0);
    static NSString *lastStyleSignature = nil;
    NSString *styleSignature = [NSString stringWithFormat:@"%@#%.0f#%.0f#%.0f#%.0f",
                                gDockStyle, height, width, corner, reserve];
    if (![styleSignature isEqualToString:(lastStyleSignature ?: @"")]) {
        BOOL switched = (lastStyleSignature.length > 0);
        lastStyleSignature = [styleSignature copy];
        WCLogLine(@"info", @"dock", @"样式=%@ 切换=%d 高=%.0f 宽=%.0f 圆角=%.0f 留白=%.0f",
                  gDockStyle, switched ? 1 : 0, height, width, corner, reserve);
    }
}

static UIView *WCDockBuildIsland(void) {
    UIView *host = gDockHost;
    UITabBar *bar = gDockBar;
    if (!host || !bar) return nil;

    // 1.8.4：胶囊外面那圈灰就是这块 0.12/14 的独立阴影；直接移除，
    // 只保留胶囊自己的玻璃（含极细高光边），左右 / 下方完全透出壁纸。
    UIView *shadow = [host viewWithTag:WCDockShadowTag];
    if (shadow) [shadow removeFromSuperview];

    UIView *existing = [host viewWithTag:WCDockIslandTag];
    if (existing) {
        // 液态强度 / 高度 / 轻量模式变化时，重建一次，保证图层参数一致。
        NSString *signature = [NSString stringWithFormat:@"%.0f-%.0f-%d-%@",
                               gLiquid, gDockHeight, gLite ? 1 : 0, gDockStyle];
        if (![signature isEqualToString:gBuiltSignature ?: @""]) {
            gBuiltSignature = signature;
            [existing removeFromSuperview];
            [[host viewWithTag:WCDockShadowTag] removeFromSuperview];
            [[host viewWithTag:WCDockSearchCapsuleTag] removeFromSuperview];
            [[host viewWithTag:WCDockAvatarCapsuleTag] removeFromSuperview];
            return WCDockBuildIsland();
        }
        WCDockLayoutIsland(existing, bar);
        [host bringSubviewToFront:existing];
        return existing;
    }

    UIVisualEffect *effect = nil;
    Class glassClass = NSClassFromString(@"UIGlassEffect");
    if (WCDockNativeGlassAvailable()) {
        @try {
            id (*send)(id, SEL, NSInteger) = (id (*)(id, SEL, NSInteger))objc_msgSend;
            effect = send(glassClass, @selector(effectWithStyle:), 0);
        } @catch (NSException *exception) {
            effect = nil;
        }
        WCLogLine(@"info", @"dock", @"glass=native (UIGlassEffect %@)", effect ? @"ok" : @"fallback");
    }
    if (!effect) {
        effect = [UIBlurEffect effectWithStyle:WCDockEffectStyle()];
        WCLogLine(@"info", @"dock", @"glass=simulated ultraThin tint=%.2f liquid=%.0f",
                  WCDockTintAlpha(), gLiquid);
    }

    WCDockGlassIsland *island = [[WCDockGlassIsland alloc] initWithEffect:effect];
    island.tag = WCDockIslandTag;
    island.layer.cornerCurve = kCACornerCurveContinuous;
    island.clipsToBounds = YES;
    island.layer.zPosition = 300.0;
    // 1.8.4：底栏与分组面板共用同一套液态玻璃配方（这里已有原生模糊底，只补 tint/sheen）。
    WCApplyLiquidGlass(island, MAX(8.0, gDockHeight / 2.0), WCLiquidGlassStyleDock, NO);

    // 长按 0.6s 拖动浮岛；拖完把 offset 写回偏好。
    UILongPressGestureRecognizer *drag = [[UILongPressGestureRecognizer alloc]
        initWithTarget:WCDockDrag() action:@selector(wc_dragIsland:)];
    drag.minimumPressDuration = 0.6;
    [island addGestureRecognizer:drag];

    // 1.7.4：四个图标用 UIStackView 均布（fillEqually + spacing 8）铺满内容区，
    // 不再挤在中间；头像独立固定在最右侧，不参与四格均分。
    UIStackView *tabs = [[UIStackView alloc] initWithFrame:CGRectZero];
    tabs.tag = WCDockTabsStackTag;
    tabs.axis = UILayoutConstraintAxisHorizontal;
    tabs.distribution = UIStackViewDistributionFillEqually;
    tabs.alignment = UIStackViewAlignmentFill;
    tabs.spacing = 8.0;
    [island.contentView addSubview:tabs];

    for (NSUInteger i = 0; i < 4; i++) {
        // 1.7.2：必须是 Custom —— System 类型会把非 template 图也按 tint 染色，
        // 这正是之前蓝点/蓝方块的直接原因。
        // 1.8.3：改走 initWithFrame:，保证清底色 / 关高亮 / 只缩放的配置一定生效。
        WCDockTabButton *button = [[WCDockTabButton alloc] initWithFrame:CGRectZero];
        button.tag = (NSInteger)i;
        button.tintColor = [UIColor clearColor];
        button.accessibilityIdentifier = [NSString stringWithFormat:@"tab%lu", (unsigned long)i];
        [button addTarget:WCDockTap() action:@selector(wc_tapTab:)
          forControlEvents:UIControlEventTouchUpInside];
        // 关键：UIVisualEffectView 不允许直接 addSubview，会抛异常，
        // 异常被 @catch 后就会留下"原生底栏已隐藏、浮岛仍是 0 尺寸"的空白底栏。
        [tabs addArrangedSubview:button];
    }

    UIButton *search = [UIButton buttonWithType:UIButtonTypeSystem];
    search.tag = WCDockSearchTag;
    search.accessibilityIdentifier = @"search";
    [search setImage:[UIImage systemImageNamed:@"magnifyingglass"] forState:UIControlStateNormal];
    [search setTintColor:[UIColor colorWithWhite:0.30 alpha:1.0]];
    [search addTarget:WCDockTap() action:@selector(wc_tapSearch:)
      forControlEvents:UIControlEventTouchUpInside];
    search.hidden = YES;
    [island.contentView addSubview:search];

    // 1.7.7：头像独立成圆形胶囊（52pt，右侧 12，和浮岛同一垂直中心）。
    UIView *oldCapsule = [host viewWithTag:WCDockAvatarCapsuleTag];
    if (oldCapsule) [oldCapsule removeFromSuperview];
    WCDockGlassIsland *capsule = [[WCDockGlassIsland alloc] initWithEffect:effect];
    capsule.tag = WCDockAvatarCapsuleTag;
    capsule.clipsToBounds = YES;
    capsule.layer.cornerCurve = kCACornerCurveContinuous;
    capsule.layer.zPosition = 300.0;
    // 1.8.4：头像胶囊也走共用配方（原生模糊底 + 同一 tint / 高光），再补原来的白边。
    WCApplyLiquidGlass(capsule, WCDockAvatarSide / 2.0, WCLiquidGlassStyleDock, NO);
    capsule.layer.borderWidth = 2.0;
    capsule.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.9].CGColor;
    // 1.7.1：必须用 UIButtonTypeCustom —— System 按钮会把不透明头像当 template
    // 整块染成系统蓝，截图里那个「纯蓝实心圆」就是这么来的。
    UIButton *avatar = [UIButton buttonWithType:UIButtonTypeCustom];
    avatar.tag = WCDockAvatarTag;
    avatar.accessibilityIdentifier = @"avatar";
    avatar.backgroundColor = [UIColor clearColor];
    avatar.imageView.contentMode = UIViewContentModeScaleAspectFill;
    avatar.imageView.clipsToBounds = YES;
    [avatar addTarget:WCDockTap() action:@selector(wc_tapAvatar:)
      forControlEvents:UIControlEventTouchUpInside];
    // 长按 0.55s 也打开菜单。
    UILongPressGestureRecognizer *press = [[UILongPressGestureRecognizer alloc]
        initWithTarget:WCDockTap() action:@selector(wc_longPressDock:)];
    press.minimumPressDuration = 0.55;
    [avatar addGestureRecognizer:press];
    [capsule.contentView addSubview:avatar];
    [host addSubview:capsule];

    [host addSubview:island];
    [host bringSubviewToFront:island];
    gBuiltSignature = [NSString stringWithFormat:@"%.0f-%.0f-%d-%@",
                      gLiquid, gDockHeight, gLite ? 1 : 0, gDockStyle];
    gIslandFresh = YES;
    WCDockLayoutIsland(island, bar);
    WCLogLine(@"info", @"dock", @"浮岛挂载 host=%@ island=%@",
              NSStringFromClass([host class]), NSStringFromClass([island class]));
    return island;
}

/// 1.6.2：出现动效 0.3s：scale 0.94 + alpha 0 → 1。
static void WCDockPlayAppearIfNeeded(void) {
    if (!gIslandFresh) return;
    gIslandFresh = NO;
    UIView *island = [gDockHost viewWithTag:WCDockIslandTag];
    if (!island) return;

    island.alpha = 0.0;
    island.transform = CGAffineTransformMakeScale(0.94, 0.94);
    UIViewPropertyAnimator *animator = [[UIViewPropertyAnimator alloc]
        initWithDuration:0.30 curve:UIViewAnimationCurveEaseOut
        animations:^{
            island.alpha = 1.0;
            island.transform = CGAffineTransformIdentity;
        }];
    [animator startAnimation];
    WCLogLine(@"info", @"dock", @"出现动效 0.3s scale 0.94 -> 1");
}

/// 1.6.2：切换选中时，新的玻璃小胶囊 0.22s easeOut 淡入 / 旧的淡出。
static void WCDockAnimateSelection(void) {
    UIView *island = [gDockHost viewWithTag:WCDockIslandTag];
    UITabBar *bar = gDockBar;
    if (!island || !bar) return;

    // 1.8.3：选中蒙层已取消，这里只把残留块统一清成透明 + 隐藏。
    UIView *content = WCDockIslandContent(island);
    for (NSUInteger i = 0; i < 4; i++) {
        UIButton *button = (UIButton *)[content viewWithTag:(NSInteger)i];
        if (![button isKindOfClass:[UIButton class]]) continue;
        UIView *block = [button viewWithTag:WCDockHighlightBase + (NSInteger)i];
        block.backgroundColor = [UIColor clearColor];
        block.hidden = YES;
        block.alpha = 0.0;
    }
    WCDockLayoutIsland(island, bar);
}

static void WCDockHideNativeBar(UITabBar *bar) {
    if (!bar) return;
    // 1.6.1：不用 alpha=0，留 0.02 让它"几乎不可见但仍在布局里"，
    // 万一浮岛出问题还能看出一丝底栏，恢复时也更平滑。
    bar.alpha = 0.02;
    bar.userInteractionEnabled = NO;
}

static void WCDockShowNativeBar(UITabBar *bar) {
    if (!bar) return;
    bar.alpha = 1.0;
    bar.userInteractionEnabled = YES;
}

static void WCDockRemoveVisualsFromHost(UIView *host) {
    if (!host) return;
    [[host viewWithTag:WCDockIslandTag] removeFromSuperview];
    [[host viewWithTag:WCDockMenuTag] removeFromSuperview];
    [[host viewWithTag:WCDockSearchCapsuleTag] removeFromSuperview];
    [[host viewWithTag:WCDockAvatarCapsuleTag] removeFromSuperview];
    [[host viewWithTag:WCDockShadowTag] removeFromSuperview];
    // 1.8.5：贴边样式的选中气泡也要一起摘掉，避免切样式后残留。
    [[host viewWithTag:WCDockBarBubbleTag] removeFromSuperview];
}

static void WCDockRemoveIslandEverywhere(void) {
    NSArray<UIWindow *> *windows = [UIApplication sharedApplication].windows;
    for (UIWindow *window in windows) {
        WCDockRemoveVisualsFromHost(window);
    }
    WCDockRemoveVisualsFromHost(gDockHost);
}

#pragma mark - 1.7.5 原生透明底栏 + 底层玻璃

/// 透明四件套 + iOS 13/15 两套 appearance：原生栏只留图标与点击，背景全透明。
static void WCDockBarTransparent(UITabBar *bar) {
    if (!bar) return;
    bar.alpha = 1.0;
    bar.userInteractionEnabled = YES;
    bar.backgroundColor = [UIColor clearColor];
    bar.translucent = YES;
    bar.backgroundImage = [[UIImage alloc] init];
    bar.shadowImage = [[UIImage alloc] init];
    if (@available(iOS 13.0, *)) {
        UITabBarAppearance *appearance = [[UITabBarAppearance alloc] init];
        [appearance configureWithTransparentBackground];
        appearance.backgroundColor = [UIColor clearColor];
        appearance.backgroundEffect = nil;
        appearance.shadowImage = [[UIImage alloc] init];
        appearance.shadowColor = [UIColor clearColor];
        bar.standardAppearance = appearance;
        if (@available(iOS 15.0, *)) {
            bar.scrollEdgeAppearance = appearance;
        }
    }
}

/// 关闭模块 / 还原原生时把外观还回去，并移除自建玻璃。
static void WCDockBarRestoreChrome(UITabBar *bar) {
    if (!bar) return;
    bar.alpha = 1.0;
    bar.userInteractionEnabled = YES;
    bar.backgroundColor = nil;
    bar.backgroundImage = nil;
    bar.shadowImage = nil;
    if (@available(iOS 13.0, *)) {
        UITabBarAppearance *appearance = [[UITabBarAppearance alloc] init];
        [appearance configureWithDefaultBackground];
        bar.standardAppearance = appearance;
        if (@available(iOS 15.0, *)) bar.scrollEdgeAppearance = appearance;
    }
    UIView *glass = [bar.superview viewWithTag:WCDockNativeGlassTag];
    [glass removeFromSuperview];
}

static UIView *WCDockNativeGlass(UITabBar *bar) {
    UIView *superview = bar.superview ?: gDockHost;
    if (!superview) return nil;
    UIView *glass = [superview viewWithTag:WCDockNativeGlassTag];
    if (glass && glass.superview == superview) return glass;
    [glass removeFromSuperview];

    UIVisualEffectView *view =
        [[UIVisualEffectView alloc] initWithEffect:
         [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialLight]];
    view.tag = WCDockNativeGlassTag;
    view.userInteractionEnabled = YES;
    view.layer.masksToBounds = YES;

    UIView *tint = [[UIView alloc] initWithFrame:view.contentView.bounds];
    tint.tag = WCDockNativeTintTag;   // 1.7.6：原 9931，和 badge[1] 的 tag 撞了
    tint.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tint.backgroundColor = [UIColor colorWithWhite:1.0 alpha:WCDockTintAlpha()];
    tint.userInteractionEnabled = NO;
    [view.contentView addSubview:tint];

    UIView *block = [[UIView alloc] initWithFrame:CGRectZero];
    block.tag = WCDockNativeBlockTag;
    block.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.32];
    block.userInteractionEnabled = NO;
    [view.contentView addSubview:block];

    for (NSInteger i = 0; i < 4; i++) {
        UILabel *badge = [[UILabel alloc] initWithFrame:CGRectZero];
        badge.tag = WCDockNativeBadgeBase + i;
        badge.font = [UIFont systemFontOfSize:9 weight:UIFontWeightSemibold];
        badge.textColor = [UIColor whiteColor];
        badge.backgroundColor = [UIColor colorWithRed:0.88 green:0.18 blue:0.18 alpha:1.0];
        badge.textAlignment = NSTextAlignmentCenter;
        badge.layer.cornerRadius = 7.0;
        badge.layer.masksToBounds = YES;
        badge.hidden = YES;
        [view.contentView addSubview:badge];
    }

    // 原生化后没有头像按钮：长按原生栏 0.55s 打开加号菜单（挂在 bar 上，见 SelectionWatch）。

    if (bar.superview == superview) {
        [superview insertSubview:view belowSubview:bar];
    } else {
        [superview insertSubview:view atIndex:0];
    }
    WCLogLine(@"info", @"dock", @"结构=native-transparent overlay=1 icons=native 选中同步=1");
    return view;
}

static void WCDockSetNativeGlassHidden(BOOL hidden, UITabBar *bar) {
    UIView *glass = [bar.superview viewWithTag:WCDockNativeGlassTag];
    glass.hidden = hidden;
}

static void WCDockLayoutNativeGlass(UITabBar *bar) {
    if (!bar) return;
    UIView *superview = bar.superview;
    if (!superview) return;
    UIView *glass = [superview viewWithTag:WCDockNativeGlassTag];
    if (!glass) return;

    CGRect barFrame = bar.frame;
    CGFloat height = MIN(64.0, MAX(40.0, superview.bounds.size.height));
    CGFloat width = MAX(120.0, superview.bounds.size.width - 24.0);
    CGFloat y = barFrame.origin.y + MAX(0.0, (barFrame.size.height - height) / 2.0);
    glass.frame = CGRectMake(12.0, y, width, height);
    glass.layer.cornerRadius = height / 2.0;
    glass.layer.cornerCurve = kCACornerCurveContinuous;
    glass.layer.masksToBounds = YES;
    glass.hidden = !gHomeVisible;
    UIView *content = ((UIVisualEffectView *)glass).contentView;
    UIView *tint = [content viewWithTag:WCDockNativeTintTag];
    tint.frame = content.bounds;

    NSInteger selected = -1;
    NSInteger count = (NSInteger)bar.items.count;
    for (NSInteger i = 0; i < count; i++) {
        if (bar.selectedItem && bar.items[(NSUInteger)i] == bar.selectedItem) {
            selected = i;
            break;
        }
    }
    if (selected < 0) {
        UITabBarController *tab = WCDockTabControllerForBar(bar);
        if (tab) selected = MIN(3, MAX(0, tab.selectedIndex));
    }
    CGFloat fullW = barFrame.size.width;
    CGFloat cellW = fullW / 4.0;

    UIView *block = [content viewWithTag:WCDockNativeBlockTag];
    if (selected >= 0) {
        CGFloat cx = (selected * cellW + cellW / 2.0) - glass.frame.origin.x;
        block.frame = CGRectMake(cx - (cellW - 8.0) / 2.0, (height - 44.0) / 2.0,
                                 cellW - 8.0, 44.0);
        block.layer.cornerRadius = 16.0;
        block.layer.cornerCurve = kCACornerCurveContinuous;
        block.hidden = NO;
    } else {
        block.hidden = YES;
    }

    for (NSInteger i = 0; i < 4; i++) {
        // 1.7.6：viewWithTag: 返回 UIView，必须显式校验类型，
        // 否则 tag 撞车时会直接 unrecognized selector setText:。
        UIView *raw = [content viewWithTag:WCDockNativeBadgeBase + i];
        UILabel *badge = [raw isKindOfClass:[UILabel class]] ? (UILabel *)raw : nil;
        UITabBarItem *item = i < count ? bar.items[(NSUInteger)i] : nil;
        badge.text = item.badgeValue;
        badge.hidden = (item.badgeValue.length == 0);
        CGFloat cx = (i * cellW + cellW / 2.0) - glass.frame.origin.x;
        badge.frame = CGRectMake(cx + 8.0, (height - 44.0) / 2.0 + 1.0, 20.0, 14.0);
    }

    // 搜索胶囊按自建玻璃的实际位置摆放。
    UIView *host = gDockHost;
    if (host) {
        CGRect frameInHost = [superview convertRect:glass.frame toView:host];
        WCDockLayoutSearchCapsule(host, frameInHost);
    }
}

/// 点原生 tab 后回读 selectedIndex，同步自建层的选中块。
static void WCDockAttachSelectionWatch(UITabBar *bar) {
    static char key;
    if (!bar || objc_getAssociatedObject(bar, &key)) return;
    UITapGestureRecognizer *tap =
        [[UITapGestureRecognizer alloc] initWithTarget:WCDockTap()
                                                action:@selector(wc_barTapped:)];
    tap.cancelsTouchesInView = NO;
    [bar addGestureRecognizer:tap];

    // 加号菜单入口：原生栏长按 0.55s。
    UILongPressGestureRecognizer *longPress =
        [[UILongPressGestureRecognizer alloc] initWithTarget:WCDockTap()
                                                      action:@selector(wc_longPressDock:)];
    longPress.minimumPressDuration = 0.55;
    longPress.cancelsTouchesInView = YES;
    [bar addGestureRecognizer:longPress];

    objc_setAssociatedObject(bar, &key, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static void WCDockApplyNativeStructure(UITabBar *bar) {
    if (!bar) return;
    WCDockBarTransparent(bar);
    UIView *host = gDockHost ?: bar.superview;
    [[host viewWithTag:WCDockIslandTag] removeFromSuperview];
    [[host viewWithTag:WCDockShadowTag] removeFromSuperview];
    WCDockNativeGlass(bar);
    WCDockAttachSelectionWatch(bar);
    WCDockLayoutNativeGlass(bar);
}

/// 看门狗：0.35s 后再确认一次浮岛位置；还不满足就恢复原生底栏。
/// 硬性要求：任何时刻都不能出现"原生没了、浮岛也没有"。
/// 1.8.1：同一时间只排一个，且两次执行至少间隔 0.35s；日志只在 frame/visible 变化时打印。
static void WCDockScheduleWatchdog(void) {
    if (gDockWatchdogPending) return;
    gDockWatchdogPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        gDockWatchdogPending = NO;
        NSTimeInterval now = CFAbsoluteTimeGetCurrent();
        if (now - gDockWatchdogLastRun < 0.34) return;
        gDockWatchdogLastRun = now;

        WCPrefs *prefs = [WCPrefs shared];
        BOOL on = prefs.enabled && prefs.moduleDock && prefs.dockEnabled;
        if (!on) return;
        // 1.7.5：原生结构下不做"浮岛回滚"，只同步玻璃层位置。
        if (WCDockNativeStructure) {
            if (gDockBar) WCDockLayoutNativeGlass(gDockBar);
            return;
        }
        // 非首页时浮岛本来就是隐藏状态，看门狗不做回滚判定。
        if (!gHomeVisible) return;

        UITabBar *bar = gDockBar;
        UIView *host = gDockHost;
        UIView *island = [host viewWithTag:WCDockIslandTag];

        // 宿主可能在这一帧才拿到真实尺寸：再排一次。
        if (island && bar) {
            WCDockLayoutIsland(island, bar);
        }

        if (WCDockIslandVisible(island)) {
            if (bar && bar.alpha > 0.03) {
                WCDockHideNativeBar(bar);
            }
            NSString *signature =
                [NSString stringWithFormat:@"%.1f,%.1f,%.1f,%.1f#%d",
                 island.frame.origin.x, island.frame.origin.y,
                 island.frame.size.width, island.frame.size.height, 1];
            if (![signature isEqualToString:(gDockWatchdogLogSignature ?: @"")]) {
                gDockWatchdogLogSignature = [signature copy];
                WCLogLine(@"info", @"dock", @"看门狗 OK frame=(%.0f,%.0f,%.0f,%.0f) visible=1",
                          island.frame.origin.x, island.frame.origin.y,
                          island.frame.size.width, island.frame.size.height);
            }
            return;
        }

        if (bar) {
            WCDockShowNativeBar(bar);
            WCLogLine(@"warn", @"dock",
                      @"回滚：浮岛未就位（宿主 %@ %.0fx%.0f，原生底栏 alpha=%.2f）",
                      NSStringFromClass([host class]),
                      host.bounds.size.width, host.bounds.size.height, bar.alpha);
        }
        WCDockRemoveIslandEverywhere();
    });
}

#pragma mark - 生命周期

/// 1.7.0：给首页原生列表留出底部空间（浮岛 + 搜索条 + 24），最后一行才能滚出来。
static __weak UITableView *gInsetTable = nil;
static CGFloat gInsetOriginalBottom = 0.0;

static void WCDockApplyListInset(UIView *host) {
    if (!host) return;
    // 1.7.5：原生底栏自己会留出 contentInset，再补一层会双倍底部空白。
    if (WCDockNativeStructure) return;
    UITableView *target = nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:host];
    NSUInteger budget = 400;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UITableView class]] &&
            [NSStringFromClass([view class]) containsString:@"MainFrame"]) {
            target = (UITableView *)view;
            break;
        }
        if (view.subviews.count <= 80) [queue addObjectsFromArray:view.subviews];
    }
    if (!target) {
        // 1.8.2：这条曾每 5ms 刷一次，改成进程内只报一次。
        static BOOL missLogged = NO;
        if (!missLogged) {
            missLogged = YES;
            WCLogLine(@"warn", @"dock", @"未找到 MainFrameTableView，跳过底部留白");
        }
        return;
    }
    CGFloat searchHeight = 0.0;
    if (gSearchEnabled && [gSearchPlacement isEqualToString:@"above"]) {
        searchHeight = 40.0 + 8.0;
    }
    // 1.8.0：留白跟随实际浮岛高度 60（旧偏好 50 不再压低留白），底部 8 + 透气 10。
    // 1.8.5：贴边整条按「图标区 + 安全区 + 10 透气」重算，切换样式后不留空白也不压内容。
    CGFloat islandHeight = MAX(60.0, gDockHeight);
    BOOL barStyle = [gDockStyle isEqualToString:@"bar"];
    CGFloat bottom = barStyle
        ? (islandHeight + gDockHost.safeAreaInsets.bottom + 10.0)
        : (islandHeight + 8.0 + 10.0 + searchHeight);
    if (gInsetTable != target) {
        gInsetTable = target;
        gInsetOriginalBottom = target.contentInset.bottom;
    }
    UIEdgeInsets inset = target.contentInset;
    if (fabs(inset.bottom - bottom) < 1.0) return;
    inset.bottom = bottom;
    target.contentInset = inset;
    target.verticalScrollIndicatorInsets = UIEdgeInsetsMake(0, 0, bottom,
                                                           target.verticalScrollIndicatorInsets.right);
    WCLogLine(@"info", @"dock", @"列表底部留白 bottom=%.0f island=%.0f search=%.0f",
              bottom, islandHeight, searchHeight);
}

static void WCDockClearListInset(void) {
    UITableView *table = gInsetTable;
    if (!table) return;
    UIEdgeInsets inset = table.contentInset;
    inset.bottom = gInsetOriginalBottom;
    table.contentInset = inset;
    table.verticalScrollIndicatorInsets = UIEdgeInsetsMake(0, 0, gInsetOriginalBottom,
                                                           table.verticalScrollIndicatorInsets.right);
    gInsetTable = nil;
    gInsetOriginalBottom = 0.0;
}

void WCDockApplyToTabBar(UITabBar *bar) {
    if (!bar) return;
    if (gApplyPending) return;
    gApplyPending = YES;
    __weak UITabBar *weakBar = bar;
    dispatch_async(dispatch_get_main_queue(), ^{
        gApplyPending = NO;
        if (!weakBar) return;
        if (gApplying) return;

        gApplying = YES;
        BOOL built = NO;
        if (gDockDisabled) {
            WCDockShowNativeBar(weakBar);
            return;
        }
        @try {
            WCPrefs *prefs = [WCPrefs shared];
            BOOL on = prefs.enabled && prefs.moduleDock && prefs.dockEnabled;
            gDockEnabled = on;

            if (!on) {
                WCDockShowNativeBar(weakBar);
                WCDockBarRestoreChrome(weakBar);
                WCDockRemoveIslandEverywhere();
                return;
            }

            // 1.6.3：push 出来的页面（聊天 / 搜索）只隐藏浮岛，不还原原生底栏，避免闪白。
            if (!gHomeVisible) {
                UIView *old = [gDockHost viewWithTag:WCDockIslandTag];
                old.hidden = YES;
                WCDockSetNativeGlassHidden(YES, weakBar);
                [[gDockHost viewWithTag:WCDockSearchCapsuleTag] removeFromSuperview];
                [[gDockHost viewWithTag:WCDockMenuTag] removeFromSuperview];
                if (gRestoreNativeWhenHidden) {
                    WCDockShowNativeBar(weakBar);
                }
                return;
            }

            // 1.7.6：统一挂到 keyWindow 最上层容器，和微信 + 菜单同层，zPosition 才有意义。
            UIView *host = WCDockOverlayHost();
            if (!host || !host.window) host = WCDockHostForBar(weakBar);
            if (!host || !host.window) {
                WCLogLine(@"warn", @"dock", @"浮岛宿主不可用，保持原生底栏 alpha=%.2f",
                          weakBar.alpha);
                WCDockShowNativeBar(weakBar);
                return;
            }

            // 宿主切换（控制器 view → 窗口浮层）时清掉旧宿主上的副本，避免双份残影。
            UIView *oldHost = gDockHost;
            if (oldHost && oldHost != host) WCDockRemoveVisualsFromHost(oldHost);

            gDockBar = weakBar;
            gDockHost = host;
            NSString *mountSignature =
                [NSString stringWithFormat:@"%@#%.0fx%.0f", NSStringFromClass([host class]),
                 host.bounds.size.width, host.bounds.size.height];
            if (![mountSignature isEqualToString:(gDockMountLogSignature ?: @"")]) {
                gDockMountLogSignature = [mountSignature copy];
                WCLogLine(@"info", @"dock", @"悬浮 挂载 host=%@ bounds=%.0fx%.0f",
                          NSStringFromClass([host class]),
                          host.bounds.size.width, host.bounds.size.height);
            }

            gDockHeight = prefs.dockHeight > 0 ? prefs.dockHeight : 60.0;
            gDockWidth = prefs.dockWidth > 0 ? prefs.dockWidth : 0.0;
            gDockInset = prefs.dockInset > 0 ? prefs.dockInset : 12.0;
            gOffsetX = prefs.dockOffsetX;
            gOffsetY = prefs.dockOffsetY;
            if (gOffsetY <= 0.0) gOffsetY = 10.0;   // 1.7.6：底部距手势条 10
            gWidthMode = prefs.dockWidthMode;
            gFixedWidth = prefs.dockFixedWidth;
            gSearchPlacement = prefs.dockSearchPlacement.length ? prefs.dockSearchPlacement
                                                                : @"above";
            gLiquid = prefs.dockLiquidIntensity;
            if (gLiquid < 0.0) gLiquid = 0.0;
            if (gLiquid > 100.0) gLiquid = 100.0;
            gShowTitle = prefs.dockShowTitle;
            gSearchEnabled = prefs.dockSearchEnabled;
            gLite = prefs.liteMode;
            gIntensity = prefs.glassIntensity;
            gStyle = prefs.glassStyle;
            // 1.8.5：底栏样式，切换后由 gBuiltSignature 触发一次干净重建。
            gDockStyle = prefs.dockStyle.length ? prefs.dockStyle : @"floating";

            // 1.7.5：原生透明底栏 + 底层玻璃，不再自绘浮岛图标。
            if (WCDockNativeStructure) {
                built = YES;
                WCDockShowNativeBar(weakBar);
                WCDockApplyNativeStructure(weakBar);
                WCDockScheduleWatchdog();
                return;
            }

            UIView *island = WCDockBuildIsland();
            BOOL visible = WCDockIslandVisible(island);
            // 1.8.1：frame / visible / 宿主尺寸都不变时不再打印。
            NSString *islandSignature =
                [NSString stringWithFormat:@"%.1f,%.1f,%.1f,%.1f#%.0fx%.0f#%d",
                 island.frame.origin.x, island.frame.origin.y,
                 island.frame.size.width, island.frame.size.height,
                 host.bounds.size.width, host.bounds.size.height, visible ? 1 : 0];
            if (![islandSignature isEqualToString:(gDockIslandLogSignature ?: @"")]) {
                gDockIslandLogSignature = [islandSignature copy];
                WCLogLine(@"info", @"dock",
                          @"浮岛 frame=(%.0f,%.0f,%.0f,%.0f) super=(%.0f,%.0f) visible=%d",
                          island.frame.origin.x, island.frame.origin.y,
                          island.frame.size.width, island.frame.size.height,
                          host.bounds.size.width, host.bounds.size.height,
                          visible ? 1 : 0);
            }

            if (visible) {
                built = YES;
                BOOL wasShown = weakBar.alpha > 0.03;
                WCDockHideNativeBar(weakBar);
                NSString *structureSignature =
                    [NSString stringWithFormat:@"%@#%.0f#%.0f#%.0f",
                     NSStringFromClass([host class]), island.bounds.size.height,
                     island.bounds.size.width, island.bounds.size.height / 2.0];
                if (![structureSignature isEqualToString:(gDockStructureLogSignature ?: @"")]) {
                    gDockStructureLogSignature = [structureSignature copy];
                    WCLogLine(@"info", @"dock",
                              @"结构=floating 悬浮 挂载=1 host=%@ z=300 面板 z=100 高=%.0f 宽=%.0f 圆角=%.0f 图标=auto",
                              NSStringFromClass([host class]),
                              // 1.7.8：用 bounds（跳过出现动效的 transform）打印，避免 64→60 的假高度。
                              island.bounds.size.height, island.bounds.size.width,
                              island.bounds.size.height / 2.0);
                }
                // 1.6.4：只在首次（或从 alpha=1 回到隐藏）时打日志，避免刷屏。
                if (wasShown) {
                    WCLogLine(@"info", @"dock", @"原生底栏 alpha=%.2f（浮岛已就位）",
                              weakBar.alpha);
                }
                WCDockPlayAppearIfNeeded();
                // 空宿主只是透明浮层容器，列表在其下面的控制器 view 里，留白仍从 bar 所属 VC 找。
                WCDockApplyListInset(WCDockHostForBar(weakBar));
                WCDockScheduleWatchdog();
            } else {
                [island removeFromSuperview];
                WCDockShowNativeBar(weakBar);
                WCLogLine(@"warn", @"dock", @"回滚：浮岛未就位，原生底栏 alpha=%.2f",
                          weakBar.alpha);
            }
        } @catch (NSException *exception) {
            // 构建中途抛异常：立刻把原生底栏还回去，绝不能留空白底栏。
            WCDockShowNativeBar(weakBar);
            WCDockRemoveIslandEverywhere();
            WCDockNoteException(@"apply", exception);
        } @finally {
            gApplying = NO;
            if (!built) {
                // 兜底：没建成就再确认一次原生底栏是可见的。
                WCDockShowNativeBar(weakBar);
            }
        }
    });
}

void WCDockRestore(UITabBar *bar) {
    if (!bar) return;
    WCDockShowNativeBar(bar);
    WCDockBarRestoreChrome(bar);
    WCDockRemoveIslandEverywhere();
    WCDockRemoveOverlayHosts();
    WCDockClearListInset();
    WCGroupYieldForMenu(NO);
    // 浮层宿主被整体移除，分组若仍启用则重建自己的面板（关着时直接返回）。
    WCGroupRefresh();
    // 关闭模块后重新打开时允许重试（熔断只在同一进程内生效）。
    gDockDisabled = NO;
    gDockExceptionCount = 0;
}

/// 1.7.1：浮岛可能残留在一份旧的 host 上（host 切换后旧副本没清），
/// 隐藏时遍历所有窗口，把所有同 tag 的副本一起隐藏，避免聊天页仍看到浮岛。
static void WCDockHideIslandsEverywhere(void) {
    NSMutableArray<UIView *> *islands = [NSMutableArray array];
    NSMutableArray<UIView *> *extras = [NSMutableArray array];
    NSMutableArray<UIView *> *glassViews = [NSMutableArray array];
    NSMutableArray<UIView *> *queue = [NSMutableArray array];
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        [queue addObject:window];
    }
    if (gDockHost) [queue addObject:gDockHost];
    NSUInteger budget = 1500;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if (view.tag == WCDockIslandTag) [islands addObject:view];
        if (view.tag == WCDockMenuTag || view.tag == WCDockSearchCapsuleTag) [extras addObject:view];
        if (view.tag == WCDockNativeGlassTag) [glassViews addObject:view];
        [queue addObjectsFromArray:view.subviews];
    }
    for (UIView *view in islands) view.hidden = YES;
    for (UIView *view in glassViews) view.hidden = YES;
    for (UIView *view in extras) [view removeFromSuperview];
}

void WCDockSetHomeVisible(BOOL visible, NSString *reason, BOOL restoreNative) {
    BOOL changed = (gHomeVisible != visible);
    gHomeVisible = visible;
    gRestoreNativeWhenHidden = restoreNative;

    dispatch_async(dispatch_get_main_queue(), ^{
        // 1.7.6：面板跟随首页可见性（二级页隐藏，回首页恢复）。
        WCGroupSetPanelHidden(!gHomeVisible);
        if (!gHomeVisible) {
            // 只隐藏、不移除，回到首页立即显示（避免重建开销）。
            WCDockHideIslandsEverywhere();
            [gDockHost viewWithTag:WCDockIslandTag].hidden = YES;
            [gDockHost viewWithTag:WCDockAvatarCapsuleTag].hidden = YES;
            WCDockSetNativeGlassHidden(YES, gDockBar);
            [[gDockHost viewWithTag:WCDockMenuTag] removeFromSuperview];
            [[gDockHost viewWithTag:WCDockSearchCapsuleTag] removeFromSuperview];
            WCGroupYieldForMenu(NO);
            if (restoreNative) {
                if (gDockBar) WCDockShowNativeBar(gDockBar);
                WCLogLine(@"info", @"dock", @"隐藏 原因=非tab cls=%@ 浮岛 hidden=1 原生底栏 alpha=%.2f",
                          reason ?: @"-", gDockBar.alpha);
            } else {
                WCLogLine(@"info", @"dock", @"隐藏 原因=push cls=%@ 浮岛 hidden=1 原生底栏保持隐藏",
                          reason ?: @"-");
            }
            return;
        }

        // 1.8.1：可见性没变化就不打印，只在首次/切换时留痕。
        if (changed) {
            WCLogLine(@"info", @"dock", @"显示 原因=tab-child cls=%@", reason ?: @"-");
        }
        if (gDockBar) WCDockApplyToTabBar(gDockBar);
    });

    if (changed) {
        WCLogLine(@"info", @"dock", @"浮岛可见=%d（%@）", visible ? 1 : 0, reason ?: @"-");
    }
}

#pragma mark - 1.6.4 顶层页面判定

/// 从 keyWindow.rootViewController 一路走到最顶层：presented → nav.top → tab.selected。
static UIViewController *WCDockTopmostViewController(void) {
    UIWindow *window = nil;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
                if (candidate.isKeyWindow) { window = candidate; break; }
            }
            if (window) break;
        }
    }
    if (!window) window = [UIApplication sharedApplication].keyWindow;

    UIViewController *vc = window.rootViewController;
    NSUInteger guard = 0;
    while (vc && guard < 24) {
        guard += 1;
        UIViewController *next = nil;
        if (vc.presentedViewController) {
            next = vc.presentedViewController;
        } else if ([vc isKindOfClass:[UINavigationController class]]) {
            next = ((UINavigationController *)vc).topViewController;
        } else if ([vc isKindOfClass:[UITabBarController class]]) {
            next = ((UITabBarController *)vc).selectedViewController;
        }
        if (!next || next == vc) break;
        vc = next;
    }
    return vc;
}

static BOOL WCDockIsSecondaryPageClass(NSString *name);

/// 1.7.0：唯一白名单 —— 顶层 VC 必须是主 TabBarController 选中页的直接子控制器
/// （四个 tab 根页），且没有在它里面 push 二级页。
static BOOL WCDockIsTabRootPage(UIViewController *top) {
    if (!top) return NO;
    UIViewController *child = top;
    UITabBarController *tab = nil;
    NSUInteger guard = 0;
    while (child.parentViewController && guard < 24) {
        guard += 1;
        UIViewController *parent = child.parentViewController;
        if ([parent isKindOfClass:[UITabBarController class]]) {
            tab = (UITabBarController *)parent;
            break;
        }
        child = parent;
    }
    if (!tab) return !WCDockIsSecondaryPageClass(NSStringFromClass([top class])) &&
                        (top.navigationController == nil ||
                         top.navigationController.viewControllers.count <= 1);
    if (child != tab.selectedViewController) return NO;
    if ([child isKindOfClass:[UINavigationController class]]) {
        UINavigationController *nav = (UINavigationController *)child;
        return (top == nav.topViewController && nav.viewControllers.count <= 1);
    }
    return (top == child);
}

/// 兜底（找不到 UITabBarController 时）：二级页类名黑名单。
static BOOL WCDockIsSecondaryPageClass(NSString *name) {
    if (name.length == 0) return NO;
    NSArray<NSString *> *keys = @[@"BaseMsgContent", @"WCSearchViewController",
                                  @"FTSHomeViewController", @"FTSBaseViewController",
                                  @"TimeLine", @"SNS", @"Moments", @"Moment",
                                  @"Scan", @"Look", @"KanKan", @"Finder",
                                  @"AppBrand", @"Search"];
    for (NSString *key in keys) {
        if ([name containsString:key]) return YES;
    }
    return NO;
}

static BOOL WCDockShouldHideForTop(UIViewController *top) {
    if (!top) return NO;
    NSString *cls = NSStringFromClass([top class]) ?: @"";
    // 条件 A：类名命中聊天/朋友圈/搜索等二级页 → 隐藏（不依赖白名单）。
    if (WCDockIsSecondaryPageClass(cls)) return YES;
    // 条件 B：顶层 VC 所在导航栈已经 push 过（count > 1）→ 隐藏。
    if (top.navigationController &&
        top.navigationController.viewControllers.count > 1) return YES;
    // 条件 C：不是主 TabBarController 选中页的直接子控制器 → 隐藏。
    return !WCDockIsTabRootPage(top);
}

static BOOL gDockVerdictPending = NO;

static void WCDockRunVerdictOnce(NSString *stage) {
    UIViewController *top = WCDockTopmostViewController();
    BOOL whitelisted = WCDockIsTabRootPage(top);
    BOOL hide = WCDockShouldHideForTop(top);
    NSString *cls = NSStringFromClass([top class]) ?: @"-";
    WCLogLine(@"info", @"dock", @"判定 top=%@ 白名单=%d %@（%@）",
              cls, whitelisted ? 1 : 0, hide ? @"隐藏" : @"显示", stage ?: @"-");
    WCDockSetHomeVisible(!hide, cls, hide);
}

/// 1.7.1：0.15s + 0.6s 各复核一次（不是定时器循环）。
/// 微信的 appear 回调时机不定，单次复核仍然会被后续回调用首页态拉回来。
void WCDockScheduleVerdictCheck(void) {
    if (gDockVerdictPending) return;
    gDockVerdictPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        WCDockRunVerdictOnce(@"0.15s");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.45 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            gDockVerdictPending = NO;
            WCDockRunVerdictOnce(@"0.60s");
        });
    });
}

void WCDockHandleHome(UIViewController *controller) {
    if (!controller) return;

    WCPrefs *prefs = [WCPrefs shared];
    BOOL on = prefs.enabled && prefs.moduleDock && prefs.dockEnabled;
    gDockEnabled = on;

    // 1.6.4：聊天页显示期间首页的 appear 回调仍会触发（1.6.3 日志 23:01:39
    // 的「首页出现」），旧代码在这里无条件 gHomeVisible=YES，把刚隐藏的浮岛
    // 又拉回来了。先按顶层 VC 判定，非首页直接走隐藏分支。
    UIViewController *top = WCDockTopmostViewController();
    if (WCDockShouldHideForTop(top)) {
        NSString *cls = NSStringFromClass([top class]) ?: @"-";
        WCLogLine(@"info", @"dock", @"首页回调被忽略 top=%@ 白名单=0 隐藏", cls);
        WCDockSetHomeVisible(NO, cls, YES);
        WCDockScheduleVerdictCheck();
        return;
    }

    gHomeVisible = YES;
    gRestoreNativeWhenHidden = NO;
    WCLogLine(@"info", @"dock", @"首页出现 cls=%@ dock=%d",
              NSStringFromClass([controller class]), on ? 1 : 0);
    if (!on) return;

    UITabBar *bar = nil;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:controller.view];
    NSUInteger budget = 300;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UITabBar class]]) { bar = (UITabBar *)view; break; }
        if (view.subviews.count <= 40) {
            [queue addObjectsFromArray:view.subviews];
        }
    }
    if (bar) WCDockApplyToTabBar(bar);
    WCDockScheduleVerdictCheck();
}

static UITabBar *WCDockFindBar(void) {
    if (gDockBar) return gDockBar;

    NSArray<UIWindow *> *windows = [UIApplication sharedApplication].windows;
    for (UIWindow *window in windows) {
        NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:window];
        NSUInteger budget = 500;
        while (queue.count && budget > 0) {
            budget -= 1;
            UIView *view = queue.firstObject;
            [queue removeObjectAtIndex:0];
            if ([view isKindOfClass:[UITabBar class]]) return (UITabBar *)view;
            if (view.subviews.count <= 40) {
                [queue addObjectsFromArray:view.subviews];
            }
        }
    }
    return nil;
}

static void WCDockRefreshNow(void) {
    WCPrefs *prefs = [WCPrefs shared];
    BOOL on = prefs.enabled && prefs.moduleDock && prefs.dockEnabled;
    gDockEnabled = on;

    if (!on) {
        WCDockRemoveIslandEverywhere();
        if (gDockBar) {
            WCDockShowNativeBar(gDockBar);
        }
        WCLogLine(@"info", @"dock", @"已停用：浮岛 / 菜单已移除");
        return;
    }

    if (!gHomeVisible) {
        WCDockHideIslandsEverywhere();
        UIView *island = [gDockHost viewWithTag:WCDockIslandTag];
        island.hidden = YES;
        if (gRestoreNativeWhenHidden && gDockBar) WCDockShowNativeBar(gDockBar);
        WCLogLine(@"info", @"dock", @"非 TabBar 页：跳过应用（浮岛 hidden=1 restore=%d）",
                  gRestoreNativeWhenHidden ? 1 : 0);
        return;
    }

    UITabBar *bar = WCDockFindBar();
    if (!bar) {
        WCLogLine(@"warn", @"dock", @"未找到 UITabBar，等待首页出现");
        return;
    }
    WCDockApplyToTabBar(bar);
}

void WCDockRefresh(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        WCDockRefreshNow();
    });
}

void WCDockStart(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        WCPrefs *prefs = [WCPrefs shared];
        gDockEnabled = prefs.enabled && prefs.moduleDock && prefs.dockEnabled;
        if (!gDockEnabled) {
            WCLogLine(@"info", @"dock", @"未启用（moduleDock=0 或 dockEnabled=0）");
            return;
        }
        WCLogLine(@"info", @"dock", @"已启用 h=%.0f offset=(%.0f,%.0f) mode=%ld fixed=%.0f search=%@ liquid=%.0f",
                  prefs.dockHeight, prefs.dockOffsetX, prefs.dockOffsetY,
                  (long)prefs.dockWidthMode, prefs.dockFixedWidth,
                  prefs.dockSearchPlacement ?: @"-", prefs.dockLiquidIntensity);
        WCDockRefreshNow();
    });
}

CGFloat WCDockReservedBottom(UIView *host) {
    if (!host) return 0.0;
    CGFloat hostH = host.bounds.size.height;
    UIView *island = [host viewWithTag:WCDockIslandTag];
    CGRect islandRect = island.frame;
    BOOL islandVisible = island && !island.hidden;
    if (!island) {
        // 1.7.6：悬浮版浮岛挂在窗口浮层上，不在首页 view 里，按坐标换算回来。
        UIView *other = [gDockHost viewWithTag:WCDockIslandTag];
        if (other && other.superview) {
            islandRect = [other.superview convertRect:other.frame toView:host];
            islandVisible = !other.hidden;
        }
    }
    if (islandVisible && islandRect.size.height > 1.0) {
        return MAX(120.0, CGRectGetMinY(islandRect) - 10.0);
    }
    // 1.7.5：原生结构下按自建玻璃的实际位置留白。
    UIView *barSuper = gDockBar.superview;
    UIView *glass = [barSuper viewWithTag:WCDockNativeGlassTag];
    if (glass && glass.superview && !glass.hidden) {
        CGRect rect = [glass.superview convertRect:glass.frame toView:host];
        return MAX(120.0, CGRectGetMinY(rect) - 10.0);
    }
    CGFloat safeBottom = host.safeAreaInsets.bottom;
    // 1.8.0：列表底部留白 = 安全区 + 浮岛 60 + 底部 8 + 10 透气。
    return MAX(120.0, hostH - safeBottom - 78.0);
}
