#import "WCWallpaper.h"
#import "WCLog.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

static const NSInteger WCWallpaperViewTag = 0x57434247; // 'WCWG'
static NSString *gLastLogSignature = nil;

#pragma mark - 路径

NSString *WCWallpaperDirectory(void) {
    return WCLogDirectory();
}

static NSString *WCWallpaperBasePath(BOOL dark) {
    NSString *name = dark ? @"bg-dark" : @"bg-light";
    return [WCWallpaperDirectory() stringByAppendingPathComponent:name];
}

NSString *_Nullable WCWallpaperExistingPath(BOOL dark) {
    NSString *base = WCWallpaperBasePath(dark);
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *ext in @[@"png", @"jpg", @"jpeg"]) {
        NSString *path = [base stringByAppendingPathExtension:ext];
        if ([fm fileExistsAtPath:path]) return path;
    }
    return nil;
}

// 1.7.7：Active 会被 cell 布局高频调用，加 1s 缓存避免每次 4 次磁盘探测。
static BOOL gWallpaperActiveCache = NO;
static NSTimeInterval gWallpaperActiveStamp = -1000.0;

static void WCWallpaperInvalidateActiveCache(void) {
    gWallpaperActiveStamp = -1000.0;
}

BOOL WCWallpaperActive(void) {
    NSTimeInterval now = CFAbsoluteTimeGetCurrent();
    if (now - gWallpaperActiveStamp < 1.0) return gWallpaperActiveCache;
    gWallpaperActiveStamp = now;
    gWallpaperActiveCache = (WCWallpaperExistingPath(NO) != nil ||
                             WCWallpaperExistingPath(YES) != nil);
    return gWallpaperActiveCache;
}

#pragma mark - 保存 / 清除

BOOL WCWallpaperSaveImage(UIImage *_Nullable image, BOOL dark, NSString *_Nullable *_Nullable message) {
    if (!image) {
        if (message) *message = @"图片读取失败";
        return NO;
    }

    // 统一转 PNG：最长边限制 2048，避免把原图几十 MB 直接写盘。
    CGFloat maxSide = 2048.0;
    CGSize size = image.size;
    CGFloat scale = 1.0;
    if (MAX(size.width, size.height) > maxSide) {
        scale = maxSide / MAX(size.width, size.height);
        size = CGSizeMake(MAX(1.0, size.width * scale), MAX(1.0, size.height * scale));
    }
    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.scale = 1.0;
    format.opaque = NO;
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *normalized = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
        [image drawInRect:CGRectMake(0.0, 0.0, size.width, size.height)];
    }];

    NSString *path = [WCWallpaperBasePath(dark) stringByAppendingPathExtension:@"png"];
    [[NSFileManager defaultManager] createDirectoryAtPath:WCWallpaperDirectory()
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    NSData *png = UIImagePNGRepresentation(normalized);
    BOOL ok = [png writeToFile:path atomically:YES];
    // 旧 jpg 版本一并清掉，避免读取时命中旧图。
    if (ok) {
        for (NSString *ext in @[@"jpg", @"jpeg"]) {
            NSString *old = [[WCWallpaperBasePath(dark) stringByAppendingPathExtension:ext] copy];
            if ([[NSFileManager defaultManager] fileExistsAtPath:old]) {
                [[NSFileManager defaultManager] removeItemAtPath:old error:NULL];
            }
        }
    }
    if (message) {
        *message = ok ? path : @"PNG 写盘失败";
    }
    WCLogLine(@"info", @"bg", @"保存壁纸 mode=%@ ok=%d bytes=%lu path=%@",
              dark ? @"dark" : @"light", ok, (unsigned long)png.length, path);
    if (ok) WCWallpaperInvalidateActiveCache();
    return ok;
}

BOOL WCWallpaperClear(void) {
    BOOL removed = NO;
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSNumber *darkObj in @[@NO, @YES]) {
        BOOL dark = darkObj.boolValue;
        for (NSString *ext in @[@"png", @"jpg", @"jpeg"]) {
            NSString *path = [[WCWallpaperBasePath(dark) stringByAppendingPathExtension:ext] copy];
            if ([fm fileExistsAtPath:path]) {
                if ([fm removeItemAtPath:path error:NULL]) removed = YES;
                WCLogLine(@"info", @"bg", @"清除壁纸 mode=%@ path=%@",
                          dark ? @"dark" : @"light", path);
            }
        }
    }
    if (removed) WCWallpaperInvalidateActiveCache();
    return removed;
}

#pragma mark - 样式联动

CGFloat WCWallpaperTintAlpha(CGFloat alpha) {
    if (!WCWallpaperActive()) return alpha;
    return MAX(0.02, alpha - 0.1);
}

CGFloat WCWallpaperShadowOpacity(CGFloat opacity) {
    if (!WCWallpaperActive()) return opacity;
    return opacity * 0.5;
}

#pragma mark - 应用

static BOOL WCWallpaperDarkTrait(UIViewController *controller) {
    UITraitCollection *traits = controller.traitCollection;
    if (@available(iOS 12.0, *)) {
        if (traits.userInterfaceStyle == UIUserInterfaceStyleDark) return YES;
        if (traits.userInterfaceStyle == UIUserInterfaceStyleLight) return NO;
        // 未指定时看窗口。
        UITraitCollection *windowTraits = controller.view.window.traitCollection;
        if (windowTraits.userInterfaceStyle == UIUserInterfaceStyleDark) return YES;
    }
    return NO;
}

static NSHashTable<UIViewController *> *WCWallpaperControllers(void) {
    static NSHashTable *table;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        table = [NSHashTable weakObjectsHashTable];
    });
    return table;
}

#pragma mark - 1.7.7 导航栏 / 单元格

static const NSInteger WCWallpaperPanelGuardTag = 0x574C4750;  // 'WCGP' 分组面板
static const NSInteger WCWallpaperNavTitleTag = 0x574E4154;    // 'WNAT' 自定义标题

static BOOL WCWallpaperInGroupPanel(UIView *view) {
    UIView *cur = view;
    while (cur) {
        if (cur.tag == WCWallpaperPanelGuardTag) return YES;
        cur = cur.superview;
    }
    return NO;
}

/// 近似纯白 / 纯黑（且不透明）—— 这些是挡在壁纸前面的实体卡片。
static BOOL WCWallpaperIsPaperColor(UIColor *color) {
    if (!color) return NO;
    CGFloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
    if (![color getRed:&r green:&g blue:&b alpha:&a]) return NO;
    if (a < 0.6) return NO;
    return (r > 0.97 && g > 0.97 && b > 0.97) || (r < 0.04 && g < 0.04 && b < 0.04);
}

/// 「我」页（More / Profile）的白色卡片保持半透明，让壁纸透出来。
static BOOL WCWallpaperMoreLike(UIView *view) {
    UIResponder *responder = view.nextResponder;
    while (responder) {
        if ([responder isKindOfClass:[UIViewController class]]) {
            NSString *name = NSStringFromClass([responder class]);
            return ([name rangeOfString:@"More"].location != NSNotFound ||
                    [name rangeOfString:@"Profile"].location != NSNotFound);
        }
        responder = responder.nextResponder;
    }
    return NO;
}

static void WCWallpaperStyleCell(UITableViewCell *cell) {
    if (!cell || WCWallpaperInGroupPanel(cell)) return;
    // 没有壁纸时一个字都不改，完全保持微信原生配色。
    if (!WCWallpaperActive()) return;

    UITraitCollection *traits = cell.traitCollection ?: UITraitCollection.currentTraitCollection;
    BOOL dark = (traits.userInterfaceStyle == UIUserInterfaceStyleDark);
    BOOL more = WCWallpaperMoreLike(cell);

    // More 页白卡：浅色 white 0.92 / 深色 white 0.08，其余页面直接 clear。
    UIColor *card = nil;
    if (more) {
        card = dark ? [UIColor colorWithWhite:1.0 alpha:0.08]
                    : [UIColor colorWithWhite:1.0 alpha:0.92];
    }
    cell.backgroundColor = card ?: [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];

    for (UIView *sub in cell.contentView.subviews) {
        if (!WCWallpaperIsPaperColor(sub.backgroundColor)) continue;
        sub.backgroundColor = card ?: [UIColor clearColor];
    }
}

@interface UITableViewCell (WCWallpaperSwizzle)
- (void)wcw_didMoveToSuperview;
@end

/// didMoveToSuperview 定义在 UIView 上，交换后所有 UIView 都会走到这里，
/// 所以原生实现指针必须单独保存，且先判定真的是 cell 再做样式。
static IMP gWCWallpaperOrigDidMove = NULL;

@implementation UITableViewCell (WCWallpaperSwizzle)
- (void)wcw_didMoveToSuperview {
    if (gWCWallpaperOrigDidMove) {
        ((void (*)(id, SEL))gWCWallpaperOrigDidMove)(self, @selector(didMoveToSuperview));
    }
    if (![self isKindOfClass:[UITableViewCell class]]) return;
    @try {
        WCWallpaperStyleCell((UITableViewCell *)self);
    } @catch (NSException *exception) {
    }
}
@end

/// 全局安装一次：cell 进入视图树时按壁纸状态改背景。
void WCWallpaperInstallCellHook(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        Class cls = [UITableViewCell class];
        SEL sel = @selector(didMoveToSuperview);
        Method method = class_getInstanceMethod(cls, sel);
        Method replacement = class_getInstanceMethod(cls, @selector(wcw_didMoveToSuperview));
        if (method && replacement) {
            gWCWallpaperOrigDidMove = method_getImplementation(method);
            method_exchangeImplementations(method, replacement);
            WCLogLine(@"info", @"bg", @"cell 背景 hook 已安装");
        }
    });
}

static UINavigationBar *WCWallpaperFindNavigationBar(UIViewController *controller) {
    if (!controller) return nil;
    UINavigationBar *bar = controller.navigationController.navigationBar;
    if (bar) return bar;
    UIView *cur = controller.view;
    while (cur) {
        if ([cur isKindOfClass:[UINavigationBar class]]) return (UINavigationBar *)cur;
        cur = cur.superview;
    }
    for (UIView *sub in controller.view.superview.subviews) {
        if ([sub isKindOfClass:[UINavigationBar class]]) return (UINavigationBar *)sub;
    }
    return nil;
}

static const void *WCWallpaperSavedAlphaKey = &WCWallpaperSavedAlphaKey;
static const void *WCWallpaperSavedEffectKey = &WCWallpaperSavedEffectKey;
static NSString *gLastNavLogSignature = nil;

/// 1.8.1：把 _UIBarBackground 整棵子树真正做成「无模糊、无底色、透明」。
/// alpha 只在 active 时清零，退出壁纸时按保存值还原，避免把导航栏永久弄没。
static void WCWallpaperNeutralizeBarTree(UIView *view, BOOL active, NSUInteger depth) {
    if (!view || depth > 6) return;
    view.hidden = active;
    if ([view isKindOfClass:[UIVisualEffectView class]]) {
        UIVisualEffectView *effectView = (UIVisualEffectView *)view;
        if (active) {
            if (effectView.effect &&
                !objc_getAssociatedObject(effectView, WCWallpaperSavedEffectKey)) {
                objc_setAssociatedObject(effectView, WCWallpaperSavedEffectKey,
                                         effectView.effect, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            }
            effectView.effect = nil;
        } else {
            id saved = objc_getAssociatedObject(effectView, WCWallpaperSavedEffectKey);
            if (saved) {
                effectView.effect = saved;
                objc_setAssociatedObject(effectView, WCWallpaperSavedEffectKey, nil,
                                         OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            }
        }
    }
    if (active) {
        view.backgroundColor = [UIColor clearColor];
        if (!objc_getAssociatedObject(view, WCWallpaperSavedAlphaKey)) {
            objc_setAssociatedObject(view, WCWallpaperSavedAlphaKey, @(view.alpha),
                                     OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        view.alpha = 0.0;
    } else {
        id saved = objc_getAssociatedObject(view, WCWallpaperSavedAlphaKey);
        if (saved) {
            view.alpha = [saved floatValue];
            objc_setAssociatedObject(view, WCWallpaperSavedAlphaKey, nil,
                                     OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    }
    for (UIView *child in view.subviews) {
        WCWallpaperNeutralizeBarTree(child, active, depth + 1);
    }
}

/// 1.8.3：微信自绘的导航栏背景（顶层 UIView 里包一层 UIVisualEffectView）
/// 不属于 _UIBarBackground，旧的清理逻辑漏掉它 → 顶栏仍有一块灰底。
/// 这里递归判断子树里是否含毛玻璃，命中就整棵按「装饰层」处理。
static BOOL WCWallpaperContainsEffectView(UIView *view, NSUInteger depth) {
    if (!view || depth > 5) return NO;
    if ([view isKindOfClass:[UIVisualEffectView class]]) return YES;
    for (UIView *child in view.subviews) {
        if (WCWallpaperContainsEffectView(child, depth + 1)) return YES;
    }
    return NO;
}

/// 从导航栏向上找它所属的控制器（标题 / 深浅模式需要）。
static UIViewController *WCWallpaperOwnerController(UIView *view) {
    UIResponder *responder = view.nextResponder;
    while (responder) {
        if ([responder isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)responder;
        }
        responder = responder.nextResponder;
    }
    return nil;
}

/// 1.7.7：标题浮在壁纸上（浅色 #111 / 深色 #F2F2F2 + 1px 半透明描边）。
static void WCWallpaperApplyNavigationBar(UIViewController *controller) {
    UINavigationBar *bar = WCWallpaperFindNavigationBar(controller);
    if (!bar) return;
    BOOL active = WCWallpaperActive();
    BOOL dark = WCWallpaperDarkTrait(controller);

    [bar setBackgroundImage:(active ? [UIImage new] : nil) forBarMetrics:UIBarMetricsDefault];
    [bar setShadowImage:(active ? [UIImage new] : nil)];
    bar.barTintColor = active ? [UIColor clearColor] : nil;
    bar.backgroundColor = active ? [UIColor clearColor] : nil;
    bar.translucent = active;
    // _UIBarBackground 是导航栏那层不透明渐变，壁纸下必须连子视图一起藏掉。
    // 1.8.1：子视图 hidden + alpha 0 + UIVisualEffectView 的 effect 置 nil，
    // 避免系统在 layout 后重新铺灰条 / 毛玻璃。
    BOOL bgHidden = NO;
    BOOL effectNil = NO;
    NSUInteger decorationHidden = 0;
    for (UIView *sub in bar.subviews) {
        NSString *cls = NSStringFromClass([sub class]);
        if ([cls rangeOfString:@"BarBackground"].location != NSNotFound) {
            WCWallpaperNeutralizeBarTree(sub, active, 0);
            bgHidden = sub.hidden;
            continue;
        }
        // 1.8.3：微信自绘的灰底装饰层（内容层以外的毛玻璃子树）一并透明。
        if ([cls rangeOfString:@"ContentView"].location == NSNotFound &&
            WCWallpaperContainsEffectView(sub, 0)) {
            WCWallpaperNeutralizeBarTree(sub, active, 0);
            if (sub.hidden) decorationHidden += 1;
            if (active) effectNil = YES;
        }
        if ([sub isKindOfClass:[UIVisualEffectView class]]) {
            if (active) {
                UIVisualEffectView *effectView = (UIVisualEffectView *)sub;
                if (effectView.effect &&
                    !objc_getAssociatedObject(effectView, WCWallpaperSavedEffectKey)) {
                    objc_setAssociatedObject(effectView, WCWallpaperSavedEffectKey,
                                             effectView.effect,
                                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                }
                effectView.effect = nil;
                if (!objc_getAssociatedObject(effectView, WCWallpaperSavedAlphaKey)) {
                    objc_setAssociatedObject(effectView, WCWallpaperSavedAlphaKey, @(sub.alpha),
                                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                }
                sub.alpha = 0.0;
                effectNil = YES;
            } else {
                WCWallpaperNeutralizeBarTree(sub, NO, 0);
            }
        }
    }
    bar.clipsToBounds = NO;

    // 1.8.2：iOS 15+ 的 appearance 会在 layout 里把背景图/材质写回来，
    // 必须显式改成 transparent，光设 setBackgroundImage 不够。
    if (active) {
        if (@available(iOS 13.0, *)) {
            UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
            [appearance configureWithTransparentBackground];
            appearance.backgroundColor = [UIColor clearColor];
            appearance.backgroundEffect = nil;
            appearance.shadowColor = [UIColor clearColor];
            bar.standardAppearance = appearance;
            bar.scrollEdgeAppearance = appearance;
            if (@available(iOS 15.0, *)) bar.compactAppearance = appearance;
        }
    }
    // 1.8.2：把导航栏上任何非 ContentView 的不透明底色清掉（微信自绘 title 栏 / hookView）。
    for (UIView *sub in bar.subviews) {
        NSString *cls = NSStringFromClass([sub class]);
        if ([cls rangeOfString:@"ContentView"].location != NSNotFound) continue;
        if (active && sub.backgroundColor &&
            CGColorGetAlpha(sub.backgroundColor.CGColor) > 0.01) {
            sub.backgroundColor = [UIColor clearColor];
        }
    }

    // 1.8.1：四个页面各打一条（同一 cls + 状态只打一次）。
    NSString *navSignature = [NSString stringWithFormat:@"%@#%d#%d#%d#%lu",
                              NSStringFromClass([controller class]),
                              active ? 1 : 0, bgHidden ? 1 : 0, effectNil ? 1 : 0,
                              (unsigned long)decorationHidden];
    if (![navSignature isEqualToString:(gLastNavLogSignature ?: @"")]) {
        gLastNavLogSignature = [navSignature copy];
        WCLogLine(@"info", @"nav",
                  @"bar 透明 cls=%@ bgHidden=%d effect=%d 装饰=%lu tint=clear shadow=nil active=%d",
                  NSStringFromClass([controller class]), bgHidden ? 1 : 0,
                  effectNil ? 1 : 0, (unsigned long)decorationHidden, active ? 1 : 0);
    }

    UILabel *label = (UILabel *)[bar viewWithTag:WCWallpaperNavTitleTag];
    if (!active) {
        if ([label isKindOfClass:[UILabel class]]) {
            if (bar.topItem.titleView == label) bar.topItem.titleView = nil;
            [label removeFromSuperview];
        }
        bar.titleTextAttributes = nil;
        return;
    }

    if (!bar.topItem) return;
    NSString *title = bar.topItem.title;
    if (title.length == 0) title = controller.navigationItem.title;
    if (title.length == 0) return;

    if (![label isKindOfClass:[UILabel class]]) {
        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 36)];
        label.tag = WCWallpaperNavTitleTag;
        label.textAlignment = NSTextAlignmentCenter;
        label.backgroundColor = [UIColor clearColor];
        bar.topItem.titleView = label;
    }
    label.attributedText = [[NSAttributedString alloc] initWithString:title attributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize:17.0 weight:UIFontWeightSemibold],
        NSForegroundColorAttributeName: dark ? [UIColor colorWithWhite:0.949 alpha:1.0]
                                             : [UIColor colorWithRed:0.067 green:0.067
                                                                blue:0.067 alpha:1.0],
        NSStrokeColorAttributeName: dark ? [UIColor colorWithWhite:0.0 alpha:0.45]
                                         : [UIColor colorWithWhite:1.0 alpha:0.55],
        NSStrokeWidthAttributeName: @(-2.0),   // 负值 = 填充 + 描边
    }];
    [label sizeToFit];
}

/// 页面底下的滚动容器跟随壁纸：有壁纸转 clear，没壁纸恢复纯白 / 纯黑。
static void WCWallpaperApplyScrollBackgrounds(UIView *root, UIColor *fallback, BOOL wallpaper) {
    if (!root) return;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:root];
    NSUInteger budget = 600;
    while (queue.count && budget > 0) {
        budget -= 1;
        UIView *view = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if ([view isKindOfClass:[UIScrollView class]]) {
            view.backgroundColor = wallpaper ? [UIColor clearColor] : fallback;
            if ([view isKindOfClass:[UITableView class]]) {
                UITableView *table = (UITableView *)view;
                // 1.7.7：「我」页的灰色缝隙来自 backgroundView，必须清掉。
                table.backgroundView = nil;
                for (UITableViewCell *cell in table.visibleCells) {
                    WCWallpaperStyleCell(cell);
                }
            }
            if (view.subviews.count <= 80) [queue addObjectsFromArray:view.subviews];
            continue;
        }
        if (view.subviews.count <= 80) [queue addObjectsFromArray:view.subviews];
    }
}

#pragma mark - 1.8.1 导航控制器 / 导航栏重刷

// 1.8.2：didShowViewController:animated: 是 UINavigationControllerDelegate 的回调名，
// UINavigationController 自身并没有可靠实现 —— 1.8.1 的钩子实际上永远等不到调用。
// 改成真正会执行的三组 push / pop / setViewControllers，再叠加四个页面的 viewDidAppear:。
static IMP gWCWallpaperOrigNavPush = NULL;
static IMP gWCWallpaperOrigNavPop = NULL;
static IMP gWCWallpaperOrigNavSetVCs = NULL;
static IMP gWCWallpaperOrigBarLayout = NULL;
static NSMutableDictionary<NSString *, NSValue *> *gWCWallpaperAppearOrig = nil;
static NSString *gWCWallpaperTreeSignature = nil;
static NSTimeInterval gWCWallpaperLastLayoutRun = 0.0;

static void WCWallpaperScheduleRefresh(UIViewController *controller) {
    if (!controller) return;
    if (!WCWallpaperActive()) return;
    // 一帧后再刷，避免导航控制器自己的 appearance 把我们刚清掉的东西写回来。
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            WCWallpaperApplyToController(controller);
        } @catch (NSException *exception) {
        }
    });
}

@interface UINavigationController (WCWallpaperSwizzle)
- (void)wcw_pushViewController:(UIViewController *)viewController animated:(BOOL)animated;
- (UIViewController *)wcw_popViewControllerAnimated:(BOOL)animated;
- (void)wcw_setViewControllers:(NSArray<UIViewController *> *)controllers animated:(BOOL)animated;
@end

@implementation UINavigationController (WCWallpaperSwizzle)
- (void)wcw_pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (gWCWallpaperOrigNavPush) {
        ((void (*)(id, SEL, id, BOOL))gWCWallpaperOrigNavPush)(self, _cmd, viewController, animated);
    }
    WCWallpaperScheduleRefresh(viewController ?: self.topViewController);
}

- (UIViewController *)wcw_popViewControllerAnimated:(BOOL)animated {
    UIViewController *popped = nil;
    if (gWCWallpaperOrigNavPop) {
        popped = ((id (*)(id, SEL, BOOL))gWCWallpaperOrigNavPop)(self, _cmd, animated);
    }
    WCWallpaperScheduleRefresh(self.topViewController);
    return popped;
}

- (void)wcw_setViewControllers:(NSArray<UIViewController *> *)controllers animated:(BOOL)animated {
    if (gWCWallpaperOrigNavSetVCs) {
        ((void (*)(id, SEL, id, BOOL))gWCWallpaperOrigNavSetVCs)(self, _cmd, controllers, animated);
    }
    WCWallpaperScheduleRefresh(self.topViewController);
}
@end

/// 1.8.2：一次性层级 dump —— 只在「类名 / frame / hidden / alpha / 背景」变化时重打，
/// 用来抓出真正带灰底的类（_UIBarBackground / MMUIHookView / 自绘 title 栏）。
static void WCWallpaperAppendTree(UIView *view, NSString *path,
                                  NSMutableString *signature,
                                  NSMutableArray<NSString *> *lines, NSUInteger depth) {
    if (!view || depth > 2) return;
    NSString *cls = NSStringFromClass([view class]);
    NSString *bg = view.backgroundColor ? [view.backgroundColor description] : @"nil";
    NSString *line = [NSString stringWithFormat:
        @"层级 %@ cls=%@ frame=(%.0f,%.0f,%.0f,%.0f) alpha=%.2f hidden=%d bg=%@",
        path, cls, view.frame.origin.x, view.frame.origin.y,
        view.frame.size.width, view.frame.size.height, view.alpha, view.hidden ? 1 : 0, bg];
    [lines addObject:line];
    [signature appendFormat:@"%@#%.0f#%.0f#%.0f#%.0f#%.2f#%d#%@|", cls,
        view.frame.origin.x, view.frame.origin.y, view.frame.size.width,
        view.frame.size.height, view.alpha, view.hidden ? 1 : 0, bg];
    NSUInteger i = 0;
    for (UIView *child in view.subviews) {
        WCWallpaperAppendTree(child, [NSString stringWithFormat:@"%@.%lu", path, (unsigned long)i],
                              signature, lines, depth + 1);
        i += 1;
    }
}

static void WCWallpaperDumpBarTree(UINavigationBar *bar) {
    if (!bar) return;
    NSMutableString *signature = [NSMutableString string];
    NSMutableArray<NSString *> *lines = [NSMutableArray array];
    NSUInteger i = 0;
    for (UIView *sub in bar.subviews) {
        WCWallpaperAppendTree(sub, [NSString stringWithFormat:@"%lu", (unsigned long)i],
                              signature, lines, 0);
        i += 1;
    }
    if (gWCWallpaperTreeSignature && [gWCWallpaperTreeSignature isEqualToString:signature]) return;
    gWCWallpaperTreeSignature = [signature copy];
    WCLogLine(@"info", @"nav", @"层级 根=%@ 子=%lu", NSStringFromClass([bar class]),
              (unsigned long)bar.subviews.count);
    for (NSString *line in lines) WCLogLine(@"info", @"nav", @"%@", line);
}

@interface UINavigationBar (WCWallpaperSwizzle)
- (void)wcw_layoutSubviews;
@end

@implementation UINavigationBar (WCWallpaperSwizzle)
- (void)wcw_layoutSubviews {
    if (gWCWallpaperOrigBarLayout) {
        ((void (*)(id, SEL))gWCWallpaperOrigBarLayout)(self, _cmd);
    }
    if (!WCWallpaperActive()) return;
    UINavigationBar *bar = self;
    // 1.8.2：layout 可能被每帧调用，0.35s 内只处理一次，避免日志与视图树来回抖。
    NSTimeInterval now = CACurrentMediaTime();
    if (now - gWCWallpaperLastLayoutRun < 0.35) return;
    gWCWallpaperLastLayoutRun = now;
    WCWallpaperDumpBarTree(bar);
    // 绝不在 layoutSubviews 里改视图树，全部推迟到下一 runloop。
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            // 已经透明就不再动视图树，避免「改 hidden → 触发 layout → 再异步刷」的死循环。
            BOOL needsWork = bar.backgroundColor == nil ||
                             CGColorGetAlpha(bar.backgroundColor.CGColor) > 0.01;
            for (UIView *sub in bar.subviews) {
                if ([NSStringFromClass([sub class]) rangeOfString:@"BarBackground"].location != NSNotFound &&
                    !sub.hidden) {
                    needsWork = YES;
                }
                if ([sub isKindOfClass:[UIVisualEffectView class]] &&
                    ((UIVisualEffectView *)sub).effect != nil) {
                    needsWork = YES;
                }
            }
            if (!needsWork) return;

            UIViewController *owner = WCWallpaperOwnerController(bar);
            if ([owner isKindOfClass:[UINavigationController class]]) {
                owner = ((UINavigationController *)owner).topViewController;
            }
            if (owner) {
                WCWallpaperApplyNavigationBar(owner);
            } else {
                for (UIView *sub in bar.subviews) {
                    if ([NSStringFromClass([sub class]) rangeOfString:@"BarBackground"].location != NSNotFound) {
                        WCWallpaperNeutralizeBarTree(sub, YES, 0);
                    }
                }
                bar.backgroundColor = [UIColor clearColor];
            }
        } @catch (NSException *exception) {
        }
    });
}
@end

/// 1.8.2：四个真实页面类的 viewDidAppear: 钩子（类可能晚于启动才加载，所以按需补装）。
static NSArray<NSString *> *WCWallpaperAppearClassNames(void) {
    static NSArray<NSString *> *names;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        names = @[@"NewMainFrameViewController",
                  @"ContactsViewController",
                  @"FindFriendEntryViewController",
                  @"MoreViewController"];
    });
    return names;
}

static void WCWallpaperHookAppearForClass(Class cls) {
    if (!cls) return;
    NSString *name = NSStringFromClass(cls);
    if (![WCWallpaperAppearClassNames() containsObject:name]) return;
    if (!gWCWallpaperAppearOrig) gWCWallpaperAppearOrig = [NSMutableDictionary dictionary];
    if (gWCWallpaperAppearOrig[name]) return;

    SEL sel = @selector(viewDidAppear:);
    Method method = class_getInstanceMethod(cls, sel);
    if (!method) {
        WCLogLine(@"warn", @"nav", @"钩子 装 cls=%@ sel=viewDidAppear: ok=0 原因=no-method", name);
        return;
    }
    IMP orig = method_getImplementation(method);
    const char *types = method_getTypeEncoding(method);
    IMP replacement = imp_implementationWithBlock(^(UIViewController *selfVC, BOOL animated) {
        ((void (*)(id, SEL, BOOL))orig)(selfVC, sel, animated);
        WCWallpaperScheduleRefresh(selfVC);
    });
    BOOL added = class_addMethod(cls, sel, replacement, types);
    if (!added) method_setImplementation(method, replacement);
    gWCWallpaperAppearOrig[name] = [NSValue valueWithPointer:(void *)orig];
    WCLogLine(@"info", @"nav", @"钩子 装 cls=%@ sel=viewDidAppear: ok=1 added=%d",
              name, added ? 1 : 0);
}

static void WCWallpaperInstallNavigationHooks(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        // 1.8.2：class_addMethod + method_setImplementation，避免误交换父类（UIView）的方法。
        Class navCls = [UINavigationController class];
        struct { SEL sel; SEL repl; IMP *orig; const char *label; } hooks[] = {
            { @selector(pushViewController:animated:),
              @selector(wcw_pushViewController:animated:), &gWCWallpaperOrigNavPush,
              "pushViewController:animated:" },
            { @selector(popViewControllerAnimated:),
              @selector(wcw_popViewControllerAnimated:), &gWCWallpaperOrigNavPop,
              "popViewControllerAnimated:" },
            { @selector(setViewControllers:animated:),
              @selector(wcw_setViewControllers:animated:), &gWCWallpaperOrigNavSetVCs,
              "setViewControllers:animated:" },
        };
        for (NSUInteger i = 0; i < sizeof(hooks) / sizeof(hooks[0]); i++) {
            Method method = class_getInstanceMethod(navCls, hooks[i].sel);
            Method repl = class_getInstanceMethod(navCls, hooks[i].repl);
            if (!method || !repl) {
                WCLogLine(@"warn", @"nav", @"钩子 装 cls=UINavigationController sel=%s ok=0",
                          hooks[i].label);
                continue;
            }
            *(hooks[i].orig) = method_getImplementation(method);
            IMP replacement = method_getImplementation(repl);
            const char *types = method_getTypeEncoding(repl);
            BOOL added = class_addMethod(navCls, hooks[i].sel, replacement, types);
            if (!added) method_setImplementation(method, replacement);
            WCLogLine(@"info", @"nav", @"钩子 装 cls=UINavigationController sel=%s ok=1 added=%d",
                      hooks[i].label, added ? 1 : 0);
        }

        Class barCls = [UINavigationBar class];
        SEL barSel = @selector(layoutSubviews);
        Method barMethod = class_getInstanceMethod(barCls, barSel);
        Method barReplacement = class_getInstanceMethod(barCls, @selector(wcw_layoutSubviews));
        if (barMethod && barReplacement) {
            gWCWallpaperOrigBarLayout = method_getImplementation(barMethod);
            IMP replacement = method_getImplementation(barReplacement);
            const char *types = method_getTypeEncoding(barReplacement);
            BOOL added = class_addMethod(barCls, barSel, replacement, types);
            if (!added) method_setImplementation(barMethod, replacement);
            WCLogLine(@"info", @"nav", @"钩子 装 cls=UINavigationBar sel=layoutSubviews ok=1 added=%d",
                      added ? 1 : 0);
        } else {
            WCLogLine(@"warn", @"nav", @"钩子 装 cls=UINavigationBar sel=layoutSubviews ok=0");
        }

        for (NSString *name in WCWallpaperAppearClassNames()) {
            WCWallpaperHookAppearForClass(NSClassFromString(name));
        }
    });
}

static NSString *gLastMountSignature = nil;

void WCWallpaperApplyToController(UIViewController *controller) {
    if (!controller || ![controller isViewLoaded]) return;
    WCWallpaperInstallNavigationHooks();
    // 1.8.2：真实页面类出现时补装 viewDidAppear:（类可能晚于启动才加载）。
    WCWallpaperHookAppearForClass([controller class]);
    UIView *root = controller.view;
    if (!root) return;

    NSHashTable *controllers = WCWallpaperControllers();
    @synchronized(controllers) {
        [controllers addObject:controller];
    }
    WCWallpaperInstallCellHook();

    BOOL dark = WCWallpaperDarkTrait(controller);
    BOOL active = WCWallpaperActive();
    NSString *cls = NSStringFromClass([controller class]);

    UIImageView *existing = (UIImageView *)[root viewWithTag:WCWallpaperViewTag];
    if (!active) {
        [existing removeFromSuperview];
        UIColor *paper = dark ? [UIColor blackColor] : [UIColor whiteColor];
        root.backgroundColor = paper;
        WCWallpaperApplyScrollBackgrounds(root, paper, NO);
        WCWallpaperApplyNavigationBar(controller);
        if (![gLastLogSignature isEqualToString:@"none"]) {
            gLastLogSignature = @"none";
            WCLogLine(@"info", @"bg", @"壁纸 未设置，恢复纯%@", dark ? @"黑" : @"白");
        }
        return;
    }

    NSString *path = WCWallpaperExistingPath(dark) ?: WCWallpaperExistingPath(!dark);
    UIImage *image = path ? [UIImage imageWithContentsOfFile:path] : nil;
    if (!image) {
        [existing removeFromSuperview];
        WCLogLine(@"warn", @"bg", @"壁纸 读取失败 path=%@", path ?: @"-");
        return;
    }

    UIImageView *bg = existing;
    if (!bg) {
        bg = [[UIImageView alloc] initWithFrame:root.bounds];
        bg.tag = WCWallpaperViewTag;
        bg.contentMode = UIViewContentModeScaleAspectFill;
        bg.clipsToBounds = YES;
        bg.userInteractionEnabled = NO;
        bg.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [root insertSubview:bg atIndex:0];
    } else {
        bg.frame = root.bounds;
        [root sendSubviewToBack:bg];
    }
    bg.image = image;

    // 1.8.2：壁纸在却看不见时，打印挂载位置与被上层不透明兄弟遮挡的数量。
    NSUInteger bgIndex = [root.subviews indexOfObject:bg];
    NSUInteger opaqueAbove = 0;
    for (NSUInteger i = bgIndex + 1; i < root.subviews.count; i++) {
        UIView *sib = root.subviews[i];
        if (sib.hidden || sib.alpha < 0.05) continue;
        UIColor *sibColor = sib.backgroundColor;
        if (sibColor && CGColorGetAlpha(sibColor.CGColor) > 0.6) opaqueAbove += 1;
    }
    NSString *mountSignature = [NSString stringWithFormat:@"%@#%lu#%lu#%lu#%d",
                                cls, (unsigned long)bgIndex,
                                (unsigned long)root.subviews.count,
                                (unsigned long)opaqueAbove, root.clipsToBounds ? 1 : 0];
    if (![mountSignature isEqualToString:(gLastMountSignature ?: @"")]) {
        gLastMountSignature = [mountSignature copy];
        WCLogLine(@"info", @"bg",
                  @"挂载 cls=%@ idx=%lu 父cls=%@ 父bg=%@ clips=%d 上层不透明=%lu",
                  cls, (unsigned long)bgIndex, NSStringFromClass([root class]),
                  root.backgroundColor ? [root.backgroundColor description] : @"nil",
                  root.clipsToBounds ? 1 : 0, (unsigned long)opaqueAbove);
    }

    // 页面底色与列表都转 clear，否则壁纸被白 / 黑底遮住。
    // 1.8.0：根视图开裁剪，防止壁纸越界；表格 / 列表全部 clear。
    root.backgroundColor = [UIColor clearColor];
    root.clipsToBounds = YES;
    // 导航容器自身也可能是默认灰底，会从导航栏/状态栏区域透出来。
    UINavigationController *nav = controller.navigationController;
    if (nav && nav.view) nav.view.backgroundColor = [UIColor clearColor];
    WCWallpaperApplyScrollBackgrounds(root, [UIColor clearColor], YES);
    // 1.7.7：导航栏透明 + 自定义标题浮在壁纸上。
    WCWallpaperApplyNavigationBar(controller);

    BOOL usedDark = dark;
    if (!WCWallpaperExistingPath(dark) && WCWallpaperExistingPath(!dark)) usedDark = !dark;
    NSString *signature = [NSString stringWithFormat:@"%@|%@|%@",
                           usedDark ? @"dark" : @"light", path, cls];
    if (![gLastLogSignature isEqualToString:signature]) {
        gLastLogSignature = signature;
        WCLogLine(@"info", @"bg", @"壁纸 mode=%@ cls=%@ has=1 path=%@",
                  usedDark ? @"dark" : @"light", cls, path);
    }
}

void WCWallpaperRefresh(void) {
    NSHashTable *controllers = WCWallpaperControllers();
    NSArray<UIViewController *> *all = nil;
    @synchronized(controllers) {
        all = controllers.allObjects;
    }
    for (UIViewController *controller in all) {
        WCWallpaperApplyToController(controller);
    }
    WCLogLine(@"info", @"bg", @"壁纸刷新 控制器=%lu mode=%@", (unsigned long)all.count,
              WCWallpaperActive() ? @"on" : @"off");
}
