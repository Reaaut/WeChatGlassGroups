#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 内置诊断日志。
//
// 设计原则：
// - 只记录类名 / 方法名 / 模块名 / 状态，不采集任何设备标识或用户内容。
// - 写盘失败（沙盒、权限、磁盘满）时降级到 NSLog，并在日志里留下一次
//   "[fallback]" 记录，便于区分“没写进去”与“没加载”。
// - 单个文件上限 512 KB，超过后从行边界截断，保留最近一半。
//
// 关键语义：如果日志文件不存在，说明 dylib 从来没被 dyld 加载，
// 本模块自身也不会执行 —— 这正是“没加载”最可靠的判据。

#ifdef __cplusplus
extern "C" {
#endif

/// 日志目录：rootless 为 /var/jb/var/mobile/Library/WCTheme，否则 /var/mobile/...
NSString *WCLogDirectory(void);

/// 日志文件完整路径。
NSString *WCLogFilePath(void);

/// 启动标记：在任何 hook 之前调用。写 "[boot] loaded vX pid=N"。
void WCLogBoot(NSString *version);

/// 追加一行日志。level 例如 info / warn / boot / hook。
void WCLogLine(NSString *level, NSString *module, NSString *format, ...) NS_FORMAT_FUNCTION(3, 4);

/// 读取最近 maxLines 行（没有文件时返回空数组）。供偏好面板使用。
NSArray<NSString *> *WCLogTail(NSUInteger maxLines);

/// 探测某个 hook 目标是否存在，并把结果写进日志。
/// 类不存在或方法不存在时返回 NO（表示该 hook 会被跳过）。
BOOL WCHookProbe(NSString *module, NSString *className, NSString *selectorName);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
