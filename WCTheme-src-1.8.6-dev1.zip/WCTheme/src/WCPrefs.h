#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 供 .x（ObjC）与 .mm（ObjC++）共同引用，固定 C linkage。
#ifdef __cplusplus
extern "C" {
#endif

// 偏好域名。修改包名时，需要同步修改这里 + layout/DEBIAN/control 的 Package
// + Resources/Info.plist 的 CFBundleIdentifier + 偏好面板 bundle 名。
extern NSString *const WCThemeDomain;

// 1.7.3：落盘统一加 "wxgb." 前缀，和参考包自己的 WCLG* 键彻底隔开。
// 传进来的仍是 WCPrefs 的公开 key，函数只负责加前缀（已加过则原样返回）。
extern NSString *WCStorageKey(NSString *key);

// 偏好变更的 Darwin 通知：偏好面板每次写入后发送，tweak 收到后热加载。
extern NSString *const WCThemePrefsChangedNotification;

// 手动抓取当前界面类名的 Darwin 通知（偏好面板按钮 -> 微信进程）。
extern NSString *const WCThemeDumpHierarchyNotification;

// 所有偏好 key。偏好面板 plist、WCPrefs 都使用同一套 key。
extern NSString *const WCKeyEnabled;
extern NSString *const WCKeyGlassEnabled;
extern NSString *const WCKeyGlassIntensity;
extern NSString *const WCKeyGlassStyle;
extern NSString *const WCKeyAdBlockEnabled;
extern NSString *const WCKeyDiscoveryEnabled;
extern NSString *const WCKeyLayoutEnabled;
extern NSString *const WCKeyCellCornerRadius;
extern NSString *const WCKeyCellInset;
extern NSString *const WCKeyNavBarAlpha;
extern NSString *const WCKeyTabBarAlpha;
extern NSString *const WCKeyStatusBarStyle;

// 1.2.0 新增：按表面处理的毛玻璃 / 液态卡片 / 微信内入口。
extern NSString *const WCKeyCardEnabled;
extern NSString *const WCKeyCardCornerRadius;
extern NSString *const WCKeyCardInset;
extern NSString *const WCKeyPerformanceFirst;
extern NSString *const WCKeyLegacyGlassEnabled;
extern NSString *const WCKeyEntryButtonEnabled;

// 1.3.0 新增：首页分组 / 悬浮底栏 / 大标题。
extern NSString *const WCKeyGroupEnabled;
extern NSString *const WCKeyDockEnabled;
extern NSString *const WCKeyBigTitleEnabled;
extern NSString *const WCKeyDockInset;

// 1.4.0 新增：底栏增强 / 轻量材质 / 角标改色。
extern NSString *const WCKeyDockPlusEnabled;
extern NSString *const WCKeySearchFloatBottom;
extern NSString *const WCKeyLiteMode;
extern NSString *const WCKeyBadgeColorEnabled;
extern NSString *const WCKeyBadgePreset;
extern NSString *const WCKeyBadgeHex;

// 1.5.0 新增：分组安全模式 / 胶囊布局参数。
extern NSString *const WCKeyGroupSafeMode;
extern NSString *const WCKeyGroupOffset;
extern NSString *const WCKeyGroupSpacing;
extern NSString *const WCKeyGroupCorner;

// 1.6.0 新增：底栏浮岛尺寸 / 标题 / 搜索 / 分组胶囊颜色。
extern NSString *const WCKeyDockHeight;
extern NSString *const WCKeyDockWidth;
extern NSString *const WCKeyDockShowTitle;
extern NSString *const WCKeyDockSearchEnabled;
extern NSString *const WCKeyGroupChipHex;

// 1.6.2 新增：浮岛自定义位置 / 宽度模式 / 搜索胶囊位置 / 液态强度。
extern NSString *const WCKeyDockOffsetX;
extern NSString *const WCKeyDockOffsetY;
extern NSString *const WCKeyDockWidthMode;
extern NSString *const WCKeyDockFixedWidth;
extern NSString *const WCKeyDockSearchPlacement;
extern NSString *const WCKeyDockLiquidIntensity;

// 1.7.0 新增：分组自定义名 / 自定义组规则 / 搜索条模式与 HTML 卡片。
extern NSString *const WCKeyGroupNamePinned;
extern NSString *const WCKeyGroupNameFriends;
extern NSString *const WCKeyGroupNameGroups;
extern NSString *const WCKeyGroupNameService;
extern NSString *const WCKeyGroupNameOfficial;
extern NSString *const WCKeyGroupNameOther;
extern NSString *const WCKeyCustomGroup1Name;
extern NSString *const WCKeyCustomGroup1Keyword;
extern NSString *const WCKeyCustomGroup2Name;
extern NSString *const WCKeyCustomGroup2Keyword;
extern NSString *const WCKeyCustomGroup3Name;
extern NSString *const WCKeyCustomGroup3Keyword;
extern NSString *const WCKeySearchMode;
extern NSString *const WCKeySearchCardHTML;
extern NSString *const WCKeySearchCardHeight;
// 1.7.1 新增：分组面板顶部「Hey .」下方副标题，默认空。
extern NSString *const WCKeyGroupSubtitle;

// 1.7.2 新增：组间上下间距 / 首页自定义标题卡。
extern NSString *const WCKeyGroupSpacingV;
extern NSString *const WCKeyTitleText;
extern NSString *const WCKeyTitleSubtitle;
extern NSString *const WCKeyTitleCardEnabled;
extern NSString *const WCKeyCustomLabelPlacement;

// 1.8.3：隐藏分组面板背后灰框（容器玻璃 + 阴影），默认开（= 当前透明效果）。
extern NSString *const WCKeyGroupHideFrame;

// 1.8.5：底栏样式。floating（默认，悬浮胶囊）/ bar（贴边气泡底栏）。
extern NSString *const WCKeyDockStyle;

// 1.7.3：单组隐藏开关（默认全部显示）。
extern NSString *const WCKeyGroupHidePinned;
extern NSString *const WCKeyGroupHideFriends;
extern NSString *const WCKeyGroupHideGroups;
extern NSString *const WCKeyGroupHideService;
extern NSString *const WCKeyGroupHideOfficial;
extern NSString *const WCKeyGroupHideOther;

// 1.5.1 新增：分模块总闸 + 安全启动。默认全部关闭，只留 core。
extern NSString *const WCKeySafeBoot;
extern NSString *const WCKeyModuleGlass;
extern NSString *const WCKeyModuleDock;
extern NSString *const WCKeyModuleGroup;
extern NSString *const WCKeyModuleBadge;
extern NSString *const WCKeyModuleLayout;

/// 写入偏好并广播 Darwin 通知（微信进程与偏好面板同时生效）。
void WCSetPrefBool(NSString *key, BOOL value);
void WCSetPrefDouble(NSString *key, double value);
void WCSetPrefInteger(NSString *key, NSInteger value);
/// 写入字符串偏好（角标自定义色值等）。
void WCSetPrefString(NSString *key, NSString *value);
void WCPostPrefsChangedNotification(void);

/// 清空所有 key（恢复默认值）。
void WCPrefsResetToDefaults(void);

#ifdef __cplusplus
}
#endif

/// 统一偏好读取器。
/// 读取来源：CFPreferences（com.wctheme.dev）；读不到时再读 rootless/rootful 的
/// 偏好文件。所有 getter 都带默认值，调用方不需要关心 key 是否存在。
@interface WCPrefs : NSObject

+ (instancetype)shared;

/// 重新读取磁盘上的偏好（收到 Darwin 通知后调用）。
+ (void)reload;

@property (nonatomic, readonly) BOOL enabled;
/// 安全启动：为 YES 时 %ctor 只加载 core + 日志，不启动任何模块。
@property (nonatomic, readonly) BOOL safeBoot;
/// 分模块总闸：默认全部 NO。打开哪个模块，哪个模块才会注册 UI/监听。
@property (nonatomic, readonly) BOOL moduleGlass;
@property (nonatomic, readonly) BOOL moduleDock;
@property (nonatomic, readonly) BOOL moduleGroup;
@property (nonatomic, readonly) BOOL moduleBadge;
@property (nonatomic, readonly) BOOL moduleLayout;
@property (nonatomic, readonly) BOOL glassEnabled;
/// 0.04 ~ 0.16 的白色 tint alpha（滑块值即 alpha）。默认 0.08。
@property (nonatomic, readonly) double glassIntensity;
/// 0 = system material, 1 = thin material, 2 = ultra thin material
@property (nonatomic, readonly) NSInteger glassStyle;

@property (nonatomic, readonly) BOOL adBlockEnabled;
@property (nonatomic, readonly) BOOL discoveryEnabled;

@property (nonatomic, readonly) BOOL layoutEnabled;
@property (nonatomic, readonly) double cellCornerRadius;
@property (nonatomic, readonly) double cellInset;
@property (nonatomic, readonly) double navBarAlpha;
@property (nonatomic, readonly) double tabBarAlpha;
/// 0 = 不修改, 1 = 深色文字, 2 = 浅色文字
@property (nonatomic, readonly) NSInteger statusBarStyle;

/// 液态卡片：列表 cell 圆角卡片化（不做透明化）。默认开。
@property (nonatomic, readonly) BOOL cardEnabled;
@property (nonatomic, readonly) double cardCornerRadius;
@property (nonatomic, readonly) double cardInset;
/// 性能优先：关掉 cell 阴影，避免滚动时重绘抖动。默认关（阴影用 shadowPath，成本可控）。
@property (nonatomic, readonly) BOOL performanceFirst;

/// 旧版"全局近白背景换色"。观感差，默认关，仅作 fallback。
@property (nonatomic, readonly) BOOL legacyGlassEnabled;

/// 微信内「WCTheme 设置」悬浮入口是否显示。默认开。
@property (nonatomic, readonly) BOOL entryButtonEnabled;

/// 首页胶囊分组（纯叠加，不参与列表布局）。默认关。
@property (nonatomic, readonly) BOOL groupEnabled;
/// 安全模式：强制停用分组（移除 overlay、监听、缓存）。默认关。
@property (nonatomic, readonly) BOOL groupSafeMode;
/// 分组胶囊相对导航栏底部的下移量。默认 15。
@property (nonatomic, readonly) double groupOffset;
/// 分组胶囊之间的横向间距。默认 9。
@property (nonatomic, readonly) double groupSpacing;
/// 分组胶囊 / 展开卡片的圆角。默认 22。
@property (nonatomic, readonly) double groupCorner;
/// 底栏悬浮胶囊玻璃 dock。默认关（1.4.0 起需手动开启）。
@property (nonatomic, readonly) BOOL dockEnabled;
/// 顶栏大标题（导航栏内的左对齐大字）。默认开。
@property (nonatomic, readonly) BOOL bigTitleEnabled;
/// dock 与屏幕左右边缘的距离。默认 14。
@property (nonatomic, readonly) double dockInset;
/// 浮岛高度，默认 54。
@property (nonatomic, readonly) double dockHeight;
/// 浮岛宽度；0 = 自适应（内容宽度：4 个图标 + 头像）。
@property (nonatomic, readonly) double dockWidth;
/// 是否在图标下方显示文字。默认 NO。
@property (nonatomic, readonly) BOOL dockShowTitle;
/// 是否显示搜索胶囊。默认 NO。
@property (nonatomic, readonly) BOOL dockSearchEnabled;
/// 1.6.2：浮岛左边距（长按拖动后写回这里）。默认 14。
@property (nonatomic, readonly) double dockOffsetX;
/// 1.6.2：浮岛距底部安全区的偏移。默认 10。
@property (nonatomic, readonly) double dockOffsetY;
/// 1.6.2：宽度模式 0 = 自适应（内容宽、居中），1 = 固定宽度。默认 0。
@property (nonatomic, readonly) NSInteger dockWidthMode;
/// 1.6.2：固定宽度（240–420）。默认 300。
@property (nonatomic, readonly) double dockFixedWidth;
/// 1.6.2：搜索胶囊位置 above / insideLeft / none。默认 above。
@property (nonatomic, readonly, copy) NSString *dockSearchPlacement;
/// 1.6.2：液态玻璃强度 0–100（映射到 tint 0.06–0.20 与描边亮度）。默认 60。
@property (nonatomic, readonly) double dockLiquidIntensity;
/// 1.8.5：底栏样式 floating / bar。默认 floating。
@property (nonatomic, readonly, copy) NSString *dockStyle;
/// 分组胶囊底色（#RRGGBB），默认 #1E70E6。
@property (nonatomic, readonly, copy) NSString *groupChipHex;

/// 1.7.0：内置组的自定义显示名（为空则用默认「置顶 / 好友 / 群聊 / 服务号 / 公众号 / 其他」）。
@property (nonatomic, readonly, copy) NSString *groupNamePinned;
@property (nonatomic, readonly, copy) NSString *groupNameFriends;
@property (nonatomic, readonly, copy) NSString *groupNameGroups;
@property (nonatomic, readonly, copy) NSString *groupNameService;
@property (nonatomic, readonly, copy) NSString *groupNameOfficial;
@property (nonatomic, readonly, copy) NSString *groupNameOther;
/// 1.7.0：3 个自定义组规则，每项 { ident, name, keyword }（keyword 为空表示未启用）。
@property (nonatomic, readonly, copy) NSArray<NSDictionary *> *customGroupRules;
/// 1.7.0：搜索条模式 input / html。默认 input。
@property (nonatomic, readonly, copy) NSString *searchMode;
/// 1.7.0：HTML 卡片内容（可含完整 HTML 片段，注入本地模板）。
@property (nonatomic, readonly, copy) NSString *searchCardHTML;
/// 1.7.0：HTML 卡片高度 40–64。默认 48。
@property (nonatomic, readonly) double searchCardHeight;
/// 1.7.1：分组面板副标题（默认空，空则不占位）。
@property (nonatomic, readonly, copy) NSString *groupSubtitle;

/// 1.7.2：组间上下间距 6–24，默认 12。
@property (nonatomic, readonly) double groupSpacingV;
/// 1.7.2：首页自定义标题卡文字，默认「微信」。
@property (nonatomic, readonly, copy) NSString *titleText;
/// 1.7.2：首页标题卡副标题，默认空。
@property (nonatomic, readonly, copy) NSString *titleSubtitle;
/// 1.7.2：是否显示首页自定义标题，默认开。
@property (nonatomic, readonly) BOOL titleCardEnabled;
/// 1.7.4：自定义标签（标题文字）位置：0=关闭（保持默认左上）/1=左上/2=右上/3=底部左侧。
@property (nonatomic, readonly) NSInteger customLabelPlacement;

/// 1.7.3：单组隐藏（默认全部显示）。参数为 pinned/friends/groups/service/official/other。
- (BOOL)groupHiddenForIdent:(NSString *)ident;

/// 1.8.3：隐藏面板背后灰框（面板级玻璃底 + 阴影）。默认 YES。
@property (nonatomic, readonly) BOOL groupHideFrame;

/// 底栏右侧圆形「＋」。默认开（随 dock 一起生效）。
@property (nonatomic, readonly) BOOL dockPlusEnabled;
/// 悬浮搜索胶囊（底栏上方）。默认关。
@property (nonatomic, readonly) BOOL searchFloatBottom;
/// 轻量版：关闭阴影 / 多层描边，只留单层模糊。默认关。
@property (nonatomic, readonly) BOOL liteMode;
/// 未读角标改色。默认关。
@property (nonatomic, readonly) BOOL badgeColorEnabled;
/// 角标预设色板：0 红 / 1 蓝 / 2 紫 / 3 绿 / 4 橙 / 5 自定义。默认 0。
@property (nonatomic, readonly) NSInteger badgePreset;
/// 自定义角标色值（#RRGGBB）。默认 #FA5151。
@property (nonatomic, readonly, copy) NSString *badgeHex;

@end

NS_ASSUME_NONNULL_END
