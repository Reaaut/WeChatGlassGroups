#import "WCDiscovery.h"
#import "WCPrefs.h"

#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <os/log.h>
#import <objc/runtime.h>

static os_log_t gDiscoveryLog = NULL;
static NSTimer *gDiscoveryTimer = nil;
static NSMutableSet<NSString *> *gSeenClasses = nil;

static void WCDiscoveryLog(NSString *message) {
    if (gDiscoveryLog) {
        os_log_info(gDiscoveryLog, "%{public}s", message.UTF8String);
    }
    NSLog(@"[WCTheme][Discovery] %@", message);
}

static UIWindow *WCKeyWindow(void) {
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            if (scene.activationState != UISceneActivationStateForegroundActive) continue;

            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                if (window.isKeyWindow) return window;
            }
        }
    }

    UIWindow *legacy = [UIApplication sharedApplication].keyWindow;
    if (legacy) return legacy;
    return [UIApplication sharedApplication].windows.firstObject;
}

static NSArray<NSString *> *WCMethodKeywords(void) {
    static NSArray<NSString *> *keywords;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keywords = @[
            @"advert", @"banner", @"splash", @"promote", @"promotion",
            @"launch", @"welcome", @"timeline", @"brand", @"notice",
            @"feed", @"sns", @"webview", @"webviewcontroller"
        ];
    });
    return keywords;
}

static BOOL WCMethodLooksInteresting(NSString *selector, NSString *className) {
    NSString *lowerSelector = selector.lowercaseString;
    NSString *lowerClass = className.lowercaseString;
    if ([lowerClass containsString:@"advert"] || [lowerClass containsString:@"banner"]) {
        return YES;
    }
    for (NSString *keyword in WCMethodKeywords()) {
        if ([lowerSelector rangeOfString:keyword].location != NSNotFound) return YES;
    }
    return NO;
}

static void WCDumpMethodsForClass(Class cls) {
    NSString *className = NSStringFromClass(cls);
    Class current = cls;
    int depth = 0;

    while (current && depth < 5) {
        unsigned int count = 0;
        Method *methods = class_copyMethodList(current, &count);
        if (methods) {
            for (unsigned int index = 0; index < count; index++) {
                NSString *selector = NSStringFromSelector(method_getName(methods[index]));
                if (!WCMethodLooksInteresting(selector, className)) continue;

                const char *types = method_getTypeEncoding(methods[index]);
                NSString *typesString = types ? [NSString stringWithUTF8String:types] : @"?";
                WCDiscoveryLog([NSString stringWithFormat:
                                @"    %@[%@ %@]  types=%@",
                                (depth == 0 ? @"-" : @"- (super)"),
                                NSStringFromClass(current), selector, typesString]);
            }
            free(methods);
        }
        current = class_getSuperclass(current);
        depth++;
    }
}

static void WCDumpViewTree(UIView *view, int depth, int maxDepth, NSUInteger *budget) {
    if (!view || depth > maxDepth || *budget == 0) return;
    *budget -= 1;

    WCDiscoveryLog([NSString stringWithFormat:@"    %@V: %@  frame=%@",
                    [@"" stringByPaddingToLength:(NSUInteger)(depth * 2)
                                       withString:@" "
                                  startingAtIndex:0],
                    NSStringFromClass([view class]),
                    NSStringFromCGRect(view.frame)]);

    for (UIView *child in view.subviews) {
        WCDumpViewTree(child, depth + 1, maxDepth, budget);
    }
}

static void WCDiscoveryScan(BOOL includeViewTree) {
    void (^scan)(void) = ^{
        UIWindow *window = WCKeyWindow();
        if (!window) {
            WCDiscoveryLog(@"当前没有 key window，跳过");
            return;
        }

        WCDiscoveryLog([NSString stringWithFormat:@"==== 扫描 key window: %@ ====",
                        NSStringFromClass([window class])]);

        NSMutableArray<UIViewController *> *queue = [NSMutableArray array];
        if (window.rootViewController) {
            [queue addObject:window.rootViewController];
        }

        while (queue.count > 0) {
            UIViewController *controller = queue.firstObject;
            [queue removeObjectAtIndex:0];

            NSString *className = NSStringFromClass([controller class]);
            if (![gSeenClasses containsObject:className]) {
                [gSeenClasses addObject:className];

                Class superClass = class_getSuperclass([controller class]);
                WCDiscoveryLog([NSString stringWithFormat:
                                @"[VC] %@  (super=%@)",
                                className,
                                superClass ? NSStringFromClass(superClass) : @"nil"]);
                WCDumpMethodsForClass([controller class]);
            }

            for (UIViewController *child in controller.childViewControllers) {
                [queue addObject:child];
            }
            if (controller.presentedViewController) {
                [queue addObject:controller.presentedViewController];
            }
        }

        if (includeViewTree) {
            WCDiscoveryLog(@"---- 视图树（深度 5，最多 400 行）----");
            NSUInteger budget = 400;
            WCDumpViewTree(window, 0, 5, &budget);
            WCDiscoveryLog(@"---- 视图树结束 ----");
        }
    };

    if ([NSThread isMainThread]) {
        scan();
    } else {
        dispatch_async(dispatch_get_main_queue(), scan);
    }
}

static void WCDiscoveryDarwinCallback(CFNotificationCenterRef center,
                                      void *observer,
                                      CFNotificationName name,
                                      const void *object,
                                      CFDictionaryRef userInfo) {
    WCDiscoveryScan(YES);
}

void WCDiscoveryDumpNow(void) {
    WCDiscoveryScan(YES);
}

void WCDiscoveryRefresh(void) {
    void (^apply)(void) = ^{
        WCPrefs *prefs = [WCPrefs shared];
        BOOL shouldRun = prefs.enabled && prefs.discoveryEnabled;

        if (shouldRun && !gDiscoveryTimer) {
            gDiscoveryTimer = [NSTimer scheduledTimerWithTimeInterval:1.5
                                                              repeats:YES
                                                                block:^(NSTimer *timer) {
                WCDiscoveryScan(NO);
            }];
            WCDiscoveryScan(NO);
        } else if (!shouldRun && gDiscoveryTimer) {
            [gDiscoveryTimer invalidate];
            gDiscoveryTimer = nil;
        }
    };

    // 统一异步到主线程：%ctor 可能早于 UIApplicationMain 执行，
    // 这里不能同步访问 UIApplication。
    dispatch_async(dispatch_get_main_queue(), apply);
}

void WCDiscoveryStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gDiscoveryLog = os_log_create("com.wctheme.dev", "discovery");
        gSeenClasses = [NSMutableSet set];

        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                       NULL,
                                       WCDiscoveryDarwinCallback,
                                       (__bridge CFStringRef)WCThemeDumpHierarchyNotification,
                                       NULL,
                                       CFNotificationSuspensionBehaviorDeliverImmediately);

        WCDiscoveryRefresh();
    });
}
