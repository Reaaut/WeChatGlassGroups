# WCTheme — 微信主题 tweak（rootless / Dopamine）

> 目标设备：iPhone 14 Pro (arm64)，iOS 16.6.1，Dopamine **rootless**（`/var/jb`），
> 注入由 ellekit / MobileSubstrate 完成。
> 目标 App：微信 `com.tencent.xin`。
>
> 工程绝对路径：`C:\Users\86181\Documents\Trae-CN\temp_20261103_02\WCTheme`

## 0. 1.8.5（可选底栏样式：贴边整条 / 悬浮胶囊）

文章里那套底栏是「**贴边整条 + 顶角圆角 + 选中项气泡 + 图标下方文字**」，和悬浮胶囊是两种容器几何，不是纯参数差异，所以做成同构不同参数（同一份取图 / 点击链路，只在容器布局分支）。

| 项 | 值 |
| --- | --- |
| 设置项 | `wxgb.dockStyle`，`floating`（默认）/ `bar` |
| 系统设置 | 「底栏样式 Dock style」，多值选择（悬浮胶囊 Floating pill / 贴边整条 Edge bar） |
| 微信内面板 | 底栏分区第二行，同一个 `choiceString` 行，中英文标题 |
| floating | 宽=屏宽−24、x=12、y=安全区底−8、圆角=高/2、头像胶囊在条外右侧 |
| bar | 宽=屏宽、x=0、底边贴屏（高=60+安全区）、只圆上两角 10pt、头像并入条内右侧、图标下显示文字、选中项顶出一颗 44pt 玻璃气泡 |
| 重建 | 样式进入 `gBuiltSignature`，切换后旧浮岛 / 头像胶囊 / 气泡 / 搜索胶囊一起 `removeFromSuperview`，再重建；列表底部留白按新样式重算（floating=高+18+搜索，bar=高+安全区+10） |
| 日志 | `[dock] 样式=floating|bar 切换=1 高=60 宽=345 圆角=30 留白=88`（签名变化才打） |

## 0. 1.8.4（底栏去灰边 / 面板贴合内容 / 统一液态配方 / 头像功能菜单）

| 块 | 结论与做法 | 关键日志 |
| --- | --- | --- |
| 底栏外侧灰 | 灰不是原生栏也不是壁纸，是浮岛外那块独立 `WCDockShadowTag`（black 0.12 / radius 14 / offset 4）向外扩散；直接整块移除，只保留胶囊自身玻璃与 1px 高光边 | `[dock] 底 灰源=0 命中=无 浮岛bg=clear 容器bg=clear 原生栏 hidden=1 alpha=0.00` |
| 底栏玻璃归一 | 浮岛/头像胶囊也调 `WCApplyLiquidGlass`，但 dock 档不再叠 tint/sheen（胶囊已有 `updateGlassForRadius` 的 tint），避免把 1.8.3 已确认的观感打亮 | `[glass] 配方 使用=dock corner=30.0 blur=native tint=0.14 sheen=0 feather=0` |
| 面板尺寸 | 面板高度原来恒为 `bottom-top`（日志 568 vs 内容 161，余量 407），改成按内容 hug：`Σ组头 + Σ组间距 + 展开行高 + 上下 padding + 16`，展开/收起动画结束后 0.05s 重建一次 | `[group] 几何 面板=(12,95,370,188) 内边距=8.0 行高=56 头像=40.0 行距=12.0 左右=(12.0,12.0) 内容宽=346.0 改前=568→改后=188` |
| 面板灰面 | 组行不再用「模糊 1.0 + 白 0.05」叠两层，改走共用配方 panel 档（`ultraThin` 0.62 + tint 0.045 + 顶部 sheen + 1px 白边），行玻璃计数按真实 tag 统计 | `[group] 玻璃 面板 blur=1 tint=0.045 组行玻璃=3/3 不透明底=0 原生表 hidden=1 bg=clear` |
| 头像菜单 | 点头像弹自绘液态玻璃菜单（与分组面板同配方，锚在浮岛上沿、避开底栏），两列 9 项：个人信息 / 我的二维码 / 扫一扫 / 收付款 / 朋友圈 / 主题 / 壁纸 / 分组设置 / 关闭浮层；点空白或再点一次收起，弹出时分组面板让位 | `[dock] 头像 菜单 弹出=1 项数=9` |
| 功能真接通 | 每项三级降级：运行时探测类名 → 切 tab 按文字点入口 → URL scheme；全部 `@try/@catch`，失败只提示不计入熔断 | `[dock] 头像 动作=scan 方式=vc ok=1 cls=ScanQRCodeViewController` / `方式=入口点击` / `方式=scheme` / `... ok=0 失败原因=类不存在\|实例化失败\|无导航控制器\|入口没找到\|scheme未注册` |

## 0. 1.8.3（灰框开关 / 图标缩小 / 点击无蒙层 / 分享遮挡）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 灰框开关 | 新增 `groupHideFrame`（`wxgb.groupHideFrame`，默认开=隐藏面板级玻璃底 + 外层阴影，只留每条胶囊玻璃）；系统 Settings 与微信内面板均有「隐藏分组灰框」，切换即时广播 | `[group] 灰框 hidden=1 开关=1 命中=UIVisualEffectView(..)` |
| 背后灰框 | `WCOverlayContainerView` / 面板外层 / 外层 padding 区 bg + layer bg 全部 clear、`backgroundView=nil`；按 1.8.2 层级 dump 精准命中，不全局铺 | `[group] 背后 灰框=0 命中=.. 容器bg=clear` |
| 顶栏 | 恒透明（不随开关）；新增命中微信自绘装饰层：非 ContentView 且子树含 `UIVisualEffectView` 整棵 hidden + alpha 0 + effect nil | `[nav] bar 透明 cls=.. bgHidden=1 effect=1 装饰=n tint=clear shadow=nil active=1` |
| 底栏图标 | `WCDockIconScale=0.86`（28pt→24pt），只缩图标，胶囊/间距不变，仍 `AlwaysOriginal` + 屏幕 scale | `[dock] 图标尺寸=24pt 缩放=0.86 方案=.. 4/4` |
| 点击透明框 | 清 `backgroundColor` / `backgroundImage` / 选中蒙层，`adjustsImageWhenHighlighted=NO`、`showsTouchWhenHighlighted=NO`，重写 `setHighlighted:` 只做 0.94 scale | `[dock] 点击 反馈=scale 底色=clear 蒙层=0` |
| 分享遮挡 | 模态链 + `UIWindowDidBecomeVisible/Hidden` 双重判定（类名含 Share/Forward/Picker/ContactSelect…），面板 `hidden=YES` 且置底，搜索胶囊同步隐藏，收起后恢复 | `[group] 遮挡 隐藏=1 原因=模态 cls=..` / `隐藏=0 原因=恢复 cls=-` |

## 0. 1.8.2（先取证再改：底栏真取图 / 壁纸透出 / 顶栏真钩子 / 去灰杠）

| 块 | 结论与做法 | 关键日志 |
| --- | --- | --- |
| 日志取证 | `[dock] 图标段` 证明 bar 段全 100% 非透明（bbox 266×238 超 92% 守卫）；真实原因是原生底栏 8 个候选里 4 个空壳 `UITabBarButton`、4 个 `MMTabBarItemView`，按 x 取前 4 正好取到两个空壳 → 永远 2/4 | `[dock] 原生按钮 候选=8 有效=4` |
| 底栏图标 | 只保留子树里真带 `UIImage` 的 item view；取图链路 imgview → `UITabBarItem.image/selectedImage` → ivar → itemview 快照 → bundle PNG；官方图落盘 `WCTheme/icons/tabN.png`；4 项不齐整条回退，禁止半成品 | `[dock] 图标取图 i=.. 来源=imgview\|tabbaritem\|ivar\|snapshot\|bundle size=(w×h)`、`[dock] 图标方案=direct 4/4 尺寸=28 彩色=1` |
| 背景 | 面板 / 组行玻璃从 `SystemMaterial` 换成 `SystemUltraThinMaterial`（alpha 0.72/0.78、tint 0.06），壁纸从面板透出；`[bg] 挂载` 打印是否被上层不透明兄弟挡住 | `[bg] 挂载 cls=.. idx=0 父cls=.. 父bg=clear clips=1 上层不透明=0` |
| 顶栏 | `didShowViewController:` 是 delegate 回调，1.8.1 钩子实际不触发；改为 `pushViewController:animated:` / `popViewControllerAnimated:` / `setViewControllers:animated:` + 四页 `viewDidAppear:`；`UINavigationBarAppearance` 设 transparent；壁纸模式停用 surface 玻璃 tint；导航栏层级只在变化时 dump | `[nav] 钩子 装 cls=UINavigationController sel=pushViewController:animated: ok=1`、`[nav] 层级 cls=_UIBarBackground frame=(..) alpha=.. hidden=.. bg=..` |
| 灰杠 | 去掉胶囊 1pt 与行内 0.5pt 白色描边（底边就是那条灰线），远阴影从 0.10/14/8 收到 0.05/8/2；新增行高余量与细线视图扫描 | `[group] 行高 表=.. cell=56 内容=.. 余量=.. 分隔=0 footer=..`、`[group] 灰杠 扫描=n 命中=..` |
| 日志降频 | `未找到 MainFrameTableView` 进程内只报一次；`[nav] layoutSubviews` 0.35s 节流 + 层级签名去重 | 正常使用 5 分钟 < 40KB |

## 0. 1.8.1（图标逐段诊断 / 面板去白底 / 导航栏深透明 / 日志治理）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 底栏图标 | 等分裁切逐段打印非透明率与外接矩形；blank 段即时用 `MMTabBarItemView` 单独重拍回退；收尾打印 k/4 与失败明细；快照 key 去掉选中项，避免每轮重拍 | `[dock] 图标段 i=.. ... blank=0\|1 来源=bar\|itemview`、`[dock] 图标方案=bar-snapshot 4/4 尺寸=.. 彩色=1 失败=[..]` |
| 分组面板 | 面板 `visible=1` 且 frame 非零后才隐藏原生 `MainFrameTableView`；列表及 UIScrollView 背景 clear、`backgroundView=nil`、`separatorStyle=None`；不透明底计数必须为 0 | `[group] 玻璃 面板 blur=1 tint=0.12 组行玻璃=.. 不透明底=0 原生表 hidden=1 bg=clear` |
| 导航栏 | 新增 `UINavigationController didShowViewController:` 与 `UINavigationBar layoutSubviews` 异步重刷；`_UIBarBackground` 全子树 hidden + alpha 0 + effect nil；四页各一条 | `[nav] bar 透明 cls=ContactsViewController bgHidden=1 effect=1 tint=clear shadow=nil` |
| 日志治理 | 看门狗 ≥0.35s 且仅值变化时打印；挂载 / frame / 结构 / 显示原因全部按签名去重 | 正常使用 5 分钟 < 40KB |

## 0. 1.8.0（面板玻璃化 / 壁纸真全局 / 官方底栏图标 / 搜索三级兜底）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 分组面板玻璃 | 容器 `backgroundColor=clear` + `UIVisualEffectView`（`SystemMaterialLight/Dark`，alpha 0.90）+ 白/黑 tint 0.12，不再有任何不透明底；`wxgb.groupGap` 组间距保持不变 | `[group] 面板 玻璃=1` |
| 组行胶囊 | `WCGroupApplyGlass`：圆角 = 行高/2、`CAGradientLayer` 顶部 sheen、1px `white 0.25` 描边、near/far 双层阴影；展开会话行同一套玻璃，`separatorStyle=None` + `separatorInset=0` + `_separator/_edgeBottom` 全隐藏 | — |
| 壁纸全局 | `WCSurfaceGlass` 在壁纸存在时把 table / 根视图底色写 clear；`WCWallpaperApplyToController` 对 NewMainFrame / Contacts / FindFriendEntry / More 四类都 `insertSubview:atIndex:0` 挂壁纸并 `clipsToBounds`；导航栏 `_UIBarBackground` 及子视图 hidden、背景图/阴影 nil、barTint clear、translucent、navigationBar clear | `[bg] 壁纸 mode=.. cls=.. has=1 path=..` 四类各一条 |
| 底栏官方图标 | 整条 `UITabBar` 快照按 item 等分，每段取最大非透明外接矩形居中贴正方形画布（AlwaysOriginal / scale=屏幕）；空段回退 `MMTabBarItemView` 自带 icon view 快照，不再画绿圆/蓝圆 | `[dock] 图标方案=bar-snapshot N/4 尺寸=28 彩色=1 barW=.. barH=..` |
| 浮岛尺寸 | `x=12`、`height=60`、`width=305`、`cornerRadius=30`，四图标均分；头像独立 52pt 胶囊、间距 8、整体底部距安全区 8；列表底部留白 island=60 | `[dock] 结构=floating ... 高=60 宽=305 圆角=30` |
| 搜索键 | 一级 `showSearchBar:searchBar:autoStartGreenMic:`（传真实 `WCSearchBar`）→ 二级 `UITextField`/`UISearchBar` 控件事件 → 三级 `accessibilityActivate`/私有触摸；点击前先切回消息 tab | `[dock] 搜索 进入=1 方式=selector\|button\|simulated` / `[dock] 搜索 进入=0 原因=..` |

## 0. 1.7.9（平铺采集 + 折叠边界置顶 + 自持置顶集合）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 平铺 vs section | `WCGroupCollect` / `WCGroupProgressiveStep` 仍遍历所有 section，但分类不再依赖 section 编号：所有行摊平成一条线性序列（`section`/`row` 只用于点击的真实 indexPath），置顶按「折叠行之前的线性位置」判定 | `[group] 采集 sections=.. rows=.. cells=.. 候选=.. 桶[...]` |
| 置顶优先级 | 自持覆盖 `wxgb.pin/pinOverride` > 折叠边界（`个置顶聊天` / `个置顶` / class 含 Fold）> 逐行字段（`m_bIsTop` 等，全部为 true 视为字段失真退回边界） | `[group] 置顶 边界=.. 来源=fold\|field\|override 覆盖=..` |
| 长按改置顶 | `WCGroupFoldCell` 增加 0.55s 长按手势，翻转当前置顶状态并写入自持集合，异步重建面板 | `[group] 长按置顶 user=..` / `[group] 置顶覆盖 user=.. 置顶=1 来源=override` |
| 合成行 | 标题含「个置顶聊天」「个置顶」、class 含 `Fold`、`placeholder_foldgroup` 的行一律跳过，不当会话 | — |
| 点击映射 | 同一 `userName` 在一轮采集内固定映射到第一次采集到的真实 `indexPath`；新一轮采集（gen 变化）才更新 | `[group] 点击 row=.. section=..` |

## 0. 1.7.8（全 section 采集 + 累积合并 / 整条 bar 快照裁切 / 日志去噪）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 分组采集 | `WCGroupCollect` 从 `numberOfRowsInSection:0` 改为双重循环：`for s in 0..<numberOfSections` × `for r in 0..<numberOfRowsInSection(s)`，累计上限 600 行；每条记录真实 `section` / `row`，点击走 `WCGroupScrollToIndexPath` + delegate 的真实 indexPath；置顶只认折叠行所在 section，其它 section 一律按 `userName` 规则分类，不再用 top 字段跨 section 判断 | `[group] 首屏 sections=.. rows=.. cells=.. 候选=.. 耗时=..ms` / `[group] 采集 sections=.. rows=.. cells=.. 候选=.. 创建=.. 桶[...]` |
| 累积合并 | `gGroupKnownItems` 以 `userName` 为 key 常驻，每次采集只增不减；只有全量采集完成（未触 600 上限）才 `WCGroupKnownPrune` 删除已消失会话 | `[group] 合并 前=N 后=M` |
| 增量触发 | `updateMainSessionListNotify:` / `scrollViewDidScroll:` / `scrollViewDidEndDecelerating:` 三个 selector 挂钩，内部 0.5s 节流；只扫 `visibleCells` 做 upsert + publish，不整表重建 | `[group] 增量 触发=scroll\|scroll-end\|list-notify 前=.. 后=.. cells=.. 桶[...]` |
| 底栏图标 | 整条 `UITabBar` 一次 `UIGraphicsImageRenderer` + `renderInContext`（拍前临时透明化背景、alpha 拉回 1、藏起浮岛 / 阴影 / 搜索胶囊 / 头像胶囊）；按 `items.count` 四等分，每列取中心最大非透明外接矩形去上下留白，缩放到 28pt `AlwaysOriginal`；失败按 key 记忆，绝不按 item 重试，整条失败才退 SF Symbols | `[dock] 图标方案=bar-snapshot N/4 尺寸=28 彩色=1 barW=.. barH=..` / `[dock] 图标方案=symbol 失败原因=..` |
| 日志去噪 | `面板让位` 只在 `(菜单, hidden, home)` 变化时打，0.6s 轮询 `home=0` 不再重复；浮岛高度改用 `island.bounds`（跳过出现动效 transform），杜绝 64→60 假读数 | `[group] 面板让位 菜单=.. hidden=.. home=..` / `[dock] 结构=floating ... 高=60 宽=.. 圆角=30 图标=bar-snapshot` |

## 0. 1.7.7（分组只在首页 / 壁纸全局 + 顶栏 / 分类修正 / 官方图标快照 / 头像独立胶囊）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 面板只在首页 | `WCGroupSetPageVisible(BOOL, cls)`：`NewMainFrameViewController` 的 will/didAppear 置 YES；`ContactsViewController` / `FindFriendEntryViewController` / `MoreViewController` / `BaseMsgContentViewController` / `WCSearchViewController` / `TimeLineViewController` / 所有 `WCFTS*` push 页置 NO → `panel.hidden=YES`，并把原生列表 `table.hidden=NO`；回首页重建并恢复 | `[group] 页面 home=1\|0 cls=..` / `[group] 面板让位 菜单=.. hidden=.. home=..` |
| 壁纸全局 + 顶栏 | 壁纸 `UIImageView`（tag `0x57434247`）铺到四个主 VC 的 view 最底层；view / 列表 / cell 全部 clear，`table.backgroundView=nil`；`UITableViewCell didMoveToSuperview` swizzle 统一改 cell 背景（排除分组面板 tag `0x574C4750`）；「我」页白卡 `white 0.92` / 深色 `0.08`；`UINavigationBar` 背景图 / 阴影置空、`barTintColor=clear`、`translucent=YES`、`_UIBarBackground.hidden=YES`，标题改自定义 label（浅 `#111` / 深 `#F2F2F2` + 1px 半透明描边）；关闭壁纸恢复纯白 / 纯黑与原导航栏 | `[bg] 壁纸 mode=light\|dark cls=.. has=1 path=..` / `[bg] cell 背景 hook 已安装` |
| 分组分类 | 先找折叠行（标题「N个置顶聊天」或 class 含 `Fold`），该行之前才算置顶；无折叠行时只认 `m_bIsTop` / `m_bIsStickyOnTop` / `m_isTop` / `m_uiTopFlag` 任一为真，全 nil 视为非置顶；再按 `@chatroom` → 群聊、`gh_` → 公众号、`@biz` → 服务号、其它 → 好友；自定义关键词最后覆盖 | `[group] row i=.. user=.. top=.. sticky=.. flag=.. title=..` / `[group] 桶[pinned=.. friends=.. ...]` |
| 累积合并 | 同一 `userName` 只入一个桶；采集 upsert 进 `gGroupKnownItems`，重建不清空；只有全量采集完成（未触发行数上限）才裁剪已删除会话 | `[group] 合并 前=N 后=M` |
| 官方图标快照 | 微信 `item.image=nil`（`MMTabBarItemView` 自绘）：对每个 `MMTabBarItemView` / `UITabBarButton` 用 `UIGraphicsImageRenderer` + `[view.layer renderInContext:]` 拍整项，裁顶部 70% 高度、水平居中，`AlwaysOriginal` 彩色 28pt；拍前临时隐藏浮岛 / 阴影 / 搜索胶囊 / 头像胶囊；空白则 0.2s 后重拍一次，仍失败退 SF Symbols | `[dock] 图标方案=snapshot N/4 尺寸=28pt 彩色=AlwaysOriginal` / `[dock] 图标 idx=.. src=snapshot\|symbol 失败原因=..` |
| 头像独立胶囊 | 浮岛只放 4 tab：宽=屏宽−24−56−8、高 60、圆角 30、X=12；头像独立圆形胶囊直径 52、右侧 12、与浮岛同中心、玻璃同材质 + 2pt 白描边、点击 / 长按 0.55s 开菜单；搜索胶囊仍贴浮岛上方 8pt 且等宽 | `[dock] 浮岛 frame=(..) 头像胶囊 frame=(..)` |
| 面板不透明 | 面板容器底改 `white 0.96`（深色 `#111` 0.94），壁纸不再透上来冲淡内容 | `[group] 面板 frame=(..)` |

## 0. 1.7.6（异常回路修复 / 底栏回悬浮版 / 分组首屏提速 / 胶囊再瘦身）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 异常回路 | 根因：`WCDockNativeGlass` 里 tint 的 tag `9931` 与角标 `9930+i` 的 `9931` 撞车，`viewWithTag:` 返回 `UIView` 后 `.text` 打出 `-[UIView setText:]`；apply 被 layout 反复触发 → 2230 次/17ms。1.7.6 停用原生透明分支，tag 改 `9939`，角标取值加 `isKindOfClass:UILabel` 校验 | `[dock] exception stage=.. name=.. reason=.. stack=..` |
| 熔断 | 同一进程 apply 失败累计 ≥3 次 → `gDockDisabled=YES`，还原原生栏、移除自建层、停止重试；点击回调全部 `@try/@catch` | `[dock] 熔断：异常累计3次，已停用` |
| 底栏 | 回到悬浮胶囊：宽=屏宽−24、高 60、圆角 30、底部距手势条 10；图标 `AlwaysTemplate`（未选中 `#1A1A1A`/深色 `#EDEDED`，选中 `#07C160`）；`UIButtonTypeCustom`；浅色 `SystemMaterialLight` + 白 0.14、深色 `SystemMaterialDark` + 白 0.06；1px 白 0.35（深色 0.14）；阴影 `black 0.12 / r14 / (0,4)`；选中块 40×40 圆角 14；头像 44 + 2pt 白描边；搜索胶囊上方 8pt、等宽、高 44、圆角 22；二级页浮岛 hidden 并恢复原生栏 | `[dock] 结构=floating 悬浮 挂载=1 host=.. 高=.. 宽=..` |
| 搜索 | 只保留 selector → button → simulated 三级兜底，删除 present 裸 `WCSearchViewController`；每步打「尝试 / 结果」 | `[dock] 搜索 尝试=selector cls=.. 结果=..` / `搜索 进入=1 方式=..` |
| 分组首屏 | 首屏只扫 `visibleCells`（<30ms）立即出面板；其余每批 30 行 / 30ms 增量补齐；按 `userName` 缓存内容、`indexPath` 缓存 item，二次进入不造 cell；列表无数据时等 `updateMainSessionListNotify` 再建 | `[group] 首屏 cells=.. 候选=.. 耗时=..ms` / `[group] 补齐完成 rows=..` |
| 胶囊瘦身 | 高 44 / 圆角 22 / 内缩 12 / 组间 10；组名 18pt semibold、数量 14pt；行高 56 / 标题 16 / 摘要 13 / 时间 12；阴影 `black 0.05 / r6 / (0,2)`；描边 0.5pt 白 0.16；去掉内侧第二道高光；面板上下各 8、圆角 24 | `[group] 面板 frame=(...)` |
| 菜单让位 | `zPosition` 只在同一 superview 内比较，微信 + 菜单在更上层窗口 → 面板 / 浮岛 / 搜索胶囊统一换宿主到 `keyWindow` 最上层透明容器（tag `0x57434F48`，hitTest 空白穿透），面板 z=100、浮岛 300、胶囊 310、自建菜单 1000000；同时监听 `UIWindowDidBecomeVisible/Hidden/DidResignKey` + 0.6s 查 presented 链（类名含 Menu/Sheet/Action/Alert），命中即 `panel.hidden=YES`，消失恢复；关闭 / 熔断 / 模块停用按 tag 遍历窗口移除 | `[dock] 悬浮 挂载 host=..` / `[group] 面板 frame=(..) z=100 mount=..` / `[group] 面板让位 菜单=1 hidden=1` |

## 0. 1.7.5（全局壁纸 / 分组瘦身 / 菜单层级 / 中文组名 / 原生透明底栏 / 搜索三级兜底）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 全局壁纸 | `bg-light.png` / `bg-dark.png`（jpg 也接受，读入后统一转 PNG），四主 VC 的 view 最底层插 `UIImageView`（tag `0x57434247`，`scaleAspectFill` / `clipsToBounds` / `userInteractionEnabled=NO`）；页面与列表转 clear；`traitCollectionDidChange` 按 `userInterfaceStyle` 换图，未设置模式回落另一张；两张都没有则移除并恢复纯白 / 纯黑；有壁纸时玻璃 tint alpha 减 0.1 | `[bg] 壁纸 mode=light\|dark has=1 path=..` |
| 设置 | 新增「浅色壁纸 / 深色壁纸 / 清除壁纸」，`PHPickerViewController`（iOS 14+，老系统回落 `UIImagePickerController`），保存即 `WCWallpaperRefresh` | `[bg] 保存壁纸 mode=.. ok=.. bytes=..` |
| 分组瘦身 | 胶囊高 52 / 圆角 26 / 左右内缩 12（左边缘 24）/ 组间 12；组名 19pt semibold，数量 14pt `#8A8A8E`；展开行高 60、标题 16、摘要 13、时间 12；去掉外阴影，描边 0.5pt 白 0.18；面板标题 26pt semibold、分段条 15pt | `[group] 面板 frame=..` |
| 菜单层级 | 分组面板 `zPosition=800000`，加号菜单 `zPosition=1200000`，弹出后再 `dispatch_async` `bringSubviewToFront` | `[group] 菜单层级 menu=1200000 panel=800000` |
| 中文组名 | 输入框不再限定 ASCII（默认键盘 / 系统字体），保存 trim 首尾空白、组名按 UTF-16 限 12 字；`NSUserDefaults` 原样存 UTF-8 字符串，日志 `%@` 原样 | `[group] 组名保存 key=.. value=..` |
| 底栏 | 保留原生 `UITabBar` 不 hidden：`clear / translucent / 空 backgroundImage / 空 shadowImage` + `configureWithTransparentBackground`（standard + scrollEdge）；自建玻璃垫在原生栏下面（同 superview，`belowSubview:`），高 64、圆角 32，只画背景 / 选中块 / 角标，不画图标；图标由原生渲染；点 tab 后回读 `selectedItem` 同步选中块；二级页只隐藏自建层 | `[dock] 结构=native-transparent overlay=1 icons=native 选中同步=1` |
| 搜索 | 点搜索胶囊先切回「消息」模式；依次 selector `showSearchBar:searchBar:autoStartGreenMic:` → 原生 `WCSearchBar` 控件 → `UIAccessibility` 模拟点击；成功 / 失败都落日志 | `[dock] 搜索 进入=1 方式=selector\|button\|simulated` / `方式=none 原因=..` |

## 0. 1.7.4（底栏图标统一 / 面板去白卡 / 去灰杠 / 自定义标签位置）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 面板几何 | 不再用 table bounds：`x=12`、`w=屏宽−24`，顶边 `safeArea+8`（有标题时=标题底+16），底边=浮岛 top−8；容器 `clipsToBounds=YES`、四角 26，胶囊再内缩 12pt、容器上下各留 10pt；隐藏滚动条、`contentInset.bottom=16` | `[group] 面板 frame=(...) safe=.. table=(...)` |
| 全局底色 | 首页/通讯录/发现/我 `view.backgroundColor` 纯白 `#FFFFFF`（深色 `#000`），列表同色、`backgroundView=nil`；首页 `separatorStyle=None`，其余分隔线 `#EDEDED`；`traitCollectionDidChange` 即时刷新。`WCSurfaceGlass` 不再把首页/列表清成透明 | `[surface] 底色 首页 #FFF 表=..` |
| 标题 | 去掉玻璃卡：22pt semibold `#111`（深色 `#F2F2F2`）+ 13pt `#8A8A8E` 副标题；直接浮在白底、`x=24` 与胶囊对齐，标题底到第一组 16pt；关闭或文字显式清空时整块不占高度；原生 titleView 置空且保留导航栏高度 | `[title] 标题 text=.. frame=(...)` / `[title] 隐藏原生标题 labels=..` |
| 底栏图标 | `item-image` → `item-selected` → `UITabBarButton` 内 `UIImageView.image` → SF Symbols 单色（26pt、`#1A1A1A`/深色 `#F2F2F2`、选中 `.fill`）；仍拿不到才 `none`，绝不画灰点/色块；每个 button 层级只打一次 | `[dock] btn i cls=.. sub=..` / `[dock] 图标 idx=.. src=..` |
| 底栏比例 | 按参考包 44/20/6/12 等比放大：高 64 → 圆角=高/2=32，左右内边 12、图标间距 8、头像 46（右侧 12）、选中块 40×44 圆角 16 | `[dock] 浮岛 frame=(...)` |
| 交互 | 长按组头弹出「上移/下移/隐藏」，顺序存自有 suite `com.wctheme.dev.group`；设置里提供 6 个内置组隐藏开关；偏好落盘统一加 `wxgb.` 前缀（兼容读旧键，绝不用 `WCLG*`） | `[group] 排序 .. 顺序=..` |

## 0. 1.7.2（官方 cell 内容 + 液态外壳 / 置顶 / 标题卡 / 底栏图标与尺寸）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 分组内容 | 展开组的会话行不再自绘：按 indexPath 向原生 dataSource 取 `MainFrameCell`，透明底 `renderInContext` 成快照（头像/标题/摘要/时间/红点原样，群聊即官方九宫格头像），只外包一层液态玻璃。快照按「采集代次 + indexPath + 行宽」缓存，仅在可见行渲染 | `[group] 采集 rows=.. 候选=..` |
| 液态外壳 | 收起/展开统一一套：`SystemMaterialDark/Light` 模糊 + tint；三线收口——外白 0.26 / 内高光白 0.12 / 底暗边黑 0.12；阴影 black 0.18 / radius 16 / offset(0,6)。组名 17pt 中粗、数量 13pt 灰。组间上下间距 `groupSpacingV`（6–24，默认 12），点「显示效果」立即重建 | `[group] 折叠切换` |
| 置顶 | 三路判定任一成立：`m_bIsTop`/`m_bIsStickyOnTop`/`m_uiTopFlag` 等字段；或 cell 在「N个置顶聊天」折叠行之前。始终排第一；为空也打原因 | `[group] 置顶 折叠=.. 布尔=.. 位置=.. 桶[pinned=..]` |
| 标题卡 | 隐藏原生「微信(6)」（titleView 置空 + 顶部 label alpha 0，不动 `hidesBackButton`），在标题位置放液态玻璃卡：左对齐 34pt 粗体 + 可选 13pt 副标题（圆角 18、左右 12pt、高 64） | `[title] 隐藏原生标题 labels=..` / `[title] 卡片=1 text=..` |
| 搜索 | 删除分组面板内部搜索条；只保留浮岛上方一条，宽度严格 = 浮岛宽、左右对齐、高 44 / 圆角 22。点击依次走官方 `showSearchBar:searchBar:autoStartGreenMic:` → present `WCSearchViewController` → 模拟点击 `WCSearchBar` | `[dock] 搜索 官方入口=..` |
| 底栏图标 | 去掉灰色圆点/快照色块兜底。链路：`item-image` → `item-selected` → 直接把原生 `UITabBarButton` 的 `UIImageView` 搬进格子（`tabbutton-imageview`）→ `none`（不画 + error）。按钮改 `UIButtonTypeCustom`、`AlwaysOriginal`、清 tint | `[dock] item i image=.. mode=.. size=..` / `[dock] 图标 idx=.. src=..` |
| 底栏尺寸 | 默认宽 = 宿主宽 − 20、高 64、图标 28pt、头像 46pt、格宽均分、圆角 = 高/2，仍可在设置里调 | `[dock] 浮岛 frame=(...)` |

## 0. 1.6.3（QQ 折叠分组 / 浮岛串页 / 聊天页黑屏）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 分组 | 推翻横向 chip：改成不透明竖向折叠面板（`UITableView` 覆盖列表区域，从搜索栏 maxY + 8 到浮岛上方 10pt）。section header = 组行（`›` / `▾` + 组名 + 数量），点击 `reloadSections:UITableViewRowAnimationFade`；展开后显示会话行（头像 + 标题 + 摘要 + 时间），点击 `WCGroupScrollToIndexPath` 滚到原列表对应 cell。顶部「收起全部 / 展开全部 / ×」，关闭后保留「分组 ›」入口。空组不生成 section | `[group] 折叠面板 组=N 行=N frame=(...) super=(...)` |
| 浮岛串页 | 判定改为「是否属于主 TabBar 的子控制器」：`viewWillAppear` 沿父链找到 `UITabBarController` → 显示；只有 push 出来的聊天页/搜索页隐藏。通讯录/发现/我 一直显示，选中态跟随 `tabBar.selectedItem`。隐藏时只 `hidden=YES`，不还原原生底栏（避免闪白） | `[dock] 显示 原因=tab-child cls=...` / `[dock] 隐藏 原因=push cls=...` |
| 聊天页 | `WCSurfaceGlassHandleController` 命中 `BaseMsgContentViewController` 时**整段 early return**：只做导航栏透明，不做页面背景模糊、不做卡片、不遍历视图树；`WCSurfaceRefreshTree` 遇到 Chat 列表直接 return；偏好刷新 0.35s 去抖 | `[perf] enter chat ms=...`（>100ms 打 warn） |
| 稳定性 | 继续保留：先确认浮岛可见再隐藏原生栏、0.2s 看门狗回滚、默认关闭、外部 `disable` 文件 | — |

## 0. 1.7.1（液态胶囊分组 / 底栏头像与图标 / 聊天页浮岛）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 液态胶囊分组 | 按参考图重做：每组一行半圆胶囊（高 52 / 圆角 26，左右 8pt、组间 12pt）；收起 `›`、展开 `∨`。展开后 header 变「上圆角 + 下直角」，与组内行连成一整块连续玻璃、底部圆角 26 收口，不再每行单独卡片。行高 64，40pt 圆形头像（群聊九宫格合成头像），标题 15pt / 摘要 13pt 白 0.55 / 时间 12pt 白 0.4，分隔线 0.5pt 白 0.08 从头像右侧开始 | `[group] 折叠切换 组=.. 展开=1` |
| 材质与动画 | 收起 header：`SystemMaterialDark/Light` 模糊 + 深 tint 0.55 + 1px 白 0.22 描边（顶部 0.32）；展开容器整圈白 0.26 + 顶部内高光 0.18；三线错开 0.5px（外层描边 / 内侧白 0.12 高光 / 底部黑 0.12 暗边）。按压 scale 0.98 + tint 0.06、抬起 0.18s easeOut；展开 0.28s `UIViewAnimationOptionCurveEaseInOut` + `reloadSections:Fade`；行内 alpha 0→1 + translateY(-6)→0，逐行 0.04s stagger（最多 6 行） | — |
| 面板 | 底色跟随深浅模式（深 `#111` 0.96 / 浅白 0.97），圆角 20 continuous + 外阴影；顶部「Hey .」40pt 粗 + 可配置副标题（默认空），不做卡片；底部搜索胶囊宽=面板−16、高 44、圆角 22，点击聚焦原生搜索 | `[group] 搜索：命中原生搜索栏 field=1` |
| 采集修复 | 1.7.1 根因：离屏 cell 从 dataSource 新建后 bounds=0，label 全空 → 400 行只认出 9 条。改为先给真实布局尺寸、`layoutIfNeeded` 再读标题/摘要/头像。无 `userName` 的会话打 `[group] 无 userName 标题=..` 并归「其他」，不再静默丢；标题缺失用 userName 兜底 | `[group] 采集 cells=.. 候选=.. 头像缺失=..` / `[group] 头像 row=.. 命中=1|0` |
| 自定义组名 | 用户输入原样显示（`sgi/sgushs/zhsisb` 属于用户自拟名，不是乱码）；只有名字为空的自定义组才整组隐藏 | `[group] 组名 ident=.. name=.. src=custom|default` |
| 底栏头像 | 根因：头像按钮是 `UIButtonTypeSystem`，不透明头像被当 template 整块染成系统蓝 → 纯蓝圆。改为 `UIButtonTypeCustom` + `AlwaysOriginal`；来源 custom 文件 →「我」页原生头像（先 layoutIfNeeded，BFS 放宽到顶部大图/按钮图，0.35s 补采一次）→ 灰色剪影 | `[dock] 头像 src=custom|account|none` |
| 底栏图标 | 根因：`UITabBarItem.image` 在该时机为 nil（日志 `原生图为 nil`）。改为 item.image → selectedImage → 原生 `UITabBarButton` 子视图 UIImageView / 整体快照（26pt aspect-fit）→ 极简灰色圆点，绝不空槽 | `[dock] 图标 idx=0 src=item|selected|snapshot|fallback size=..` |
| 聊天页浮岛 | 双重判定：A 类名命中 `BaseMsgContent` / `TimeLine` / `WCSearch` / `FTS`；B `top.navigationController.viewControllers.count > 1`；任一成立即隐藏。并在 viewDidAppear + 0.15s + 0.6s 各复核一次；隐藏时遍历所有窗口把残留浮岛副本一起隐藏 | `[dock] 判定 top=.. 白名单=0 隐藏（0.15s/0.60s）` |

## 0. 1.7.0（分组真实化 / 二级页浮岛 / 底栏正确性）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 分组分类 | 9 个桶（`pinned/friends/groups/service/official/other/custom1..3`）。分类顺序：自定义关键词 → 置顶（只认 `m_bTop` / `m_bIsTop` / `m_bIsStickyOnTop` 等布尔字段）→ `@chatroom`=群聊 → `gh_`=公众号 → `@biz`/系统号名单=服务号 → 其余单聊=好友；`userName` 取不到才用标题启发式。空组不显示 section | `[group] 采集 rows=.. 候选=.. 桶[pinned=10 friends=..]` |
| 全量采集 | 1.7.0 根因：`visibleCells` 只覆盖首屏（首屏恰好全是置顶），改为按 `numberOfSections` / `numberOfRowsInSection` 逐行向 dataSource 申请 cell（只读），上限 400 行 | `[group] 接管列表 ... 桶[置顶=10 好友=..]` |
| 真实头像 | 从原生 cell 里 BFS 找类名含 `HeadImage` / `Avatar` 的 `UIImageView`，`UIGraphicsImageRenderer` 圆形裁剪 40×40，按会话 key 存 `NSCache`（200 条）；取不到用灰色首字（不再用高饱和蓝） | — |
| 点击进聊天 | 不再 `scrollToRow`：调用原生 table 的 `delegate` `tableView:didSelectRowAtIndexPath:`，让微信自己 push 会话；delegate 缺失才回退滚动 | `[group] 点击 row=.. section=.. -> delegate=类名` |
| 自定义组名 | 6 个内置组 + 3 个自定义组均可改名（`groupNamePinned`… / `customGroup1Name|Keyword`…），空值回落默认名；自定义组按标题/摘要关键词匹配，优先于内置分类 | — |
| 液态 header | section header 用 `SystemMaterialLight` 模糊 + 白 tint 0.12 + 45° 渐变描边（展开态 0.80/0.26）+ 顶部 1pt 内高光（展开态 0.45）；面板底色仍为白 0.98 不透明 | — |
| 二级页浮岛 | 唯一白名单：顶层 VC 必须是主 `UITabBarController` 选中页的**直接子控制器**且未 push 二级页。朋友圈（`TimeLine`/`SNS`/`Moments`）、扫一扫、看一看、搜一搜、视频号、小程序、聊天、搜索全部隐藏并恢复原生底栏；0.15s 二次复核 | `[dock] 判定 top=.. 白名单=0 隐藏` |
| 底栏正确性 | 外观/尺寸/液态参数**未改动**。图标只取原生 `image`/`selectedImage`（`AlwaysOriginal`、26pt 等比 aspect-fit、选中只加背景不染色、`selectedImage=nil` 沿用 `image`、不回退 SF Symbols）；`MainFrameTableView` 底部 `contentInset = 浮岛 + 搜索条 + 24`；右侧头像优先自定义文件 →「我」页原生头像 snapshot → 灰色剪影 | `[dock] 图标 idx=0 src=native size=..` / `[dock] 列表底部留白 bottom=..` |
| 参考 | WCGlass 4.1.6 逆向证据（数据源方案 vs 叠加层取舍、可复用键名与 selector）见 `docs/reference-group.md` | — |

## 0. 1.6.4（分组接管列表 / 聊天页浮岛 / 底栏图标）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 分组接管 | 分组开启时原生 `MainFrameTableView` 直接 `hidden=YES`（不是 alpha 0），`WCGroupFoldView` 与它**同 x/y/w/h**，背景白 0.98 不透明；`list.contentInset.bottom = 浮岛高度 + 24`。顶部新增「分组 / 消息」分段胶囊（两种模式都保留），取代 1.6.3 的小胶囊入口；取消分组时 `table.hidden=NO` | `[group] 接管列表 table.hidden=1 mode=分组 组=N 行=N frame=(...)` |
| 聊天页浮岛 | 新增 `WCDockTopmostViewController()`：从 `keyWindow.rootViewController` 沿 presented → nav.top → tab.selected 走到最顶层；类名含 `BaseMsgContent` / `WCSearch` / `FTSHome` / `FTSBase` 一律隐藏并恢复原生底栏 `alpha=1`。`WCDockHandleHome` 先做该判定（修复聊天页期间首页 appear 回调把浮岛拉回来），并 `dispatch_after 0.15s` 单次兜底重判 | `[dock] 判定 top=... 隐藏/显示` / `[dock] 首页回调被忽略 top=...` |
| 底栏图标 | 优先读 `UITabBarItem.image` / `selectedImage`（template 才 tint，其余 `AlwaysOriginal`），取不到才回退 SF Symbols；默认全宽（宿主宽 − 28）、高 58、图标 26pt、四格等分、左右 8pt；头像 42pt，右侧 12pt；选中态 40×40 圆角 14 液态胶囊 | `[dock] 浮岛 frame=...` |
| 搜索胶囊 | 严格 `searchY = dockFrame.minY - 8 - 38`，仅 `dockSearchPlacement=above` 时显示 | — |
| 稳定性 | 先确认浮岛可见再隐藏原生栏、0.2s 看门狗回滚、默认关闭、外部 `disable` 文件 | — |

### 设计规范（后续新增界面统一沿用）

用户已确认当前视觉语言，新增的任何面板 / 卡片 / 浮层都必须沿用下列约束，不要回退成纯白板或纯色块：

1. **玻璃材质分层**：底层 `UIVisualEffectView` 模糊 + 白色 tint（0.06–0.20），上层折射渐变（白 .18 → .02 → .10，45°）+ 径向高光（白 .22，中心偏左上），边缘用 2px 渐变描边（上白 .55 / 下白 .12）+ 内侧 0.5px 白 .35 亮线，外层投影 `black .18 / radius 18 / offset (0,8)`。
2. **圆角**：统一 `cornerCurve = kCACornerCurveContinuous`；浮岛圆角 = 高度一半（27pt），面板 / 卡片 12–16，胶囊 高度一半。
3. **卡片间距与内边距**：卡片之间 12，卡片内边距 16；列表行高 56。
4. **字号**：主标题 15（`UIFontWeightMedium/Semibold`），副标题 / 说明 13，辅助信息 12；颜色用同一套强调色（默认 `#1E70E6`）与系统 `labelColor / secondaryLabelColor`。
5. **可读性**：承载正文内容的面板必须**不透明**（白 0.98 或 `systemGroupedBackground`），只有纯装饰层才允许半透明。

## 0. 1.6.2（浮岛外观 / 位置 / 头像 / 分组）

| 块 | 做法 | 关键日志 |
| --- | --- | --- |
| 浮岛外观 | 无文字、SF Symbols 线性图标（`message.fill` / `person.2` / `safari` / `person`，23pt regular，深灰 #333，选中主题色）；宽度 = `padding 10 ×2 + 46×4 + 间距 6 + 头像 40`，默认居中；选中态 34×34 圆角 12 液态小胶囊 | `[dock] 浮岛 frame=... visible=1` |
| 液态玻璃（iOS 16 模拟） | 超薄 light 材质 + tint 0.06–0.20；`CAGradientLayer` 45° 折射（白 .18→.02→.10）+ 径向高光（白 .22）；`CAShapeLayer` mask 出 2px 上白 .55 / 下白 .12 渐变描边 + 内侧 0.5px 白 .35 亮线；外层兄弟视图投影 `radius 18 / opacity .18 / offset (0,8)`；强度 0 → 全部隐藏回普通磨砂 | `[dock] glass=simulated ultraThin tint=...` / `glass=native` |
| 动效 | 选中切换 0.22s easeOut 淡入淡出玻璃块；首次挂载 0.3s `scale 0.94 + alpha 0` 淡入 | `[dock] 出现动效 0.3s` |
| 位置 | `dockOffsetX/dockOffsetY`（0–80）、`dockWidthMode` + `dockFixedWidth`（240–420）、`dockHeight`（48–68）；长按 0.6s 拖动，松手吸附左右安全边并写回两个 offset | `[dock] 拖动保存 offsetX=... offsetY=...` |
| 搜索胶囊 | 默认关闭；`dockSearchPlacement = above / insideLeft / none`。above 是独立胶囊（宽 = 浮岛 65%，高 38，圆角半高，靠右浮在浮岛上方 8pt），不参与浮岛 frame | `[dock] 搜索胶囊 frame=(...)` |
| 自定义头像 | 相册选图 → 圆形裁剪 256×256 PNG → `/var/jb/var/mobile/Library/WCTheme/avatar.png`；浮岛与菜单 header 共用；默认中性灰圆占位；可恢复默认 | `[settings] 保存头像 ok=1` |
| 仅首页 | `viewWillAppear` 判断首页/聊天页/搜索页/通讯录/发现/我；非首页把浮岛 `hidden=YES`（不移除）并还原原生底栏 `alpha=1` | `[dock] 非首页隐藏 cls=...` |
| 分组修复 | 见下方「分组」专段 | `[group] 采集 cells=... 候选=...` / `[group] 胶囊面板 ...` |

### 分组：日志原文 → 根因 → 改动 → 结果

- **原文**（`wctheme(9).log`）：1.6.0 与 1.6.1 两次启动都只有
  `[boot ] modules glass=1 dock=1 group=1 badge=0 layout=1` 和 `stage=group ms=0.1`，
  而 `[group]` 一行都没有（仅 20:02 以前旧版本留下 `[group] 面板 收起 height=30 组=5`）；
  另有一条旧日志 `[group] cellData=MainFrameCellData ivars=m_sessionInfo,m_cpKeyForNickname...`。
- **根因**：① `MainFrameCellData` 的 ivars 没有昵称字段，标题只能靠 label 兜底；
  而 `WCGroupTitleFromCell` 只在「子视图数 ≤ 8」时才入队，微信首页 cell 的
  contentView 子视图远超 8 个 → 一个 label 都遍历不到 → 每个 cell 都被跳过；
  ② `WCGroupCollect` 把「5 个空桶」也当成有效结果缓存（`gGroupCacheValid=YES`），
  空签名下 `total==0` 静默返回，重试 3 次后彻底放弃 → 全程无日志。
- **改动**：去掉子视图数限制（预算 80，字号 ≥ 11 取最大者）；同时从
  `m_sessionInfo` 取昵称/用户名；只有「列表在 window 内 **且至少采到 1 个会话**」
  才写缓存；面板 y 改为「搜索栏 `convertRect:toView:` 的 maxY + 8 +
  `groupOffset`(=0)」；`zPosition=900000` + `bringSubviewToFront`；
  每次采集/可见变化都打日志。
- **可观察结果**：日志出现 `[group] 采集 cells=N 候选≥1 ...` 与
  `[group] 胶囊面板 组=... chips=... frame=(x,y,w,h) super=(w,h)`，首页搜索栏正下方
  出现胶囊标签，点开见会话行，点会话滚动到对应 cell。

## 0. 1.6.1 修两处（底栏可见性 + 搜索框通透）

- **底栏空白根因**：`WCDockBuildIsland` 把 tab 按钮/搜索/头像直接 `addSubview` 到
  `UIVisualEffectView`，UIKit 抛 `has been added as a subview to <UIVisualEffectView>`；
  异常被 `@catch` 吞掉时原生底栏已经 `alpha=0`，浮岛 frame 仍是 0 → 底部整条空白。
  修法：子视图加到 `island.contentView`；宿主从 `bar.superview`（只有 49pt 高）改成
  tabBar 所属控制器视图；**先确认浮岛可见（80% 面积在窗内）才隐藏原生底栏**
  （`alpha=0.02`），0.2s 看门狗不通过就恢复 `alpha=1` 并打 `回滚：浮岛未就位`。
- **搜索框白底**：白底来自 `_UISearchBarBackground` / `barTintColor`，1.6.0 只给整条
  bar 加 `cornerRadius=h/2`，结果就是一条白色大胶囊（日志 `h=52.0 radius=26.0`）。
  1.6.1 改成 `barTintColor=clear` + `backgroundImage=空` + `_UISearchBarBackground` 隐藏
  + `searchTextField` 半透明白（白 0.55）+ 输入框自身圆角，**高度/宽度/位置全不动**。
- 日志确认：`[dock] 浮岛 frame=(x,y,w,h) super=(w,h) visible=1` →
  `[dock] 原生底栏 alpha=0.02（浮岛已就位）` → `[dock] 看门狗 OK`。

## 0. 1.6.0 变更（四块同版本）

1.6.0 一次交付四块，仍然是**所有模块默认关闭** + 外部 `disable` 文件可用：

| 块 | 做法 | 默认 |
| --- | --- | --- |
| 顶部标题 | 删除全部自建标题；导航栏只做透明 + 模糊，标题交给微信原生 | 随「玻璃」模块 |
| 搜索框 | 只改 `cornerRadius`（原生高度一半）+ 可选薄模糊，不改高度/y/宽度/内边距 | 随「玻璃」模块 |
| 底栏浮岛 | 原生 `UITabBar` 视觉隐藏（`alpha=0`，保留对象与 delegate），宿父视图上挂悬浮胶囊（4 图标 + 圆形头像）；点击走 `setSelectedIndex:` + `tabBar:didSelectItem:`；角标从 `UITabBarItem.badgeValue` 复制到胶囊右上角 | `moduleDock` + `dockEnabled` |
| 头像菜单 | 点头像向上展开卡片：头像/昵称/日期/wxid（点 wxid 复制）+ 3×4 网格 12 项，长按拖动排序、点击震动并转发原生入口 | 跟浮岛 |
| 首页分组 | 横向胶囊标签贴在搜索栏下方，点击展开卡片，卡片点一条 `scrollToRowAtIndexPath:` | `moduleGroup` + `groupEnabled` |
| 设置面板 | 浅灰底 + 白色圆角 16 卡片；每组顶部效果预览；底部固定「显示效果（立即应用）」 | 常驻 |

> 1.6.0 修掉了「分组开了没效果」的缓存 bug：`viewWillAppear` 时列表还没进 window，
> 旧代码把空结果标记为有效缓存，之后签名恒为空、面板永不创建。现在只有
> 「table 在 window 且分组数完整」才缓存，否则 0.25s 后重试，最多 3 次。

## 0.1 1.5.1 卡死自救（3 步）

1.5.1 默认不加载任何模块（玻璃 / 底栏 / 分组 / 角标 / 布局全部关闭），只有 core + 日志。
如果仍然卡，或者打开某个模块后卡死，按下面 3 步恢复：

1. **用电脑在手机上下发 disable 文件**（rootless 路径）：

   ```bash
   # SSH / Filza / NewTerm 任选其一
   touch /var/jb/var/mobile/Library/WCTheme/disable
   ```

   （老式 rootful 设备改路径为 `/var/mobile/Library/WCTheme/disable`。）
2. **强制退出微信**（上滑杀掉进程），再打开。`disable` 存在时 tweak 在 `%ctor`
   第一行直接 return：不注册 hook、不初始化、不写日志，等同没装 tweak。
3. 想恢复功能时，**删掉 disable 文件**，然后到 设置 → WCTheme → 「模块开关」
   里**一次只打开一个模块**，重启微信验证；确认不卡再开下一个。

> 注意：`disable` 只停用不卸载。已经完全救不回来时，用 Sileo / Filza 卸载包即可。
> 日志仍在 `/var/jb/var/mobile/Library/WCTheme/wctheme.log`，卡死时日志最后一行能指出
> 卡在哪个 stage（例如 `stage=dock ms=...`）。

## 0.2 当前状态（先看这里）

| 项目 | 状态 |
| --- | --- |
| 当前版本 | **1.8.5**（`layout/DEBIAN/control` / `Resources/Info.plist` / `Tweak.x` 启动日志一致） |
| 构建验证 | GitHub Actions `make clean package FINALPACKAGE=1`，run `41798298473` success，artifact `wctheme-deb` |
| 目标设备 | iPhone 14 Pro（arm64），iOS 16.6.1，Dopamine **rootless**（`/var/jb`） |
| 注入方式 | ellekit / MobileSubstrate，仅注入 `com.tencent.xin` |
| 已跑通 | 底栏浮岛（两套样式）、官方图标取图 4/4、分组折叠面板、头像功能菜单（含扫一扫 / 收付款三级降级）、全局壁纸、顶栏透明、未读角标 |
| 未完成 | 真机观感微调（面板 tint / bar 样式气泡位置）；扫描类接口在不同微信版本上可能落到「入口点击」或 scheme |

## 1. 这个插件是干什么的

WCTheme 是一个 **rootless 越狱环境的微信（`com.tencent.xin`）外观增强 tweak**，全部逻辑在本地，无网络请求：

- **底栏**：把原生 `UITabBar` 视觉隐藏，换成自绘液态玻璃浮岛，可切换两种样式（悬浮胶囊 `floating` / 贴边整条 `bar`）；图标直接取微信自己的原生图，不画替代图标。
- **分组**：把首页会话列表做成 QQ 式竖向折叠胶囊面板（置顶 / 好友 / 群聊 / 服务号 / 公众号 / 其他），可自定义组名、关键词、隐藏组、改置顶。
- **头像菜单**：点右下角头像胶囊弹出 9 项功能菜单（个人信息 / 我的二维码 / 扫一扫 / 收付款 / 朋友圈 / 主题设置 / 壁纸设置 / 分组设置 / 关闭浮层），每项都有「运行时类名 → 页面入口点击 → URL scheme」三级降级。
- **外观**：全局壁纸（浅色 / 深色两套）、导航栏透明、液态卡片、搜索胶囊、未读角标改色。
- **可选模块**：毛玻璃、去广告（hook 注册表，默认空表）、布局微调、运行时类名发现。默认只开 core，模块需要手动逐个打开。

## 2. 依赖

| 依赖 | 说明 |
| --- | --- |
| Theos | 构建系统；`TARGET = iphone:clang:latest:15.0`，`ARCHS = arm64` |
| rootless 布局 | `THEOS_PACKAGE_SCHEME = rootless`，产物 `iphoneos-arm64`，装到 `/var/jb` |
| ellekit（或 mobilesubstrate） | 运行时注入；`control` 里写 `ellekit \| mobilesubstrate` |
| PreferenceLoader | 系统「设置」里的偏好入口 |
| iOS SDK 15.0+ | CI 用 `theos/sdks` 全量；本地建议 16.5 |
| 运行环境 | iOS 15.0+ arm64；已在 iOS 16.6.1 验证 |

`Makefile` 里 `WCTheme_WEAK_LIBRARIES = substrate` 是**故意弱链接**：ellekit 若没在 `/var/jb/Library/Frameworks` 提供 CydiaSubstrate，dyld 不会因为一条缺失的强依赖拒绝加载整个 dylib。

## 3. 目录结构

```
WCTheme/
├── Makefile                              # tweak(WCTheme) + 偏好 bundle(WCThemePrefs) 两个 target
├── WCTheme.plist                         # Theos 注入过滤器：Bundles=com.tencent.xin / Executables=WeChat
├── Tweak.x                               # %ctor：读偏好、启动各模块、注册 prefsChanged 通知
├── Glass.x                               # Logos 钩子：UIView setBackgroundColor: / UIWindow
├── SurfaceGlass.x                        # Logos 钩子：UITableViewCell / UINavigationBar / UITabBar / VC
├── SettingsEntry.x                       # Logos 钩子：UIViewController viewDidAppear（微信内入口）
├── src/
│   ├── WCPrefs.h / .mm                   # 偏好 key 常量、默认值、CFPreferences + plist 兜底、写后广播
│   ├── WCLog.h / .mm                     # WCLogLine(level, tag, fmt...) 统一日志（带降频签名）
│   ├── WCGlass.h / .mm                   # 页面级毛玻璃（窗口底图 + 背景替换）
│   ├── WCSurfaceGlass.h / .mm            # 表面级玻璃 + **WCApplyLiquidGlass 共用液态配方**
│   ├── WCLayout.h / .mm                  # 布局微调（cell 圆角/内缩、状态栏）
│   ├── WCAnchors.h / .mm                 # 微信宿主类运行时探测 + 锚点 hook 安装
│   ├── WCWallpaper.h / .mm               # 全局壁纸 + 导航栏透明 + 装饰层清理
│   ├── WCGroup.h / .mm                   # 首页分组折叠面板（采集 / 分类 / 展开 / 让位）
│   ├── WCDock.h / .mm                    # 底栏浮岛、两套样式、图标取图、头像菜单与动作降级
│   ├── WCBadge.h / .mm                   # 未读角标改色
│   ├── WCAdBlock.h / .mm                 # 去广告 hook 注册表（默认空表，全部运行时校验）
│   ├── WCDiscovery.h / .mm               # 运行时类名 / 方法 / 视图树抓取
│   └── WCSettingsEntry.h / .mm           # 微信内设置面板（齿轮入口 + 分区跳转）
├── prefs/
│   └── RootListController.mm             # 系统「设置」面板控制器（读写偏好 + 按钮）
├── Resources/
│   ├── Info.plist                        # 偏好 bundle 描述（CFBundleIdentifier=com.wctheme.dev）
│   └── RootListController.plist          # 系统设置面板 specifiers
├── layout/
│   ├── DEBIAN/control                    # 版本 / 架构 / 依赖
│   ├── DEBIAN/postinst                   # 安装后处理（权限 / 签名）
│   └── Library/PreferenceLoader/Preferences/WCTheme.plist   # 设置入口指向 WCThemePrefs
├── docs/
│   ├── CHANGELOG.md                      # 版本变更（由 git log 整理）
│   ├── reference-group.md                # 分组模块参考笔记
│   └── reference-map.md                  # 模块 / 文件映射参考
└── .github/workflows/build.yml           # CI：Theos + make clean package + artifact / tag Release
```

> 注意两个同名 `WCTheme.plist` 不是重复：根目录那个是 **Theos 注入过滤器**（tweak.mk 必需），`layout/Library/PreferenceLoader/...` 那个是 **设置入口**（装进设备用）。

## 4. 本地编译

Windows 原生不能跑 Theos，用 WSL2（Ubuntu 22.04）或 Linux：

```bash
sudo apt update
sudo apt install -y make git curl xz-utils zip unzip fakeroot rsync \
  libxml2 libplist-utils libtinfo6 lld clang

export THEOS="$HOME/theos"
git clone --recursive https://github.com/theos/theos.git "$THEOS"

# Linux 工具链（提供 clang / ldid）
wget https://github.com/kabiroberai/swift-toolchain-linux/releases/download/v2.3.0/swift-5.8-ubuntu22.04.tar.xz
tar -xf swift-5.8-ubuntu22.04.tar.xz -C "$THEOS/toolchain"

# iOS SDK
git clone https://github.com/theos/sdks.git "$THEOS/sdks"

cd /mnt/c/Users/86181/Documents/Trae-CN/temp_20261103_02/WCTheme
make clean package FINALPACKAGE=1
ls -lh packages/    # com.wctheme.dev_1.8.5_iphoneos-arm64.deb
```

两个老坑（都已在仓库里规避，改动时别踩回去）：

- **所有源文件 / plist / control 必须是 UTF-8 无 BOM**，带 BOM 会让 libplist 解析失败、`ldid` 打包失败。
- **ObjC++ 里装箱要用 `NSNumber`**（`@(x)`），`const void *` 与 `IMP` 互转要显式强转。

## 5. GitHub Actions 出包

推 `main` 即触发 `.github/workflows/build.yml`：`make clean package FINALPACKAGE=1` → 上传 artifact `wctheme-deb`（内含 `packages/*.deb`）。打 `v*` tag 时额外创建 Release 并附上 deb。

```bash
git add -A
git commit -m "1.8.x: ..."
git push origin main
# 取 artifact：
# GET /repos/Reaaut/WCTheme/actions/runs/<run_id>/artifacts → wctheme-deb → zip 解压
```

## 6. 装到哪

| 内容 | 路径（rootless） |
| --- | --- |
| tweak 动态库 | `/var/jb/Library/MobileSubstrate/DynamicLibraries/WCTheme.dylib` |
| 注入过滤器 | `/var/jb/Library/MobileSubstrate/DynamicLibraries/WCTheme.plist` |
| 偏好面板 | `/var/jb/Library/PreferenceBundles/WCThemePrefs.bundle` |
| 设置入口 | `/var/jb/Library/PreferenceLoader/Preferences/WCTheme.plist` |
| 运行时数据 | `/var/jb/var/mobile/Library/WCTheme/`（`avatar.png`、`bg-light.png`、`bg-dark.png`、`icons/tabN.png`、`disable` 开关文件） |

安装：Filza 打开 deb → 安装，或 Sileo 本地包安装；首次装完 respring 再开微信。

## 7. 日志与应急开关

日志：`WCLogLine` 统一输出，tag 是 `boot/core/dock/group/nav/bg/glass/badge`，高频行都有「签名变化才打印」降频。

```bash
# 设备端
log stream --predicate 'subsystem == "com.wctheme.dev"'
# Windows
idevicesyslog | Select-String "WCTheme"
```

应急开关（按严重程度从轻到重）：

| 开关 | 位置 | 作用 |
| --- | --- | --- |
| 模块开关 | 设置 → WCTheme → 模块开关 | 逐个关掉 dock / group / badge / layout / glass，只留 core |
| 安全启动 `safeBoot` | 同上第一组 | 只加载 core + 日志，所有模块不启动；**排障首选** |
| 外部 kill switch | 设备上新建空文件 `/var/jb/var/mobile/Library/WCTheme/disable` | 无论偏好如何，进程内直接不加载任何 hook；删文件即恢复 |
| 运行时熔断 | 自动 | dock apply 异常累计 3 次 → `gDockDisabled=YES`，还原原生底栏并停止重试 |
| 底栏临时隐藏 | 头像菜单 →「关闭浮层」 | `dockEnabled=0`，再点头像或设置里可恢复 |

## 8. 设置项总表（存储键都以 `wxgb.` 前缀写入 `com.wctheme.dev` 域）

> 代码里 `WCStorageKey()` 会自动补 `wxgb.` 前缀；系统设置面板写的是不带前缀的旧键，读取时有旧键回退，两种写法都能生效。

| 键 | 含义 | 默认 |
| --- | --- | --- |
| `wxgb.enabled` | 总开关 | 开 |
| `wxgb.safeBoot` | 安全启动（只加载 core） | 关 |
| `wxgb.entryButtonEnabled` | 微信内齿轮入口 | 开 |
| `wxgb.moduleGlass` | 模块：玻璃 / 搜索栏 | 关 |
| `wxgb.moduleDock` | 模块：底栏 dock | 关 |
| `wxgb.moduleGroup` | 模块：首页分组 | 关 |
| `wxgb.moduleBadge` | 模块：未读角标 | 关 |
| `wxgb.moduleLayout` | 模块：布局微调 / 卡片 / 标题 | 关 |
| `wxgb.groupEnabled` | 首页分组折叠面板 | 关 |
| `wxgb.groupSafeMode` | 分组安全模式（彻底停用） | 关 |
| `wxgb.groupHideFrame` | 隐藏分组面板背后灰框（1.8.3） | 开 |
| `wxgb.groupSpacingV` | 组间上下间距 | 12 |
| `wxgb.groupOffset` / `wxgb.groupSpacing` / `wxgb.groupCorner` / `wxgb.groupChipHex` | 面板偏移 / 组间距 / 圆角 / 胶囊色 | — |
| `wxgb.groupSubtitle` | 组头副标题 | 空 |
| `wxgb.groupNamePinned` / `…Friends` / `…Groups` / `…Service` / `…Official` / `…Other` | 六类组名自定义 | 空=默认 |
| `wxgb.customGroup1Name` / `customGroup1Keyword`（2、3 同） | 自定义分组组名 / 关键词 | 空 |
| `wxgb.groupHidePinned` / `…Friends` / `…Groups` / `…Service` / `…Official` / `…Other` | 隐藏对应组 | 关 |
| `wxgb.titleCardEnabled` | 自定义标题 | 开 |
| `wxgb.titleText` / `wxgb.titleSubtitle` | 标题 / 副标题文字 | 微信 / 空 |
| `wxgb.customLabelPlacement` | 标签位置（0 关 / 1 左上 / 2 右上 / 3 底部左侧） | 0 |
| `wxgb.bigTitleEnabled` | 大标题 | — |
| `wxgb.dockEnabled` | 底栏浮岛 | 关 |
| `wxgb.dockStyle` | 底栏样式 `floating` / `bar`（1.8.5） | `floating` |
| `wxgb.dockHeight` | 浮岛高度 | 60 |
| `wxgb.dockWidth` / `wxgb.dockWidthMode` / `wxgb.dockFixedWidth` | 宽度 / 自适应或固定 / 固定值 | 0 / 0 / 300 |
| `wxgb.dockOffsetX` / `wxgb.dockOffsetY` | 浮岛位置偏移 | 12 / 10 |
| `wxgb.dockInset` | 浮岛左右内缩 | 12 |
| `wxgb.dockShowTitle` | 图标下显示文字 | 关（`bar` 样式强制显示） |
| `wxgb.dockSearchEnabled` / `wxgb.dockSearchPlacement` | 搜索胶囊开关 / 位置 | — / `above` |
| `wxgb.dockLiquidIntensity` | 液态玻璃强度 0–100 | 60 |
| `wxgb.dockPlusEnabled` | 底栏加号入口 | 关 |
| `wxgb.liteMode` | 轻量版（只保留单层模糊） | 关 |
| `wxgb.cardEnabled` / `wxgb.cardCornerRadius` / `wxgb.cardInset` / `wxgb.performanceFirst` | 液态卡片 / 圆角 / 内缩 / 关阴影 | 关 / 14 / 12 / 关 |
| `wxgb.glassEnabled` / `wxgb.glassStyle` / `wxgb.glassIntensity` | 毛玻璃 / 材质档位 / tint 强度 | 开 / 0 / 0.08 |
| `wxgb.legacyGlassEnabled` | 旧版全局换色 fallback | 关 |
| `wxgb.adBlockEnabled` / `wxgb.discoveryEnabled` | 去广告 / 运行时类名发现 | 关 |
| `wxgb.layoutEnabled` / `wxgb.cellCornerRadius` / `wxgb.cellInset` | 布局微调 / cell 圆角 / 内缩 | 关 |
| `wxgb.navBarAlpha` / `wxgb.tabBarAlpha` / `wxgb.statusBarStyle` | 导航栏 / 标签栏透明度 / 状态栏样式 | — |
| `wxgb.badgeColorEnabled` / `wxgb.badgePreset` / `wxgb.badgeHex` | 角标改色 / 预设 / 自定义色 | 关 |
| `wxgb.searchMode` / `wxgb.searchCardHTML` / `wxgb.searchCardHeight` / `wxgb.searchFloatBottom` | 搜索模式 / 卡片 HTML / 高度 / 浮动底距 | — |

## 9. 模块实现边界

**已实现（UIKit 通用层 / 真机验证过的微信锚点）**：底栏浮岛与图标取图、分组折叠面板与置顶分类、头像菜单 9 项动作、全局壁纸与透明顶栏、未读角标、微信内设置面板与齿轮入口。

**需要真机补**：微信各版本的自绘广告类名（默认注册表为空，不编造类名）；扫一扫 / 收付款在部分版本只能落到「入口点击」或 URL scheme；面板 tint 在深色壁纸下的观感。

## 10. 安全设计

- 所有 Logos hook 内部 `@try/@catch`；点击回调同样包异常，失败只提示。
- dock 异常累计 3 次自动熔断并还原原生底栏，绝不进入高频重试循环。
- 去广告注册表：`objc_getClass` → `class_respondsToSelector` → `class_getInstanceMethod/class_getClassMethod` → 参数个数 → 返回值编码，任何一步失败只日志跳过。
- 偏好读取：CFPreferences 失败再读 plist；所有 getter 有默认值。
- 代码内没有任何网络请求、上传或设备标识收集。

## 11. 版本

- 当前：**1.8.5**
- Deployment target：iOS 15.0（`TARGET = iphone:clang:latest:15.0`）
- 架构：`arm64`（单一 arm64 切片，避免 arm64e 签名/加载引入额外变量）
- 包格式：rootless（`/var/jb`，`iphoneos-arm64`）
- 变更历史：见 `docs/CHANGELOG.md`
