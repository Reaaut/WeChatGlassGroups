#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <os/log.h>
#import <unistd.h>

#import "WCPrefs.h"
#import "WCLog.h"
#import "WCGlass.h"
#import "WCAdBlock.h"
#import "WCDiscovery.h"
#import "WCAnchors.h"
#import "WCSurfaceGlass.h"
#import "WCSettingsEntry.h"
#import "WCGroup.h"
#import "WCWallpaper.h"
#import "WCDock.h"
#import "WCBadge.h"

/// 外部 kill switch：文件存在就完全跳过初始化（不注册 hook、不写日志）。
/// 路径与日志目录一致，日志能写就说明这里可写。
static BOOL WCThemeKillSwitchActive(void) {
    NSArray<NSString *> *paths = @[
        [WCLogDirectory() stringByAppendingPathComponent:@"disable"],
        @"/var/jb/var/mobile/Library/WCTheme/disable",
        @"/var/mobile/Library/WCTheme/disable",
    ];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *path in paths) {
        if ([fm fileExistsAtPath:path]) return YES;
    }
    return NO;
}

/// 启动自检：每个 stage 记录耗时，卡住时日志能指出停在哪个阶段。
static double gStageStart = 0.0;

static void WCStageBegin(void) {
    gStageStart = CFAbsoluteTimeGetCurrent();
}

static void WCStageEnd(NSString *name) {
    double ms = (CFAbsoluteTimeGetCurrent() - gStageStart) * 1000.0;
    WCLogLine(@"info", @"boot", @"stage=%@ ms=%.1f", name, ms);
}

static void WCThemePrefsChangedCallback(CFNotificationCenterRef center,
                                        void *observer,
                                        CFNotificationName name,
                                        const void *object,
                                        CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        WCLogLine(@"info", @"core", @"收到偏好变更通知，重新加载");
        [WCPrefs reload];
        WCPrefs *prefs = [WCPrefs shared];
        WCLogLine(@"info", @"boot", @"modules glass=%d dock=%d group=%d badge=%d layout=%d",
                  prefs.moduleGlass, prefs.moduleDock, prefs.moduleGroup,
                  prefs.moduleBadge, prefs.moduleLayout);
        // 1.7.5：壁纸独立于模块开关，偏好变化后立即重刷（深浅 / 清除都不用重启）。
        WCWallpaperRefresh();
        // 1.5.1：模块总闸不在运行时热切换，避免半开半关留下残留。
        // 只刷新已启用模块的显示参数。
        if (prefs.moduleGlass) {
            WCSurfaceGlassRefresh();
            WCGlassRefresh();
        }
        if (prefs.moduleLayout) WCSurfaceGlassRefresh();
        if (prefs.moduleGroup) WCGroupRefresh();
        if (prefs.moduleDock) WCDockRefresh();
        if (prefs.moduleBadge) WCBadgeRefresh();
    });
}

%ctor {
    // 第一优先级：kill switch。命中时像 tweak 没被加载一样退出。
    if (WCThemeKillSwitchActive()) return;

    @autoreleasepool {
        WCLogBoot(@"1.8.5");

        [WCPrefs reload];
        WCPrefs *prefs = [WCPrefs shared];
        WCLogLine(@"info", @"core", @"prefs enabled=%d safeBoot=%d glass=%d card=%d legacy=%d group=%d safe=%d dock=%d plus=%d searchFloat=%d lite=%d badge=%d title=%d",
                  prefs.enabled, prefs.safeBoot, prefs.glassEnabled, prefs.cardEnabled,
                  prefs.legacyGlassEnabled, prefs.groupEnabled, prefs.groupSafeMode,
                  prefs.dockEnabled, prefs.dockPlusEnabled, prefs.searchFloatBottom,
                  prefs.liteMode, prefs.badgeColorEnabled, prefs.bigTitleEnabled);
        WCLogLine(@"info", @"boot", @"modules glass=%d dock=%d group=%d badge=%d layout=%d",
                  prefs.moduleGlass, prefs.moduleDock, prefs.moduleGroup,
                  prefs.moduleBadge, prefs.moduleLayout);

        if (!prefs.enabled || prefs.safeBoot) {
            WCLogLine(@"info", @"boot", @"安全启动：只保留 core + 日志，跳过全部模块");
            WCLogLine(@"info", @"core", @"init done (safe)");
            return;
        }

        // 只有表面类模块才需要微信宿主类锚点；全关时一个 hook 都不装。
        BOOL anySurface = prefs.moduleGlass || prefs.moduleDock || prefs.moduleGroup;
        if (anySurface) {
            WCStageBegin();
            WCAnchorLogAll();
            WCAnchorInstallAll();
            WCStageEnd(@"anchors");
        } else {
            WCLogLine(@"info", @"boot", @"跳过 anchors（glass/dock/group 全关）");
        }

        if (prefs.adBlockEnabled) {
            WCStageBegin();
            WCAdBlockInstallAll();
            WCStageEnd(@"adblock");
        }
        if (prefs.discoveryEnabled) {
            WCStageBegin();
            WCDiscoveryStart();
            WCStageEnd(@"discovery");
        }

        if (prefs.moduleGlass) {
            WCStageBegin();
            WCGlassStart();
            WCSurfaceGlassStart();
            WCStageEnd(@"glass");
        }

        WCStageBegin();
        WCSettingsEntryStart();
        WCStageEnd(@"entry");

        if (prefs.moduleGroup) {
            WCStageBegin();
            WCGroupStart();
            WCStageEnd(@"group");
        }
        if (prefs.moduleDock) {
            WCStageBegin();
            WCDockStart();
            WCStageEnd(@"dock");
        }

        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                       NULL,
                                       WCThemePrefsChangedCallback,
                                       (__bridge CFStringRef)WCThemePrefsChangedNotification,
                                       NULL,
                                       CFNotificationSuspensionBehaviorDeliverImmediately);

        if (prefs.moduleGlass) {
            WCGlassRefresh();
            WCSurfaceGlassRefresh();
        }
        if (prefs.moduleGroup) WCGroupRefresh();
        if (prefs.moduleDock) WCDockRefresh();
        if (prefs.moduleBadge) WCBadgeRefresh();

        WCLogLine(@"info", @"core", @"init done");
        // 1.7.5：壁纸在主 VC 出现时也会自动挂；这里先登记一次，覆盖已存在的首页。
        WCWallpaperRefresh();
    }
}