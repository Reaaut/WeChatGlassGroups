#import <UIKit/UIKit.h>
#import "WCGlass.h"

// 毛玻璃：全部基于 UIKit 通用层，不猜微信私有类名。
//
// 1) UIView 的 setBackgroundColor: 是本模块的“主 hook 点”：
//    绝大多数界面背景最终都走这里。接近纯白的背景会被换成半透明白，
//    露出窗口第 0 层的 UIVisualEffectView。
// 2) UIWindow 的 makeKeyAndVisible / didMoveToWindow 负责把 blur 挂到窗口底层；
//    另有 UIWindowDidBecomeKey/Visible 通知兜底（见 WCGlass.mm）。
// 任何一步失败都只影响视觉效果，不影响微信启动。

%hook UIView

- (void)setBackgroundColor:(UIColor *)color {
    UIColor *finalColor = color;
    @try {
        UIColor *adjusted = WCGlassAdjustedColor(self, color);
        if (adjusted) {
            finalColor = adjusted;
        }
    } @catch (NSException *exception) {
        finalColor = color;
    }

    @try {
        %orig(finalColor);
    } @catch (NSException *exception) {
        // 背景色设置失败时不再重试，避免死循环。
    }
}

%end

%hook UIWindow

- (void)makeKeyAndVisible {
    %orig;
    @try {
        WCGlassAttachToWindow(self);
    } @catch (NSException *exception) {
    }
}

- (void)didMoveToWindow {
    %orig;
    @try {
        WCGlassAttachToWindow(self);
    } @catch (NSException *exception) {
    }
}

%end
