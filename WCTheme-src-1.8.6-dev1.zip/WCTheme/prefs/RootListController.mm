#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>

#import "WCPrefs.h"
#import "WCLog.h"

@interface RootListController : PSListController
- (void)wc_showAlertWithTitle:(NSString *)title message:(NSString *)message;
@end

#pragma mark - 诊断页

/// 只读诊断页：展示加载时间、模块开关、hook 探测结果和最近日志。
/// 日志本身由 tweak 进程写盘（/var/jb/var/mobile/Library/WCTheme/wctheme.log），
/// 这里只读取，不做任何上传。
@interface WCThemeDiagnosticsController : UIViewController
@property (nonatomic, copy) NSString *diagnosticText;
@end

@implementation WCThemeDiagnosticsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"诊断";

    UITextView *textView = [[UITextView alloc] initWithFrame:self.view.bounds];
    textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    textView.editable = NO;
    textView.alwaysBounceVertical = YES;
    textView.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    textView.text = self.diagnosticText ?: @"";
    [self.view addSubview:textView];

    self.navigationItem.rightBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:@"复制日志"
                                         style:UIBarButtonItemStylePlain
                                        target:self
                                        action:@selector(wc_copyLog)];
}

- (void)wc_copyLog {
    [UIPasteboard generalPasteboard].string = self.diagnosticText ?: @"";
    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:@"已复制"
                                             message:@"诊断内容已复制到剪贴板。"
                                      preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end

#pragma mark - WCTheme

@implementation RootListController

- (id)specifiers {
    if (_specifiers == nil) {
        _specifiers = [self loadSpecifiersFromPlistName:@"RootListController" target:self];
    }
    return _specifiers;
}

#pragma mark - 读写偏好

- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (!key) {
        return [super readPreferenceValue:specifier];
    }

    id value = (__bridge_transfer id)CFPreferencesCopyAppValue(
        (__bridge CFStringRef)WCStorageKey(key),
        (__bridge CFStringRef)WCThemeDomain);
    if (!value) {
        // 兼容 1.7.2 旧键。
        value = (__bridge_transfer id)CFPreferencesCopyAppValue(
            (__bridge CFStringRef)key,
            (__bridge CFStringRef)WCThemeDomain);
    }
    if (value) return value;

    id defaultValue = [specifier propertyForKey:@"defaults"];
    return defaultValue ?: @0;
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (!key) {
        [super setPreferenceValue:value specifier:specifier];
        return;
    }

    CFPreferencesSetAppValue((__bridge CFStringRef)WCStorageKey(key),
                             (__bridge CFPropertyListRef)value,
                             (__bridge CFStringRef)WCThemeDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)WCThemeDomain);

    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                        (__bridge CFNotificationName)WCThemePrefsChangedNotification,
                                        NULL, NULL, true);
}

#pragma mark - 按钮

- (void)dumpHierarchy {
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                        (__bridge CFNotificationName)WCThemeDumpHierarchyNotification,
                                        NULL, NULL, true);

    [self wc_showAlertWithTitle:@"已发送抓取请求"
                         message:@"请保持微信在前台。1~2 秒后，用 Console.app（过滤 WCTheme）或 idevicesyslog 查看 [WCTheme][Discovery] 输出。"];
}

- (void)applyNow {
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                        (__bridge CFNotificationName)WCThemePrefsChangedNotification,
                                        NULL, NULL, true);

    [self wc_showAlertWithTitle:@"已通知微信进程"
                         message:@"材质 / 分组 / 浮岛会在下一个 runloop 重挂，不用重启微信。底栏仍未出现时，切到「通讯录」再切回「微信」。"];
}

- (void)reloadPrefs {
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                        (__bridge CFNotificationName)WCThemePrefsChangedNotification,
                                        NULL, NULL, true);

    [self wc_showAlertWithTitle:@"已通知微信进程"
                         message:@"毛玻璃会立即刷新；布局类改动如果没生效，请从后台彻底划掉微信再重新打开。"];
}

- (void)resetDefaults {
    WCPrefsResetToDefaults();
    [self reloadSpecifiers];
    [self wc_showAlertWithTitle:@"已恢复默认值"
                         message:@"建议彻底划掉微信后重新打开，确保所有模块按默认配置生效。"];
}

/// 1.6.2：删除自定义头像，浮岛/菜单回到中性占位。
- (void)resetAvatar {
    NSString *base = @"/var/jb/var/mobile/Library/WCTheme";
    if (![[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"]) {
        base = @"/var/mobile/Library/WCTheme";
    }
    NSString *path = [base stringByAppendingPathComponent:@"avatar.png"];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL existed = [fm fileExistsAtPath:path];
    if (existed) {
        [fm removeItemAtPath:path error:NULL];
    }
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                        (__bridge CFNotificationName)WCThemePrefsChangedNotification,
                                        NULL, NULL, true);
    [self wc_showAlertWithTitle:existed ? @"已恢复默认头像" : @"当前就是默认头像"
                         message:path];
}

- (void)showDiagnostics {
    WCThemeDiagnosticsController *vc = [[WCThemeDiagnosticsController alloc] init];
    vc.diagnosticText = [self wc_buildDiagnosticText];

    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [self presentViewController:nav animated:YES completion:nil];
}

/// 汇总：加载状态 -> 注入环境 -> 模块开关 -> hook 探测 -> 最近 200 行日志。
- (NSString *)wc_buildDiagnosticText {
    NSMutableArray<NSString *> *out = [NSMutableArray array];
    NSFileManager *fm = [NSFileManager defaultManager];

    NSString *path = WCLogFilePath();
    BOOL logExists = [fm fileExistsAtPath:path];
    NSArray<NSString *> *log = WCLogTail(200);

    [out addObject:@"WCTheme 诊断"];
    [out addObject:[NSString stringWithFormat:@"日志文件：%@", path]];
    [out addObject:[NSString stringWithFormat:@"日志文件存在：%@", logExists ? @"是" : @"否"]];
    [out addObject:@""];
    [out addObject:@"【关键判读】"];
    if (!logExists) {
        [out addObject:@"日志文件不存在 => WCTheme.dylib 从未被 dyld 加载。"];
        [out addObject:@"这不是开关或效果参数的问题：请先确认注入环境（ellekit / 依赖 / 签名）。"];
    } else {
        [out addObject:@"日志文件存在 => dylib 至少被加载过一次；下面看最后一次加载与 hook 结果。"];
    }
    [out addObject:@""];

    // 版本 / 加载时间：取最后一条 [boot] 记录。
    NSString *lastBoot = nil;
    NSString *version = @"未知";
    for (NSString *line in log) {
        if ([line rangeOfString:@"[boot ]"].location == NSNotFound) continue;
        lastBoot = line;
        NSRange v = [line rangeOfString:@"loaded v"];
        if (v.location != NSNotFound) {
            NSUInteger start = v.location + v.length;
            NSRange end = [line rangeOfString:@" pid=" options:0 range:NSMakeRange(start, line.length - start)];
            NSUInteger stop = (end.location != NSNotFound) ? end.location : line.length;
            version = [line substringWithRange:NSMakeRange(start, stop - start)];
        }
    }
    [out addObject:[NSString stringWithFormat:@"版本：%@", version]];
    [out addObject:[NSString stringWithFormat:@"最近一次加载：%@", lastBoot ?: @"无 [boot] 记录（可能日志被截断）"]];

    // 注入环境：ellekit / CydiaSubstrate 文件是否存在。
    NSString *root = [fm fileExistsAtPath:@"/var/jb"] ? @"/var/jb" : @"";
    NSString *ellekit = [root stringByAppendingString:@"/usr/lib/libellekit.dylib"];
    NSString *substrate = [root stringByAppendingString:@"/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate"];
    [out addObject:[NSString stringWithFormat:@"ellekit：%@（%@）",
                    [fm fileExistsAtPath:ellekit] ? @"存在" : @"缺失", ellekit]];
    [out addObject:[NSString stringWithFormat:@"CydiaSubstrate：%@（%@）",
                    [fm fileExistsAtPath:substrate] ? @"存在" : @"缺失", substrate]];
    [out addObject:@""];

    WCPrefs *prefs = [WCPrefs shared];
    [out addObject:@"【模块开关】"];
    [out addObject:[NSString stringWithFormat:@"总开关：%@", prefs.enabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"毛玻璃：%@", prefs.glassEnabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"液态卡片：%@", prefs.cardEnabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"性能优先：%@", prefs.performanceFirst ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"旧版全局换色：%@", prefs.legacyGlassEnabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"微信内入口：%@", prefs.entryButtonEnabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"布局微调：%@", prefs.layoutEnabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"去广告：%@", prefs.adBlockEnabled ? @"开" : @"关"]];
    [out addObject:[NSString stringWithFormat:@"类名发现：%@", prefs.discoveryEnabled ? @"开" : @"关"]];
    [out addObject:@""];

    // hook 探测：最近 30 条 [hook] 记录。
    [out addObject:@"【hook 探测（最近 30 条）】"];
    NSMutableArray<NSString *> *hooks = [NSMutableArray array];
    for (NSString *line in log) {
        if ([line rangeOfString:@"[hook ]"].location != NSNotFound) {
            [hooks addObject:line];
        }
    }
    if (hooks.count == 0) {
        [out addObject:@"无记录（dylib 未加载，或钩子初始化前就失败）"];
    } else {
        NSUInteger from = hooks.count > 30 ? hooks.count - 30 : 0;
        [out addObjectsFromArray:[hooks subarrayWithRange:NSMakeRange(from, hooks.count - from)]];
    }
    [out addObject:@""];

    [out addObject:@"【最近 200 行日志】"];
    if (log.count == 0) {
        [out addObject:@"（空）"];
    } else {
        [out addObjectsFromArray:log];
    }

    return [out componentsJoinedByString:@"\n"];
}

#pragma mark - 辅助

- (void)wc_showAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好"
                                              style:UIAlertActionStyleDefault
                                            handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
